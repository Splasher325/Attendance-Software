/*    */ package com.sun.java.accessibility;
/*    */ 
/*    */ import java.security.AccessController;
/*    */ import java.security.Permission;
/*    */ import java.security.PrivilegedAction;
/*    */ import jdk.Exported;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Exported(false)
/*    */ abstract class AccessBridgeLoader
/*    */ {
/*    */   static
/*    */   {
/* 35 */     AccessController.doPrivileged(new PrivilegedAction()
/*    */     {
/*    */       public Object run() {
/* 38 */         System.loadLibrary("JavaAccessBridge-32");
/* 39 */         return null; } }, null, new Permission[] { new RuntimePermission("loadLibrary.JavaAccessBridge-32") });
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 45 */   boolean useJAWT_DLL = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   AccessBridgeLoader()
/*    */   {
/* 53 */     String str = System.getProperty("java.version");
/* 54 */     if (str != null) {
/* 55 */       this.useJAWT_DLL = (str.compareTo("1.4.1") >= 0);
/*    */     }
/* 57 */     if (this.useJAWT_DLL)
/*    */     {
/* 59 */       AccessController.doPrivileged(new PrivilegedAction()
/*    */       {
/*    */         public Object run() {
/* 62 */           System.loadLibrary("JAWT");
/* 63 */           System.loadLibrary("JAWTAccessBridge-32");
/* 64 */           return null; } }, null, new Permission[] { new RuntimePermission("loadLibrary.JAWT"), new RuntimePermission("loadLibrary.JAWTAccessBridge-32") });
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\access-bridge-32.jar!\com\sun\java\accessibility\AccessBridgeLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */