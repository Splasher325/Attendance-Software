/*      */ package com.sun.java.accessibility;
/*      */ 
/*      */ import com.sun.java.accessibility.util.SwingEventMonitor;
/*      */ import com.sun.java.accessibility.util.Translator;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.EventQueue;
/*      */ import java.awt.Font;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.FocusEvent;
/*      */ import java.awt.event.FocusListener;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.WindowEvent;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Vector;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import javax.accessibility.Accessible;
/*      */ import javax.accessibility.AccessibleAction;
/*      */ import javax.accessibility.AccessibleComponent;
/*      */ import javax.accessibility.AccessibleContext;
/*      */ import javax.accessibility.AccessibleEditableText;
/*      */ import javax.accessibility.AccessibleHyperlink;
/*      */ import javax.accessibility.AccessibleHypertext;
/*      */ import javax.accessibility.AccessibleIcon;
/*      */ import javax.accessibility.AccessibleRelation;
/*      */ import javax.accessibility.AccessibleRelationSet;
/*      */ import javax.accessibility.AccessibleRole;
/*      */ import javax.accessibility.AccessibleSelection;
/*      */ import javax.accessibility.AccessibleState;
/*      */ import javax.accessibility.AccessibleStateSet;
/*      */ import javax.accessibility.AccessibleTable;
/*      */ import javax.accessibility.AccessibleText;
/*      */ import javax.accessibility.AccessibleValue;
/*      */ import javax.swing.JTable;
/*      */ import javax.swing.JTree;
/*      */ import javax.swing.KeyStroke;
/*      */ import javax.swing.event.CaretEvent;
/*      */ import javax.swing.event.MenuEvent;
/*      */ import javax.swing.event.PopupMenuEvent;
/*      */ import javax.swing.text.AttributeSet;
/*      */ import javax.swing.text.JTextComponent;
/*      */ import javax.swing.text.StyleConstants;
/*      */ import javax.swing.tree.TreeModel;
/*      */ import javax.swing.tree.TreePath;
/*      */ import sun.awt.AppContext;
/*      */ import sun.awt.SunToolkit;
/*      */ 
/*      */ @jdk.Exported(false)
/*      */ public final class AccessBridge extends AccessBridgeLoader
/*      */ {
/*   59 */   private final String AccessBridgeVersion = "AccessBridge 2.0.4";
/*      */   
/*      */   private static AccessBridge theAccessBridge;
/*      */   
/*      */   private ObjectReferences references;
/*      */   private EventHandler eventHandler;
/*   65 */   private boolean runningOnJDK1_4 = false;
/*   66 */   private boolean runningOnJDK1_5 = false;
/*      */   
/*      */ 
/*   69 */   private ConcurrentHashMap<String, AccessibleRole> accessibleRoleMap = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   75 */   private ArrayList<AccessibleRole> extendedVirtualNameSearchRoles = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   82 */   private ArrayList<AccessibleRole> noExtendedVirtualNameSearchParentRoles = new ArrayList();
/*      */   
/*      */   private Method javaGetComponentFromNativeWindowHandleMethod;
/*      */   
/*      */   private Method javaGetNativeWindowHandleFromComponentMethod;
/*      */   
/*      */   java.awt.Toolkit toolkit;
/*      */   
/*      */   public AccessBridge()
/*      */   {
/*   92 */     theAccessBridge = this;
/*   93 */     this.references = new ObjectReferences();
/*      */     
/*      */ 
/*   96 */     Runtime localRuntime = Runtime.getRuntime();
/*   97 */     shutdownHook localshutdownHook = new shutdownHook(null);
/*   98 */     localRuntime.addShutdownHook(new Thread(localshutdownHook));
/*      */     
/*      */ 
/*  101 */     initAccessibleRoleMap();
/*      */     
/*      */ 
/*  104 */     String str = getJavaVersionProperty();
/*  105 */     debugString("JDK version = " + str);
/*  106 */     this.runningOnJDK1_4 = (str.compareTo("1.4") >= 0);
/*  107 */     this.runningOnJDK1_5 = (str.compareTo("1.5") >= 0);
/*      */     
/*      */ 
/*      */ 
/*  111 */     if (initHWNDcalls() == true)
/*      */     {
/*      */ 
/*      */ 
/*  115 */       com.sun.java.accessibility.util.EventQueueMonitor.isGUIInitialized();
/*      */       
/*      */ 
/*  118 */       this.eventHandler = new EventHandler(this);
/*      */       
/*      */ 
/*  121 */       if (this.runningOnJDK1_4) {
/*  122 */         javax.swing.MenuSelectionManager.defaultManager().addChangeListener(this.eventHandler);
/*      */       }
/*      */       
/*      */ 
/*  126 */       addNativeWindowHandler(new DefaultNativeWindowHandler(null));
/*      */       
/*      */ 
/*  129 */       Thread localThread = new Thread(new dllRunner(null));
/*  130 */       localThread.setDaemon(true);
/*  131 */       localThread.start();
/*  132 */       debugString("AccessBridge started");
/*      */     }
/*      */   }
/*      */   
/*      */   private class dllRunner implements Runnable
/*      */   {
/*      */     private dllRunner() {}
/*      */     
/*      */     public void run() {
/*  141 */       AccessBridge.this.runDLL();
/*      */     }
/*      */   }
/*      */   
/*      */   private class shutdownHook implements Runnable
/*      */   {
/*      */     private shutdownHook() {}
/*      */     
/*      */     public void run()
/*      */     {
/*  151 */       AccessBridge.this.debugString("***** shutdownHook: shutting down...");
/*  152 */       AccessBridge.this.javaShutdown();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initAccessibleRoleMap()
/*      */   {
/*      */     try
/*      */     {
/*  166 */       Class localClass = Class.forName("javax.accessibility.AccessibleRole");
/*  167 */       if (null != localClass) {
/*  168 */         AccessibleRole localAccessibleRole1 = AccessibleRole.UNKNOWN;
/*  169 */         java.lang.reflect.Field[] arrayOfField = localClass.getFields();
/*  170 */         int i = 0;
/*  171 */         for (i = 0; i < arrayOfField.length; i++) {
/*  172 */           java.lang.reflect.Field localField = arrayOfField[i];
/*  173 */           if (AccessibleRole.class == localField.getType()) {
/*  174 */             AccessibleRole localAccessibleRole2 = (AccessibleRole)localField.get(localAccessibleRole1);
/*  175 */             String str = localAccessibleRole2.toDisplayString(Locale.US);
/*  176 */             this.accessibleRoleMap.put(str, localAccessibleRole2);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception localException) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  187 */     this.extendedVirtualNameSearchRoles.add(AccessibleRole.COMBO_BOX);
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  192 */       this.extendedVirtualNameSearchRoles.add(AccessibleRole.DATE_EDITOR);
/*      */     } catch (NoSuchFieldError localNoSuchFieldError1) {}
/*  194 */     this.extendedVirtualNameSearchRoles.add(AccessibleRole.LIST);
/*  195 */     this.extendedVirtualNameSearchRoles.add(AccessibleRole.PASSWORD_TEXT);
/*  196 */     this.extendedVirtualNameSearchRoles.add(AccessibleRole.SLIDER);
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  201 */       this.extendedVirtualNameSearchRoles.add(AccessibleRole.SPIN_BOX);
/*      */     } catch (NoSuchFieldError localNoSuchFieldError2) {}
/*  203 */     this.extendedVirtualNameSearchRoles.add(AccessibleRole.TABLE);
/*  204 */     this.extendedVirtualNameSearchRoles.add(AccessibleRole.TEXT);
/*  205 */     this.extendedVirtualNameSearchRoles.add(AccessibleRole.UNKNOWN);
/*      */     
/*  207 */     this.noExtendedVirtualNameSearchParentRoles.add(AccessibleRole.TABLE);
/*  208 */     this.noExtendedVirtualNameSearchParentRoles.add(AccessibleRole.TOOL_BAR);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private native void runDLL();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private native void sendDebugString(String paramString);
/*      */   
/*      */ 
/*      */ 
/*      */   private void debugString(String paramString)
/*      */   {
/*  225 */     sendDebugString(paramString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void decrementReference(Object paramObject)
/*      */   {
/*  234 */     this.references.decrement(paramObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getJavaVersionProperty()
/*      */   {
/*  241 */     String str = System.getProperty("java.version");
/*  242 */     if (str != null) {
/*  243 */       this.references.increment(str);
/*  244 */       return str;
/*      */     }
/*  246 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getAccessBridgeVersion()
/*      */   {
/*  253 */     String str = new String("AccessBridge 2.0.4");
/*  254 */     this.references.increment(str);
/*  255 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private native int isJAWTInstalled();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private native int jawtGetNativeWindowHandleFromComponent(Component paramComponent);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private native Component jawtGetComponentFromNativeWindowHandle(int paramInt);
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean initHWNDcalls()
/*      */   {
/*  277 */     Class[] arrayOfClass1 = new Class[1];
/*  278 */     arrayOfClass1[0] = Integer.TYPE;
/*  279 */     Class[] arrayOfClass2 = new Class[1];
/*      */     try {
/*  281 */       arrayOfClass2[0] = Class.forName("java.awt.Component");
/*      */     } catch (ClassNotFoundException localClassNotFoundException) {
/*  283 */       debugString("Exception: " + localClassNotFoundException.toString());
/*      */     }
/*  285 */     Object[] arrayOfObject = new Object[1];
/*      */     
/*  287 */     boolean bool = false;
/*      */     
/*  289 */     this.toolkit = java.awt.Toolkit.getDefaultToolkit();
/*      */     
/*  291 */     if (this.useJAWT_DLL) {
/*  292 */       bool = true;
/*      */     }
/*      */     else
/*      */     {
/*      */       try
/*      */       {
/*  298 */         this.javaGetComponentFromNativeWindowHandleMethod = this.toolkit.getClass().getMethod("getComponentFromNativeWindowHandle", arrayOfClass1);
/*      */         
/*  300 */         if (this.javaGetComponentFromNativeWindowHandleMethod != null) {
/*      */           try {
/*  302 */             arrayOfObject[0] = new Integer(1);
/*  303 */             Component localComponent = (Component)this.javaGetComponentFromNativeWindowHandleMethod.invoke(this.toolkit, arrayOfObject);
/*  304 */             bool = true;
/*      */           } catch (InvocationTargetException localInvocationTargetException1) {
/*  306 */             debugString("Exception: " + localInvocationTargetException1.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException1) {
/*  308 */             debugString("Exception: " + localIllegalAccessException1.toString());
/*      */           }
/*      */         }
/*      */       } catch (NoSuchMethodException localNoSuchMethodException1) {
/*  312 */         debugString("Exception: " + localNoSuchMethodException1.toString());
/*      */       } catch (SecurityException localSecurityException1) {
/*  314 */         debugString("Exception: " + localSecurityException1.toString());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/*  321 */         this.javaGetNativeWindowHandleFromComponentMethod = this.toolkit.getClass().getMethod("getNativeWindowHandleFromComponent", arrayOfClass2);
/*      */         
/*  323 */         if (this.javaGetNativeWindowHandleFromComponentMethod != null) {
/*      */           try {
/*  325 */             arrayOfObject[0] = new java.awt.Button("OK");
/*  326 */             Integer localInteger = (Integer)this.javaGetNativeWindowHandleFromComponentMethod.invoke(this.toolkit, arrayOfObject);
/*  327 */             bool = true;
/*      */           } catch (InvocationTargetException localInvocationTargetException2) {
/*  329 */             debugString("Exception: " + localInvocationTargetException2.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException2) {
/*  331 */             debugString("Exception: " + localIllegalAccessException2.toString());
/*      */           } catch (Exception localException) {
/*  333 */             debugString("Exception: " + localException.toString());
/*      */           }
/*      */         }
/*      */       } catch (NoSuchMethodException localNoSuchMethodException2) {
/*  337 */         debugString("Exception: " + localNoSuchMethodException2.toString());
/*      */       } catch (SecurityException localSecurityException2) {
/*  339 */         debugString("Exception: " + localSecurityException2.toString());
/*      */       }
/*      */     }
/*  342 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  351 */   private static ConcurrentHashMap<Integer, AccessibleContext> windowHandleToContextMap = new ConcurrentHashMap();
/*      */   
/*      */ 
/*  354 */   private static ConcurrentHashMap<AccessibleContext, Integer> contextToWindowHandleMap = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void registerVirtualFrame(Accessible paramAccessible, Integer paramInteger)
/*      */   {
/*  361 */     if (paramAccessible != null) {
/*  362 */       AccessibleContext localAccessibleContext = (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */ 
/*  365 */         public AccessibleContext call() throws Exception { return this.val$a.getAccessibleContext(); } }, paramAccessible);
/*      */       
/*      */ 
/*  368 */       windowHandleToContextMap.put(paramInteger, localAccessibleContext);
/*  369 */       contextToWindowHandleMap.put(localAccessibleContext, paramInteger);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void revokeVirtualFrame(Accessible paramAccessible, Integer paramInteger)
/*      */   {
/*  378 */     AccessibleContext localAccessibleContext = (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */ 
/*  381 */       public AccessibleContext call() throws Exception { return this.val$a.getAccessibleContext(); } }, paramAccessible);
/*      */     
/*      */ 
/*  384 */     windowHandleToContextMap.remove(paramInteger);
/*  385 */     contextToWindowHandleMap.remove(localAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*  389 */   private static Vector<NativeWindowHandler> nativeWindowHandlers = new Vector();
/*      */   
/*      */ 
/*      */ 
/*      */   private static void addNativeWindowHandler(NativeWindowHandler paramNativeWindowHandler)
/*      */   {
/*  395 */     if (paramNativeWindowHandler == null) {
/*  396 */       throw new IllegalArgumentException();
/*      */     }
/*  398 */     nativeWindowHandlers.addElement(paramNativeWindowHandler);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static boolean removeNativeWindowHandler(NativeWindowHandler paramNativeWindowHandler)
/*      */   {
/*  405 */     if (paramNativeWindowHandler == null) {
/*  406 */       throw new IllegalArgumentException();
/*      */     }
/*  408 */     return nativeWindowHandlers.removeElement(paramNativeWindowHandler);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean isJavaWindow(int paramInt)
/*      */   {
/*  415 */     AccessibleContext localAccessibleContext = getContextFromNativeWindowHandle(paramInt);
/*  416 */     if (localAccessibleContext != null) {
/*  417 */       saveContextToWindowHandleMapping(localAccessibleContext, paramInt);
/*  418 */       return true;
/*      */     }
/*  420 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void saveContextToWindowHandleMapping(AccessibleContext paramAccessibleContext, int paramInt)
/*      */   {
/*  428 */     debugString("saveContextToWindowHandleMapping...");
/*  429 */     if (paramAccessibleContext == null) {
/*  430 */       return;
/*      */     }
/*  432 */     if (!contextToWindowHandleMap.containsKey(paramAccessibleContext)) {
/*  433 */       debugString("saveContextToWindowHandleMapping: ac = " + paramAccessibleContext + "; handle = " + paramInt);
/*  434 */       contextToWindowHandleMap.put(paramAccessibleContext, Integer.valueOf(paramInt));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getContextFromNativeWindowHandle(int paramInt)
/*      */   {
/*  444 */     AccessibleContext localAccessibleContext = (AccessibleContext)windowHandleToContextMap.get(Integer.valueOf(paramInt));
/*  445 */     if (localAccessibleContext != null) {
/*  446 */       saveContextToWindowHandleMapping(localAccessibleContext, paramInt);
/*  447 */       return localAccessibleContext;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  452 */     int i = nativeWindowHandlers.size();
/*  453 */     for (int j = 0; j < i; j++) {
/*  454 */       NativeWindowHandler localNativeWindowHandler = (NativeWindowHandler)nativeWindowHandlers.elementAt(j);
/*  455 */       final Accessible localAccessible = localNativeWindowHandler.getAccessibleFromNativeWindowHandle(paramInt);
/*  456 */       if (localAccessible != null) {
/*  457 */         localAccessibleContext = (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */ 
/*  460 */           public AccessibleContext call() throws Exception { return localAccessible.getAccessibleContext(); } }, localAccessible);
/*      */         
/*      */ 
/*  463 */         saveContextToWindowHandleMapping(localAccessibleContext, paramInt);
/*  464 */         return localAccessibleContext;
/*      */       }
/*      */     }
/*      */     
/*  468 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getNativeWindowHandleFromContext(AccessibleContext paramAccessibleContext)
/*      */   {
/*  476 */     debugString("getNativeWindowHandleFromContext: ac = " + paramAccessibleContext);
/*      */     try {
/*  478 */       return ((Integer)contextToWindowHandleMap.get(paramAccessibleContext)).intValue();
/*      */     } catch (Exception localException) {}
/*  480 */     return 0;
/*      */   }
/*      */   
/*      */   private static abstract interface NativeWindowHandler {
/*      */     public abstract Accessible getAccessibleFromNativeWindowHandle(int paramInt);
/*      */   }
/*      */   
/*      */   private class DefaultNativeWindowHandler implements AccessBridge.NativeWindowHandler { private DefaultNativeWindowHandler() {}
/*      */     
/*  489 */     public Accessible getAccessibleFromNativeWindowHandle(int paramInt) { final Component localComponent = getComponentFromNativeWindowHandle(paramInt);
/*  490 */       if ((localComponent instanceof Accessible)) {
/*  491 */         AccessibleContext localAccessibleContext = (AccessibleContext)AccessBridge.InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */ 
/*  494 */           public AccessibleContext call() throws Exception { return localComponent.getAccessibleContext(); } }, localComponent);
/*      */         
/*      */ 
/*  497 */         AccessBridge.this.saveContextToWindowHandleMapping(localAccessibleContext, paramInt);
/*  498 */         return (Accessible)localComponent;
/*      */       }
/*  500 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private Component getComponentFromNativeWindowHandle(int paramInt)
/*      */     {
/*  508 */       if (AccessBridge.this.useJAWT_DLL) {
/*  509 */         AccessBridge.this.debugString("*** calling jawtGetComponentFromNativeWindowHandle");
/*  510 */         return AccessBridge.this.jawtGetComponentFromNativeWindowHandle(paramInt);
/*      */       }
/*  512 */       AccessBridge.this.debugString("*** calling javaGetComponentFromNativeWindowHandle");
/*  513 */       Object[] arrayOfObject = new Object[1];
/*  514 */       if (AccessBridge.this.javaGetComponentFromNativeWindowHandleMethod != null) {
/*      */         try {
/*  516 */           arrayOfObject[0] = Integer.valueOf(paramInt);
/*  517 */           Object localObject = AccessBridge.this.javaGetComponentFromNativeWindowHandleMethod.invoke(AccessBridge.this.toolkit, arrayOfObject);
/*  518 */           if ((localObject instanceof Accessible)) {
/*  519 */             final Accessible localAccessible = (Accessible)localObject;
/*  520 */             AccessibleContext localAccessibleContext = (AccessibleContext)AccessBridge.InvocationUtils.invokeAndWait(new Callable()
/*      */             {
/*      */ 
/*  523 */               public AccessibleContext call() throws Exception { return localAccessible.getAccessibleContext(); } }, (Component)localObject);
/*      */             
/*      */ 
/*  526 */             AccessBridge.this.saveContextToWindowHandleMapping(localAccessibleContext, paramInt);
/*      */           }
/*  528 */           return (Component)localObject;
/*      */         } catch (InvocationTargetException|IllegalAccessException localInvocationTargetException) {
/*  530 */           AccessBridge.this.debugString("Exception: " + localInvocationTargetException.toString());
/*      */         }
/*      */       }
/*      */       
/*  534 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getNativeWindowHandleFromComponent(final Component paramComponent)
/*      */   {
/*  542 */     if (this.useJAWT_DLL) {
/*  543 */       debugString("*** calling jawtGetNativeWindowHandleFromComponent");
/*  544 */       return jawtGetNativeWindowHandleFromComponent(paramComponent);
/*      */     }
/*  546 */     Object[] arrayOfObject = new Object[1];
/*  547 */     debugString("*** calling javaGetNativeWindowHandleFromComponent");
/*  548 */     if (this.javaGetNativeWindowHandleFromComponentMethod != null) {
/*      */       try {
/*  550 */         arrayOfObject[0] = paramComponent;
/*  551 */         Integer localInteger = (Integer)this.javaGetNativeWindowHandleFromComponentMethod.invoke(this.toolkit, arrayOfObject);
/*      */         
/*  553 */         AccessibleContext localAccessibleContext = (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */ 
/*  556 */           public AccessibleContext call() throws Exception { return paramComponent.getAccessibleContext(); } }, paramComponent);
/*      */         
/*      */ 
/*  559 */         contextToWindowHandleMap.put(localAccessibleContext, localInteger);
/*  560 */         return localInteger.intValue();
/*      */       } catch (InvocationTargetException localInvocationTargetException) {
/*  562 */         debugString("Exception: " + localInvocationTargetException.toString());
/*      */       } catch (IllegalAccessException localIllegalAccessException) {
/*  564 */         debugString("Exception: " + localIllegalAccessException.toString());
/*      */       }
/*      */     }
/*      */     
/*  568 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getAccessibleContextAt(int paramInt1, int paramInt2, AccessibleContext paramAccessibleContext)
/*      */   {
/*  578 */     if (paramAccessibleContext == null) {
/*  579 */       return null;
/*      */     }
/*  581 */     if ((windowHandleToContextMap != null) && 
/*  582 */       (windowHandleToContextMap.containsValue(getRootAccessibleContext(paramAccessibleContext))))
/*      */     {
/*      */ 
/*  585 */       return getAccessibleContextAt_1(paramInt1, paramInt2, paramAccessibleContext);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  590 */     return getAccessibleContextAt_2(paramInt1, paramInt2, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getRootAccessibleContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/*  598 */     if (paramAccessibleContext == null) {
/*  599 */       return null;
/*      */     }
/*  601 */     (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AccessibleContext call() throws Exception {
/*  604 */         Object localObject = paramAccessibleContext.getAccessibleParent();
/*  605 */         if (localObject == null) {
/*  606 */           return paramAccessibleContext;
/*      */         }
/*  608 */         Accessible localAccessible = ((Accessible)localObject).getAccessibleContext().getAccessibleParent();
/*  609 */         while (localAccessible != null) {
/*  610 */           localObject = localAccessible;
/*  611 */           localAccessible = ((Accessible)localObject).getAccessibleContext().getAccessibleParent();
/*      */         }
/*  613 */         return ((Accessible)localObject).getAccessibleContext(); } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getAccessibleContextAt_1(final int paramInt1, final int paramInt2, final AccessibleContext paramAccessibleContext)
/*      */   {
/*  623 */     debugString(" : getAccessibleContextAt_1 called");
/*  624 */     debugString("   -> x = " + paramInt1 + " y = " + paramInt2 + " parent = " + paramAccessibleContext);
/*      */     
/*  626 */     if (paramAccessibleContext == null) return null;
/*  627 */     final AccessibleComponent localAccessibleComponent = (AccessibleComponent)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */ 
/*  630 */       public AccessibleComponent call() throws Exception { return paramAccessibleContext.getAccessibleComponent(); } }, paramAccessibleContext);
/*      */     
/*      */ 
/*  633 */     if (localAccessibleComponent != null) {
/*  634 */       final Point localPoint = (Point)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */ 
/*  637 */         public Point call() throws Exception { return localAccessibleComponent.getLocation(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/*  640 */       final Accessible localAccessible = (Accessible)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */ 
/*  643 */         public Accessible call() throws Exception { return localAccessibleComponent.getAccessibleAt(new Point(paramInt1 - localPoint.x, paramInt2 - localPoint.y)); } }, paramAccessibleContext);
/*      */       
/*      */ 
/*  646 */       if (localAccessible != null) {
/*  647 */         AccessibleContext localAccessibleContext = (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */ 
/*  650 */           public AccessibleContext call() throws Exception { return localAccessible.getAccessibleContext(); } }, paramAccessibleContext);
/*      */         
/*      */ 
/*  653 */         if (localAccessibleContext != null) {
/*  654 */           if (localAccessibleContext != paramAccessibleContext)
/*      */           {
/*  656 */             return getAccessibleContextAt_1(paramInt1 - localPoint.x, paramInt2 - localPoint.y, localAccessibleContext);
/*      */           }
/*      */           
/*  659 */           return localAccessibleContext;
/*      */         }
/*      */       }
/*      */     }
/*  663 */     return paramAccessibleContext;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getAccessibleContextAt_2(final int paramInt1, final int paramInt2, AccessibleContext paramAccessibleContext)
/*      */   {
/*  671 */     debugString("getAccessibleContextAt_2 called");
/*  672 */     debugString("   -> x = " + paramInt1 + " y = " + paramInt2 + " parent = " + paramAccessibleContext);
/*      */     
/*  674 */     (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AccessibleContext call() throws Exception {
/*  677 */         Accessible localAccessible = com.sun.java.accessibility.util.EventQueueMonitor.getAccessibleAt(new Point(paramInt1, paramInt2));
/*  678 */         if (localAccessible != null) {
/*  679 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/*  680 */           if (localAccessibleContext != null) {
/*  681 */             AccessBridge.this.debugString("   returning childAC = " + localAccessibleContext);
/*  682 */             return localAccessibleContext;
/*      */           }
/*      */         }
/*  685 */         return null; } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getAccessibleContextWithFocus()
/*      */   {
/*  694 */     Component localComponent = com.sun.java.accessibility.util.AWTEventMonitor.getComponentWithFocus();
/*  695 */     if (localComponent != null) {
/*  696 */       final Accessible localAccessible = Translator.getAccessible(localComponent);
/*  697 */       if (localAccessible != null) {
/*  698 */         AccessibleContext localAccessibleContext = (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */ 
/*  701 */           public AccessibleContext call() throws Exception { return localAccessible.getAccessibleContext(); } }, localComponent);
/*      */         
/*      */ 
/*  704 */         if (localAccessibleContext != null) {
/*  705 */           return localAccessibleContext;
/*      */         }
/*      */       }
/*      */     }
/*  709 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getAccessibleNameFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/*  716 */     debugString("***** ac = " + paramAccessibleContext.getClass());
/*  717 */     if (paramAccessibleContext != null) {
/*  718 */       String str = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */ 
/*  721 */         public String call() throws Exception { return paramAccessibleContext.getAccessibleName(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/*  724 */       if (str != null) {
/*  725 */         this.references.increment(str);
/*  726 */         debugString("Returning AccessibleName from Context: " + str);
/*  727 */         return str;
/*      */       }
/*  729 */       return null;
/*      */     }
/*      */     
/*  732 */     debugString("getAccessibleNameFromContext; ac = null!");
/*  733 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getVirtualAccessibleNameFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/*  743 */     if (null != paramAccessibleContext)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  750 */       String str1 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */ 
/*  753 */         public String call() throws Exception { return paramAccessibleContext.getAccessibleName(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/*  756 */       if ((null != str1) && (0 != str1.length())) {
/*  757 */         debugString("bk -- The Virtual Accessible Name was obtained from AccessibleContext::getAccessibleName.");
/*  758 */         this.references.increment(str1);
/*  759 */         return str1;
/*      */       }
/*  761 */       String str2 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */ 
/*  764 */         public String call() throws Exception { return paramAccessibleContext.getAccessibleDescription(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/*  767 */       if ((null != str2) && (0 != str2.length())) {
/*  768 */         debugString("bk -- The Virtual Accessible Name was obtained from AccessibleContext::getAccessibleDescription.");
/*  769 */         this.references.increment(str2);
/*  770 */         return str2;
/*      */       }
/*      */       
/*  773 */       debugString("The Virtual Accessible Name was not found using AccessibleContext::getAccessibleDescription. or getAccessibleName");
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  780 */       int i = 0;
/*  781 */       AccessibleRole localAccessibleRole1 = (AccessibleRole)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */ 
/*  784 */         public AccessibleRole call() throws Exception { return paramAccessibleContext.getAccessibleRole(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/*  787 */       AccessibleContext localAccessibleContext1 = null;
/*  788 */       AccessibleRole localAccessibleRole2 = AccessibleRole.UNKNOWN;
/*      */       
/*  790 */       if (this.extendedVirtualNameSearchRoles.contains(localAccessibleRole1)) {
/*  791 */         localAccessibleContext1 = getAccessibleParentFromContext(paramAccessibleContext);
/*  792 */         if (null != localAccessibleContext1) {
/*  793 */           localObject1 = localAccessibleContext1;
/*  794 */           localAccessibleRole2 = (AccessibleRole)InvocationUtils.invokeAndWait(new Callable()
/*      */           {
/*      */ 
/*  797 */             public AccessibleRole call() throws Exception { return localObject1.getAccessibleRole(); } }, paramAccessibleContext);
/*      */           
/*      */ 
/*  800 */           if (AccessibleRole.UNKNOWN != localAccessibleRole2) {
/*  801 */             i = 1;
/*  802 */             if (this.noExtendedVirtualNameSearchParentRoles.contains(localAccessibleRole2)) {
/*  803 */               i = 0;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       final Object localObject5;
/*  809 */       if (0 == i) {
/*  810 */         debugString("bk -- getVirtualAccessibleNameFromContext will not use the extended name search algorithm.  role = " + localAccessibleRole1.toDisplayString(Locale.US));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  824 */         if (AccessibleRole.LABEL == localAccessibleRole1)
/*      */         {
/*      */ 
/*      */ 
/*  828 */           localObject1 = (AccessibleText)InvocationUtils.invokeAndWait(new Callable()
/*      */           {
/*      */ 
/*  831 */             public AccessibleText call() throws Exception { return paramAccessibleContext.getAccessibleText(); } }, paramAccessibleContext);
/*      */           
/*      */ 
/*  834 */           if (null != localObject1) {
/*  835 */             int j = ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */             {
/*      */ 
/*  838 */               public Integer call() throws Exception { return Integer.valueOf(localObject1.getCharCount()); } }, paramAccessibleContext)).intValue();
/*      */             
/*      */ 
/*  841 */             localObject3 = getAccessibleTextRangeFromContext(paramAccessibleContext, 0, j);
/*  842 */             if (null != localObject3) {
/*  843 */               debugString("bk -- The Virtual Accessible Name was obtained from the Accessible Text of the LABEL object.");
/*  844 */               this.references.increment(localObject3);
/*  845 */               return (String)localObject3;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  851 */           debugString("bk -- Attempting to obtain the Virtual Accessible Name from the Accessible Icon information.");
/*  852 */           localObject2 = (AccessibleIcon[])InvocationUtils.invokeAndWait(new Callable()
/*      */           {
/*      */ 
/*  855 */             public AccessibleIcon[] call() throws Exception { return paramAccessibleContext.getAccessibleIcon(); } }, paramAccessibleContext);
/*      */           
/*      */ 
/*  858 */           if ((null != localObject2) && (localObject2.length > 0)) {
/*  859 */             localObject3 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */             {
/*      */ 
/*  862 */               public String call() throws Exception { return localObject2[0].getAccessibleIconDescription(); } }, paramAccessibleContext);
/*      */             
/*      */ 
/*  865 */             if (localObject3 != null) {
/*  866 */               debugString("bk -- The Virtual Accessible Name was obtained from the description of the first Accessible Icon found in the LABEL object.");
/*  867 */               this.references.increment(localObject3);
/*  868 */               return (String)localObject3;
/*      */             }
/*      */           } else {
/*  871 */             localAccessibleContext1 = getAccessibleParentFromContext(paramAccessibleContext);
/*  872 */             if (null != localAccessibleContext1) {
/*  873 */               localObject3 = localAccessibleContext1;
/*  874 */               localAccessibleRole2 = (AccessibleRole)InvocationUtils.invokeAndWait(new Callable()
/*      */               {
/*      */ 
/*  877 */                 public AccessibleRole call() throws Exception { return localObject3.getAccessibleRole(); } }, paramAccessibleContext);
/*      */               
/*      */ 
/*  880 */               if (AccessibleRole.TABLE == localAccessibleRole2) {
/*  881 */                 k = ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */                 {
/*      */ 
/*  884 */                   public Integer call() throws Exception { return Integer.valueOf(paramAccessibleContext.getAccessibleIndexInParent()); } }, paramAccessibleContext)).intValue();
/*      */                 
/*      */ 
/*  887 */                 localAccessibleContext2 = getAccessibleChildFromContext(localAccessibleContext1, k);
/*  888 */                 debugString("bk -- Making a second attempt to obtain the Virtual Accessible Name from the Accessible Icon information for the Table Cell.");
/*  889 */                 if (localAccessibleContext2 != null) {
/*  890 */                   localObject4 = (AccessibleIcon[])InvocationUtils.invokeAndWait(new Callable()
/*      */                   {
/*      */ 
/*  893 */                     public AccessibleIcon[] call() throws Exception { return localAccessibleContext2.getAccessibleIcon(); } }, paramAccessibleContext);
/*      */                   
/*      */ 
/*  896 */                   if ((null != localObject4) && (localObject4.length > 0)) {
/*  897 */                     localObject5 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */                     {
/*  899 */                       public String call() { return localObject4[0].getAccessibleIconDescription(); } }, paramAccessibleContext);
/*      */                     
/*      */ 
/*  902 */                     if (localObject5 != null) {
/*  903 */                       debugString("bk -- The Virtual Accessible Name was obtained from the description of the first Accessible Icon found in the Table Cell object.");
/*  904 */                       this.references.increment(localObject5);
/*  905 */                       return (String)localObject5;
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*  912 */         } else if ((AccessibleRole.TOGGLE_BUTTON == localAccessibleRole1) || (AccessibleRole.PUSH_BUTTON == localAccessibleRole1))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  917 */           debugString("bk -- Attempting to obtain the Virtual Accessible Name from the Accessible Icon information.");
/*  918 */           localObject1 = (AccessibleIcon[])InvocationUtils.invokeAndWait(new Callable()
/*      */           {
/*  920 */             public AccessibleIcon[] call() { return paramAccessibleContext.getAccessibleIcon(); } }, paramAccessibleContext);
/*      */           
/*      */ 
/*  923 */           if ((null != localObject1) && (localObject1.length > 0)) {
/*  924 */             localObject2 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */             {
/*  926 */               public String call() { return localObject1[0].getAccessibleIconDescription(); } }, paramAccessibleContext);
/*      */             
/*      */ 
/*  929 */             if (localObject2 != null) {
/*  930 */               debugString("bk -- The Virtual Accessible Name was obtained from the description of the first Accessible Icon found in the TOGGLE_BUTTON or PUSH_BUTTON object.");
/*  931 */               this.references.increment(localObject2);
/*  932 */               return (String)localObject2;
/*      */             }
/*      */           }
/*  935 */         } else if (AccessibleRole.CHECK_BOX == localAccessibleRole1)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  951 */           localObject1 = (AccessibleValue)InvocationUtils.invokeAndWait(new Callable()
/*      */           {
/*      */ 
/*  954 */             public AccessibleValue call() throws Exception { return paramAccessibleContext.getAccessibleValue(); } }, paramAccessibleContext);
/*      */           
/*      */ 
/*  957 */           if (null != localObject1) {
/*  958 */             str1 = null;
/*  959 */             localObject2 = (Number)InvocationUtils.invokeAndWait(new Callable()
/*      */             {
/*      */ 
/*  962 */               public Number call() throws Exception { return localObject1.getCurrentAccessibleValue(); } }, paramAccessibleContext);
/*      */             
/*      */ 
/*  965 */             if (null != localObject2) {
/*  966 */               if (1 == ((Number)localObject2).intValue()) {
/*  967 */                 str1 = Boolean.TRUE.toString();
/*  968 */               } else if (0 == ((Number)localObject2).intValue()) {
/*  969 */                 str1 = Boolean.FALSE.toString();
/*      */               } else {
/*  971 */                 str1 = localObject2.toString();
/*      */               }
/*  973 */               if (null != str1) {
/*  974 */                 this.references.increment(str1);
/*  975 */                 return str1;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*  980 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  988 */       final Object localObject1 = localAccessibleContext1;
/*  989 */       final Object localObject2 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */ 
/*  992 */         public String call() throws Exception { return localObject1.getAccessibleName(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/*  995 */       final Object localObject3 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */ 
/*  998 */         public String call() throws Exception { return localObject1.getAccessibleDescription(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1007 */       if ((AccessibleRole.SLIDER == localAccessibleRole1) && (AccessibleRole.PANEL == localAccessibleRole2) && (null != localObject2))
/*      */       {
/*      */ 
/* 1010 */         debugString("bk -- The Virtual Accessible Name was obtained from the Accessible Name of the SLIDER object's parent object.");
/* 1011 */         this.references.increment(localObject2);
/* 1012 */         return (String)localObject2;
/*      */       }
/*      */       
/* 1015 */       int k = 0;
/*      */       
/* 1017 */       final AccessibleContext localAccessibleContext2 = paramAccessibleContext;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1023 */       if ((AccessibleRole.TEXT == localAccessibleRole1) && (AccessibleRole.COMBO_BOX == localAccessibleRole2))
/*      */       {
/* 1025 */         k = 1;
/* 1026 */         if (null != localObject2) {
/* 1027 */           debugString("bk -- The Virtual Accessible Name for this Edit Combo box was obtained from the Accessible Name of the object's parent object.");
/* 1028 */           this.references.increment(localObject2);
/* 1029 */           return (String)localObject2; }
/* 1030 */         if (null != localObject3) {
/* 1031 */           debugString("bk -- The Virtual Accessible Name for this Edit Combo box was obtained from the Accessible Description of the object's parent object.");
/* 1032 */           this.references.increment(localObject3);
/* 1033 */           return (String)localObject3;
/*      */         }
/* 1035 */         localAccessibleContext2 = localAccessibleContext1;
/* 1036 */         localAccessibleRole2 = AccessibleRole.UNKNOWN;
/* 1037 */         localAccessibleContext1 = getAccessibleParentFromContext(localAccessibleContext2);
/* 1038 */         if (null != localAccessibleContext1) {
/* 1039 */           localObject4 = localAccessibleContext1;
/* 1040 */           localAccessibleRole2 = (AccessibleRole)InvocationUtils.invokeAndWait(new Callable()
/*      */           {
/*      */ 
/* 1043 */             public AccessibleRole call() throws Exception { return localObject4.getAccessibleRole(); } }, paramAccessibleContext);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1055 */       final Object localObject4 = getJavaVersionProperty();
/* 1056 */       if ((null != localObject4) && (((String)localObject4).compareTo("1.3") >= 0)) {
/* 1057 */         localObject5 = localAccessibleContext1;
/* 1058 */         AccessibleRelationSet localAccessibleRelationSet = (AccessibleRelationSet)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */ 
/* 1061 */           public AccessibleRelationSet call() throws Exception { return localObject5.getAccessibleRelationSet(); } }, paramAccessibleContext);
/*      */         
/*      */ 
/* 1064 */         if ((localAccessibleRelationSet != null) && (localAccessibleRelationSet.size() > 0) && (localAccessibleRelationSet.contains(AccessibleRelation.LABELED_BY))) {
/* 1065 */           AccessibleRelation localAccessibleRelation = localAccessibleRelationSet.get(AccessibleRelation.LABELED_BY);
/* 1066 */           if (localAccessibleRelation != null) {
/* 1067 */             Object[] arrayOfObject = localAccessibleRelation.getTarget();
/* 1068 */             Object localObject6 = arrayOfObject[0];
/* 1069 */             if ((localObject6 instanceof Accessible)) {
/* 1070 */               AccessibleContext localAccessibleContext3 = ((Accessible)localObject6).getAccessibleContext();
/* 1071 */               if (localAccessibleContext3 != null) {
/* 1072 */                 String str3 = localAccessibleContext3.getAccessibleName();
/* 1073 */                 localObject7 = localAccessibleContext3.getAccessibleDescription();
/* 1074 */                 if (null != str3) {
/* 1075 */                   debugString("bk -- The Virtual Accessible Name was obtained using the LABELED_BY AccessibleRelation -- Name Case.");
/* 1076 */                   this.references.increment(str3);
/* 1077 */                   return str3; }
/* 1078 */                 if (null != localObject7) {
/* 1079 */                   debugString("bk -- The Virtual Accessible Name was obtained using the LABELED_BY AccessibleRelation -- Description Case.");
/* 1080 */                   this.references.increment(localObject7);
/* 1081 */                   return (String)localObject7;
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       } else {
/* 1088 */         debugString("bk -- This version of Java does not support AccessibleContext::getAccessibleRelationSet.");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1099 */       int m = 0;
/* 1100 */       int n = 0;
/* 1101 */       int i1 = 0;
/* 1102 */       int i2 = 0;
/* 1103 */       int i3 = 0;
/* 1104 */       int i4 = 0;
/* 1105 */       int i5 = 0;
/* 1106 */       final Object localObject7 = localAccessibleContext2;
/* 1107 */       int i6 = ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */ 
/* 1110 */         public Integer call() throws Exception { return Integer.valueOf(localObject7.getAccessibleIndexInParent()); } }, paramAccessibleContext)).intValue();
/*      */       
/*      */ 
/* 1113 */       if (null != localAccessibleContext1) {
/* 1114 */         final AccessibleContext localAccessibleContext4 = localAccessibleContext1;
/* 1115 */         m = ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */ 
/* 1118 */           public Integer call() throws Exception { return Integer.valueOf(localAccessibleContext4.getAccessibleChildrenCount() - 1); } }, paramAccessibleContext)).intValue();
/*      */       }
/*      */       
/*      */ 
/* 1122 */       n = getAccessibleXcoordFromContext(localAccessibleContext2);
/* 1123 */       i1 = getAccessibleYcoordFromContext(localAccessibleContext2);
/* 1124 */       i2 = getAccessibleWidthFromContext(localAccessibleContext2);
/* 1125 */       i3 = getAccessibleHeightFromContext(localAccessibleContext2);
/* 1126 */       i4 = n + 2;
/* 1127 */       i5 = i1 + 2;
/*      */       
/* 1129 */       int i7 = i6 - 1;
/*      */       
/*      */ 
/*      */ 
/* 1133 */       int i8 = 0;
/* 1134 */       int i9 = 0;
/* 1135 */       int i10 = 0;
/* 1136 */       int i11 = 0;
/* 1137 */       String str4 = null;
/* 1138 */       String str5 = null;
/* 1139 */       final int i12; final AccessibleContext localAccessibleContext5; final Accessible localAccessible; final AccessibleContext localAccessibleContext6; AccessibleRole localAccessibleRole3; while (i7 >= 0) {
/* 1140 */         i12 = i7;
/* 1141 */         localAccessibleContext5 = localAccessibleContext1;
/* 1142 */         localAccessible = (Accessible)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */ 
/* 1145 */           public Accessible call() throws Exception { return localAccessibleContext5.getAccessibleChild(i12); } }, paramAccessibleContext);
/*      */         
/*      */ 
/* 1148 */         if (null != localAccessible) {
/* 1149 */           localAccessibleContext6 = (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */           {
/*      */ 
/* 1152 */             public AccessibleContext call() throws Exception { return localAccessible.getAccessibleContext(); } }, paramAccessibleContext);
/*      */           
/*      */ 
/* 1155 */           if (null != localAccessibleContext6) {
/* 1156 */             localAccessibleRole3 = (AccessibleRole)InvocationUtils.invokeAndWait(new Callable()
/*      */             {
/*      */ 
/* 1159 */               public AccessibleRole call() throws Exception { return localAccessibleContext6.getAccessibleRole(); } }, paramAccessibleContext);
/*      */             
/*      */ 
/* 1162 */             if (AccessibleRole.LABEL == localAccessibleRole3) {
/* 1163 */               i8 = getAccessibleXcoordFromContext(localAccessibleContext6);
/* 1164 */               i9 = getAccessibleYcoordFromContext(localAccessibleContext6);
/* 1165 */               i10 = getAccessibleWidthFromContext(localAccessibleContext6);
/* 1166 */               i11 = getAccessibleHeightFromContext(localAccessibleContext6);
/* 1167 */               if ((i8 < n) && (i9 <= i5) && (i5 <= i9 + i11))
/*      */               {
/* 1169 */                 str4 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */                 {
/* 1171 */                   public String call() { return localAccessibleContext6.getAccessibleName(); } }, paramAccessibleContext);
/*      */                 
/*      */ 
/* 1174 */                 if (null != str4) {
/* 1175 */                   debugString("bk -- The Virtual Accessible Name was obtained from Accessible Name of a LABEL object positioned to the left of the object.");
/* 1176 */                   this.references.increment(str4);
/* 1177 */                   return str4;
/*      */                 }
/* 1179 */                 str5 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */                 {
/* 1181 */                   public String call() { return localAccessibleContext6.getAccessibleDescription(); } }, paramAccessibleContext);
/*      */                 
/*      */ 
/* 1184 */                 if (null != str5) {
/* 1185 */                   debugString("bk -- The Virtual Accessible Name was obtained from Accessible Description of a LABEL object positioned to the left of the object.");
/* 1186 */                   this.references.increment(str5);
/* 1187 */                   return str5;
/*      */                 }
/* 1189 */               } else if ((i9 < i5) && (i8 <= i4) && (i4 <= i8 + i10))
/*      */               {
/* 1191 */                 str4 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */                 {
/* 1193 */                   public String call() { return localAccessibleContext6.getAccessibleName(); } }, paramAccessibleContext);
/*      */                 
/*      */ 
/* 1196 */                 if (null != str4) {
/* 1197 */                   debugString("bk -- The Virtual Accessible Name was obtained from Accessible Name of a LABEL object positioned above the object.");
/* 1198 */                   this.references.increment(str4);
/* 1199 */                   return str4;
/*      */                 }
/* 1201 */                 str5 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */                 {
/* 1203 */                   public String call() { return localAccessibleContext6.getAccessibleDescription(); } }, paramAccessibleContext);
/*      */                 
/*      */ 
/* 1206 */                 if (null != str5) {
/* 1207 */                   debugString("bk -- The Virtual Accessible Name was obtained from Accessible Description of a LABEL object positioned above the object.");
/* 1208 */                   this.references.increment(str5);
/* 1209 */                   return str5;
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/* 1215 */         i7--;
/*      */       }
/* 1217 */       i7 = i6 + 1;
/* 1218 */       while (i7 <= m) {
/* 1219 */         i12 = i7;
/* 1220 */         localAccessibleContext5 = localAccessibleContext1;
/* 1221 */         localAccessible = (Accessible)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */ 
/* 1224 */           public Accessible call() throws Exception { return localAccessibleContext5.getAccessibleChild(i12); } }, paramAccessibleContext);
/*      */         
/*      */ 
/* 1227 */         if (null != localAccessible) {
/* 1228 */           localAccessibleContext6 = (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */           {
/*      */ 
/* 1231 */             public AccessibleContext call() throws Exception { return localAccessible.getAccessibleContext(); } }, paramAccessibleContext);
/*      */           
/*      */ 
/* 1234 */           if (null != localAccessibleContext6) {
/* 1235 */             localAccessibleRole3 = (AccessibleRole)InvocationUtils.invokeAndWait(new Callable()
/*      */             {
/*      */ 
/* 1238 */               public AccessibleRole call() throws Exception { return localAccessibleContext6.getAccessibleRole(); } }, paramAccessibleContext);
/*      */             
/*      */ 
/* 1241 */             if (AccessibleRole.LABEL == localAccessibleRole3) {
/* 1242 */               i8 = getAccessibleXcoordFromContext(localAccessibleContext6);
/* 1243 */               i9 = getAccessibleYcoordFromContext(localAccessibleContext6);
/* 1244 */               i10 = getAccessibleWidthFromContext(localAccessibleContext6);
/* 1245 */               i11 = getAccessibleHeightFromContext(localAccessibleContext6);
/* 1246 */               if ((i8 < n) && (i9 <= i5) && (i5 <= i9 + i11))
/*      */               {
/* 1248 */                 str4 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */                 {
/* 1250 */                   public String call() { return localAccessibleContext6.getAccessibleName(); } }, paramAccessibleContext);
/*      */                 
/*      */ 
/* 1253 */                 if (null != str4) {
/* 1254 */                   debugString("bk -- The Virtual Accessible Name was obtained from Accessible Name of a LABEL object positioned to the left of the object.");
/* 1255 */                   this.references.increment(str4);
/* 1256 */                   return str4;
/*      */                 }
/* 1258 */                 str5 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */                 {
/* 1260 */                   public String call() { return localAccessibleContext6.getAccessibleDescription(); } }, paramAccessibleContext);
/*      */                 
/*      */ 
/* 1263 */                 if (null != str5) {
/* 1264 */                   debugString("bk -- The Virtual Accessible Name was obtained from Accessible Description of a LABEL object positioned to the left of the object.");
/* 1265 */                   this.references.increment(str5);
/* 1266 */                   return str5;
/*      */                 }
/* 1268 */               } else if ((i9 < i5) && (i8 <= i4) && (i4 <= i8 + i10))
/*      */               {
/* 1270 */                 str4 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */                 {
/* 1272 */                   public String call() { return localAccessibleContext6.getAccessibleName(); } }, paramAccessibleContext);
/*      */                 
/*      */ 
/* 1275 */                 if (null != str4) {
/* 1276 */                   debugString("bk -- The Virtual Accessible Name was obtained from Accessible Name of a LABEL object positioned above the object.");
/* 1277 */                   this.references.increment(str4);
/* 1278 */                   return str4;
/*      */                 }
/* 1280 */                 str5 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */                 {
/* 1282 */                   public String call() { return localAccessibleContext6.getAccessibleDescription(); } }, paramAccessibleContext);
/*      */                 
/*      */ 
/* 1285 */                 if (null != str5) {
/* 1286 */                   debugString("bk -- The Virtual Accessible Name was obtained from Accessible Description of a LABEL object positioned above the object.");
/* 1287 */                   this.references.increment(str5);
/* 1288 */                   return str5;
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/* 1294 */         i7++;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1306 */       if ((AccessibleRole.TEXT == localAccessibleRole1) || (AccessibleRole.COMBO_BOX == localAccessibleRole1) || (k != 0))
/*      */       {
/*      */ 
/* 1309 */         i7 = i6 - 1;
/* 1310 */         while (i7 >= 0) {
/* 1311 */           i12 = i7;
/* 1312 */           localAccessibleContext5 = localAccessibleContext1;
/* 1313 */           localAccessible = (Accessible)InvocationUtils.invokeAndWait(new Callable()
/*      */           {
/*      */ 
/* 1316 */             public Accessible call() throws Exception { return localAccessibleContext5.getAccessibleChild(i12); } }, paramAccessibleContext);
/*      */           
/*      */ 
/* 1319 */           if (null != localAccessible) {
/* 1320 */             localAccessibleContext6 = (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */             {
/*      */ 
/* 1323 */               public AccessibleContext call() throws Exception { return localAccessible.getAccessibleContext(); } }, paramAccessibleContext);
/*      */             
/*      */ 
/* 1326 */             if (null != localAccessibleContext6) {
/* 1327 */               localAccessibleRole3 = (AccessibleRole)InvocationUtils.invokeAndWait(new Callable()
/*      */               {
/*      */ 
/* 1330 */                 public AccessibleRole call() throws Exception { return localAccessibleContext6.getAccessibleRole(); } }, paramAccessibleContext);
/*      */               
/*      */ 
/* 1333 */               if ((AccessibleRole.PUSH_BUTTON == localAccessibleRole3) || (AccessibleRole.TOGGLE_BUTTON == localAccessibleRole3))
/*      */               {
/* 1335 */                 i8 = getAccessibleXcoordFromContext(localAccessibleContext6);
/* 1336 */                 i9 = getAccessibleYcoordFromContext(localAccessibleContext6);
/* 1337 */                 i10 = getAccessibleWidthFromContext(localAccessibleContext6);
/* 1338 */                 i11 = getAccessibleHeightFromContext(localAccessibleContext6);
/* 1339 */                 if ((i8 < n) && (i9 <= i5) && (i5 <= i9 + i11))
/*      */                 {
/* 1341 */                   str4 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */                   {
/* 1343 */                     public String call() { return localAccessibleContext6.getAccessibleName(); } }, paramAccessibleContext);
/*      */                   
/*      */ 
/* 1346 */                   if (null != str4) {
/* 1347 */                     debugString("bk -- The Virtual Accessible Name was obtained from Accessible Name of a PUSH_BUTTON or TOGGLE_BUTTON object positioned to the left of the object.");
/* 1348 */                     this.references.increment(str4);
/* 1349 */                     return str4;
/*      */                   }
/* 1351 */                   str5 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */                   {
/* 1353 */                     public String call() { return localAccessibleContext6.getAccessibleDescription(); } }, paramAccessibleContext);
/*      */                   
/*      */ 
/* 1356 */                   if (null != str5) {
/* 1357 */                     debugString("bk -- The Virtual Accessible Name was obtained from Accessible Description of a PUSH_BUTTON or TOGGLE_BUTTON object positioned to the left of the object.");
/* 1358 */                     this.references.increment(str5);
/* 1359 */                     return str5;
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/* 1365 */           i7--;
/*      */         }
/* 1367 */         i7 = i6 + 1;
/* 1368 */         while (i7 <= m) {
/* 1369 */           i12 = i7;
/* 1370 */           localAccessibleContext5 = localAccessibleContext1;
/* 1371 */           localAccessible = (Accessible)InvocationUtils.invokeAndWait(new Callable()
/*      */           {
/*      */ 
/* 1374 */             public Accessible call() throws Exception { return localAccessibleContext5.getAccessibleChild(i12); } }, paramAccessibleContext);
/*      */           
/*      */ 
/* 1377 */           if (null != localAccessible) {
/* 1378 */             localAccessibleContext6 = (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */             {
/*      */ 
/* 1381 */               public AccessibleContext call() throws Exception { return localAccessible.getAccessibleContext(); } }, paramAccessibleContext);
/*      */             
/*      */ 
/* 1384 */             if (null != localAccessibleContext6) {
/* 1385 */               localAccessibleRole3 = (AccessibleRole)InvocationUtils.invokeAndWait(new Callable()
/*      */               {
/*      */ 
/* 1388 */                 public AccessibleRole call() throws Exception { return localAccessibleContext6.getAccessibleRole(); } }, paramAccessibleContext);
/*      */               
/*      */ 
/* 1391 */               if ((AccessibleRole.PUSH_BUTTON == localAccessibleRole3) || (AccessibleRole.TOGGLE_BUTTON == localAccessibleRole3))
/*      */               {
/* 1393 */                 i8 = getAccessibleXcoordFromContext(localAccessibleContext6);
/* 1394 */                 i9 = getAccessibleYcoordFromContext(localAccessibleContext6);
/* 1395 */                 i10 = getAccessibleWidthFromContext(localAccessibleContext6);
/* 1396 */                 i11 = getAccessibleHeightFromContext(localAccessibleContext6);
/* 1397 */                 if ((i8 < n) && (i9 <= i5) && (i5 <= i9 + i11))
/*      */                 {
/* 1399 */                   str4 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */                   {
/* 1401 */                     public String call() { return localAccessibleContext6.getAccessibleName(); } }, paramAccessibleContext);
/*      */                   
/*      */ 
/* 1404 */                   if (null != str4) {
/* 1405 */                     debugString("bk -- The Virtual Accessible Name was obtained from Accessible Name of a PUSH_BUTTON or TOGGLE_BUTTON object positioned to the left of the object.");
/* 1406 */                     this.references.increment(str4);
/* 1407 */                     return str4;
/*      */                   }
/* 1409 */                   str5 = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */                   {
/* 1411 */                     public String call() { return localAccessibleContext6.getAccessibleDescription(); } }, paramAccessibleContext);
/*      */                   
/*      */ 
/* 1414 */                   if (null != str5) {
/* 1415 */                     debugString("bk -- The Virtual Accessible Name was obtained from Accessible Description of a PUSH_BUTTON or TOGGLE_BUTTON object positioned to the left of the object.");
/* 1416 */                     this.references.increment(str5);
/* 1417 */                     return str5;
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/* 1423 */           i7++;
/*      */         }
/*      */       }
/* 1426 */       return null;
/*      */     }
/* 1428 */     debugString("AccessBridge::getVirtualAccessibleNameFromContext error - ac == null.");
/* 1429 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getAccessibleDescriptionFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 1437 */     if (paramAccessibleContext != null) {
/* 1438 */       String str = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */ 
/* 1441 */         public String call() throws Exception { return paramAccessibleContext.getAccessibleDescription(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/* 1444 */       if (str != null) {
/* 1445 */         this.references.increment(str);
/* 1446 */         debugString("Returning AccessibleDescription from Context: " + str);
/* 1447 */         return str;
/*      */       }
/*      */     } else {
/* 1450 */       debugString("getAccessibleDescriptionFromContext; ac = null");
/*      */     }
/* 1452 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getAccessibleRoleStringFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 1459 */     if (paramAccessibleContext != null) {
/* 1460 */       AccessibleRole localAccessibleRole = (AccessibleRole)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */ 
/* 1463 */         public AccessibleRole call() throws Exception { return paramAccessibleContext.getAccessibleRole(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/* 1466 */       if (localAccessibleRole != null) {
/* 1467 */         String str = localAccessibleRole.toDisplayString(Locale.US);
/* 1468 */         if (str != null) {
/* 1469 */           this.references.increment(str);
/* 1470 */           debugString("Returning AccessibleRole from Context: " + str);
/* 1471 */           return str;
/*      */         }
/*      */       }
/*      */     } else {
/* 1475 */       debugString("getAccessibleRoleStringFromContext; ac = null");
/*      */     }
/* 1477 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getAccessibleRoleStringFromContext_en_US(AccessibleContext paramAccessibleContext)
/*      */   {
/* 1484 */     return getAccessibleRoleStringFromContext(paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getAccessibleStatesStringFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 1491 */     if (paramAccessibleContext != null) {
/* 1492 */       AccessibleStateSet localAccessibleStateSet = (AccessibleStateSet)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */ 
/* 1495 */         public AccessibleStateSet call() throws Exception { return paramAccessibleContext.getAccessibleStateSet(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/* 1498 */       if (localAccessibleStateSet != null) {
/* 1499 */         String str = localAccessibleStateSet.toString();
/* 1500 */         if ((str != null) && 
/* 1501 */           (str.indexOf(AccessibleState.MANAGES_DESCENDANTS.toDisplayString(Locale.US)) == -1))
/*      */         {
/*      */ 
/* 1504 */           AccessibleRole localAccessibleRole = paramAccessibleContext.getAccessibleRole();
/* 1505 */           if ((localAccessibleRole == AccessibleRole.LIST) || (localAccessibleRole == AccessibleRole.TABLE) || (localAccessibleRole == AccessibleRole.TREE))
/*      */           {
/*      */ 
/* 1508 */             str = str + ",";
/* 1509 */             str = str + AccessibleState.MANAGES_DESCENDANTS.toDisplayString(Locale.US);
/*      */           }
/* 1511 */           this.references.increment(str);
/* 1512 */           debugString("Returning AccessibleStateSet from Context: " + str);
/* 1513 */           return str;
/*      */         }
/*      */       }
/*      */     } else {
/* 1517 */       debugString("getAccessibleStatesStringFromContext; ac = null");
/*      */     }
/* 1519 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getAccessibleStatesStringFromContext_en_US(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 1526 */     if (paramAccessibleContext != null) {
/* 1527 */       AccessibleStateSet localAccessibleStateSet = (AccessibleStateSet)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */ 
/* 1530 */         public AccessibleStateSet call() throws Exception { return paramAccessibleContext.getAccessibleStateSet(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/* 1533 */       if (localAccessibleStateSet != null) {
/* 1534 */         String str = "";
/* 1535 */         AccessibleState[] arrayOfAccessibleState = localAccessibleStateSet.toArray();
/* 1536 */         if ((arrayOfAccessibleState != null) && (arrayOfAccessibleState.length > 0)) {
/* 1537 */           str = arrayOfAccessibleState[0].toDisplayString(Locale.US);
/* 1538 */           for (int i = 1; i < arrayOfAccessibleState.length; i++) {
/* 1539 */             str = str + "," + arrayOfAccessibleState[i].toDisplayString(Locale.US);
/*      */           }
/*      */         }
/* 1542 */         this.references.increment(str);
/* 1543 */         debugString("Returning AccessibleStateSet en_US from Context: " + str);
/* 1544 */         return str;
/*      */       }
/*      */     }
/* 1547 */     debugString("getAccessibleStatesStringFromContext; ac = null");
/* 1548 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private AccessibleContext getAccessibleParentFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 1555 */     if (paramAccessibleContext == null)
/* 1556 */       return null;
/* 1557 */     (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AccessibleContext call() throws Exception {
/* 1560 */         Accessible localAccessible = paramAccessibleContext.getAccessibleParent();
/* 1561 */         if (localAccessible != null) {
/* 1562 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 1563 */           if (localAccessibleContext != null) {
/* 1564 */             return localAccessibleContext;
/*      */           }
/*      */         }
/* 1567 */         return null; } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleIndexInParentFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 1576 */     if (paramAccessibleContext == null)
/* 1577 */       return -1;
/* 1578 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */ 
/* 1581 */       public Integer call() throws Exception { return Integer.valueOf(paramAccessibleContext.getAccessibleIndexInParent()); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleChildrenCountFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 1590 */     if (paramAccessibleContext == null)
/* 1591 */       return -1;
/* 1592 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */ 
/* 1595 */       public Integer call() throws Exception { return Integer.valueOf(paramAccessibleContext.getAccessibleChildrenCount()); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getAccessibleChildFromContext(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 1605 */     if (paramAccessibleContext == null) {
/* 1606 */       return null;
/*      */     }
/*      */     
/* 1609 */     final JTable localJTable = (JTable)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public JTable call()
/*      */         throws Exception
/*      */       {
/* 1614 */         Accessible localAccessible1 = paramAccessibleContext.getAccessibleParent();
/* 1615 */         if (localAccessible1 != null) {
/* 1616 */           int i = paramAccessibleContext.getAccessibleIndexInParent();
/*      */           
/* 1618 */           Accessible localAccessible2 = localAccessible1.getAccessibleContext().getAccessibleChild(i);
/* 1619 */           if ((localAccessible2 instanceof JTable)) {
/* 1620 */             return (JTable)localAccessible2;
/*      */           }
/*      */         }
/* 1623 */         return null; } }, paramAccessibleContext);
/*      */     
/*      */ 
/*      */ 
/* 1627 */     if (localJTable == null) {
/* 1628 */       (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public AccessibleContext call() throws Exception {
/* 1631 */           Accessible localAccessible = paramAccessibleContext.getAccessibleChild(paramInt);
/* 1632 */           if (localAccessible != null) {
/* 1633 */             return localAccessible.getAccessibleContext();
/*      */           }
/* 1635 */           return null; } }, paramAccessibleContext);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1640 */     AccessibleTable localAccessibleTable = getAccessibleTableFromContext(paramAccessibleContext);
/*      */     
/* 1642 */     final int i = getAccessibleTableRow(localAccessibleTable, paramInt);
/* 1643 */     final int j = getAccessibleTableColumn(localAccessibleTable, paramInt);
/*      */     
/* 1645 */     (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AccessibleContext call() throws Exception {
/* 1648 */         javax.swing.table.TableCellRenderer localTableCellRenderer = localJTable.getCellRenderer(i, j);
/* 1649 */         if (localTableCellRenderer == null) {
/* 1650 */           localObject = localJTable.getColumnClass(j);
/* 1651 */           localTableCellRenderer = localJTable.getDefaultRenderer((Class)localObject);
/*      */         }
/*      */         
/* 1654 */         Object localObject = localTableCellRenderer.getTableCellRendererComponent(localJTable, localJTable.getValueAt(i, j), false, false, i, j);
/*      */         
/* 1656 */         if ((localObject instanceof Accessible)) {
/* 1657 */           return ((Component)localObject).getAccessibleContext();
/*      */         }
/* 1659 */         return null; } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Rectangle getAccessibleBoundsOnScreenFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 1668 */     if (paramAccessibleContext == null)
/* 1669 */       return null;
/* 1670 */     (Rectangle)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Rectangle call() throws Exception {
/* 1673 */         AccessibleComponent localAccessibleComponent = paramAccessibleContext.getAccessibleComponent();
/* 1674 */         if (localAccessibleComponent != null) {
/* 1675 */           Rectangle localRectangle = localAccessibleComponent.getBounds();
/* 1676 */           if (localRectangle != null) {
/*      */             try {
/* 1678 */               Point localPoint = localAccessibleComponent.getLocationOnScreen();
/* 1679 */               if (localPoint != null) {
/* 1680 */                 localRectangle.x = localPoint.x;
/* 1681 */                 localRectangle.y = localPoint.y;
/* 1682 */                 return localRectangle;
/*      */               }
/*      */             } catch (Exception localException) {
/* 1685 */               return null;
/*      */             }
/*      */           }
/*      */         }
/* 1689 */         return null; } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleXcoordFromContext(AccessibleContext paramAccessibleContext)
/*      */   {
/* 1698 */     if (paramAccessibleContext != null) {
/* 1699 */       Rectangle localRectangle = getAccessibleBoundsOnScreenFromContext(paramAccessibleContext);
/* 1700 */       if (localRectangle != null) {
/* 1701 */         debugString(" - Returning Accessible x coord from Context: " + localRectangle.x);
/* 1702 */         return localRectangle.x;
/*      */       }
/*      */     } else {
/* 1705 */       debugString("getAccessibleXcoordFromContext ac = null");
/*      */     }
/* 1707 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleYcoordFromContext(AccessibleContext paramAccessibleContext)
/*      */   {
/* 1714 */     debugString("getAccessibleYcoordFromContext() called");
/* 1715 */     if (paramAccessibleContext != null) {
/* 1716 */       Rectangle localRectangle = getAccessibleBoundsOnScreenFromContext(paramAccessibleContext);
/* 1717 */       if (localRectangle != null) {
/* 1718 */         return localRectangle.y;
/*      */       }
/*      */     } else {
/* 1721 */       debugString("getAccessibleYcoordFromContext; ac = null");
/*      */     }
/* 1723 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleHeightFromContext(AccessibleContext paramAccessibleContext)
/*      */   {
/* 1730 */     if (paramAccessibleContext != null) {
/* 1731 */       Rectangle localRectangle = getAccessibleBoundsOnScreenFromContext(paramAccessibleContext);
/* 1732 */       if (localRectangle != null) {
/* 1733 */         return localRectangle.height;
/*      */       }
/*      */     } else {
/* 1736 */       debugString("getAccessibleHeightFromContext; ac = null");
/*      */     }
/* 1738 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleWidthFromContext(AccessibleContext paramAccessibleContext)
/*      */   {
/* 1745 */     if (paramAccessibleContext != null) {
/* 1746 */       Rectangle localRectangle = getAccessibleBoundsOnScreenFromContext(paramAccessibleContext);
/* 1747 */       if (localRectangle != null) {
/* 1748 */         return localRectangle.width;
/*      */       }
/*      */     } else {
/* 1751 */       debugString("getAccessibleWidthFromContext; ac = null");
/*      */     }
/* 1753 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleComponent getAccessibleComponentFromContext(AccessibleContext paramAccessibleContext)
/*      */   {
/* 1761 */     if (paramAccessibleContext != null) {
/* 1762 */       AccessibleComponent localAccessibleComponent = paramAccessibleContext.getAccessibleComponent();
/* 1763 */       if (localAccessibleComponent != null) {
/* 1764 */         debugString("Returning AccessibleComponent Context");
/* 1765 */         return localAccessibleComponent;
/*      */       }
/*      */     } else {
/* 1768 */       debugString("getAccessibleComponentFromContext; ac = null");
/*      */     }
/* 1770 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private AccessibleAction getAccessibleActionFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 1777 */     debugString("Returning AccessibleAction Context");
/* 1778 */     paramAccessibleContext == null ? null : (AccessibleAction)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */ 
/* 1781 */       public AccessibleAction call() throws Exception { return paramAccessibleContext.getAccessibleAction(); } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleSelection getAccessibleSelectionFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 1790 */     paramAccessibleContext == null ? null : (AccessibleSelection)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */ 
/* 1793 */       public AccessibleSelection call() throws Exception { return paramAccessibleContext.getAccessibleSelection(); } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleText getAccessibleTextFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 1802 */     paramAccessibleContext == null ? null : (AccessibleText)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */ 
/* 1805 */       public AccessibleText call() throws Exception { return paramAccessibleContext.getAccessibleText(); } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleValue getAccessibleValueFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 1814 */     paramAccessibleContext == null ? null : (AccessibleValue)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */ 
/* 1817 */       public AccessibleValue call() throws Exception { return paramAccessibleContext.getAccessibleValue(); } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Rectangle getCaretLocation(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 1829 */     debugString("getCaretLocation");
/* 1830 */     if (paramAccessibleContext == null)
/* 1831 */       return null;
/* 1832 */     (Rectangle)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Rectangle call() throws Exception
/*      */       {
/* 1836 */         Rectangle localRectangle = null;
/* 1837 */         Accessible localAccessible1 = paramAccessibleContext.getAccessibleParent();
/* 1838 */         if ((localAccessible1 instanceof Accessible)) {
/* 1839 */           int i = paramAccessibleContext.getAccessibleIndexInParent();
/*      */           
/* 1841 */           Accessible localAccessible2 = localAccessible1.getAccessibleContext().getAccessibleChild(i);
/*      */           
/* 1843 */           if ((localAccessible2 instanceof JTextComponent)) {
/* 1844 */             JTextComponent localJTextComponent = (JTextComponent)localAccessible2;
/*      */             try {
/* 1846 */               localRectangle = localJTextComponent.modelToView(localJTextComponent.getCaretPosition());
/* 1847 */               if (localRectangle != null) {
/* 1848 */                 Point localPoint = localJTextComponent.getLocationOnScreen();
/* 1849 */                 localRectangle.translate(localPoint.x, localPoint.y);
/*      */               }
/*      */             }
/*      */             catch (javax.swing.text.BadLocationException localBadLocationException) {}
/*      */           }
/*      */         }
/* 1855 */         return localRectangle; } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getCaretLocationX(AccessibleContext paramAccessibleContext)
/*      */   {
/* 1864 */     Rectangle localRectangle = getCaretLocation(paramAccessibleContext);
/* 1865 */     if (localRectangle != null) {
/* 1866 */       return localRectangle.x;
/*      */     }
/* 1868 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getCaretLocationY(AccessibleContext paramAccessibleContext)
/*      */   {
/* 1876 */     Rectangle localRectangle = getCaretLocation(paramAccessibleContext);
/* 1877 */     if (localRectangle != null) {
/* 1878 */       return localRectangle.y;
/*      */     }
/* 1880 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getCaretLocationHeight(AccessibleContext paramAccessibleContext)
/*      */   {
/* 1888 */     Rectangle localRectangle = getCaretLocation(paramAccessibleContext);
/* 1889 */     if (localRectangle != null) {
/* 1890 */       return localRectangle.height;
/*      */     }
/* 1892 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getCaretLocationWidth(AccessibleContext paramAccessibleContext)
/*      */   {
/* 1900 */     Rectangle localRectangle = getCaretLocation(paramAccessibleContext);
/* 1901 */     if (localRectangle != null) {
/* 1902 */       return localRectangle.width;
/*      */     }
/* 1904 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleCharCountFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 1912 */     if (paramAccessibleContext == null)
/* 1913 */       return -1;
/* 1914 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 1917 */         AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 1918 */         if (localAccessibleText != null) {
/* 1919 */           return Integer.valueOf(localAccessibleText.getCharCount());
/*      */         }
/* 1921 */         return Integer.valueOf(-1); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleCaretPositionFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 1930 */     if (paramAccessibleContext == null)
/* 1931 */       return -1;
/* 1932 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 1935 */         AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 1936 */         if (localAccessibleText != null) {
/* 1937 */           return Integer.valueOf(localAccessibleText.getCaretPosition());
/*      */         }
/* 1939 */         return Integer.valueOf(-1); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleIndexAtPointFromContext(final AccessibleContext paramAccessibleContext, final int paramInt1, final int paramInt2)
/*      */   {
/* 1950 */     debugString("getAccessibleIndexAtPointFromContext: x = " + paramInt1 + "; y = " + paramInt2);
/* 1951 */     if (paramAccessibleContext == null)
/* 1952 */       return -1;
/* 1953 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 1956 */         AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 1957 */         AccessibleComponent localAccessibleComponent = paramAccessibleContext.getAccessibleComponent();
/* 1958 */         if ((localAccessibleText != null) && (localAccessibleComponent != null))
/*      */         {
/*      */           try
/*      */           {
/* 1962 */             Point localPoint1 = localAccessibleComponent.getLocationOnScreen();
/*      */             
/* 1964 */             if (localPoint1 != null) {
/* 1965 */               int i = paramInt1 - localPoint1.x;
/* 1966 */               if (i < 0) {
/* 1967 */                 i = 0;
/*      */               }
/* 1969 */               int j = paramInt2 - localPoint1.y;
/* 1970 */               if (j < 0) {
/* 1971 */                 j = 0;
/*      */               }
/*      */               
/* 1974 */               Point localPoint2 = new Point(i, j);
/* 1975 */               int k = localAccessibleText.getIndexAtPoint(new Point(i, j));
/* 1976 */               return Integer.valueOf(k);
/*      */             }
/*      */           }
/*      */           catch (Exception localException) {}
/*      */         }
/* 1981 */         return Integer.valueOf(-1); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getAccessibleLetterAtIndexFromContext(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 1990 */     if (paramAccessibleContext != null) {
/* 1991 */       String str = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public String call() throws Exception {
/* 1994 */           AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 1995 */           if (localAccessibleText == null) return null;
/* 1996 */           return localAccessibleText.getAtIndex(1, paramInt); } }, paramAccessibleContext);
/*      */       
/*      */ 
/* 1999 */       if (str != null) {
/* 2000 */         this.references.increment(str);
/* 2001 */         return str;
/*      */       }
/*      */     } else {
/* 2004 */       debugString("getAccessibleLetterAtIndexFromContext; ac = null");
/*      */     }
/* 2006 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getAccessibleWordAtIndexFromContext(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 2013 */     if (paramAccessibleContext != null) {
/* 2014 */       String str = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public String call() throws Exception {
/* 2017 */           AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 2018 */           if (localAccessibleText == null) return null;
/* 2019 */           return localAccessibleText.getAtIndex(2, paramInt); } }, paramAccessibleContext);
/*      */       
/*      */ 
/* 2022 */       if (str != null) {
/* 2023 */         this.references.increment(str);
/* 2024 */         return str;
/*      */       }
/*      */     } else {
/* 2027 */       debugString("getAccessibleWordAtIndexFromContext; ac = null");
/*      */     }
/* 2029 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getAccessibleSentenceAtIndexFromContext(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 2036 */     if (paramAccessibleContext != null) {
/* 2037 */       String str = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public String call() throws Exception {
/* 2040 */           AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 2041 */           if (localAccessibleText == null) return null;
/* 2042 */           return localAccessibleText.getAtIndex(3, paramInt); } }, paramAccessibleContext);
/*      */       
/*      */ 
/* 2045 */       if (str != null) {
/* 2046 */         this.references.increment(str);
/* 2047 */         return str;
/*      */       }
/*      */     } else {
/* 2050 */       debugString("getAccessibleSentenceAtIndexFromContext; ac = null");
/*      */     }
/* 2052 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleTextSelectionStartFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 2059 */     if (paramAccessibleContext == null) return -1;
/* 2060 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 2063 */         AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 2064 */         if (localAccessibleText != null) {
/* 2065 */           return Integer.valueOf(localAccessibleText.getSelectionStart());
/*      */         }
/* 2067 */         return Integer.valueOf(-1); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleTextSelectionEndFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 2076 */     if (paramAccessibleContext == null)
/* 2077 */       return -1;
/* 2078 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 2081 */         AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 2082 */         if (localAccessibleText != null) {
/* 2083 */           return Integer.valueOf(localAccessibleText.getSelectionEnd());
/*      */         }
/* 2085 */         return Integer.valueOf(-1); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getAccessibleTextSelectedTextFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 2094 */     if (paramAccessibleContext != null) {
/* 2095 */       String str = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public String call() throws Exception {
/* 2098 */           AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 2099 */           if (localAccessibleText == null) return null;
/* 2100 */           return localAccessibleText.getSelectedText(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/* 2103 */       if (str != null) {
/* 2104 */         this.references.increment(str);
/* 2105 */         return str;
/*      */       }
/*      */     } else {
/* 2108 */       debugString("getAccessibleTextSelectedTextFromContext; ac = null");
/*      */     }
/* 2110 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getAccessibleAttributesAtIndexFromContext(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 2118 */     if (paramAccessibleContext == null)
/* 2119 */       return null;
/* 2120 */     AttributeSet localAttributeSet = (AttributeSet)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AttributeSet call() throws Exception {
/* 2123 */         AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 2124 */         if (localAccessibleText != null) {
/* 2125 */           return localAccessibleText.getCharacterAttribute(paramInt);
/*      */         }
/* 2127 */         return null; } }, paramAccessibleContext);
/*      */     
/*      */ 
/* 2130 */     String str = expandStyleConstants(localAttributeSet);
/* 2131 */     if (str != null) {
/* 2132 */       this.references.increment(str);
/* 2133 */       return str;
/*      */     }
/* 2135 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleTextLineLeftBoundsFromContext(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 2149 */     if (paramAccessibleContext == null)
/* 2150 */       return -1;
/* 2151 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 2154 */         AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 2155 */         if (localAccessibleText != null)
/*      */         {
/*      */ 
/*      */ 
/* 2159 */           Rectangle localRectangle2 = localAccessibleText.getCharacterBounds(paramInt);
/* 2160 */           int k = localAccessibleText.getCharCount();
/* 2161 */           if (localRectangle2 == null) {
/* 2162 */             return Integer.valueOf(-1);
/*      */           }
/*      */           
/*      */ 
/* 2166 */           int j = 1;
/* 2167 */           int i = paramInt - j < 0 ? 0 : paramInt - j;
/* 2168 */           Rectangle localRectangle1 = localAccessibleText.getCharacterBounds(i);
/*      */           
/* 2170 */           while ((localRectangle1 != null) && (localRectangle1.y >= localRectangle2.y) && (i > 0))
/*      */           {
/*      */ 
/* 2173 */             j <<= 1;
/* 2174 */             i = paramInt - j < 0 ? 0 : paramInt - j;
/* 2175 */             localRectangle1 = localAccessibleText.getCharacterBounds(i);
/*      */           }
/* 2177 */           if (i != 0)
/*      */           {
/*      */ 
/* 2180 */             j >>= 1;
/*      */             
/* 2182 */             while (j > 0) {
/* 2183 */               localRectangle1 = localAccessibleText.getCharacterBounds(i + j);
/* 2184 */               if (localRectangle1.y < localRectangle2.y) {
/* 2185 */                 i += j;
/*      */               }
/*      */               
/*      */ 
/* 2189 */               j >>= 1;
/*      */             }
/*      */             
/* 2192 */             i++;
/*      */           }
/* 2194 */           return Integer.valueOf(i);
/*      */         }
/* 2196 */         return Integer.valueOf(-1); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleTextLineRightBoundsFromContext(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 2211 */     if (paramAccessibleContext == null)
/* 2212 */       return -1;
/* 2213 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 2216 */         AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 2217 */         if (localAccessibleText != null)
/*      */         {
/*      */ 
/*      */ 
/* 2221 */           Rectangle localRectangle2 = localAccessibleText.getCharacterBounds(paramInt);
/* 2222 */           int k = localAccessibleText.getCharCount();
/* 2223 */           if (localRectangle2 == null) {
/* 2224 */             return Integer.valueOf(-1);
/*      */           }
/*      */           
/*      */ 
/* 2228 */           int j = 1;
/* 2229 */           int i = paramInt + j > k - 1 ? k - 1 : paramInt + j;
/*      */           
/* 2231 */           Rectangle localRectangle1 = localAccessibleText.getCharacterBounds(i);
/*      */           
/* 2233 */           while ((localRectangle1 != null) && (localRectangle1.y <= localRectangle2.y) && (i < k - 1))
/*      */           {
/*      */ 
/* 2236 */             j <<= 1;
/* 2237 */             i = paramInt + j > k - 1 ? k - 1 : paramInt + j;
/*      */             
/* 2239 */             localRectangle1 = localAccessibleText.getCharacterBounds(i);
/*      */           }
/* 2241 */           if (i != k - 1)
/*      */           {
/*      */ 
/* 2244 */             j >>= 1;
/*      */             
/* 2246 */             while (j > 0) {
/* 2247 */               localRectangle1 = localAccessibleText.getCharacterBounds(i - j);
/* 2248 */               if (localRectangle1.y > localRectangle2.y) {
/* 2249 */                 i -= j;
/*      */               }
/*      */               
/*      */ 
/* 2253 */               j >>= 1;
/*      */             }
/*      */             
/* 2256 */             i--;
/*      */           }
/* 2258 */           return Integer.valueOf(i);
/*      */         }
/* 2260 */         return Integer.valueOf(-1); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getAccessibleTextRangeFromContext(final AccessibleContext paramAccessibleContext, final int paramInt1, final int paramInt2)
/*      */   {
/* 2270 */     String str = (String)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public String call() throws Exception {
/* 2273 */         if (paramAccessibleContext != null) {
/* 2274 */           AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 2275 */           if (localAccessibleText != null)
/*      */           {
/* 2277 */             if (paramInt1 > paramInt2) {
/* 2278 */               return null;
/*      */             }
/* 2280 */             if (paramInt2 >= localAccessibleText.getCharCount()) {
/* 2281 */               return null;
/*      */             }
/* 2283 */             StringBuffer localStringBuffer = new StringBuffer(paramInt2 - paramInt1 + 1);
/* 2284 */             for (int i = paramInt1; i <= paramInt2; i++) {
/* 2285 */               localStringBuffer.append(localAccessibleText.getAtIndex(1, i));
/*      */             }
/* 2287 */             return localStringBuffer.toString();
/*      */           }
/*      */         }
/* 2290 */         return null; } }, paramAccessibleContext);
/*      */     
/*      */ 
/* 2293 */     if (str != null) {
/* 2294 */       this.references.increment(str);
/* 2295 */       return str;
/*      */     }
/* 2297 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AttributeSet getAccessibleAttributeSetAtIndexFromContext(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 2306 */     (AttributeSet)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AttributeSet call() throws Exception {
/* 2309 */         if (paramAccessibleContext != null) {
/* 2310 */           AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 2311 */           if (localAccessibleText != null) {
/* 2312 */             AttributeSet localAttributeSet = localAccessibleText.getCharacterAttribute(paramInt);
/* 2313 */             if (localAttributeSet != null) {
/* 2314 */               AccessBridge.this.references.increment(localAttributeSet);
/* 2315 */               return localAttributeSet;
/*      */             }
/*      */           }
/*      */         }
/* 2319 */         return null; } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Rectangle getAccessibleTextRectAtIndexFromContext(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 2331 */     Rectangle localRectangle1 = (Rectangle)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Rectangle call() throws Exception
/*      */       {
/* 2335 */         if (paramAccessibleContext != null) {
/* 2336 */           AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 2337 */           if (localAccessibleText != null) {
/* 2338 */             Rectangle localRectangle = localAccessibleText.getCharacterBounds(paramInt);
/* 2339 */             if (localRectangle != null) {
/* 2340 */               String str = localAccessibleText.getAtIndex(1, paramInt);
/* 2341 */               if ((str != null) && (str.equals("\n"))) {
/* 2342 */                 localRectangle.width = 0;
/*      */               }
/* 2344 */               return localRectangle;
/*      */             }
/*      */           }
/*      */         }
/* 2348 */         return null; } }, paramAccessibleContext);
/*      */     
/*      */ 
/* 2351 */     Rectangle localRectangle2 = getAccessibleBoundsOnScreenFromContext(paramAccessibleContext);
/* 2352 */     if ((localRectangle1 != null) && (localRectangle2 != null)) {
/* 2353 */       localRectangle1.translate(localRectangle2.x, localRectangle2.y);
/* 2354 */       return localRectangle1;
/*      */     }
/* 2356 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleXcoordTextRectAtIndexFromContext(AccessibleContext paramAccessibleContext, int paramInt)
/*      */   {
/* 2363 */     if (paramAccessibleContext != null) {
/* 2364 */       Rectangle localRectangle = getAccessibleTextRectAtIndexFromContext(paramAccessibleContext, paramInt);
/* 2365 */       if (localRectangle != null) {
/* 2366 */         return localRectangle.x;
/*      */       }
/*      */     } else {
/* 2369 */       debugString("getAccessibleXcoordTextRectAtIndexFromContext; ac = null");
/*      */     }
/* 2371 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleYcoordTextRectAtIndexFromContext(AccessibleContext paramAccessibleContext, int paramInt)
/*      */   {
/* 2378 */     if (paramAccessibleContext != null) {
/* 2379 */       Rectangle localRectangle = getAccessibleTextRectAtIndexFromContext(paramAccessibleContext, paramInt);
/* 2380 */       if (localRectangle != null) {
/* 2381 */         return localRectangle.y;
/*      */       }
/*      */     } else {
/* 2384 */       debugString("getAccessibleYcoordTextRectAtIndexFromContext; ac = null");
/*      */     }
/* 2386 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleHeightTextRectAtIndexFromContext(AccessibleContext paramAccessibleContext, int paramInt)
/*      */   {
/* 2393 */     if (paramAccessibleContext != null) {
/* 2394 */       Rectangle localRectangle = getAccessibleTextRectAtIndexFromContext(paramAccessibleContext, paramInt);
/* 2395 */       if (localRectangle != null) {
/* 2396 */         return localRectangle.height;
/*      */       }
/*      */     } else {
/* 2399 */       debugString("getAccessibleHeightTextRectAtIndexFromContext; ac = null");
/*      */     }
/* 2401 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleWidthTextRectAtIndexFromContext(AccessibleContext paramAccessibleContext, int paramInt)
/*      */   {
/* 2408 */     if (paramAccessibleContext != null) {
/* 2409 */       Rectangle localRectangle = getAccessibleTextRectAtIndexFromContext(paramAccessibleContext, paramInt);
/* 2410 */       if (localRectangle != null) {
/* 2411 */         return localRectangle.width;
/*      */       }
/*      */     } else {
/* 2414 */       debugString("getAccessibleWidthTextRectAtIndexFromContext; ac = null");
/*      */     }
/* 2416 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean getBoldFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2425 */     if (paramAttributeSet != null) {
/* 2426 */       return StyleConstants.isBold(paramAttributeSet);
/*      */     }
/* 2428 */     debugString("getBoldFromAttributeSet; as = null");
/*      */     
/* 2430 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean getItalicFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2437 */     if (paramAttributeSet != null) {
/* 2438 */       return StyleConstants.isItalic(paramAttributeSet);
/*      */     }
/* 2440 */     debugString("getItalicFromAttributeSet; as = null");
/*      */     
/* 2442 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean getUnderlineFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2449 */     if (paramAttributeSet != null) {
/* 2450 */       return StyleConstants.isUnderline(paramAttributeSet);
/*      */     }
/* 2452 */     debugString("getUnderlineFromAttributeSet; as = null");
/*      */     
/* 2454 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean getStrikethroughFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2461 */     if (paramAttributeSet != null) {
/* 2462 */       return StyleConstants.isStrikeThrough(paramAttributeSet);
/*      */     }
/* 2464 */     debugString("getStrikethroughFromAttributeSet; as = null");
/*      */     
/* 2466 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean getSuperscriptFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2473 */     if (paramAttributeSet != null) {
/* 2474 */       return StyleConstants.isSuperscript(paramAttributeSet);
/*      */     }
/* 2476 */     debugString("getSuperscriptFromAttributeSet; as = null");
/*      */     
/* 2478 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean getSubscriptFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2485 */     if (paramAttributeSet != null) {
/* 2486 */       return StyleConstants.isSubscript(paramAttributeSet);
/*      */     }
/* 2488 */     debugString("getSubscriptFromAttributeSet; as = null");
/*      */     
/* 2490 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getBackgroundColorFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2497 */     if (paramAttributeSet != null) {
/* 2498 */       String str = StyleConstants.getBackground(paramAttributeSet).toString();
/* 2499 */       if (str != null) {
/* 2500 */         this.references.increment(str);
/* 2501 */         return str;
/*      */       }
/*      */     } else {
/* 2504 */       debugString("getBackgroundColorFromAttributeSet; as = null");
/*      */     }
/* 2506 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getForegroundColorFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2513 */     if (paramAttributeSet != null) {
/* 2514 */       String str = StyleConstants.getForeground(paramAttributeSet).toString();
/* 2515 */       if (str != null) {
/* 2516 */         this.references.increment(str);
/* 2517 */         return str;
/*      */       }
/*      */     } else {
/* 2520 */       debugString("getForegroundColorFromAttributeSet; as = null");
/*      */     }
/* 2522 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getFontFamilyFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2529 */     if (paramAttributeSet != null) {
/* 2530 */       String str = StyleConstants.getFontFamily(paramAttributeSet).toString();
/* 2531 */       if (str != null) {
/* 2532 */         this.references.increment(str);
/* 2533 */         return str;
/*      */       }
/*      */     } else {
/* 2536 */       debugString("getFontFamilyFromAttributeSet; as = null");
/*      */     }
/* 2538 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getFontSizeFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2545 */     if (paramAttributeSet != null) {
/* 2546 */       return StyleConstants.getFontSize(paramAttributeSet);
/*      */     }
/* 2548 */     debugString("getFontSizeFromAttributeSet; as = null");
/*      */     
/* 2550 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAlignmentFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2557 */     if (paramAttributeSet != null) {
/* 2558 */       return StyleConstants.getAlignment(paramAttributeSet);
/*      */     }
/* 2560 */     debugString("getAlignmentFromAttributeSet; as = null");
/*      */     
/* 2562 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getBidiLevelFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2569 */     if (paramAttributeSet != null) {
/* 2570 */       return StyleConstants.getBidiLevel(paramAttributeSet);
/*      */     }
/* 2572 */     debugString("getBidiLevelFromAttributeSet; as = null");
/*      */     
/* 2574 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private float getFirstLineIndentFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2582 */     if (paramAttributeSet != null) {
/* 2583 */       return StyleConstants.getFirstLineIndent(paramAttributeSet);
/*      */     }
/* 2585 */     debugString("getFirstLineIndentFromAttributeSet; as = null");
/*      */     
/* 2587 */     return -1.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private float getLeftIndentFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2594 */     if (paramAttributeSet != null) {
/* 2595 */       return StyleConstants.getLeftIndent(paramAttributeSet);
/*      */     }
/* 2597 */     debugString("getLeftIndentFromAttributeSet; as = null");
/*      */     
/* 2599 */     return -1.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private float getRightIndentFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2606 */     if (paramAttributeSet != null) {
/* 2607 */       return StyleConstants.getRightIndent(paramAttributeSet);
/*      */     }
/* 2609 */     debugString("getRightIndentFromAttributeSet; as = null");
/*      */     
/* 2611 */     return -1.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private float getLineSpacingFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2618 */     if (paramAttributeSet != null) {
/* 2619 */       return StyleConstants.getLineSpacing(paramAttributeSet);
/*      */     }
/* 2621 */     debugString("getLineSpacingFromAttributeSet; as = null");
/*      */     
/* 2623 */     return -1.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private float getSpaceAboveFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2630 */     if (paramAttributeSet != null) {
/* 2631 */       return StyleConstants.getSpaceAbove(paramAttributeSet);
/*      */     }
/* 2633 */     debugString("getSpaceAboveFromAttributeSet; as = null");
/*      */     
/* 2635 */     return -1.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private float getSpaceBelowFromAttributeSet(AttributeSet paramAttributeSet)
/*      */   {
/* 2642 */     if (paramAttributeSet != null) {
/* 2643 */       return StyleConstants.getSpaceBelow(paramAttributeSet);
/*      */     }
/* 2645 */     debugString("getSpaceBelowFromAttributeSet; as = null");
/*      */     
/* 2647 */     return -1.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String expandStyleConstants(AttributeSet paramAttributeSet)
/*      */   {
/* 2669 */     String str = "";
/*      */     
/*      */ 
/*      */ 
/* 2673 */     str = str + "BidiLevel = " + StyleConstants.getBidiLevel(paramAttributeSet);
/*      */     
/* 2675 */     final Component localComponent = StyleConstants.getComponent(paramAttributeSet);
/* 2676 */     if (localComponent != null) {
/* 2677 */       if ((localComponent instanceof Accessible)) {
/* 2678 */         localObject = (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */ 
/* 2681 */           public AccessibleContext call() throws Exception { return localComponent.getAccessibleContext(); } }, localComponent);
/*      */         
/*      */ 
/* 2684 */         if (localObject != null) {
/* 2685 */           str = str + "; Accessible Component = " + (String)InvocationUtils.invokeAndWait(new Callable()
/*      */           {
/*      */ 
/* 2688 */             public String call() throws Exception { return localObject.getAccessibleName(); } }, (AccessibleContext)localObject);
/*      */         }
/*      */         else
/*      */         {
/* 2692 */           str = str + "; Innaccessible Component = " + localComponent;
/*      */         }
/*      */       } else {
/* 2695 */         str = str + "; Innaccessible Component = " + localComponent;
/*      */       }
/*      */     }
/*      */     
/* 2699 */     final Object localObject = StyleConstants.getIcon(paramAttributeSet);
/* 2700 */     if (localObject != null) {
/* 2701 */       if ((localObject instanceof javax.swing.ImageIcon)) {
/* 2702 */         str = str + "; ImageIcon = " + ((javax.swing.ImageIcon)localObject).getDescription();
/*      */       } else {
/* 2704 */         str = str + "; Icon = " + localObject;
/*      */       }
/*      */     }
/*      */     
/* 2708 */     str = str + "; FontFamily = " + StyleConstants.getFontFamily(paramAttributeSet);
/*      */     
/* 2710 */     str = str + "; FontSize = " + StyleConstants.getFontSize(paramAttributeSet);
/*      */     
/* 2712 */     if (StyleConstants.isBold(paramAttributeSet)) {
/* 2713 */       str = str + "; bold";
/*      */     }
/*      */     
/* 2716 */     if (StyleConstants.isItalic(paramAttributeSet)) {
/* 2717 */       str = str + "; italic";
/*      */     }
/*      */     
/* 2720 */     if (StyleConstants.isUnderline(paramAttributeSet)) {
/* 2721 */       str = str + "; underline";
/*      */     }
/*      */     
/* 2724 */     if (StyleConstants.isStrikeThrough(paramAttributeSet)) {
/* 2725 */       str = str + "; strikethrough";
/*      */     }
/*      */     
/* 2728 */     if (StyleConstants.isSuperscript(paramAttributeSet)) {
/* 2729 */       str = str + "; superscript";
/*      */     }
/*      */     
/* 2732 */     if (StyleConstants.isSubscript(paramAttributeSet)) {
/* 2733 */       str = str + "; subscript";
/*      */     }
/*      */     
/* 2736 */     Color localColor = StyleConstants.getForeground(paramAttributeSet);
/* 2737 */     if (localColor != null) {
/* 2738 */       str = str + "; Foreground = " + localColor;
/*      */     }
/*      */     
/* 2741 */     localColor = StyleConstants.getBackground(paramAttributeSet);
/* 2742 */     if (localColor != null) {
/* 2743 */       str = str + "; Background = " + localColor;
/*      */     }
/*      */     
/* 2746 */     str = str + "; FirstLineIndent = " + StyleConstants.getFirstLineIndent(paramAttributeSet);
/*      */     
/* 2748 */     str = str + "; RightIndent = " + StyleConstants.getRightIndent(paramAttributeSet);
/*      */     
/* 2750 */     str = str + "; LeftIndent = " + StyleConstants.getLeftIndent(paramAttributeSet);
/*      */     
/* 2752 */     str = str + "; LineSpacing = " + StyleConstants.getLineSpacing(paramAttributeSet);
/*      */     
/* 2754 */     str = str + "; SpaceAbove = " + StyleConstants.getSpaceAbove(paramAttributeSet);
/*      */     
/* 2756 */     str = str + "; SpaceBelow = " + StyleConstants.getSpaceBelow(paramAttributeSet);
/*      */     
/* 2758 */     str = str + "; Alignment = " + StyleConstants.getAlignment(paramAttributeSet);
/*      */     
/* 2760 */     javax.swing.text.TabSet localTabSet = StyleConstants.getTabSet(paramAttributeSet);
/* 2761 */     if (localTabSet != null) {
/* 2762 */       str = str + "; TabSet = " + localTabSet;
/*      */     }
/*      */     
/* 2765 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getCurrentAccessibleValueFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 2777 */     if (paramAccessibleContext != null) {
/* 2778 */       Number localNumber = (Number)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public Number call() throws Exception {
/* 2781 */           AccessibleValue localAccessibleValue = paramAccessibleContext.getAccessibleValue();
/* 2782 */           if (localAccessibleValue == null) return null;
/* 2783 */           return localAccessibleValue.getCurrentAccessibleValue(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/* 2786 */       if (localNumber != null) {
/* 2787 */         String str = localNumber.toString();
/* 2788 */         if (str != null) {
/* 2789 */           this.references.increment(str);
/* 2790 */           return str;
/*      */         }
/*      */       }
/*      */     } else {
/* 2794 */       debugString("getCurrentAccessibleValueFromContext; ac = null");
/*      */     }
/* 2796 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getMaximumAccessibleValueFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 2805 */     if (paramAccessibleContext != null) {
/* 2806 */       Number localNumber = (Number)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public Number call() throws Exception {
/* 2809 */           AccessibleValue localAccessibleValue = paramAccessibleContext.getAccessibleValue();
/* 2810 */           if (localAccessibleValue == null) return null;
/* 2811 */           return localAccessibleValue.getMaximumAccessibleValue(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/* 2814 */       if (localNumber != null) {
/* 2815 */         String str = localNumber.toString();
/* 2816 */         if (str != null) {
/* 2817 */           this.references.increment(str);
/* 2818 */           return str;
/*      */         }
/*      */       }
/*      */     } else {
/* 2822 */       debugString("getMaximumAccessibleValueFromContext; ac = null");
/*      */     }
/* 2824 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getMinimumAccessibleValueFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 2833 */     if (paramAccessibleContext != null) {
/* 2834 */       Number localNumber = (Number)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public Number call() throws Exception {
/* 2837 */           AccessibleValue localAccessibleValue = paramAccessibleContext.getAccessibleValue();
/* 2838 */           if (localAccessibleValue == null) return null;
/* 2839 */           return localAccessibleValue.getMinimumAccessibleValue(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/* 2842 */       if (localNumber != null) {
/* 2843 */         String str = localNumber.toString();
/* 2844 */         if (str != null) {
/* 2845 */           this.references.increment(str);
/* 2846 */           return str;
/*      */         }
/*      */       }
/*      */     } else {
/* 2850 */       debugString("getMinimumAccessibleValueFromContext; ac = null");
/*      */     }
/* 2852 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addAccessibleSelectionFromContext(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/*      */     try
/*      */     {
/* 2864 */       InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public Object call() throws Exception {
/* 2867 */           if (paramAccessibleContext != null) {
/* 2868 */             AccessibleSelection localAccessibleSelection = paramAccessibleContext.getAccessibleSelection();
/* 2869 */             if (localAccessibleSelection != null) {
/* 2870 */               localAccessibleSelection.addAccessibleSelection(paramInt);
/*      */             }
/*      */           }
/* 2873 */           return null; } }, paramAccessibleContext);
/*      */     }
/*      */     catch (Exception localException) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void clearAccessibleSelectionFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/*      */     try
/*      */     {
/* 2885 */       InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public Object call() throws Exception {
/* 2888 */           AccessibleSelection localAccessibleSelection = paramAccessibleContext.getAccessibleSelection();
/* 2889 */           if (localAccessibleSelection != null) {
/* 2890 */             localAccessibleSelection.clearAccessibleSelection();
/*      */           }
/* 2892 */           return null; } }, paramAccessibleContext);
/*      */     }
/*      */     catch (Exception localException) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getAccessibleSelectionFromContext(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 2904 */     (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AccessibleContext call() throws Exception {
/* 2907 */         if (paramAccessibleContext != null) {
/* 2908 */           AccessibleSelection localAccessibleSelection = paramAccessibleContext.getAccessibleSelection();
/* 2909 */           if (localAccessibleSelection != null) {
/* 2910 */             Accessible localAccessible = localAccessibleSelection.getAccessibleSelection(paramInt);
/* 2911 */             if (localAccessible == null) {
/* 2912 */               return null;
/*      */             }
/* 2914 */             return localAccessible.getAccessibleContext();
/*      */           }
/*      */         }
/* 2917 */         return null; } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleSelectionCountFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 2927 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 2930 */         if (paramAccessibleContext != null) {
/* 2931 */           AccessibleSelection localAccessibleSelection = paramAccessibleContext.getAccessibleSelection();
/* 2932 */           if (localAccessibleSelection != null) {
/* 2933 */             return Integer.valueOf(localAccessibleSelection.getAccessibleSelectionCount());
/*      */           }
/*      */         }
/* 2936 */         return Integer.valueOf(-1); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isAccessibleChildSelectedFromContext(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 2946 */     ((Boolean)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Boolean call() throws Exception {
/* 2949 */         if (paramAccessibleContext != null) {
/* 2950 */           AccessibleSelection localAccessibleSelection = paramAccessibleContext.getAccessibleSelection();
/* 2951 */           if (localAccessibleSelection != null) {
/* 2952 */             return Boolean.valueOf(localAccessibleSelection.isAccessibleChildSelected(paramInt));
/*      */           }
/*      */         }
/* 2955 */         return Boolean.valueOf(false); } }, paramAccessibleContext)).booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void removeAccessibleSelectionFromContext(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 2965 */     InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Object call() throws Exception {
/* 2968 */         if (paramAccessibleContext != null) {
/* 2969 */           AccessibleSelection localAccessibleSelection = paramAccessibleContext.getAccessibleSelection();
/* 2970 */           if (localAccessibleSelection != null) {
/* 2971 */             localAccessibleSelection.removeAccessibleSelection(paramInt);
/*      */           }
/*      */         }
/* 2974 */         return null; } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void selectAllAccessibleSelectionFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 2984 */     InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Object call() throws Exception {
/* 2987 */         if (paramAccessibleContext != null) {
/* 2988 */           AccessibleSelection localAccessibleSelection = paramAccessibleContext.getAccessibleSelection();
/* 2989 */           if (localAccessibleSelection != null) {
/* 2990 */             localAccessibleSelection.selectAllAccessibleSelection();
/*      */           }
/*      */         }
/* 2993 */         return null; } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3000 */   ConcurrentHashMap<AccessibleTable, AccessibleContext> hashtab = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */   private AccessibleTable getAccessibleTableFromContext(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 3006 */     String str = getJavaVersionProperty();
/* 3007 */     if ((str != null) && (str.compareTo("1.3") >= 0)) {
/* 3008 */       (AccessibleTable)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public AccessibleTable call() throws Exception {
/* 3011 */           if (paramAccessibleContext != null) {
/* 3012 */             AccessibleTable localAccessibleTable = paramAccessibleContext.getAccessibleTable();
/* 3013 */             if (localAccessibleTable != null) {
/* 3014 */               AccessBridge.this.hashtab.put(localAccessibleTable, paramAccessibleContext);
/* 3015 */               return localAccessibleTable;
/*      */             }
/*      */           }
/* 3018 */           return null; } }, paramAccessibleContext);
/*      */     }
/*      */     
/*      */ 
/* 3022 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getContextFromAccessibleTable(AccessibleTable paramAccessibleTable)
/*      */   {
/* 3030 */     return (AccessibleContext)this.hashtab.get(paramAccessibleTable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleTableRowCount(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 3037 */     debugString("##### getAccessibleTableRowCount");
/* 3038 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 3041 */         if (paramAccessibleContext != null) {
/* 3042 */           AccessibleTable localAccessibleTable = paramAccessibleContext.getAccessibleTable();
/* 3043 */           if (localAccessibleTable != null) {
/* 3044 */             return Integer.valueOf(localAccessibleTable.getAccessibleRowCount());
/*      */           }
/*      */         }
/* 3047 */         return Integer.valueOf(-1); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleTableColumnCount(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 3056 */     debugString("##### getAccessibleTableColumnCount");
/* 3057 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 3060 */         if (paramAccessibleContext != null) {
/* 3061 */           AccessibleTable localAccessibleTable = paramAccessibleContext.getAccessibleTable();
/* 3062 */           if (localAccessibleTable != null) {
/* 3063 */             return Integer.valueOf(localAccessibleTable.getAccessibleColumnCount());
/*      */           }
/*      */         }
/* 3066 */         return Integer.valueOf(-1); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getAccessibleTableCellAccessibleContext(final AccessibleTable paramAccessibleTable, final int paramInt1, final int paramInt2)
/*      */   {
/* 3076 */     debugString("getAccessibleTableCellAccessibleContext: at = " + paramAccessibleTable.getClass());
/* 3077 */     if (paramAccessibleTable == null) return null;
/* 3078 */     (AccessibleContext)InvocationUtils.invokeAndWait(new Callable() {
/*      */       public AccessibleContext call() throws Exception {
/*      */         Object localObject1;
/* 3081 */         if (!(paramAccessibleTable instanceof AccessibleContext)) {
/* 3082 */           localObject1 = paramAccessibleTable.getAccessibleAt(paramInt1, paramInt2);
/* 3083 */           if (localObject1 != null) {
/* 3084 */             return ((Accessible)localObject1).getAccessibleContext();
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 3089 */           localObject1 = (AccessibleContext)paramAccessibleTable;
/* 3090 */           Accessible localAccessible1 = ((AccessibleContext)localObject1).getAccessibleParent();
/* 3091 */           if (localAccessible1 != null) {
/* 3092 */             int i = ((AccessibleContext)localObject1).getAccessibleIndexInParent();
/*      */             
/* 3094 */             Accessible localAccessible2 = localAccessible1.getAccessibleContext().getAccessibleChild(i);
/* 3095 */             if ((localAccessible2 instanceof JTable)) {
/* 3096 */               JTable localJTable = (JTable)localAccessible2;
/*      */               
/* 3098 */               javax.swing.table.TableCellRenderer localTableCellRenderer = localJTable.getCellRenderer(paramInt1, paramInt2);
/* 3099 */               if (localTableCellRenderer == null) {
/* 3100 */                 localObject2 = localJTable.getColumnClass(paramInt2);
/* 3101 */                 localTableCellRenderer = localJTable.getDefaultRenderer((Class)localObject2);
/*      */               }
/*      */               
/* 3104 */               Object localObject2 = localTableCellRenderer.getTableCellRendererComponent(localJTable, localJTable.getValueAt(paramInt1, paramInt2), false, false, paramInt1, paramInt2);
/*      */               
/* 3106 */               if ((localObject2 instanceof Accessible)) {
/* 3107 */                 return ((Component)localObject2).getAccessibleContext();
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/* 3112 */         return null;
/*      */       }
/* 3114 */     }, getContextFromAccessibleTable(paramAccessibleTable));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleTableCellIndex(final AccessibleTable paramAccessibleTable, int paramInt1, int paramInt2)
/*      */   {
/* 3121 */     debugString("##### getAccessibleTableCellIndex: at=" + paramAccessibleTable);
/* 3122 */     if (paramAccessibleTable != null)
/*      */     {
/* 3124 */       int i = paramInt1 * ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public Integer call() throws Exception {
/* 3127 */           return Integer.valueOf(paramAccessibleTable.getAccessibleColumnCount());
/*      */         }
/* 3129 */       }, getContextFromAccessibleTable(paramAccessibleTable))).intValue() + paramInt2;
/*      */       
/* 3131 */       debugString("   ##### getAccessibleTableCellIndex=" + i);
/* 3132 */       return i;
/*      */     }
/* 3134 */     debugString(" ##### getAccessibleTableCellIndex FAILED");
/* 3135 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleTableCellRowExtent(final AccessibleTable paramAccessibleTable, final int paramInt1, final int paramInt2)
/*      */   {
/* 3142 */     debugString("##### getAccessibleTableCellRowExtent");
/* 3143 */     if (paramAccessibleTable != null) {
/* 3144 */       int i = ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public Integer call() throws Exception {
/* 3147 */           return Integer.valueOf(paramAccessibleTable.getAccessibleRowExtentAt(paramInt1, paramInt2));
/*      */         }
/*      */         
/* 3150 */       }, getContextFromAccessibleTable(paramAccessibleTable))).intValue();
/* 3151 */       debugString("   ##### getAccessibleTableCellRowExtent=" + i);
/* 3152 */       return i;
/*      */     }
/* 3154 */     debugString(" ##### getAccessibleTableCellRowExtent FAILED");
/* 3155 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleTableCellColumnExtent(final AccessibleTable paramAccessibleTable, final int paramInt1, final int paramInt2)
/*      */   {
/* 3162 */     debugString("##### getAccessibleTableCellColumnExtent");
/* 3163 */     if (paramAccessibleTable != null) {
/* 3164 */       int i = ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public Integer call() throws Exception {
/* 3167 */           return Integer.valueOf(paramAccessibleTable.getAccessibleColumnExtentAt(paramInt1, paramInt2));
/*      */         }
/*      */         
/* 3170 */       }, getContextFromAccessibleTable(paramAccessibleTable))).intValue();
/* 3171 */       debugString("   ##### getAccessibleTableCellColumnExtent=" + i);
/* 3172 */       return i;
/*      */     }
/* 3174 */     debugString(" ##### getAccessibleTableCellColumnExtent FAILED");
/* 3175 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isAccessibleTableCellSelected(final AccessibleTable paramAccessibleTable, final int paramInt1, final int paramInt2)
/*      */   {
/* 3183 */     debugString("##### isAccessibleTableCellSelected: [" + paramInt1 + "][" + paramInt2 + "]");
/* 3184 */     if (paramAccessibleTable == null)
/* 3185 */       return false;
/* 3186 */     ((Boolean)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Boolean call() throws Exception {
/* 3189 */         boolean bool = false;
/* 3190 */         Accessible localAccessible = paramAccessibleTable.getAccessibleAt(paramInt1, paramInt2);
/* 3191 */         if (localAccessible != null) {
/* 3192 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 3193 */           if (localAccessibleContext == null)
/* 3194 */             return Boolean.valueOf(false);
/* 3195 */           AccessibleStateSet localAccessibleStateSet = localAccessibleContext.getAccessibleStateSet();
/* 3196 */           if (localAccessibleStateSet != null) {
/* 3197 */             bool = localAccessibleStateSet.contains(AccessibleState.SELECTED);
/*      */           }
/*      */         }
/* 3200 */         return Boolean.valueOf(bool);
/*      */       }
/* 3202 */     }, getContextFromAccessibleTable(paramAccessibleTable))).booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleTable getAccessibleTableRowHeader(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 3210 */     debugString(" #####  getAccessibleTableRowHeader called");
/* 3211 */     AccessibleTable localAccessibleTable = (AccessibleTable)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AccessibleTable call() throws Exception {
/* 3214 */         if (paramAccessibleContext != null) {
/* 3215 */           AccessibleTable localAccessibleTable = paramAccessibleContext.getAccessibleTable();
/* 3216 */           if (localAccessibleTable != null) {
/* 3217 */             return localAccessibleTable.getAccessibleRowHeader();
/*      */           }
/*      */         }
/* 3220 */         return null; } }, paramAccessibleContext);
/*      */     
/*      */ 
/* 3223 */     if (localAccessibleTable != null) {
/* 3224 */       this.hashtab.put(localAccessibleTable, paramAccessibleContext);
/*      */     }
/* 3226 */     return localAccessibleTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleTable getAccessibleTableColumnHeader(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 3234 */     debugString("##### getAccessibleTableColumnHeader");
/* 3235 */     if (paramAccessibleContext == null)
/* 3236 */       return null;
/* 3237 */     AccessibleTable localAccessibleTable = (AccessibleTable)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AccessibleTable call()
/*      */         throws Exception
/*      */       {
/* 3242 */         Accessible localAccessible1 = paramAccessibleContext.getAccessibleParent();
/* 3243 */         if (localAccessible1 != null) {
/* 3244 */           int i = paramAccessibleContext.getAccessibleIndexInParent();
/*      */           
/* 3246 */           Accessible localAccessible2 = localAccessible1.getAccessibleContext().getAccessibleChild(i);
/* 3247 */           if ((localAccessible2 instanceof JTable)) {
/* 3248 */             JTable localJTable = (JTable)localAccessible2;
/* 3249 */             if (localJTable.getTableHeader() == null) {
/* 3250 */               return null;
/*      */             }
/*      */           }
/*      */         }
/* 3254 */         AccessibleTable localAccessibleTable = paramAccessibleContext.getAccessibleTable();
/* 3255 */         if (localAccessibleTable != null) {
/* 3256 */           return localAccessibleTable.getAccessibleColumnHeader();
/*      */         }
/* 3258 */         return null; } }, paramAccessibleContext);
/*      */     
/*      */ 
/* 3261 */     if (localAccessibleTable != null) {
/* 3262 */       this.hashtab.put(localAccessibleTable, paramAccessibleContext);
/*      */     }
/* 3264 */     return localAccessibleTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleTableRowHeaderRowCount(AccessibleContext paramAccessibleContext)
/*      */   {
/* 3273 */     debugString(" #####  getAccessibleTableRowHeaderRowCount called");
/* 3274 */     if (paramAccessibleContext != null) {
/* 3275 */       final AccessibleTable localAccessibleTable = getAccessibleTableRowHeader(paramAccessibleContext);
/* 3276 */       if (localAccessibleTable != null) {
/* 3277 */         ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */           public Integer call() throws Exception {
/* 3280 */             if (localAccessibleTable != null) {
/* 3281 */               return Integer.valueOf(localAccessibleTable.getAccessibleRowCount());
/*      */             }
/* 3283 */             return Integer.valueOf(-1); } }, paramAccessibleContext)).intValue();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3288 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleTableRowHeaderColumnCount(AccessibleContext paramAccessibleContext)
/*      */   {
/* 3296 */     debugString(" #####  getAccessibleTableRowHeaderColumnCount called");
/* 3297 */     if (paramAccessibleContext != null) {
/* 3298 */       final AccessibleTable localAccessibleTable = getAccessibleTableRowHeader(paramAccessibleContext);
/* 3299 */       if (localAccessibleTable != null) {
/* 3300 */         ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */           public Integer call() throws Exception {
/* 3303 */             if (localAccessibleTable != null) {
/* 3304 */               return Integer.valueOf(localAccessibleTable.getAccessibleColumnCount());
/*      */             }
/* 3306 */             return Integer.valueOf(-1); } }, paramAccessibleContext)).intValue();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3311 */     debugString(" ##### getAccessibleTableRowHeaderColumnCount FAILED");
/* 3312 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleTableColumnHeaderRowCount(AccessibleContext paramAccessibleContext)
/*      */   {
/* 3321 */     debugString("##### getAccessibleTableColumnHeaderRowCount");
/* 3322 */     if (paramAccessibleContext != null) {
/* 3323 */       final AccessibleTable localAccessibleTable = getAccessibleTableColumnHeader(paramAccessibleContext);
/* 3324 */       if (localAccessibleTable != null) {
/* 3325 */         ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */           public Integer call() throws Exception {
/* 3328 */             if (localAccessibleTable != null) {
/* 3329 */               return Integer.valueOf(localAccessibleTable.getAccessibleRowCount());
/*      */             }
/* 3331 */             return Integer.valueOf(-1); } }, paramAccessibleContext)).intValue();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3336 */     debugString(" ##### getAccessibleTableColumnHeaderRowCount FAILED");
/* 3337 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleTableColumnHeaderColumnCount(AccessibleContext paramAccessibleContext)
/*      */   {
/* 3346 */     debugString("#####  getAccessibleTableColumnHeaderColumnCount");
/* 3347 */     if (paramAccessibleContext != null) {
/* 3348 */       final AccessibleTable localAccessibleTable = getAccessibleTableColumnHeader(paramAccessibleContext);
/* 3349 */       if (localAccessibleTable != null) {
/* 3350 */         ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */           public Integer call() throws Exception {
/* 3353 */             if (localAccessibleTable != null) {
/* 3354 */               return Integer.valueOf(localAccessibleTable.getAccessibleColumnCount());
/*      */             }
/* 3356 */             return Integer.valueOf(-1); } }, paramAccessibleContext)).intValue();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3361 */     debugString(" ##### getAccessibleTableColumnHeaderColumnCount FAILED");
/* 3362 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getAccessibleTableRowDescription(final AccessibleTable paramAccessibleTable, final int paramInt)
/*      */   {
/* 3370 */     (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AccessibleContext call() throws Exception {
/* 3373 */         if (paramAccessibleTable != null) {
/* 3374 */           Accessible localAccessible = paramAccessibleTable.getAccessibleRowDescription(paramInt);
/* 3375 */           if (localAccessible != null) {
/* 3376 */             return localAccessible.getAccessibleContext();
/*      */           }
/*      */         }
/* 3379 */         return null;
/*      */       }
/* 3381 */     }, getContextFromAccessibleTable(paramAccessibleTable));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getAccessibleTableColumnDescription(final AccessibleTable paramAccessibleTable, final int paramInt)
/*      */   {
/* 3389 */     if (paramAccessibleTable == null)
/* 3390 */       return null;
/* 3391 */     (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AccessibleContext call() throws Exception {
/* 3394 */         Accessible localAccessible = paramAccessibleTable.getAccessibleColumnDescription(paramInt);
/* 3395 */         if (localAccessible != null) {
/* 3396 */           return localAccessible.getAccessibleContext();
/*      */         }
/* 3398 */         return null;
/*      */       }
/* 3400 */     }, getContextFromAccessibleTable(paramAccessibleTable));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleTableRowSelectionCount(final AccessibleTable paramAccessibleTable)
/*      */   {
/* 3407 */     if (paramAccessibleTable != null) {
/* 3408 */       ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public Integer call() throws Exception {
/* 3411 */           int[] arrayOfInt = paramAccessibleTable.getSelectedAccessibleRows();
/* 3412 */           if (arrayOfInt != null) {
/* 3413 */             return Integer.valueOf(arrayOfInt.length);
/*      */           }
/* 3415 */           return Integer.valueOf(-1);
/*      */         }
/* 3417 */       }, getContextFromAccessibleTable(paramAccessibleTable))).intValue();
/*      */     }
/* 3419 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleTableRowSelections(final AccessibleTable paramAccessibleTable, final int paramInt)
/*      */   {
/* 3426 */     if (paramAccessibleTable != null) {
/* 3427 */       ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public Integer call() throws Exception {
/* 3430 */           int[] arrayOfInt = paramAccessibleTable.getSelectedAccessibleRows();
/* 3431 */           if (arrayOfInt.length > paramInt) {
/* 3432 */             return Integer.valueOf(arrayOfInt[paramInt]);
/*      */           }
/* 3434 */           return Integer.valueOf(-1);
/*      */         }
/* 3436 */       }, getContextFromAccessibleTable(paramAccessibleTable))).intValue();
/*      */     }
/* 3438 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isAccessibleTableRowSelected(final AccessibleTable paramAccessibleTable, final int paramInt)
/*      */   {
/* 3446 */     if (paramAccessibleTable == null)
/* 3447 */       return false;
/* 3448 */     ((Boolean)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Boolean call() throws Exception {
/* 3451 */         return Boolean.valueOf(paramAccessibleTable.isAccessibleRowSelected(paramInt));
/*      */       }
/* 3453 */     }, getContextFromAccessibleTable(paramAccessibleTable))).booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isAccessibleTableColumnSelected(final AccessibleTable paramAccessibleTable, final int paramInt)
/*      */   {
/* 3461 */     if (paramAccessibleTable == null)
/* 3462 */       return false;
/* 3463 */     ((Boolean)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Boolean call() throws Exception {
/* 3466 */         return Boolean.valueOf(paramAccessibleTable.isAccessibleColumnSelected(paramInt));
/*      */       }
/* 3468 */     }, getContextFromAccessibleTable(paramAccessibleTable))).booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleTableColumnSelectionCount(final AccessibleTable paramAccessibleTable)
/*      */   {
/* 3475 */     if (paramAccessibleTable == null)
/* 3476 */       return -1;
/* 3477 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 3480 */         int[] arrayOfInt = paramAccessibleTable.getSelectedAccessibleColumns();
/* 3481 */         if (arrayOfInt != null) {
/* 3482 */           return Integer.valueOf(arrayOfInt.length);
/*      */         }
/* 3484 */         return Integer.valueOf(-1);
/*      */       }
/* 3486 */     }, getContextFromAccessibleTable(paramAccessibleTable))).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleTableColumnSelections(final AccessibleTable paramAccessibleTable, final int paramInt)
/*      */   {
/* 3493 */     if (paramAccessibleTable == null)
/* 3494 */       return -1;
/* 3495 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 3498 */         int[] arrayOfInt = paramAccessibleTable.getSelectedAccessibleColumns();
/* 3499 */         if ((arrayOfInt != null) && (arrayOfInt.length > paramInt)) {
/* 3500 */           return Integer.valueOf(arrayOfInt[paramInt]);
/*      */         }
/* 3502 */         return Integer.valueOf(-1);
/*      */       }
/* 3504 */     }, getContextFromAccessibleTable(paramAccessibleTable))).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleTableRow(final AccessibleTable paramAccessibleTable, int paramInt)
/*      */   {
/* 3513 */     if (paramAccessibleTable == null)
/* 3514 */       return -1;
/* 3515 */     int i = ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 3518 */         return Integer.valueOf(paramAccessibleTable.getAccessibleColumnCount());
/*      */       }
/* 3520 */     }, getContextFromAccessibleTable(paramAccessibleTable))).intValue();
/* 3521 */     return paramInt / i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleTableColumn(final AccessibleTable paramAccessibleTable, int paramInt)
/*      */   {
/* 3528 */     if (paramAccessibleTable == null)
/* 3529 */       return -1;
/* 3530 */     int i = ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 3533 */         return Integer.valueOf(paramAccessibleTable.getAccessibleColumnCount());
/*      */       }
/* 3535 */     }, getContextFromAccessibleTable(paramAccessibleTable))).intValue();
/* 3536 */     return paramInt % i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleTableIndex(final AccessibleTable paramAccessibleTable, int paramInt1, int paramInt2)
/*      */   {
/* 3544 */     if (paramAccessibleTable == null)
/* 3545 */       return -1;
/* 3546 */     int i = ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 3549 */         return Integer.valueOf(paramAccessibleTable.getAccessibleColumnCount());
/*      */       }
/* 3551 */     }, getContextFromAccessibleTable(paramAccessibleTable))).intValue();
/* 3552 */     return paramInt1 * i + paramInt2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleRelationCount(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 3562 */     String str = getJavaVersionProperty();
/* 3563 */     if ((str != null) && (str.compareTo("1.3") >= 0) && 
/* 3564 */       (paramAccessibleContext != null)) {
/* 3565 */       AccessibleRelationSet localAccessibleRelationSet = (AccessibleRelationSet)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */ 
/* 3568 */         public AccessibleRelationSet call() throws Exception { return paramAccessibleContext.getAccessibleRelationSet(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/* 3571 */       if (localAccessibleRelationSet != null) {
/* 3572 */         return localAccessibleRelationSet.size();
/*      */       }
/*      */     }
/* 3575 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getAccessibleRelationKey(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 3583 */     (String)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public String call() throws Exception {
/* 3586 */         if (paramAccessibleContext != null) {
/* 3587 */           AccessibleRelationSet localAccessibleRelationSet = paramAccessibleContext.getAccessibleRelationSet();
/* 3588 */           if (localAccessibleRelationSet != null) {
/* 3589 */             AccessibleRelation[] arrayOfAccessibleRelation = localAccessibleRelationSet.toArray();
/* 3590 */             if ((arrayOfAccessibleRelation != null) && (paramInt >= 0) && (paramInt < arrayOfAccessibleRelation.length)) {
/* 3591 */               return arrayOfAccessibleRelation[paramInt].getKey();
/*      */             }
/*      */           }
/*      */         }
/* 3595 */         return null; } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleRelationTargetCount(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 3605 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 3608 */         if (paramAccessibleContext != null) {
/* 3609 */           AccessibleRelationSet localAccessibleRelationSet = paramAccessibleContext.getAccessibleRelationSet();
/* 3610 */           if (localAccessibleRelationSet != null) {
/* 3611 */             AccessibleRelation[] arrayOfAccessibleRelation = localAccessibleRelationSet.toArray();
/* 3612 */             if ((arrayOfAccessibleRelation != null) && (paramInt >= 0) && (paramInt < arrayOfAccessibleRelation.length)) {
/* 3613 */               Object[] arrayOfObject = arrayOfAccessibleRelation[paramInt].getTarget();
/* 3614 */               return Integer.valueOf(arrayOfObject.length);
/*      */             }
/*      */           }
/*      */         }
/* 3618 */         return Integer.valueOf(-1); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getAccessibleRelationTarget(final AccessibleContext paramAccessibleContext, final int paramInt1, final int paramInt2)
/*      */   {
/* 3629 */     debugString("***** getAccessibleRelationTarget");
/* 3630 */     (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AccessibleContext call() throws Exception {
/* 3633 */         if (paramAccessibleContext != null) {
/* 3634 */           AccessibleRelationSet localAccessibleRelationSet = paramAccessibleContext.getAccessibleRelationSet();
/* 3635 */           if (localAccessibleRelationSet != null) {
/* 3636 */             AccessibleRelation[] arrayOfAccessibleRelation = localAccessibleRelationSet.toArray();
/* 3637 */             if ((arrayOfAccessibleRelation != null) && (paramInt1 >= 0) && (paramInt1 < arrayOfAccessibleRelation.length)) {
/* 3638 */               Object[] arrayOfObject = arrayOfAccessibleRelation[paramInt1].getTarget();
/* 3639 */               if (arrayOfObject != null) if (((paramInt2 >= 0 ? 1 : 0) & (paramInt2 < arrayOfObject.length ? 1 : 0)) != 0) {
/* 3640 */                   Object localObject = arrayOfObject[paramInt2];
/* 3641 */                   if ((localObject instanceof Accessible)) {
/* 3642 */                     return ((Accessible)localObject).getAccessibleContext();
/*      */                   }
/*      */                 }
/*      */             }
/*      */           }
/*      */         }
/* 3648 */         return null; } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3655 */   private Map<AccessibleHypertext, AccessibleContext> hyperTextContextMap = new java.util.WeakHashMap();
/* 3656 */   private Map<AccessibleHyperlink, AccessibleContext> hyperLinkContextMap = new java.util.WeakHashMap();
/*      */   private int _visibleChildrenCount;
/*      */   private AccessibleContext _visibleChild;
/*      */   private int _currentVisibleIndex;
/*      */   private boolean _foundVisibleChild;
/*      */   
/* 3662 */   private AccessibleHypertext getAccessibleHypertext(final AccessibleContext paramAccessibleContext) { debugString("getAccessibleHyperlink");
/* 3663 */     if (paramAccessibleContext == null)
/* 3664 */       return null;
/* 3665 */     AccessibleHypertext localAccessibleHypertext = (AccessibleHypertext)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AccessibleHypertext call() throws Exception {
/* 3668 */         AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 3669 */         if (!(localAccessibleText instanceof AccessibleHypertext)) {
/* 3670 */           return null;
/*      */         }
/* 3672 */         return (AccessibleHypertext)localAccessibleText; } }, paramAccessibleContext);
/*      */     
/*      */ 
/* 3675 */     this.hyperTextContextMap.put(localAccessibleHypertext, paramAccessibleContext);
/* 3676 */     return localAccessibleHypertext;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleHyperlinkCount(AccessibleContext paramAccessibleContext)
/*      */   {
/* 3683 */     debugString("getAccessibleHyperlinkCount");
/* 3684 */     if (paramAccessibleContext == null) {
/* 3685 */       return 0;
/*      */     }
/* 3687 */     final AccessibleHypertext localAccessibleHypertext = getAccessibleHypertext(paramAccessibleContext);
/* 3688 */     if (localAccessibleHypertext == null) {
/* 3689 */       return 0;
/*      */     }
/*      */     
/* 3692 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */ 
/* 3695 */       public Integer call() throws Exception { return Integer.valueOf(localAccessibleHypertext.getLinkCount()); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleHyperlink getAccessibleHyperlink(final AccessibleHypertext paramAccessibleHypertext, final int paramInt)
/*      */   {
/* 3704 */     debugString("getAccessibleHyperlink");
/* 3705 */     if (paramAccessibleHypertext == null) {
/* 3706 */       return null;
/*      */     }
/* 3708 */     AccessibleContext localAccessibleContext = (AccessibleContext)this.hyperTextContextMap.get(paramAccessibleHypertext);
/* 3709 */     if ((paramInt < 0) || 
/* 3710 */       (paramInt >= ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception
/*      */       {
/* 3713 */         return Integer.valueOf(paramAccessibleHypertext.getLinkCount());
/*      */       }
/* 3710 */     }, localAccessibleContext)).intValue()))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3716 */       return null;
/*      */     }
/* 3718 */     AccessibleHyperlink localAccessibleHyperlink = (AccessibleHyperlink)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AccessibleHyperlink call() throws Exception {
/* 3721 */         AccessibleHyperlink localAccessibleHyperlink = paramAccessibleHypertext.getLink(paramInt);
/* 3722 */         if ((localAccessibleHyperlink == null) || (!localAccessibleHyperlink.isValid())) {
/* 3723 */           return null;
/*      */         }
/* 3725 */         return localAccessibleHyperlink; } }, localAccessibleContext);
/*      */     
/*      */ 
/* 3728 */     this.hyperLinkContextMap.put(localAccessibleHyperlink, localAccessibleContext);
/* 3729 */     return localAccessibleHyperlink;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getAccessibleHyperlinkText(final AccessibleHyperlink paramAccessibleHyperlink)
/*      */   {
/* 3736 */     debugString("getAccessibleHyperlinkText");
/* 3737 */     if (paramAccessibleHyperlink == null) {
/* 3738 */       return null;
/*      */     }
/* 3740 */     (String)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public String call() throws Exception {
/* 3743 */         String str = paramAccessibleHyperlink.getAccessibleActionDescription(0);
/* 3744 */         if (str != null) {
/* 3745 */           return str.toString();
/*      */         }
/* 3747 */         return null;
/*      */       }
/* 3749 */     }, (AccessibleContext)this.hyperLinkContextMap.get(paramAccessibleHyperlink));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getAccessibleHyperlinkURL(final AccessibleHyperlink paramAccessibleHyperlink)
/*      */   {
/* 3756 */     debugString("getAccessibleHyperlinkURL");
/* 3757 */     if (paramAccessibleHyperlink == null) {
/* 3758 */       return null;
/*      */     }
/* 3760 */     (String)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public String call() throws Exception {
/* 3763 */         Object localObject = paramAccessibleHyperlink.getAccessibleActionObject(0);
/* 3764 */         if (localObject != null) {
/* 3765 */           return localObject.toString();
/*      */         }
/* 3767 */         return null;
/*      */       }
/*      */       
/* 3770 */     }, (AccessibleContext)this.hyperLinkContextMap.get(paramAccessibleHyperlink));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleHyperlinkStartIndex(final AccessibleHyperlink paramAccessibleHyperlink)
/*      */   {
/* 3777 */     debugString("getAccessibleHyperlinkStartIndex");
/* 3778 */     if (paramAccessibleHyperlink == null) {
/* 3779 */       return -1;
/*      */     }
/* 3781 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 3784 */         return Integer.valueOf(paramAccessibleHyperlink.getStartIndex());
/*      */       }
/* 3786 */     }, (AccessibleContext)this.hyperLinkContextMap.get(paramAccessibleHyperlink))).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleHyperlinkEndIndex(final AccessibleHyperlink paramAccessibleHyperlink)
/*      */   {
/* 3793 */     debugString("getAccessibleHyperlinkEndIndex");
/* 3794 */     if (paramAccessibleHyperlink == null) {
/* 3795 */       return -1;
/*      */     }
/* 3797 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 3800 */         return Integer.valueOf(paramAccessibleHyperlink.getEndIndex());
/*      */       }
/* 3802 */     }, (AccessibleContext)this.hyperLinkContextMap.get(paramAccessibleHyperlink))).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleHypertextLinkIndex(final AccessibleHypertext paramAccessibleHypertext, final int paramInt)
/*      */   {
/* 3811 */     debugString("getAccessibleHypertextLinkIndex: charIndex = " + paramInt);
/* 3812 */     if (paramAccessibleHypertext == null) {
/* 3813 */       return -1;
/*      */     }
/* 3815 */     int i = ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 3818 */         return Integer.valueOf(paramAccessibleHypertext.getLinkIndex(paramInt));
/*      */       }
/* 3820 */     }, (AccessibleContext)this.hyperTextContextMap.get(paramAccessibleHypertext))).intValue();
/* 3821 */     debugString("getAccessibleHypertextLinkIndex returning " + i);
/* 3822 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean activateAccessibleHyperlink(AccessibleContext paramAccessibleContext, final AccessibleHyperlink paramAccessibleHyperlink)
/*      */   {
/* 3831 */     if (paramAccessibleHyperlink == null) {
/* 3832 */       return false;
/*      */     }
/* 3834 */     boolean bool = ((Boolean)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */ 
/* 3837 */       public Boolean call() throws Exception { return Boolean.valueOf(paramAccessibleHyperlink.doAccessibleAction(0)); } }, paramAccessibleContext)).booleanValue();
/*      */     
/*      */ 
/* 3840 */     debugString("activateAccessibleHyperlink: returning = " + bool);
/* 3841 */     return bool;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private KeyStroke getMnemonic(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 3851 */     if (paramAccessibleContext == null)
/* 3852 */       return null;
/* 3853 */     (KeyStroke)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public KeyStroke call() throws Exception {
/* 3856 */         AccessibleComponent localAccessibleComponent = paramAccessibleContext.getAccessibleComponent();
/* 3857 */         if (!(localAccessibleComponent instanceof javax.accessibility.AccessibleExtendedComponent)) {
/* 3858 */           return null;
/*      */         }
/* 3860 */         javax.accessibility.AccessibleExtendedComponent localAccessibleExtendedComponent = (javax.accessibility.AccessibleExtendedComponent)localAccessibleComponent;
/* 3861 */         if (localAccessibleExtendedComponent != null) {
/* 3862 */           javax.accessibility.AccessibleKeyBinding localAccessibleKeyBinding = localAccessibleExtendedComponent.getAccessibleKeyBinding();
/* 3863 */           if (localAccessibleKeyBinding != null) {
/* 3864 */             Object localObject = localAccessibleKeyBinding.getAccessibleKeyBinding(0);
/* 3865 */             if ((localObject instanceof KeyStroke)) {
/* 3866 */               return (KeyStroke)localObject;
/*      */             }
/*      */           }
/*      */         }
/* 3870 */         return null; } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private KeyStroke getAccelerator(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 3881 */     if (paramAccessibleContext == null)
/* 3882 */       return null;
/* 3883 */     (KeyStroke)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public KeyStroke call() throws Exception {
/* 3886 */         Accessible localAccessible1 = paramAccessibleContext.getAccessibleParent();
/* 3887 */         if ((localAccessible1 instanceof Accessible)) {
/* 3888 */           int i = paramAccessibleContext.getAccessibleIndexInParent();
/*      */           
/* 3890 */           Accessible localAccessible2 = localAccessible1.getAccessibleContext().getAccessibleChild(i);
/* 3891 */           if ((localAccessible2 instanceof javax.swing.JMenuItem)) {
/* 3892 */             javax.swing.JMenuItem localJMenuItem = (javax.swing.JMenuItem)localAccessible2;
/* 3893 */             if (localJMenuItem == null)
/* 3894 */               return null;
/* 3895 */             KeyStroke localKeyStroke = localJMenuItem.getAccelerator();
/* 3896 */             return localKeyStroke;
/*      */           }
/*      */         }
/* 3899 */         return null; } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int fKeyNumber(KeyStroke paramKeyStroke)
/*      */   {
/* 3908 */     if (paramKeyStroke == null)
/* 3909 */       return 0;
/* 3910 */     int i = 0;
/* 3911 */     String str1 = java.awt.event.KeyEvent.getKeyText(paramKeyStroke.getKeyCode());
/* 3912 */     if ((str1 != null) && ((str1.length() == 2) || (str1.length() == 3))) {
/* 3913 */       String str2 = str1.substring(0, 1);
/* 3914 */       if (str2.equals("F")) {
/*      */         try {
/* 3916 */           int j = Integer.parseInt(str1.substring(1));
/* 3917 */           if ((j >= 1) && (j <= 24)) {
/* 3918 */             i = j;
/*      */           }
/*      */         }
/*      */         catch (Exception localException) {}
/*      */       }
/*      */     }
/* 3924 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int controlCode(KeyStroke paramKeyStroke)
/*      */   {
/* 3931 */     if (paramKeyStroke == null)
/* 3932 */       return 0;
/* 3933 */     int i = paramKeyStroke.getKeyCode();
/* 3934 */     switch (i) {
/*      */     case 8: 
/*      */     case 33: 
/*      */     case 34: 
/*      */     case 35: 
/*      */     case 36: 
/*      */     case 37: 
/*      */     case 38: 
/*      */     case 39: 
/*      */     case 40: 
/*      */     case 127: 
/*      */     case 155: 
/*      */     case 224: 
/*      */     case 225: 
/*      */     case 226: 
/*      */     case 227: 
/*      */       break;
/*      */     default: 
/* 3952 */       i = 0;
/*      */     }
/*      */     
/* 3955 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private char getKeyChar(KeyStroke paramKeyStroke)
/*      */   {
/* 3963 */     if (paramKeyStroke == null)
/* 3964 */       return '\000';
/* 3965 */     int i = fKeyNumber(paramKeyStroke);
/* 3966 */     if (i != 0)
/*      */     {
/* 3968 */       debugString("   Shortcut is: F" + i);
/* 3969 */       return (char)i;
/*      */     }
/*      */     
/* 3972 */     int j = controlCode(paramKeyStroke);
/* 3973 */     if (j != 0) {
/* 3974 */       debugString("   Shortcut is control character: " + Integer.toHexString(j));
/* 3975 */       return (char)j;
/*      */     }
/* 3977 */     String str = java.awt.event.KeyEvent.getKeyText(paramKeyStroke.getKeyCode());
/* 3978 */     debugString("   Shortcut is: " + str);
/* 3979 */     if ((str != null) || (str.length() > 0)) {
/* 3980 */       CharSequence localCharSequence = str.subSequence(0, 1);
/* 3981 */       if ((localCharSequence != null) || (localCharSequence.length() > 0)) {
/* 3982 */         return localCharSequence.charAt(0);
/*      */       }
/*      */     }
/* 3985 */     return '\000';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getModifiers(KeyStroke paramKeyStroke)
/*      */   {
/* 3992 */     if (paramKeyStroke == null)
/* 3993 */       return 0;
/* 3994 */     debugString("In AccessBridge.getModifiers");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3999 */     int i = 0;
/*      */     
/* 4001 */     if (fKeyNumber(paramKeyStroke) != 0) {
/* 4002 */       i |= 0x100;
/*      */     }
/*      */     
/* 4005 */     if (controlCode(paramKeyStroke) != 0) {
/* 4006 */       i |= 0x200;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4014 */     java.util.StringTokenizer localStringTokenizer = new java.util.StringTokenizer(paramKeyStroke.toString());
/* 4015 */     while (localStringTokenizer.hasMoreTokens()) {
/* 4016 */       String str = localStringTokenizer.nextToken();
/*      */       
/*      */ 
/*      */ 
/* 4020 */       if (str.startsWith("met")) {
/* 4021 */         debugString("   found meta");
/* 4022 */         i |= 0x4;
/*      */       }
/* 4024 */       if (str.startsWith("ctr")) {
/* 4025 */         debugString("   found ctrl");
/* 4026 */         i |= 0x2;
/*      */       }
/* 4028 */       if (str.startsWith("alt")) {
/* 4029 */         debugString("   found alt");
/* 4030 */         i |= 0x8;
/*      */       }
/* 4032 */       if (str.startsWith("shi")) {
/* 4033 */         debugString("   found shift");
/* 4034 */         i |= 0x1;
/*      */       }
/*      */     }
/* 4037 */     debugString("   returning modifiers: 0x" + Integer.toHexString(i));
/* 4038 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleKeyBindingsCount(AccessibleContext paramAccessibleContext)
/*      */   {
/* 4045 */     if ((paramAccessibleContext == null) || (!this.runningOnJDK1_4))
/* 4046 */       return 0;
/* 4047 */     int i = 0;
/*      */     
/* 4049 */     if (getMnemonic(paramAccessibleContext) != null) {
/* 4050 */       i++;
/*      */     }
/* 4052 */     if (getAccelerator(paramAccessibleContext) != null) {
/* 4053 */       i++;
/*      */     }
/* 4055 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private char getAccessibleKeyBindingChar(AccessibleContext paramAccessibleContext, int paramInt)
/*      */   {
/* 4062 */     if ((paramAccessibleContext == null) || (!this.runningOnJDK1_4))
/* 4063 */       return '\000';
/* 4064 */     KeyStroke localKeyStroke; if ((paramInt == 0) && (getMnemonic(paramAccessibleContext) == null)) {
/* 4065 */       localKeyStroke = getAccelerator(paramAccessibleContext);
/* 4066 */       if (localKeyStroke != null) {
/* 4067 */         return getKeyChar(localKeyStroke);
/*      */       }
/*      */     }
/* 4070 */     if (paramInt == 0) {
/* 4071 */       localKeyStroke = getMnemonic(paramAccessibleContext);
/* 4072 */       if (localKeyStroke != null) {
/* 4073 */         return getKeyChar(localKeyStroke);
/*      */       }
/* 4075 */     } else if (paramInt == 1) {
/* 4076 */       localKeyStroke = getAccelerator(paramAccessibleContext);
/* 4077 */       if (localKeyStroke != null) {
/* 4078 */         return getKeyChar(localKeyStroke);
/*      */       }
/*      */     }
/* 4081 */     return '\000';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getAccessibleKeyBindingModifiers(AccessibleContext paramAccessibleContext, int paramInt)
/*      */   {
/* 4088 */     if ((paramAccessibleContext == null) || (!this.runningOnJDK1_4))
/* 4089 */       return 0;
/* 4090 */     KeyStroke localKeyStroke; if ((paramInt == 0) && (getMnemonic(paramAccessibleContext) == null)) {
/* 4091 */       localKeyStroke = getAccelerator(paramAccessibleContext);
/* 4092 */       if (localKeyStroke != null) {
/* 4093 */         return getModifiers(localKeyStroke);
/*      */       }
/*      */     }
/* 4096 */     if (paramInt == 0) {
/* 4097 */       localKeyStroke = getMnemonic(paramAccessibleContext);
/* 4098 */       if (localKeyStroke != null) {
/* 4099 */         return getModifiers(localKeyStroke);
/*      */       }
/* 4101 */     } else if (paramInt == 1) {
/* 4102 */       localKeyStroke = getAccelerator(paramAccessibleContext);
/* 4103 */       if (localKeyStroke != null) {
/* 4104 */         return getModifiers(localKeyStroke);
/*      */       }
/*      */     }
/* 4107 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleIconsCount(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 4116 */     debugString("getAccessibleIconsCount");
/* 4117 */     if (paramAccessibleContext == null) {
/* 4118 */       return 0;
/*      */     }
/* 4120 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 4123 */         AccessibleIcon[] arrayOfAccessibleIcon = paramAccessibleContext.getAccessibleIcon();
/* 4124 */         if (arrayOfAccessibleIcon == null) {
/* 4125 */           return Integer.valueOf(0);
/*      */         }
/* 4127 */         return Integer.valueOf(arrayOfAccessibleIcon.length); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getAccessibleIconDescription(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 4136 */     debugString("getAccessibleIconDescription: index = " + paramInt);
/* 4137 */     if (paramAccessibleContext == null) {
/* 4138 */       return null;
/*      */     }
/* 4140 */     (String)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public String call() throws Exception {
/* 4143 */         AccessibleIcon[] arrayOfAccessibleIcon = paramAccessibleContext.getAccessibleIcon();
/* 4144 */         if ((arrayOfAccessibleIcon == null) || (paramInt < 0) || (paramInt >= arrayOfAccessibleIcon.length)) {
/* 4145 */           return null;
/*      */         }
/* 4147 */         return arrayOfAccessibleIcon[paramInt].getAccessibleIconDescription(); } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleIconHeight(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 4156 */     debugString("getAccessibleIconHeight: index = " + paramInt);
/* 4157 */     if (paramAccessibleContext == null) {
/* 4158 */       return 0;
/*      */     }
/* 4160 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 4163 */         AccessibleIcon[] arrayOfAccessibleIcon = paramAccessibleContext.getAccessibleIcon();
/* 4164 */         if ((arrayOfAccessibleIcon == null) || (paramInt < 0) || (paramInt >= arrayOfAccessibleIcon.length)) {
/* 4165 */           return Integer.valueOf(0);
/*      */         }
/* 4167 */         return Integer.valueOf(arrayOfAccessibleIcon[paramInt].getAccessibleIconHeight()); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleIconWidth(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 4176 */     debugString("getAccessibleIconWidth: index = " + paramInt);
/* 4177 */     if (paramAccessibleContext == null) {
/* 4178 */       return 0;
/*      */     }
/* 4180 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 4183 */         AccessibleIcon[] arrayOfAccessibleIcon = paramAccessibleContext.getAccessibleIcon();
/* 4184 */         if ((arrayOfAccessibleIcon == null) || (paramInt < 0) || (paramInt >= arrayOfAccessibleIcon.length)) {
/* 4185 */           return Integer.valueOf(0);
/*      */         }
/* 4187 */         return Integer.valueOf(arrayOfAccessibleIcon[paramInt].getAccessibleIconWidth()); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAccessibleActionsCount(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 4198 */     debugString("getAccessibleActionsCount");
/* 4199 */     if (paramAccessibleContext == null) {
/* 4200 */       return 0;
/*      */     }
/* 4202 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 4205 */         AccessibleAction localAccessibleAction = paramAccessibleContext.getAccessibleAction();
/* 4206 */         if (localAccessibleAction == null)
/* 4207 */           return Integer.valueOf(0);
/* 4208 */         return Integer.valueOf(localAccessibleAction.getAccessibleActionCount()); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getAccessibleActionName(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 4217 */     debugString("getAccessibleActionName: index = " + paramInt);
/* 4218 */     if (paramAccessibleContext == null) {
/* 4219 */       return null;
/*      */     }
/* 4221 */     (String)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public String call() throws Exception {
/* 4224 */         AccessibleAction localAccessibleAction = paramAccessibleContext.getAccessibleAction();
/* 4225 */         if (localAccessibleAction == null) {
/* 4226 */           return null;
/*      */         }
/* 4228 */         return localAccessibleAction.getAccessibleActionDescription(paramInt); } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean doAccessibleActions(final AccessibleContext paramAccessibleContext, final String paramString)
/*      */   {
/* 4236 */     debugString("doAccessibleActions: action name = " + paramString);
/* 4237 */     if ((paramAccessibleContext == null) || (paramString == null)) {
/* 4238 */       return false;
/*      */     }
/* 4240 */     ((Boolean)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Boolean call() throws Exception {
/* 4243 */         AccessibleAction localAccessibleAction = paramAccessibleContext.getAccessibleAction();
/* 4244 */         if (localAccessibleAction == null) {
/* 4245 */           return Boolean.valueOf(false);
/*      */         }
/* 4247 */         int i = -1;
/* 4248 */         int j = localAccessibleAction.getAccessibleActionCount();
/* 4249 */         for (int k = 0; k < j; k++) {
/* 4250 */           String str = localAccessibleAction.getAccessibleActionDescription(k);
/* 4251 */           if (paramString.equals(str)) {
/* 4252 */             i = k;
/* 4253 */             break;
/*      */           }
/*      */         }
/* 4256 */         if (i == -1) {
/* 4257 */           return Boolean.valueOf(false);
/*      */         }
/* 4259 */         boolean bool = localAccessibleAction.doAccessibleAction(i);
/* 4260 */         return Boolean.valueOf(bool); } }, paramAccessibleContext)).booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean setTextContents(final AccessibleContext paramAccessibleContext, final String paramString)
/*      */   {
/* 4274 */     debugString("setTextContents: ac = " + paramAccessibleContext + "; text = " + paramString);
/*      */     
/* 4276 */     if (!(paramAccessibleContext instanceof AccessibleEditableText)) {
/* 4277 */       debugString("   ac not instanceof AccessibleEditableText: " + paramAccessibleContext);
/* 4278 */       return false;
/*      */     }
/* 4280 */     if (paramString == null) {
/* 4281 */       debugString("   text is null");
/* 4282 */       return false;
/*      */     }
/*      */     
/* 4285 */     ((Boolean)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Boolean call() throws Exception
/*      */       {
/* 4289 */         AccessibleStateSet localAccessibleStateSet = paramAccessibleContext.getAccessibleStateSet();
/* 4290 */         if (!localAccessibleStateSet.contains(AccessibleState.ENABLED)) {
/* 4291 */           return Boolean.valueOf(false);
/*      */         }
/* 4293 */         ((AccessibleEditableText)paramAccessibleContext).setTextContents(paramString);
/* 4294 */         return Boolean.valueOf(true); } }, paramAccessibleContext)).booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getInternalFrame(AccessibleContext paramAccessibleContext)
/*      */   {
/* 4308 */     return getParentWithRole(paramAccessibleContext, AccessibleRole.INTERNAL_FRAME.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getTopLevelObject(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 4318 */     debugString("getTopLevelObject; ac = " + paramAccessibleContext);
/* 4319 */     if (paramAccessibleContext == null) {
/* 4320 */       return null;
/*      */     }
/* 4322 */     (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AccessibleContext call() throws Exception {
/* 4325 */         if (paramAccessibleContext.getAccessibleRole() == AccessibleRole.DIALOG)
/*      */         {
/* 4327 */           return paramAccessibleContext;
/*      */         }
/*      */         
/* 4330 */         Object localObject1 = paramAccessibleContext.getAccessibleParent();
/* 4331 */         if (localObject1 == null) {
/* 4332 */           return paramAccessibleContext;
/*      */         }
/* 4334 */         Object localObject2 = localObject1;
/* 4335 */         while ((localObject2 != null) && (((Accessible)localObject2).getAccessibleContext() != null)) {
/* 4336 */           AccessibleContext localAccessibleContext = ((Accessible)localObject2).getAccessibleContext();
/* 4337 */           if ((localAccessibleContext != null) && (localAccessibleContext.getAccessibleRole() == AccessibleRole.DIALOG))
/*      */           {
/* 4339 */             return localAccessibleContext;
/*      */           }
/* 4341 */           localObject1 = localObject2;
/* 4342 */           localObject2 = ((Accessible)localObject1).getAccessibleContext().getAccessibleParent();
/*      */         }
/* 4344 */         return ((Accessible)localObject1).getAccessibleContext(); } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getParentWithRole(final AccessibleContext paramAccessibleContext, final String paramString)
/*      */   {
/* 4355 */     debugString("getParentWithRole; ac = " + paramAccessibleContext);
/* 4356 */     debugString("role = " + paramString);
/* 4357 */     if ((paramAccessibleContext == null) || (paramString == null)) {
/* 4358 */       return null;
/*      */     }
/*      */     
/* 4361 */     (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AccessibleContext call() throws Exception {
/* 4364 */         AccessibleRole localAccessibleRole1 = (AccessibleRole)AccessBridge.this.accessibleRoleMap.get(paramString);
/* 4365 */         if (localAccessibleRole1 == null) {
/* 4366 */           return paramAccessibleContext;
/*      */         }
/*      */         
/* 4369 */         Object localObject1 = paramAccessibleContext.getAccessibleParent();
/* 4370 */         if ((localObject1 == null) && (paramAccessibleContext.getAccessibleRole() == localAccessibleRole1)) {
/* 4371 */           return paramAccessibleContext;
/*      */         }
/*      */         
/* 4374 */         Object localObject2 = localObject1;
/* 4375 */         AccessibleContext localAccessibleContext = null;
/*      */         
/* 4377 */         while ((localObject2 != null) && ((localAccessibleContext = ((Accessible)localObject2).getAccessibleContext()) != null)) {
/* 4378 */           AccessibleRole localAccessibleRole2 = localAccessibleContext.getAccessibleRole();
/* 4379 */           if (localAccessibleRole2 == localAccessibleRole1)
/*      */           {
/* 4381 */             return localAccessibleContext;
/*      */           }
/* 4383 */           localObject1 = localObject2;
/* 4384 */           localObject2 = ((Accessible)localObject1).getAccessibleContext().getAccessibleParent();
/*      */         }
/*      */         
/* 4387 */         return null; } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getParentWithRoleElseRoot(AccessibleContext paramAccessibleContext, String paramString)
/*      */   {
/* 4399 */     AccessibleContext localAccessibleContext = getParentWithRole(paramAccessibleContext, paramString);
/* 4400 */     if (localAccessibleContext == null) {
/* 4401 */       localAccessibleContext = getTopLevelObject(paramAccessibleContext);
/*      */     }
/* 4403 */     return localAccessibleContext;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getObjectDepth(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 4412 */     debugString("getObjectDepth: ac = " + paramAccessibleContext);
/*      */     
/* 4414 */     if (paramAccessibleContext == null) {
/* 4415 */       return -1;
/*      */     }
/* 4417 */     ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Integer call() throws Exception {
/* 4420 */         int i = 0;
/* 4421 */         Object localObject1 = paramAccessibleContext.getAccessibleParent();
/* 4422 */         if (localObject1 == null) {
/* 4423 */           return Integer.valueOf(i);
/*      */         }
/* 4425 */         Object localObject2 = localObject1;
/* 4426 */         while ((localObject2 != null) && (((Accessible)localObject2).getAccessibleContext() != null)) {
/* 4427 */           localObject1 = localObject2;
/* 4428 */           localObject2 = ((Accessible)localObject1).getAccessibleContext().getAccessibleParent();
/* 4429 */           i++;
/*      */         }
/* 4431 */         return Integer.valueOf(i); } }, paramAccessibleContext)).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getActiveDescendent(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 4441 */     debugString("getActiveDescendent: ac = " + paramAccessibleContext);
/* 4442 */     if (paramAccessibleContext == null) {
/* 4443 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 4447 */     final Accessible localAccessible1 = (Accessible)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */ 
/* 4450 */       public Accessible call() throws Exception { return paramAccessibleContext.getAccessibleParent(); } }, paramAccessibleContext);
/*      */     
/*      */ 
/*      */ 
/* 4454 */     if (localAccessible1 != null) {
/* 4455 */       Accessible localAccessible2 = (Accessible)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public Accessible call() throws Exception {
/* 4458 */           int i = paramAccessibleContext.getAccessibleIndexInParent();
/* 4459 */           return localAccessible1.getAccessibleContext().getAccessibleChild(i); } }, paramAccessibleContext);
/*      */       
/*      */ 
/*      */ 
/* 4463 */       if ((localAccessible2 instanceof JTree))
/*      */       {
/* 4465 */         final JTree localJTree = (JTree)localAccessible2;
/* 4466 */         (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */ 
/*      */           public AccessibleContext call() throws Exception {
/* 4470 */             return new AccessBridge.AccessibleJTreeNode(AccessBridge.this, localJTree, localJTree.getSelectionPath(), null); } }, localAccessible2);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4477 */     (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public AccessibleContext call() throws Exception {
/* 4480 */         AccessibleSelection localAccessibleSelection = paramAccessibleContext.getAccessibleSelection();
/* 4481 */         if (localAccessibleSelection == null) {
/* 4482 */           return null;
/*      */         }
/*      */         
/* 4485 */         if (localAccessibleSelection.getAccessibleSelectionCount() != 1) {
/* 4486 */           return null;
/*      */         }
/* 4488 */         Accessible localAccessible = localAccessibleSelection.getAccessibleSelection(0);
/* 4489 */         if (localAccessible == null) {
/* 4490 */           return null;
/*      */         }
/* 4492 */         return localAccessible.getAccessibleContext(); } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getJAWSAccessibleName(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 4509 */     debugString("getJAWSAccessibleName");
/* 4510 */     if (paramAccessibleContext == null) {
/* 4511 */       return null;
/*      */     }
/*      */     
/* 4514 */     (String)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */ 
/* 4517 */       public String call() throws Exception { return paramAccessibleContext.getAccessibleName(); } }, paramAccessibleContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean requestFocus(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 4528 */     debugString("requestFocus");
/* 4529 */     if (paramAccessibleContext == null) {
/* 4530 */       return false;
/*      */     }
/* 4532 */     ((Boolean)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Boolean call() throws Exception {
/* 4535 */         AccessibleComponent localAccessibleComponent = paramAccessibleContext.getAccessibleComponent();
/* 4536 */         if (localAccessibleComponent == null) {
/* 4537 */           return Boolean.valueOf(false);
/*      */         }
/* 4539 */         localAccessibleComponent.requestFocus();
/* 4540 */         return Boolean.valueOf(paramAccessibleContext.getAccessibleStateSet().contains(AccessibleState.FOCUSED)); } }, paramAccessibleContext)).booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean selectTextRange(final AccessibleContext paramAccessibleContext, final int paramInt1, final int paramInt2)
/*      */   {
/* 4553 */     debugString("selectTextRange: start = " + paramInt1 + "; end = " + paramInt2);
/* 4554 */     if (paramAccessibleContext == null) {
/* 4555 */       return false;
/*      */     }
/* 4557 */     ((Boolean)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Boolean call() throws Exception {
/* 4560 */         AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 4561 */         if (!(localAccessibleText instanceof AccessibleEditableText)) {
/* 4562 */           return Boolean.valueOf(false);
/*      */         }
/* 4564 */         ((AccessibleEditableText)localAccessibleText).selectText(paramInt1, paramInt2);
/*      */         
/*      */ 
/* 4567 */         boolean bool = (localAccessibleText.getSelectionStart() == paramInt1) && (localAccessibleText.getSelectionEnd() == paramInt2);
/* 4568 */         return Boolean.valueOf(bool); } }, paramAccessibleContext)).booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean setCaretPosition(final AccessibleContext paramAccessibleContext, final int paramInt)
/*      */   {
/* 4579 */     debugString("setCaretPosition: position = " + paramInt);
/* 4580 */     if (paramAccessibleContext == null) {
/* 4581 */       return false;
/*      */     }
/* 4583 */     ((Boolean)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */       public Boolean call() throws Exception {
/* 4586 */         AccessibleText localAccessibleText = paramAccessibleContext.getAccessibleText();
/* 4587 */         if (!(localAccessibleText instanceof AccessibleEditableText)) {
/* 4588 */           return Boolean.valueOf(false);
/*      */         }
/* 4590 */         ((AccessibleEditableText)localAccessibleText).selectText(paramInt, paramInt);
/* 4591 */         return Boolean.valueOf(localAccessibleText.getCaretPosition() == paramInt); } }, paramAccessibleContext)).booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getVisibleChildrenCount(AccessibleContext paramAccessibleContext)
/*      */   {
/* 4607 */     debugString("getVisibleChildrenCount");
/* 4608 */     if (paramAccessibleContext == null) {
/* 4609 */       return -1;
/*      */     }
/* 4611 */     this._visibleChildrenCount = 0;
/* 4612 */     _getVisibleChildrenCount(paramAccessibleContext);
/* 4613 */     debugString("  _visibleChildrenCount = " + this._visibleChildrenCount);
/* 4614 */     return this._visibleChildrenCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void _getVisibleChildrenCount(final AccessibleContext paramAccessibleContext)
/*      */   {
/* 4622 */     if (paramAccessibleContext == null)
/* 4623 */       return;
/* 4624 */     int i = ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */ 
/* 4627 */       public Integer call() throws Exception { return Integer.valueOf(paramAccessibleContext.getAccessibleChildrenCount()); } }, paramAccessibleContext)).intValue();
/*      */     
/*      */ 
/* 4630 */     for (int j = 0; j < i; j++) {
/* 4631 */       final int k = j;
/* 4632 */       final AccessibleContext localAccessibleContext = (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public AccessibleContext call() throws Exception {
/* 4635 */           Accessible localAccessible = paramAccessibleContext.getAccessibleChild(k);
/* 4636 */           if (localAccessible != null) {
/* 4637 */             return localAccessible.getAccessibleContext();
/*      */           }
/* 4639 */           return null; } }, paramAccessibleContext);
/*      */       
/*      */ 
/* 4642 */       if ((localAccessibleContext != null) && 
/* 4643 */         (((Boolean)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public Boolean call() throws Exception
/*      */         {
/* 4646 */           return Boolean.valueOf(localAccessibleContext.getAccessibleStateSet().contains(AccessibleState.SHOWING));
/*      */         }
/* 4643 */       }, paramAccessibleContext)).booleanValue()))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4652 */         this._visibleChildrenCount += 1;
/*      */         
/* 4654 */         if (((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */           public Integer call() throws Exception {
/* 4657 */             return Integer.valueOf(localAccessibleContext.getAccessibleChildrenCount());
/*      */           }
/* 4654 */         }, paramAccessibleContext)).intValue() > 0)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4660 */           _getVisibleChildrenCount(localAccessibleContext);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AccessibleContext getVisibleChild(AccessibleContext paramAccessibleContext, int paramInt)
/*      */   {
/* 4672 */     debugString("getVisibleChild: index = " + paramInt);
/* 4673 */     if (paramAccessibleContext == null) {
/* 4674 */       return null;
/*      */     }
/* 4676 */     this._visibleChild = null;
/* 4677 */     this._currentVisibleIndex = 0;
/* 4678 */     this._foundVisibleChild = false;
/* 4679 */     _getVisibleChild(paramAccessibleContext, paramInt);
/*      */     
/* 4681 */     if (this._visibleChild != null) {
/* 4682 */       debugString("    getVisibleChild: found child = " + 
/* 4683 */         (String)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */ 
/*      */           public String call() throws Exception {
/* 4686 */             return AccessBridge.this._visibleChild.getAccessibleName(); } }, paramAccessibleContext));
/*      */     }
/*      */     
/*      */ 
/* 4690 */     return this._visibleChild;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void _getVisibleChild(final AccessibleContext paramAccessibleContext, int paramInt)
/*      */   {
/* 4698 */     if (this._visibleChild != null) {
/* 4699 */       return;
/*      */     }
/*      */     
/* 4702 */     int i = ((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */     {
/*      */ 
/* 4705 */       public Integer call() throws Exception { return Integer.valueOf(paramAccessibleContext.getAccessibleChildrenCount()); } }, paramAccessibleContext)).intValue();
/*      */     
/*      */ 
/* 4708 */     for (int j = 0; j < i; j++) {
/* 4709 */       final int k = j;
/* 4710 */       final AccessibleContext localAccessibleContext = (AccessibleContext)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public AccessibleContext call() throws Exception {
/* 4713 */           Accessible localAccessible = paramAccessibleContext.getAccessibleChild(k);
/* 4714 */           if (localAccessible == null) {
/* 4715 */             return null;
/*      */           }
/* 4717 */           return localAccessible.getAccessibleContext(); } }, paramAccessibleContext);
/*      */       
/*      */ 
/* 4720 */       if ((localAccessibleContext != null) && 
/* 4721 */         (((Boolean)InvocationUtils.invokeAndWait(new Callable()
/*      */       {
/*      */         public Boolean call() throws Exception
/*      */         {
/* 4724 */           return Boolean.valueOf(localAccessibleContext.getAccessibleStateSet().contains(AccessibleState.SHOWING));
/*      */         }
/* 4721 */       }, paramAccessibleContext)).booleanValue()))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4729 */         if ((!this._foundVisibleChild) && (this._currentVisibleIndex == paramInt)) {
/* 4730 */           this._visibleChild = localAccessibleContext;
/* 4731 */           this._foundVisibleChild = true;
/* 4732 */           return;
/*      */         }
/* 4734 */         this._currentVisibleIndex += 1;
/*      */         
/* 4736 */         if (((Integer)InvocationUtils.invokeAndWait(new Callable()
/*      */         {
/*      */           public Integer call() throws Exception {
/* 4739 */             return Integer.valueOf(localAccessibleContext.getAccessibleChildrenCount());
/*      */           }
/* 4736 */         }, paramAccessibleContext)).intValue() > 0)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4742 */           _getVisibleChild(localAccessibleContext, paramInt); }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private native void propertyCaretChange(PropertyChangeEvent paramPropertyChangeEvent, AccessibleContext paramAccessibleContext, int paramInt1, int paramInt2);
/*      */   
/*      */   private native void propertyDescriptionChange(PropertyChangeEvent paramPropertyChangeEvent, AccessibleContext paramAccessibleContext, String paramString1, String paramString2);
/*      */   
/*      */   private native void propertyNameChange(PropertyChangeEvent paramPropertyChangeEvent, AccessibleContext paramAccessibleContext, String paramString1, String paramString2);
/*      */   
/*      */   private native void propertySelectionChange(PropertyChangeEvent paramPropertyChangeEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */   private native void propertyStateChange(PropertyChangeEvent paramPropertyChangeEvent, AccessibleContext paramAccessibleContext, String paramString1, String paramString2);
/*      */   
/*      */   private native void propertyTextChange(PropertyChangeEvent paramPropertyChangeEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */   private class ObjectReferences {
/* 4760 */     private class Reference { Reference(int paramInt) { this.value = paramInt; }
/*      */       
/*      */       public String toString()
/*      */       {
/* 4764 */         return "refCount: " + this.value;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       private int value;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     ObjectReferences()
/*      */     {
/* 4777 */       this.refs = new ConcurrentHashMap(4);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     String dump()
/*      */     {
/* 4784 */       return this.refs.toString();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void increment(Object paramObject)
/*      */     {
/* 4791 */       if (paramObject == null) {
/* 4792 */         AccessBridge.this.debugString("ObjectReferences::increment - Passed in object is null");
/* 4793 */         return;
/*      */       }
/*      */       
/* 4796 */       if (this.refs.containsKey(paramObject)) {
/* 4797 */         Reference.access$1208((Reference)this.refs.get(paramObject));
/*      */       } else {
/* 4799 */         this.refs.put(paramObject, new Reference(1));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void decrement(Object paramObject)
/*      */     {
/* 4807 */       Reference localReference = (Reference)this.refs.get(paramObject);
/* 4808 */       if (localReference != null) {
/* 4809 */         Reference.access$1210(localReference);
/* 4810 */         if (localReference.value == 0) {
/* 4811 */           this.refs.remove(paramObject);
/* 4812 */         } else if (localReference.value < 0) {
/* 4813 */           AccessBridge.this.debugString("ERROR: decrementing reference count below 0");
/*      */         }
/*      */       } else {
/* 4816 */         AccessBridge.this.debugString("ERROR: object to decrement not in ObjectReferences table");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private ConcurrentHashMap<Object, Reference> refs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private native void propertyValueChange(PropertyChangeEvent paramPropertyChangeEvent, AccessibleContext paramAccessibleContext, String paramString1, String paramString2);
/*      */   
/*      */ 
/*      */ 
/*      */   private native void propertyVisibleDataChange(PropertyChangeEvent paramPropertyChangeEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */ 
/*      */ 
/*      */   private native void propertyChildChange(PropertyChangeEvent paramPropertyChangeEvent, AccessibleContext paramAccessibleContext1, AccessibleContext paramAccessibleContext2, AccessibleContext paramAccessibleContext3);
/*      */   
/*      */ 
/*      */ 
/*      */   private native void propertyActiveDescendentChange(PropertyChangeEvent paramPropertyChangeEvent, AccessibleContext paramAccessibleContext1, AccessibleContext paramAccessibleContext2, AccessibleContext paramAccessibleContext3);
/*      */   
/*      */ 
/*      */ 
/*      */   private native void javaShutdown();
/*      */   
/*      */ 
/*      */ 
/*      */   private native void focusGained(FocusEvent paramFocusEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */ 
/*      */ 
/*      */   private static final long PROPERTY_CHANGE_EVENTS = 1L;
/*      */   
/*      */ 
/*      */   private static final long FOCUS_GAINED_EVENTS = 2L;
/*      */   
/*      */   private static final long FOCUS_LOST_EVENTS = 4L;
/*      */   
/*      */   private static final long FOCUS_EVENTS = 6L;
/*      */   
/*      */   private static final long CARET_UPATE_EVENTS = 8L;
/*      */   
/*      */   private static final long CARET_EVENTS = 8L;
/*      */   
/*      */   private static final long MOUSE_CLICKED_EVENTS = 16L;
/*      */   
/*      */   private static final long MOUSE_ENTERED_EVENTS = 32L;
/*      */   
/*      */   private static final long MOUSE_EXITED_EVENTS = 64L;
/*      */   
/*      */   private static final long MOUSE_PRESSED_EVENTS = 128L;
/*      */   
/*      */   private static final long MOUSE_RELEASED_EVENTS = 256L;
/*      */   
/*      */   private static final long MOUSE_EVENTS = 496L;
/*      */   
/*      */   private static final long MENU_CANCELED_EVENTS = 512L;
/*      */   
/*      */   private native void focusLost(FocusEvent paramFocusEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */ 
/*      */   private native void caretUpdate(CaretEvent paramCaretEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */ 
/*      */   private native void mouseClicked(MouseEvent paramMouseEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */ 
/*      */   private native void mouseEntered(MouseEvent paramMouseEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */ 
/*      */   private native void mouseExited(MouseEvent paramMouseEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */ 
/*      */   private native void mousePressed(MouseEvent paramMouseEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */ 
/*      */   private native void mouseReleased(MouseEvent paramMouseEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */ 
/*      */   private native void menuCanceled(MenuEvent paramMenuEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */ 
/*      */   private native void menuDeselected(MenuEvent paramMenuEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */ 
/*      */   private native void menuSelected(MenuEvent paramMenuEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */ 
/*      */   private native void popupMenuCanceled(PopupMenuEvent paramPopupMenuEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */ 
/*      */   private native void popupMenuWillBecomeInvisible(PopupMenuEvent paramPopupMenuEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */ 
/*      */   private native void popupMenuWillBecomeVisible(PopupMenuEvent paramPopupMenuEvent, AccessibleContext paramAccessibleContext);
/*      */   
/*      */ 
/*      */   private static final long MENU_DESELECTED_EVENTS = 1024L;
/*      */   
/*      */   private static final long MENU_SELECTED_EVENTS = 2048L;
/*      */   
/*      */   private static final long MENU_EVENTS = 3584L;
/*      */   
/*      */   private static final long POPUPMENU_CANCELED_EVENTS = 4096L;
/*      */   
/*      */   private static final long POPUPMENU_WILL_BECOME_INVISIBLE_EVENTS = 8192L;
/*      */   
/*      */   private static final long POPUPMENU_WILL_BECOME_VISIBLE_EVENTS = 16384L;
/*      */   
/*      */   private static final long POPUPMENU_EVENTS = 28672L;
/*      */   
/*      */   private static final long PROPERTY_NAME_CHANGE_EVENTS = 1L;
/*      */   
/*      */   private static final long PROPERTY_DESCRIPTION_CHANGE_EVENTS = 2L;
/*      */   
/*      */   private static final long PROPERTY_STATE_CHANGE_EVENTS = 4L;
/*      */   
/*      */   private static final long PROPERTY_VALUE_CHANGE_EVENTS = 8L;
/*      */   
/*      */   private static final long PROPERTY_SELECTION_CHANGE_EVENTS = 16L;
/*      */   
/*      */   private static final long PROPERTY_TEXT_CHANGE_EVENTS = 32L;
/*      */   
/*      */   private static final long PROPERTY_CARET_CHANGE_EVENTS = 64L;
/*      */   
/*      */   private static final long PROPERTY_VISIBLEDATA_CHANGE_EVENTS = 128L;
/*      */   
/*      */   private static final long PROPERTY_CHILD_CHANGE_EVENTS = 256L;
/*      */   
/*      */   private static final long PROPERTY_ACTIVEDESCENDENT_CHANGE_EVENTS = 512L;
/*      */   
/*      */   private static final long PROPERTY_EVENTS = 1023L;
/*      */   
/*      */   private class EventHandler
/*      */     implements PropertyChangeListener, FocusListener, javax.swing.event.CaretListener, javax.swing.event.MenuListener, javax.swing.event.PopupMenuListener, java.awt.event.MouseListener, java.awt.event.WindowListener, javax.swing.event.ChangeListener
/*      */   {
/*      */     private AccessBridge accessBridge;
/*      */     
/* 4958 */     private long javaEventMask = 0L;
/* 4959 */     private long accessibilityEventMask = 0L;
/*      */     
/*      */     EventHandler(AccessBridge paramAccessBridge) {
/* 4962 */       this.accessBridge = paramAccessBridge;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void windowOpened(WindowEvent paramWindowEvent)
/*      */     {
/* 4977 */       Object localObject = null;
/* 4978 */       if (paramWindowEvent != null)
/* 4979 */         localObject = paramWindowEvent.getSource();
/* 4980 */       if ((localObject instanceof AccessBridge.NativeWindowHandler)) {
/* 4981 */         AccessBridge.addNativeWindowHandler((AccessBridge.NativeWindowHandler)localObject);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void windowClosing(WindowEvent paramWindowEvent) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void windowClosed(WindowEvent paramWindowEvent)
/*      */     {
/* 4999 */       Object localObject = null;
/* 5000 */       if (paramWindowEvent != null)
/* 5001 */         localObject = paramWindowEvent.getSource();
/* 5002 */       if ((localObject instanceof AccessBridge.NativeWindowHandler)) {
/* 5003 */         AccessBridge.removeNativeWindowHandler((AccessBridge.NativeWindowHandler)localObject);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void windowIconified(WindowEvent paramWindowEvent) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void windowDeiconified(WindowEvent paramWindowEvent) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void windowActivated(WindowEvent paramWindowEvent) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void windowDeactivated(WindowEvent paramWindowEvent) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void addJavaEventNotification(long paramLong)
/*      */     {
/* 5048 */       long l = this.javaEventMask | paramLong;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5055 */       if (((this.javaEventMask & 0x6) == 0L) && ((l & 0x6) != 0L))
/*      */       {
/* 5057 */         SwingEventMonitor.addFocusListener(this);
/*      */       }
/* 5059 */       if (((this.javaEventMask & 0x8) == 0L) && ((l & 0x8) != 0L))
/*      */       {
/* 5061 */         SwingEventMonitor.addCaretListener(this);
/*      */       }
/* 5063 */       if (((this.javaEventMask & 0x1F0) == 0L) && ((l & 0x1F0) != 0L))
/*      */       {
/* 5065 */         SwingEventMonitor.addMouseListener(this);
/*      */       }
/* 5067 */       if (((this.javaEventMask & 0xE00) == 0L) && ((l & 0xE00) != 0L))
/*      */       {
/* 5069 */         SwingEventMonitor.addMenuListener(this);
/* 5070 */         SwingEventMonitor.addPopupMenuListener(this);
/*      */       }
/* 5072 */       if (((this.javaEventMask & 0x7000) == 0L) && ((l & 0x7000) != 0L))
/*      */       {
/* 5074 */         SwingEventMonitor.addPopupMenuListener(this);
/*      */       }
/*      */       
/* 5077 */       this.javaEventMask = l;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void removeJavaEventNotification(long paramLong)
/*      */     {
/* 5086 */       long l = this.javaEventMask & (paramLong ^ 0xFFFFFFFFFFFFFFFF);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5093 */       if (((this.javaEventMask & 0x6) != 0L) && ((l & 0x6) == 0L))
/*      */       {
/* 5095 */         SwingEventMonitor.removeFocusListener(this);
/*      */       }
/* 5097 */       if (((this.javaEventMask & 0x8) != 0L) && ((l & 0x8) == 0L))
/*      */       {
/* 5099 */         SwingEventMonitor.removeCaretListener(this);
/*      */       }
/* 5101 */       if (((this.javaEventMask & 0x1F0) == 0L) && ((l & 0x1F0) != 0L))
/*      */       {
/* 5103 */         SwingEventMonitor.removeMouseListener(this);
/*      */       }
/* 5105 */       if (((this.javaEventMask & 0xE00) == 0L) && ((l & 0xE00) != 0L))
/*      */       {
/* 5107 */         SwingEventMonitor.removeMenuListener(this);
/*      */       }
/* 5109 */       if (((this.javaEventMask & 0x7000) == 0L) && ((l & 0x7000) != 0L))
/*      */       {
/* 5111 */         SwingEventMonitor.removePopupMenuListener(this);
/*      */       }
/*      */       
/* 5114 */       this.javaEventMask = l;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void addAccessibilityEventNotification(long paramLong)
/*      */     {
/* 5123 */       long l = this.accessibilityEventMask | paramLong;
/* 5124 */       if (((this.accessibilityEventMask & 0x3FF) == 0L) && ((l & 0x3FF) != 0L))
/*      */       {
/* 5126 */         com.sun.java.accessibility.util.AccessibilityEventMonitor.addPropertyChangeListener(this);
/*      */       }
/* 5128 */       this.accessibilityEventMask = l;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void removeAccessibilityEventNotification(long paramLong)
/*      */     {
/* 5137 */       long l = this.accessibilityEventMask & (paramLong ^ 0xFFFFFFFFFFFFFFFF);
/* 5138 */       if (((this.accessibilityEventMask & 0x3FF) != 0L) && ((l & 0x3FF) == 0L))
/*      */       {
/* 5140 */         com.sun.java.accessibility.util.AccessibilityEventMonitor.removePropertyChangeListener(this);
/*      */       }
/* 5142 */       this.accessibilityEventMask = l;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void propertyChange(PropertyChangeEvent paramPropertyChangeEvent)
/*      */     {
/* 5151 */       this.accessBridge.debugString("propertyChange(" + paramPropertyChangeEvent.toString() + ") called");
/*      */       
/* 5153 */       if ((paramPropertyChangeEvent != null) && ((this.accessibilityEventMask & 0x3FF) != 0L)) {
/* 5154 */         Object localObject1 = paramPropertyChangeEvent.getSource();
/*      */         AccessibleContext localAccessibleContext;
/*      */         Object localObject2;
/* 5157 */         if ((localObject1 instanceof AccessibleContext)) {
/* 5158 */           localAccessibleContext = (AccessibleContext)localObject1;
/*      */         } else {
/* 5160 */           localObject2 = Translator.getAccessible(paramPropertyChangeEvent.getSource());
/* 5161 */           if (localObject2 == null) {
/* 5162 */             return;
/*      */           }
/* 5164 */           localAccessibleContext = ((Accessible)localObject2).getAccessibleContext();
/*      */         }
/* 5166 */         if (localAccessibleContext != null) {
/* 5167 */           AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, AppContext.getAppContext());
/*      */           
/* 5169 */           this.accessBridge.debugString("AccessibleContext: " + localAccessibleContext);
/* 5170 */           localObject2 = paramPropertyChangeEvent.getPropertyName();
/*      */           
/* 5172 */           if (((String)localObject2).compareTo("AccessibleCaret") == 0) {
/* 5173 */             int i = 0;
/* 5174 */             int j = 0;
/*      */             
/* 5176 */             if ((paramPropertyChangeEvent.getOldValue() instanceof Integer)) {
/* 5177 */               i = ((Integer)paramPropertyChangeEvent.getOldValue()).intValue();
/*      */             }
/* 5179 */             if ((paramPropertyChangeEvent.getNewValue() instanceof Integer)) {
/* 5180 */               j = ((Integer)paramPropertyChangeEvent.getNewValue()).intValue();
/*      */             }
/* 5182 */             this.accessBridge.debugString(" - about to call propertyCaretChange()");
/* 5183 */             this.accessBridge.debugString("   old value: " + i + "new value: " + j);
/* 5184 */             this.accessBridge.propertyCaretChange(paramPropertyChangeEvent, localAccessibleContext, i, j); } else { Object localObject3;
/*      */             Object localObject4;
/* 5186 */             if (((String)localObject2).compareTo("AccessibleDescription") == 0) {
/* 5187 */               localObject3 = null;
/* 5188 */               localObject4 = null;
/*      */               
/* 5190 */               if (paramPropertyChangeEvent.getOldValue() != null) {
/* 5191 */                 localObject3 = paramPropertyChangeEvent.getOldValue().toString();
/*      */               }
/* 5193 */               if (paramPropertyChangeEvent.getNewValue() != null) {
/* 5194 */                 localObject4 = paramPropertyChangeEvent.getNewValue().toString();
/*      */               }
/* 5196 */               this.accessBridge.debugString(" - about to call propertyDescriptionChange()");
/* 5197 */               this.accessBridge.debugString("   old value: " + (String)localObject3 + "new value: " + (String)localObject4);
/* 5198 */               this.accessBridge.propertyDescriptionChange(paramPropertyChangeEvent, localAccessibleContext, (String)localObject3, (String)localObject4);
/*      */             }
/* 5200 */             else if (((String)localObject2).compareTo("AccessibleName") == 0) {
/* 5201 */               localObject3 = null;
/* 5202 */               localObject4 = null;
/*      */               
/* 5204 */               if (paramPropertyChangeEvent.getOldValue() != null) {
/* 5205 */                 localObject3 = paramPropertyChangeEvent.getOldValue().toString();
/*      */               }
/* 5207 */               if (paramPropertyChangeEvent.getNewValue() != null) {
/* 5208 */                 localObject4 = paramPropertyChangeEvent.getNewValue().toString();
/*      */               }
/* 5210 */               this.accessBridge.debugString(" - about to call propertyNameChange()");
/* 5211 */               this.accessBridge.debugString("   old value: " + (String)localObject3 + " new value: " + (String)localObject4);
/* 5212 */               this.accessBridge.propertyNameChange(paramPropertyChangeEvent, localAccessibleContext, (String)localObject3, (String)localObject4);
/*      */             }
/* 5214 */             else if (((String)localObject2).compareTo("AccessibleSelection") == 0) {
/* 5215 */               this.accessBridge.debugString(" - about to call propertySelectionChange() " + localAccessibleContext + "   " + Thread.currentThread() + "   " + paramPropertyChangeEvent.getSource());
/*      */               
/* 5217 */               this.accessBridge.propertySelectionChange(paramPropertyChangeEvent, localAccessibleContext);
/*      */             }
/* 5219 */             else if (((String)localObject2).compareTo("AccessibleState") == 0) {
/* 5220 */               localObject3 = null;
/* 5221 */               localObject4 = null;
/*      */               
/*      */               AccessibleState localAccessibleState;
/* 5224 */               if (paramPropertyChangeEvent.getOldValue() != null) {
/* 5225 */                 localAccessibleState = (AccessibleState)paramPropertyChangeEvent.getOldValue();
/* 5226 */                 localObject3 = localAccessibleState.toDisplayString(Locale.US);
/*      */               }
/* 5228 */               if (paramPropertyChangeEvent.getNewValue() != null) {
/* 5229 */                 localAccessibleState = (AccessibleState)paramPropertyChangeEvent.getNewValue();
/* 5230 */                 localObject4 = localAccessibleState.toDisplayString(Locale.US);
/*      */               }
/*      */               
/* 5233 */               this.accessBridge.debugString(" - about to call propertyStateChange()");
/* 5234 */               this.accessBridge.propertyStateChange(paramPropertyChangeEvent, localAccessibleContext, (String)localObject3, (String)localObject4);
/*      */             }
/* 5236 */             else if (((String)localObject2).compareTo("AccessibleText") == 0) {
/* 5237 */               this.accessBridge.debugString(" - about to call propertyTextChange()");
/* 5238 */               this.accessBridge.propertyTextChange(paramPropertyChangeEvent, localAccessibleContext);
/*      */             }
/* 5240 */             else if (((String)localObject2).compareTo("AccessibleValue") == 0) {
/* 5241 */               localObject3 = null;
/* 5242 */               localObject4 = null;
/*      */               
/* 5244 */               if (paramPropertyChangeEvent.getOldValue() != null) {
/* 5245 */                 localObject3 = paramPropertyChangeEvent.getOldValue().toString();
/*      */               }
/* 5247 */               if (paramPropertyChangeEvent.getNewValue() != null) {
/* 5248 */                 localObject4 = paramPropertyChangeEvent.getNewValue().toString();
/*      */               }
/* 5250 */               this.accessBridge.debugString(" - about to call propertyDescriptionChange()");
/* 5251 */               this.accessBridge.propertyValueChange(paramPropertyChangeEvent, localAccessibleContext, (String)localObject3, (String)localObject4);
/*      */             }
/* 5253 */             else if (((String)localObject2).compareTo("AccessibleVisibleData") == 0) {
/* 5254 */               this.accessBridge.propertyVisibleDataChange(paramPropertyChangeEvent, localAccessibleContext);
/*      */             }
/* 5256 */             else if (((String)localObject2).compareTo("AccessibleChild") == 0) {
/* 5257 */               localObject3 = null;
/* 5258 */               localObject4 = null;
/*      */               
/*      */ 
/* 5261 */               if ((paramPropertyChangeEvent.getOldValue() instanceof AccessibleContext)) {
/* 5262 */                 localObject3 = (AccessibleContext)paramPropertyChangeEvent.getOldValue();
/* 5263 */                 AccessBridge.InvocationUtils.registerAccessibleContext((AccessibleContext)localObject3, AppContext.getAppContext());
/*      */               }
/* 5265 */               if ((paramPropertyChangeEvent.getNewValue() instanceof AccessibleContext)) {
/* 5266 */                 localObject4 = (AccessibleContext)paramPropertyChangeEvent.getNewValue();
/* 5267 */                 AccessBridge.InvocationUtils.registerAccessibleContext((AccessibleContext)localObject4, AppContext.getAppContext());
/*      */               }
/* 5269 */               this.accessBridge.debugString(" - about to call propertyChildChange()");
/* 5270 */               this.accessBridge.debugString("   old AC: " + localObject3 + "new AC: " + localObject4);
/* 5271 */               this.accessBridge.propertyChildChange(paramPropertyChangeEvent, localAccessibleContext, (AccessibleContext)localObject3, (AccessibleContext)localObject4);
/*      */             }
/* 5273 */             else if (((String)localObject2).compareTo("AccessibleActiveDescendant") == 0) {
/* 5274 */               handleActiveDescendentEvent(paramPropertyChangeEvent, localAccessibleContext);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5285 */     private AccessibleContext prevAC = null;
/*      */     
/*      */     private void handleActiveDescendentEvent(PropertyChangeEvent paramPropertyChangeEvent, AccessibleContext paramAccessibleContext)
/*      */     {
/* 5289 */       if ((paramPropertyChangeEvent == null) || (paramAccessibleContext == null))
/* 5290 */         return;
/* 5291 */       AccessibleContext localAccessibleContext = null;
/* 5292 */       Object localObject = null;
/*      */       
/*      */       Accessible localAccessible1;
/*      */       
/* 5296 */       if ((paramPropertyChangeEvent.getOldValue() instanceof Accessible)) {
/* 5297 */         localAccessibleContext = ((Accessible)paramPropertyChangeEvent.getOldValue()).getAccessibleContext();
/* 5298 */       } else if ((paramPropertyChangeEvent.getOldValue() instanceof Component)) {
/* 5299 */         localAccessible1 = Translator.getAccessible(paramPropertyChangeEvent.getOldValue());
/* 5300 */         if (localAccessible1 != null)
/* 5301 */           localAccessibleContext = localAccessible1.getAccessibleContext();
/*      */       }
/*      */       Accessible localAccessible2;
/* 5304 */       if (localAccessibleContext != null) {
/* 5305 */         localAccessible2 = localAccessibleContext.getAccessibleParent();
/* 5306 */         if ((localAccessible2 instanceof JTree))
/*      */         {
/* 5308 */           localAccessibleContext = this.prevAC;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 5313 */       if ((paramPropertyChangeEvent.getNewValue() instanceof Accessible)) {
/* 5314 */         localObject = ((Accessible)paramPropertyChangeEvent.getNewValue()).getAccessibleContext();
/* 5315 */       } else if ((paramPropertyChangeEvent.getNewValue() instanceof Component)) {
/* 5316 */         localAccessible1 = Translator.getAccessible(paramPropertyChangeEvent.getNewValue());
/* 5317 */         if (localAccessible1 != null) {
/* 5318 */           localObject = localAccessible1.getAccessibleContext();
/*      */         }
/*      */       }
/* 5321 */       if (localObject != null) {
/* 5322 */         localAccessible2 = ((AccessibleContext)localObject).getAccessibleParent();
/* 5323 */         if ((localAccessible2 instanceof JTree))
/*      */         {
/* 5325 */           JTree localJTree = (JTree)localAccessible2;
/*      */           
/* 5327 */           localObject = new AccessBridge.AccessibleJTreeNode(AccessBridge.this, localJTree, localJTree.getSelectionPath(), null);
/*      */         }
/*      */       }
/*      */       
/* 5331 */       this.prevAC = ((AccessibleContext)localObject);
/*      */       
/* 5333 */       this.accessBridge.debugString("  - about to call propertyActiveDescendentChange()");
/* 5334 */       this.accessBridge.debugString("   AC: " + paramAccessibleContext);
/* 5335 */       this.accessBridge.debugString("   old AC: " + localAccessibleContext + "new AC: " + localObject);
/*      */       
/* 5337 */       AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, AppContext.getAppContext());
/* 5338 */       AccessBridge.InvocationUtils.registerAccessibleContext((AccessibleContext)localObject, AppContext.getAppContext());
/* 5339 */       this.accessBridge.propertyActiveDescendentChange(paramPropertyChangeEvent, paramAccessibleContext, localAccessibleContext, (AccessibleContext)localObject);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5345 */     private boolean stateChangeListenerAdded = false;
/*      */     
/*      */     public void focusGained(FocusEvent paramFocusEvent) {
/* 5348 */       if (AccessBridge.this.runningOnJDK1_4) {
/* 5349 */         processFocusGained();
/*      */       }
/* 5351 */       else if ((this.javaEventMask & 0x2) != 0L) {
/* 5352 */         Accessible localAccessible = Translator.getAccessible(paramFocusEvent.getSource());
/* 5353 */         if (localAccessible != null) {
/* 5354 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 5355 */           AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, SunToolkit.targetToAppContext(paramFocusEvent.getSource()));
/* 5356 */           this.accessBridge.focusGained(paramFocusEvent, localAccessibleContext);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void stateChanged(javax.swing.event.ChangeEvent paramChangeEvent)
/*      */     {
/* 5363 */       processFocusGained();
/*      */     }
/*      */     
/*      */     private void processFocusGained()
/*      */     {
/* 5368 */       Component localComponent1 = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
/* 5369 */       if (localComponent1 == null) {
/*      */         return;
/*      */       }
/*      */       Object localObject1;
/*      */       Object localObject2;
/* 5374 */       if ((localComponent1 instanceof javax.swing.JRootPane))
/*      */       {
/* 5376 */         localObject1 = javax.swing.MenuSelectionManager.defaultManager().getSelectedPath();
/* 5377 */         if (localObject1.length > 1) {
/* 5378 */           localObject2 = localObject1[(localObject1.length - 2)].getComponent();
/* 5379 */           Component localComponent2 = localObject1[(localObject1.length - 1)].getComponent();
/*      */           FocusEvent localFocusEvent;
/* 5381 */           AccessibleContext localAccessibleContext; if ((localComponent2 instanceof javax.swing.JPopupMenu))
/*      */           {
/*      */ 
/* 5384 */             localFocusEvent = new FocusEvent((Component)localObject2, 1004);
/* 5385 */             localAccessibleContext = ((Component)localObject2).getAccessibleContext();
/* 5386 */             AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, SunToolkit.targetToAppContext(localObject2));
/* 5387 */             this.accessBridge.focusGained(localFocusEvent, localAccessibleContext);
/* 5388 */           } else if ((localObject2 instanceof javax.swing.JPopupMenu))
/*      */           {
/* 5390 */             localFocusEvent = new FocusEvent(localComponent2, 1004);
/*      */             
/* 5392 */             this.accessBridge.debugString(" - about to call focusGained()");
/* 5393 */             localAccessibleContext = localComponent2.getAccessibleContext();
/* 5394 */             AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, SunToolkit.targetToAppContext(localComponent2));
/* 5395 */             this.accessBridge.debugString("   AC: " + localAccessibleContext);
/* 5396 */             this.accessBridge.focusGained(localFocusEvent, localAccessibleContext);
/*      */           }
/*      */           
/*      */         }
/*      */       }
/* 5401 */       else if ((localComponent1 instanceof Accessible)) {
/* 5402 */         localObject1 = new FocusEvent(localComponent1, 1004);
/*      */         
/* 5404 */         this.accessBridge.debugString(" - about to call focusGained()");
/* 5405 */         localObject2 = localComponent1.getAccessibleContext();
/* 5406 */         AccessBridge.InvocationUtils.registerAccessibleContext((AccessibleContext)localObject2, SunToolkit.targetToAppContext(localComponent1));
/* 5407 */         this.accessBridge.debugString("   AC: " + localObject2);
/* 5408 */         this.accessBridge.focusGained((FocusEvent)localObject1, (AccessibleContext)localObject2);
/*      */       }
/*      */     }
/*      */     
/*      */     public void focusLost(FocusEvent paramFocusEvent)
/*      */     {
/* 5414 */       if ((paramFocusEvent != null) && ((this.javaEventMask & 0x4) != 0L)) {
/* 5415 */         Accessible localAccessible = Translator.getAccessible(paramFocusEvent.getSource());
/* 5416 */         if (localAccessible != null) {
/* 5417 */           this.accessBridge.debugString(" - about to call focusLost()");
/* 5418 */           this.accessBridge.debugString("   AC: " + localAccessible.getAccessibleContext());
/* 5419 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 5420 */           AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, AppContext.getAppContext());
/* 5421 */           this.accessBridge.focusLost(paramFocusEvent, localAccessibleContext);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void caretUpdate(CaretEvent paramCaretEvent)
/*      */     {
/* 5430 */       if ((paramCaretEvent != null) && ((this.javaEventMask & 0x8) != 0L)) {
/* 5431 */         Accessible localAccessible = Translator.getAccessible(paramCaretEvent.getSource());
/* 5432 */         if (localAccessible != null) {
/* 5433 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 5434 */           AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, AppContext.getAppContext());
/* 5435 */           this.accessBridge.caretUpdate(paramCaretEvent, localAccessibleContext);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void mouseClicked(MouseEvent paramMouseEvent)
/*      */     {
/* 5445 */       if ((paramMouseEvent != null) && ((this.javaEventMask & 0x10) != 0L)) {
/* 5446 */         Accessible localAccessible = Translator.getAccessible(paramMouseEvent.getSource());
/* 5447 */         if (localAccessible != null) {
/* 5448 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 5449 */           AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, AppContext.getAppContext());
/* 5450 */           this.accessBridge.mouseClicked(paramMouseEvent, localAccessibleContext);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void mouseEntered(MouseEvent paramMouseEvent) {
/* 5456 */       if ((paramMouseEvent != null) && ((this.javaEventMask & 0x20) != 0L)) {
/* 5457 */         Accessible localAccessible = Translator.getAccessible(paramMouseEvent.getSource());
/* 5458 */         if (localAccessible != null) {
/* 5459 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 5460 */           AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, AppContext.getAppContext());
/* 5461 */           this.accessBridge.mouseEntered(paramMouseEvent, localAccessibleContext);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void mouseExited(MouseEvent paramMouseEvent) {
/* 5467 */       if ((paramMouseEvent != null) && ((this.javaEventMask & 0x40) != 0L)) {
/* 5468 */         Accessible localAccessible = Translator.getAccessible(paramMouseEvent.getSource());
/* 5469 */         if (localAccessible != null) {
/* 5470 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 5471 */           AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, AppContext.getAppContext());
/* 5472 */           this.accessBridge.mouseExited(paramMouseEvent, localAccessibleContext);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void mousePressed(MouseEvent paramMouseEvent) {
/* 5478 */       if ((paramMouseEvent != null) && ((this.javaEventMask & 0x80) != 0L)) {
/* 5479 */         Accessible localAccessible = Translator.getAccessible(paramMouseEvent.getSource());
/* 5480 */         if (localAccessible != null) {
/* 5481 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 5482 */           AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, AppContext.getAppContext());
/* 5483 */           this.accessBridge.mousePressed(paramMouseEvent, localAccessibleContext);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void mouseReleased(MouseEvent paramMouseEvent) {
/* 5489 */       if ((paramMouseEvent != null) && ((this.javaEventMask & 0x100) != 0L)) {
/* 5490 */         Accessible localAccessible = Translator.getAccessible(paramMouseEvent.getSource());
/* 5491 */         if (localAccessible != null) {
/* 5492 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 5493 */           AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, AppContext.getAppContext());
/* 5494 */           this.accessBridge.mouseReleased(paramMouseEvent, localAccessibleContext);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void menuCanceled(MenuEvent paramMenuEvent)
/*      */     {
/* 5503 */       if ((paramMenuEvent != null) && ((this.javaEventMask & 0x200) != 0L)) {
/* 5504 */         Accessible localAccessible = Translator.getAccessible(paramMenuEvent.getSource());
/* 5505 */         if (localAccessible != null) {
/* 5506 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 5507 */           AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, AppContext.getAppContext());
/* 5508 */           this.accessBridge.menuCanceled(paramMenuEvent, localAccessibleContext);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void menuDeselected(MenuEvent paramMenuEvent) {
/* 5514 */       if ((paramMenuEvent != null) && ((this.javaEventMask & 0x400) != 0L)) {
/* 5515 */         Accessible localAccessible = Translator.getAccessible(paramMenuEvent.getSource());
/* 5516 */         if (localAccessible != null) {
/* 5517 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 5518 */           AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, AppContext.getAppContext());
/* 5519 */           this.accessBridge.menuDeselected(paramMenuEvent, localAccessibleContext);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void menuSelected(MenuEvent paramMenuEvent) {
/* 5525 */       if ((paramMenuEvent != null) && ((this.javaEventMask & 0x800) != 0L)) {
/* 5526 */         Accessible localAccessible = Translator.getAccessible(paramMenuEvent.getSource());
/* 5527 */         if (localAccessible != null) {
/* 5528 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 5529 */           AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, AppContext.getAppContext());
/* 5530 */           this.accessBridge.menuSelected(paramMenuEvent, localAccessibleContext);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void popupMenuCanceled(PopupMenuEvent paramPopupMenuEvent) {
/* 5536 */       if ((paramPopupMenuEvent != null) && ((this.javaEventMask & 0x1000) != 0L)) {
/* 5537 */         Accessible localAccessible = Translator.getAccessible(paramPopupMenuEvent.getSource());
/* 5538 */         if (localAccessible != null) {
/* 5539 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 5540 */           AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, AppContext.getAppContext());
/* 5541 */           this.accessBridge.popupMenuCanceled(paramPopupMenuEvent, localAccessibleContext);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void popupMenuWillBecomeInvisible(PopupMenuEvent paramPopupMenuEvent) {
/* 5547 */       if ((paramPopupMenuEvent != null) && ((this.javaEventMask & 0x2000) != 0L)) {
/* 5548 */         Accessible localAccessible = Translator.getAccessible(paramPopupMenuEvent.getSource());
/* 5549 */         if (localAccessible != null) {
/* 5550 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 5551 */           AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, AppContext.getAppContext());
/* 5552 */           this.accessBridge.popupMenuWillBecomeInvisible(paramPopupMenuEvent, localAccessibleContext);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void popupMenuWillBecomeVisible(PopupMenuEvent paramPopupMenuEvent) {
/* 5558 */       if ((paramPopupMenuEvent != null) && ((this.javaEventMask & 0x4000) != 0L)) {
/* 5559 */         Accessible localAccessible = Translator.getAccessible(paramPopupMenuEvent.getSource());
/* 5560 */         if (localAccessible != null) {
/* 5561 */           AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 5562 */           AccessBridge.InvocationUtils.registerAccessibleContext(localAccessibleContext, AppContext.getAppContext());
/* 5563 */           this.accessBridge.popupMenuWillBecomeVisible(paramPopupMenuEvent, localAccessibleContext);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addJavaEventNotification(final long paramLong)
/*      */   {
/* 5576 */     EventQueue.invokeLater(new Runnable() {
/*      */       public void run() {
/* 5578 */         AccessBridge.this.eventHandler.addJavaEventNotification(paramLong);
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void removeJavaEventNotification(final long paramLong)
/*      */   {
/* 5587 */     EventQueue.invokeLater(new Runnable() {
/*      */       public void run() {
/* 5589 */         AccessBridge.this.eventHandler.removeJavaEventNotification(paramLong);
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addAccessibilityEventNotification(final long paramLong)
/*      */   {
/* 5599 */     EventQueue.invokeLater(new Runnable() {
/*      */       public void run() {
/* 5601 */         AccessBridge.this.eventHandler.addAccessibilityEventNotification(paramLong);
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void removeAccessibilityEventNotification(final long paramLong)
/*      */   {
/* 5610 */     EventQueue.invokeLater(new Runnable() {
/*      */       public void run() {
/* 5612 */         AccessBridge.this.eventHandler.removeAccessibilityEventNotification(paramLong);
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5628 */   private AccessibleRole[] allAccessibleRoles = { AccessibleRole.ALERT, AccessibleRole.COLUMN_HEADER, AccessibleRole.CANVAS, AccessibleRole.COMBO_BOX, AccessibleRole.DESKTOP_ICON, AccessibleRole.INTERNAL_FRAME, AccessibleRole.DESKTOP_PANE, AccessibleRole.OPTION_PANE, AccessibleRole.WINDOW, AccessibleRole.FRAME, AccessibleRole.DIALOG, AccessibleRole.COLOR_CHOOSER, AccessibleRole.DIRECTORY_PANE, AccessibleRole.FILE_CHOOSER, AccessibleRole.FILLER, AccessibleRole.ICON, AccessibleRole.LABEL, AccessibleRole.ROOT_PANE, AccessibleRole.GLASS_PANE, AccessibleRole.LAYERED_PANE, AccessibleRole.LIST, AccessibleRole.LIST_ITEM, AccessibleRole.MENU_BAR, AccessibleRole.POPUP_MENU, AccessibleRole.MENU, AccessibleRole.MENU_ITEM, AccessibleRole.SEPARATOR, AccessibleRole.PAGE_TAB_LIST, AccessibleRole.PAGE_TAB, AccessibleRole.PANEL, AccessibleRole.PROGRESS_BAR, AccessibleRole.PASSWORD_TEXT, AccessibleRole.PUSH_BUTTON, AccessibleRole.TOGGLE_BUTTON, AccessibleRole.CHECK_BOX, AccessibleRole.RADIO_BUTTON, AccessibleRole.ROW_HEADER, AccessibleRole.SCROLL_PANE, AccessibleRole.SCROLL_BAR, AccessibleRole.VIEWPORT, AccessibleRole.SLIDER, AccessibleRole.SPLIT_PANE, AccessibleRole.TABLE, AccessibleRole.TEXT, AccessibleRole.TREE, AccessibleRole.TOOL_BAR, AccessibleRole.TOOL_TIP, AccessibleRole.AWT_COMPONENT, AccessibleRole.SWING_COMPONENT, AccessibleRole.UNKNOWN };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private class AccessibleJTreeNode
/*      */     extends AccessibleContext
/*      */     implements Accessible, AccessibleComponent, AccessibleSelection, AccessibleAction
/*      */   {
/* 6098 */     private JTree tree = null;
/* 6099 */     private TreeModel treeModel = null;
/* 6100 */     private Object obj = null;
/* 6101 */     private TreePath path = null;
/* 6102 */     private Accessible accessibleParent = null;
/* 6103 */     private int index = 0;
/* 6104 */     private boolean isLeaf = false;
/*      */     
/*      */ 
/*      */ 
/*      */     AccessibleJTreeNode(JTree paramJTree, TreePath paramTreePath, Accessible paramAccessible)
/*      */     {
/* 6110 */       this.tree = paramJTree;
/* 6111 */       this.path = paramTreePath;
/* 6112 */       this.accessibleParent = paramAccessible;
/* 6113 */       if (paramJTree != null)
/* 6114 */         this.treeModel = paramJTree.getModel();
/* 6115 */       if (paramTreePath != null) {
/* 6116 */         this.obj = paramTreePath.getLastPathComponent();
/* 6117 */         if ((this.treeModel != null) && (this.obj != null)) {
/* 6118 */           this.isLeaf = this.treeModel.isLeaf(this.obj);
/*      */         }
/*      */       }
/* 6121 */       AccessBridge.this.debugString("AccessibleJTreeNode: name = " + getAccessibleName() + "; TreePath = " + paramTreePath + "; parent = " + paramAccessible);
/*      */     }
/*      */     
/*      */ 
/*      */     private TreePath getChildTreePath(int paramInt)
/*      */     {
/* 6127 */       if ((paramInt < 0) || (paramInt >= getAccessibleChildrenCount()) || (this.path == null) || (this.treeModel == null)) {
/* 6128 */         return null;
/*      */       }
/* 6130 */       Object localObject = this.treeModel.getChild(this.obj, paramInt);
/* 6131 */       Object[] arrayOfObject1 = this.path.getPath();
/* 6132 */       Object[] arrayOfObject2 = new Object[arrayOfObject1.length + 1];
/* 6133 */       System.arraycopy(arrayOfObject1, 0, arrayOfObject2, 0, arrayOfObject1.length);
/* 6134 */       arrayOfObject2[(arrayOfObject2.length - 1)] = localObject;
/* 6135 */       return new TreePath(arrayOfObject2);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public AccessibleContext getAccessibleContext()
/*      */     {
/* 6148 */       return this;
/*      */     }
/*      */     
/*      */     private AccessibleContext getCurrentAccessibleContext() {
/* 6152 */       Component localComponent = getCurrentComponent();
/* 6153 */       if ((localComponent instanceof Accessible)) {
/* 6154 */         return localComponent.getAccessibleContext();
/*      */       }
/* 6156 */       return null;
/*      */     }
/*      */     
/*      */     private Component getCurrentComponent()
/*      */     {
/* 6161 */       AccessBridge.this.debugString("AccessibleJTreeNode: getCurrentComponent");
/*      */       
/*      */ 
/*      */ 
/* 6165 */       if ((this.tree != null) && (this.tree.isVisible(this.path))) {
/* 6166 */         javax.swing.tree.TreeCellRenderer localTreeCellRenderer = this.tree.getCellRenderer();
/* 6167 */         if (localTreeCellRenderer == null) {
/* 6168 */           AccessBridge.this.debugString("  returning null 1");
/* 6169 */           return null;
/*      */         }
/* 6171 */         javax.swing.plaf.TreeUI localTreeUI = this.tree.getUI();
/* 6172 */         if (localTreeUI != null) {
/* 6173 */           int i = localTreeUI.getRowForPath(this.tree, this.path);
/* 6174 */           boolean bool1 = this.tree.isPathSelected(this.path);
/* 6175 */           boolean bool2 = this.tree.isExpanded(this.path);
/* 6176 */           boolean bool3 = false;
/* 6177 */           Component localComponent = localTreeCellRenderer.getTreeCellRendererComponent(this.tree, this.obj, bool1, bool2, this.isLeaf, i, bool3);
/*      */           
/*      */ 
/* 6180 */           AccessBridge.this.debugString("  returning = " + localComponent.getClass());
/* 6181 */           return localComponent;
/*      */         }
/*      */       }
/* 6184 */       AccessBridge.this.debugString("  returning null 2");
/* 6185 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public String getAccessibleName()
/*      */     {
/* 6197 */       AccessBridge.this.debugString("AccessibleJTreeNode: getAccessibleName");
/* 6198 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6199 */       if (localAccessibleContext != null) {
/* 6200 */         String str1 = localAccessibleContext.getAccessibleName();
/* 6201 */         if ((str1 != null) && (!str1.isEmpty())) {
/* 6202 */           String str2 = localAccessibleContext.getAccessibleName();
/* 6203 */           AccessBridge.this.debugString("    returning " + str2);
/* 6204 */           return str2;
/*      */         }
/* 6206 */         return null;
/*      */       }
/*      */       
/* 6209 */       if ((this.accessibleName != null) && (this.accessibleName.isEmpty())) {
/* 6210 */         return this.accessibleName;
/*      */       }
/* 6212 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void setAccessibleName(String paramString)
/*      */     {
/* 6222 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6223 */       if (localAccessibleContext != null) {
/* 6224 */         localAccessibleContext.setAccessibleName(paramString);
/*      */       } else {
/* 6226 */         super.setAccessibleName(paramString);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public String getAccessibleDescription()
/*      */     {
/* 6240 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6241 */       if (localAccessibleContext != null) {
/* 6242 */         return localAccessibleContext.getAccessibleDescription();
/*      */       }
/* 6244 */       return super.getAccessibleDescription();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void setAccessibleDescription(String paramString)
/*      */     {
/* 6254 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6255 */       if (localAccessibleContext != null) {
/* 6256 */         localAccessibleContext.setAccessibleDescription(paramString);
/*      */       } else {
/* 6258 */         super.setAccessibleDescription(paramString);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public AccessibleRole getAccessibleRole()
/*      */     {
/* 6269 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6270 */       if (localAccessibleContext != null) {
/* 6271 */         return localAccessibleContext.getAccessibleRole();
/*      */       }
/* 6273 */       return AccessibleRole.UNKNOWN;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public AccessibleStateSet getAccessibleStateSet()
/*      */     {
/* 6285 */       if (this.tree == null)
/* 6286 */         return null;
/* 6287 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/*      */       
/* 6289 */       int i = this.tree.getUI().getRowForPath(this.tree, this.path);
/* 6290 */       int j = this.tree.getLeadSelectionRow();
/* 6291 */       AccessibleStateSet localAccessibleStateSet; if (localAccessibleContext != null) {
/* 6292 */         localAccessibleStateSet = localAccessibleContext.getAccessibleStateSet();
/*      */       } else {
/* 6294 */         localAccessibleStateSet = new AccessibleStateSet();
/*      */       }
/*      */       
/*      */ 
/* 6298 */       if (isShowing()) {
/* 6299 */         localAccessibleStateSet.add(AccessibleState.SHOWING);
/* 6300 */       } else if (localAccessibleStateSet.contains(AccessibleState.SHOWING)) {
/* 6301 */         localAccessibleStateSet.remove(AccessibleState.SHOWING);
/*      */       }
/* 6303 */       if (isVisible()) {
/* 6304 */         localAccessibleStateSet.add(AccessibleState.VISIBLE);
/* 6305 */       } else if (localAccessibleStateSet.contains(AccessibleState.VISIBLE)) {
/* 6306 */         localAccessibleStateSet.remove(AccessibleState.VISIBLE);
/*      */       }
/* 6308 */       if (this.tree.isPathSelected(this.path)) {
/* 6309 */         localAccessibleStateSet.add(AccessibleState.SELECTED);
/*      */       }
/* 6311 */       if (j == i) {
/* 6312 */         localAccessibleStateSet.add(AccessibleState.ACTIVE);
/*      */       }
/* 6314 */       if (!this.isLeaf) {
/* 6315 */         localAccessibleStateSet.add(AccessibleState.EXPANDABLE);
/*      */       }
/* 6317 */       if (this.tree.isExpanded(this.path)) {
/* 6318 */         localAccessibleStateSet.add(AccessibleState.EXPANDED);
/*      */       } else {
/* 6320 */         localAccessibleStateSet.add(AccessibleState.COLLAPSED);
/*      */       }
/* 6322 */       if (this.tree.isEditable()) {
/* 6323 */         localAccessibleStateSet.add(AccessibleState.EDITABLE);
/*      */       }
/* 6325 */       return localAccessibleStateSet;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Accessible getAccessibleParent()
/*      */     {
/* 6337 */       if ((this.accessibleParent == null) && (this.path != null)) {
/* 6338 */         Object[] arrayOfObject1 = this.path.getPath();
/* 6339 */         if (arrayOfObject1.length > 1) {
/* 6340 */           Object localObject = arrayOfObject1[(arrayOfObject1.length - 2)];
/* 6341 */           if (this.treeModel != null) {
/* 6342 */             this.index = this.treeModel.getIndexOfChild(localObject, this.obj);
/*      */           }
/* 6344 */           Object[] arrayOfObject2 = new Object[arrayOfObject1.length - 1];
/* 6345 */           System.arraycopy(arrayOfObject1, 0, arrayOfObject2, 0, arrayOfObject1.length - 1);
/*      */           
/* 6347 */           TreePath localTreePath = new TreePath(arrayOfObject2);
/* 6348 */           this.accessibleParent = new AccessibleJTreeNode(AccessBridge.this, this.tree, localTreePath, null);
/*      */           
/*      */ 
/* 6351 */           setAccessibleParent(this.accessibleParent);
/* 6352 */         } else if (this.treeModel != null) {
/* 6353 */           this.accessibleParent = this.tree;
/* 6354 */           this.index = 0;
/* 6355 */           setAccessibleParent(this.accessibleParent);
/*      */         }
/*      */       }
/* 6358 */       return this.accessibleParent;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int getAccessibleIndexInParent()
/*      */     {
/* 6370 */       if (this.accessibleParent == null) {
/* 6371 */         getAccessibleParent();
/*      */       }
/* 6373 */       if (this.path != null) {
/* 6374 */         Object[] arrayOfObject = this.path.getPath();
/* 6375 */         if (arrayOfObject.length > 1) {
/* 6376 */           Object localObject = arrayOfObject[(arrayOfObject.length - 2)];
/* 6377 */           if (this.treeModel != null) {
/* 6378 */             this.index = this.treeModel.getIndexOfChild(localObject, this.obj);
/*      */           }
/*      */         }
/*      */       }
/* 6382 */       return this.index;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int getAccessibleChildrenCount()
/*      */     {
/* 6393 */       if ((this.obj != null) && (this.treeModel != null)) {
/* 6394 */         return this.treeModel.getChildCount(this.obj);
/*      */       }
/* 6396 */       return 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Accessible getAccessibleChild(int paramInt)
/*      */     {
/* 6408 */       if ((paramInt < 0) || (paramInt >= getAccessibleChildrenCount()) || (this.path == null) || (this.treeModel == null)) {
/* 6409 */         return null;
/*      */       }
/* 6411 */       Object localObject = this.treeModel.getChild(this.obj, paramInt);
/* 6412 */       Object[] arrayOfObject1 = this.path.getPath();
/* 6413 */       Object[] arrayOfObject2 = new Object[arrayOfObject1.length + 1];
/* 6414 */       System.arraycopy(arrayOfObject1, 0, arrayOfObject2, 0, arrayOfObject1.length);
/* 6415 */       arrayOfObject2[(arrayOfObject2.length - 1)] = localObject;
/* 6416 */       TreePath localTreePath = new TreePath(arrayOfObject2);
/* 6417 */       return new AccessibleJTreeNode(AccessBridge.this, this.tree, localTreePath, this);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Locale getLocale()
/*      */     {
/* 6434 */       if (this.tree == null)
/* 6435 */         return null;
/* 6436 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6437 */       if (localAccessibleContext != null) {
/* 6438 */         return localAccessibleContext.getLocale();
/*      */       }
/* 6440 */       return this.tree.getLocale();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener)
/*      */     {
/* 6451 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6452 */       if (localAccessibleContext != null) {
/* 6453 */         localAccessibleContext.addPropertyChangeListener(paramPropertyChangeListener);
/*      */       } else {
/* 6455 */         super.addPropertyChangeListener(paramPropertyChangeListener);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener)
/*      */     {
/* 6467 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6468 */       if (localAccessibleContext != null) {
/* 6469 */         localAccessibleContext.removePropertyChangeListener(paramPropertyChangeListener);
/*      */       } else {
/* 6471 */         super.removePropertyChangeListener(paramPropertyChangeListener);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public AccessibleAction getAccessibleAction()
/*      */     {
/* 6484 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public AccessibleComponent getAccessibleComponent()
/*      */     {
/* 6496 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public AccessibleSelection getAccessibleSelection()
/*      */     {
/* 6506 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6507 */       if ((localAccessibleContext != null) && (this.isLeaf)) {
/* 6508 */         return getCurrentAccessibleContext().getAccessibleSelection();
/*      */       }
/* 6510 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public AccessibleText getAccessibleText()
/*      */     {
/* 6521 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6522 */       if (localAccessibleContext != null) {
/* 6523 */         return getCurrentAccessibleContext().getAccessibleText();
/*      */       }
/* 6525 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public AccessibleValue getAccessibleValue()
/*      */     {
/* 6536 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6537 */       if (localAccessibleContext != null) {
/* 6538 */         return getCurrentAccessibleContext().getAccessibleValue();
/*      */       }
/* 6540 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Color getBackground()
/*      */     {
/* 6554 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6555 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6556 */         return ((AccessibleComponent)localAccessibleContext).getBackground();
/*      */       }
/* 6558 */       Component localComponent = getCurrentComponent();
/* 6559 */       if (localComponent != null) {
/* 6560 */         return localComponent.getBackground();
/*      */       }
/* 6562 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void setBackground(Color paramColor)
/*      */     {
/* 6573 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6574 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6575 */         ((AccessibleComponent)localAccessibleContext).setBackground(paramColor);
/*      */       } else {
/* 6577 */         Component localComponent = getCurrentComponent();
/* 6578 */         if (localComponent != null) {
/* 6579 */           localComponent.setBackground(paramColor);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Color getForeground()
/*      */     {
/* 6592 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6593 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6594 */         return ((AccessibleComponent)localAccessibleContext).getForeground();
/*      */       }
/* 6596 */       Component localComponent = getCurrentComponent();
/* 6597 */       if (localComponent != null) {
/* 6598 */         return localComponent.getForeground();
/*      */       }
/* 6600 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */     public void setForeground(Color paramColor)
/*      */     {
/* 6606 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6607 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6608 */         ((AccessibleComponent)localAccessibleContext).setForeground(paramColor);
/*      */       } else {
/* 6610 */         Component localComponent = getCurrentComponent();
/* 6611 */         if (localComponent != null) {
/* 6612 */           localComponent.setForeground(paramColor);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public java.awt.Cursor getCursor() {
/* 6618 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6619 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6620 */         return ((AccessibleComponent)localAccessibleContext).getCursor();
/*      */       }
/* 6622 */       Component localComponent = getCurrentComponent();
/* 6623 */       if (localComponent != null) {
/* 6624 */         return localComponent.getCursor();
/*      */       }
/* 6626 */       Accessible localAccessible = getAccessibleParent();
/* 6627 */       if ((localAccessible instanceof AccessibleComponent)) {
/* 6628 */         return ((AccessibleComponent)localAccessible).getCursor();
/*      */       }
/* 6630 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setCursor(java.awt.Cursor paramCursor)
/*      */     {
/* 6637 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6638 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6639 */         ((AccessibleComponent)localAccessibleContext).setCursor(paramCursor);
/*      */       } else {
/* 6641 */         Component localComponent = getCurrentComponent();
/* 6642 */         if (localComponent != null) {
/* 6643 */           localComponent.setCursor(paramCursor);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public Font getFont() {
/* 6649 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6650 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6651 */         return ((AccessibleComponent)localAccessibleContext).getFont();
/*      */       }
/* 6653 */       Component localComponent = getCurrentComponent();
/* 6654 */       if (localComponent != null) {
/* 6655 */         return localComponent.getFont();
/*      */       }
/* 6657 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */     public void setFont(Font paramFont)
/*      */     {
/* 6663 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6664 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6665 */         ((AccessibleComponent)localAccessibleContext).setFont(paramFont);
/*      */       } else {
/* 6667 */         Component localComponent = getCurrentComponent();
/* 6668 */         if (localComponent != null) {
/* 6669 */           localComponent.setFont(paramFont);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public java.awt.FontMetrics getFontMetrics(Font paramFont) {
/* 6675 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6676 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6677 */         return ((AccessibleComponent)localAccessibleContext).getFontMetrics(paramFont);
/*      */       }
/* 6679 */       Component localComponent = getCurrentComponent();
/* 6680 */       if (localComponent != null) {
/* 6681 */         return localComponent.getFontMetrics(paramFont);
/*      */       }
/* 6683 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */     public boolean isEnabled()
/*      */     {
/* 6689 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6690 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6691 */         return ((AccessibleComponent)localAccessibleContext).isEnabled();
/*      */       }
/* 6693 */       Component localComponent = getCurrentComponent();
/* 6694 */       if (localComponent != null) {
/* 6695 */         return localComponent.isEnabled();
/*      */       }
/* 6697 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */     public void setEnabled(boolean paramBoolean)
/*      */     {
/* 6703 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6704 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6705 */         ((AccessibleComponent)localAccessibleContext).setEnabled(paramBoolean);
/*      */       } else {
/* 6707 */         Component localComponent = getCurrentComponent();
/* 6708 */         if (localComponent != null) {
/* 6709 */           localComponent.setEnabled(paramBoolean);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean isVisible() {
/* 6715 */       if (this.tree == null)
/* 6716 */         return false;
/* 6717 */       Rectangle localRectangle1 = this.tree.getPathBounds(this.path);
/* 6718 */       Rectangle localRectangle2 = this.tree.getVisibleRect();
/* 6719 */       if ((localRectangle1 != null) && (localRectangle2 != null) && 
/* 6720 */         (localRectangle2.intersects(localRectangle1))) {
/* 6721 */         return true;
/*      */       }
/* 6723 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */     public void setVisible(boolean paramBoolean) {}
/*      */     
/*      */     public boolean isShowing()
/*      */     {
/* 6731 */       return (this.tree.isShowing()) && (isVisible());
/*      */     }
/*      */     
/*      */     public boolean contains(Point paramPoint) {
/* 6735 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6736 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6737 */         localObject = ((AccessibleComponent)localAccessibleContext).getBounds();
/* 6738 */         return ((Rectangle)localObject).contains(paramPoint);
/*      */       }
/* 6740 */       Object localObject = getCurrentComponent();
/* 6741 */       if (localObject != null) {
/* 6742 */         Rectangle localRectangle = ((Component)localObject).getBounds();
/* 6743 */         return localRectangle.contains(paramPoint);
/*      */       }
/* 6745 */       return getBounds().contains(paramPoint);
/*      */     }
/*      */     
/*      */ 
/*      */     public Point getLocationOnScreen()
/*      */     {
/* 6751 */       if (this.tree != null) {
/* 6752 */         Point localPoint1 = this.tree.getLocationOnScreen();
/* 6753 */         Rectangle localRectangle = this.tree.getPathBounds(this.path);
/* 6754 */         if ((localPoint1 != null) && (localRectangle != null)) {
/* 6755 */           Point localPoint2 = new Point(localRectangle.x, localRectangle.y);
/*      */           
/* 6757 */           localPoint2.translate(localPoint1.x, localPoint1.y);
/* 6758 */           return localPoint2;
/*      */         }
/* 6760 */         return null;
/*      */       }
/*      */       
/* 6763 */       return null;
/*      */     }
/*      */     
/*      */     private Point getLocationInJTree()
/*      */     {
/* 6768 */       Rectangle localRectangle = this.tree.getPathBounds(this.path);
/* 6769 */       if (localRectangle != null) {
/* 6770 */         return localRectangle.getLocation();
/*      */       }
/* 6772 */       return null;
/*      */     }
/*      */     
/*      */     public Point getLocation()
/*      */     {
/* 6777 */       Rectangle localRectangle = getBounds();
/* 6778 */       if (localRectangle != null) {
/* 6779 */         return localRectangle.getLocation();
/*      */       }
/* 6781 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */     public void setLocation(Point paramPoint) {}
/*      */     
/*      */     public Rectangle getBounds()
/*      */     {
/* 6789 */       if (this.tree == null)
/* 6790 */         return null;
/* 6791 */       Rectangle localRectangle = this.tree.getPathBounds(this.path);
/* 6792 */       Accessible localAccessible = getAccessibleParent();
/* 6793 */       if ((localAccessible instanceof AccessibleJTreeNode)) {
/* 6794 */         Point localPoint = ((AccessibleJTreeNode)localAccessible).getLocationInJTree();
/* 6795 */         if ((localPoint != null) && (localRectangle != null)) {
/* 6796 */           localRectangle.translate(-localPoint.x, -localPoint.y);
/*      */         } else {
/* 6798 */           return null;
/*      */         }
/*      */       }
/* 6801 */       return localRectangle;
/*      */     }
/*      */     
/*      */     public void setBounds(Rectangle paramRectangle) {
/* 6805 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6806 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6807 */         ((AccessibleComponent)localAccessibleContext).setBounds(paramRectangle);
/*      */       } else {
/* 6809 */         Component localComponent = getCurrentComponent();
/* 6810 */         if (localComponent != null) {
/* 6811 */           localComponent.setBounds(paramRectangle);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public java.awt.Dimension getSize() {
/* 6817 */       return getBounds().getSize();
/*      */     }
/*      */     
/*      */     public void setSize(java.awt.Dimension paramDimension) {
/* 6821 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6822 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6823 */         ((AccessibleComponent)localAccessibleContext).setSize(paramDimension);
/*      */       } else {
/* 6825 */         Component localComponent = getCurrentComponent();
/* 6826 */         if (localComponent != null) {
/* 6827 */           localComponent.setSize(paramDimension);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Accessible getAccessibleAt(Point paramPoint)
/*      */     {
/* 6843 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6844 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6845 */         return ((AccessibleComponent)localAccessibleContext).getAccessibleAt(paramPoint);
/*      */       }
/* 6847 */       return null;
/*      */     }
/*      */     
/*      */     public boolean isFocusTraversable()
/*      */     {
/* 6852 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6853 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6854 */         return ((AccessibleComponent)localAccessibleContext).isFocusTraversable();
/*      */       }
/* 6856 */       Component localComponent = getCurrentComponent();
/* 6857 */       if (localComponent != null) {
/* 6858 */         return localComponent.isFocusable();
/*      */       }
/* 6860 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */     public void requestFocus()
/*      */     {
/* 6866 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6867 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6868 */         ((AccessibleComponent)localAccessibleContext).requestFocus();
/*      */       } else {
/* 6870 */         Component localComponent = getCurrentComponent();
/* 6871 */         if (localComponent != null) {
/* 6872 */           localComponent.requestFocus();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void addFocusListener(FocusListener paramFocusListener) {
/* 6878 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6879 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6880 */         ((AccessibleComponent)localAccessibleContext).addFocusListener(paramFocusListener);
/*      */       } else {
/* 6882 */         Component localComponent = getCurrentComponent();
/* 6883 */         if (localComponent != null) {
/* 6884 */           localComponent.addFocusListener(paramFocusListener);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void removeFocusListener(FocusListener paramFocusListener) {
/* 6890 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 6891 */       if ((localAccessibleContext instanceof AccessibleComponent)) {
/* 6892 */         ((AccessibleComponent)localAccessibleContext).removeFocusListener(paramFocusListener);
/*      */       } else {
/* 6894 */         Component localComponent = getCurrentComponent();
/* 6895 */         if (localComponent != null) {
/* 6896 */           localComponent.removeFocusListener(paramFocusListener);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int getAccessibleSelectionCount()
/*      */     {
/* 6910 */       int i = 0;
/* 6911 */       int j = getAccessibleChildrenCount();
/* 6912 */       for (int k = 0; k < j; k++) {
/* 6913 */         TreePath localTreePath = getChildTreePath(k);
/* 6914 */         if (this.tree.isPathSelected(localTreePath)) {
/* 6915 */           i++;
/*      */         }
/*      */       }
/* 6918 */       return i;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Accessible getAccessibleSelection(int paramInt)
/*      */     {
/* 6931 */       int i = getAccessibleChildrenCount();
/* 6932 */       if ((paramInt < 0) || (paramInt >= i)) {
/* 6933 */         return null;
/*      */       }
/* 6935 */       int j = 0;
/* 6936 */       for (int k = 0; (k < i) && (paramInt >= j); k++) {
/* 6937 */         TreePath localTreePath = getChildTreePath(k);
/* 6938 */         if (this.tree.isPathSelected(localTreePath)) {
/* 6939 */           if (j == paramInt) {
/* 6940 */             return new AccessibleJTreeNode(AccessBridge.this, this.tree, localTreePath, this);
/*      */           }
/* 6942 */           j++;
/*      */         }
/*      */       }
/*      */       
/* 6946 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean isAccessibleChildSelected(int paramInt)
/*      */     {
/* 6957 */       int i = getAccessibleChildrenCount();
/* 6958 */       if ((paramInt < 0) || (paramInt >= i)) {
/* 6959 */         return false;
/*      */       }
/* 6961 */       TreePath localTreePath = getChildTreePath(paramInt);
/* 6962 */       return this.tree.isPathSelected(localTreePath);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void addAccessibleSelection(int paramInt)
/*      */     {
/* 6976 */       if (this.tree == null)
/* 6977 */         return;
/* 6978 */       TreeModel localTreeModel = this.tree.getModel();
/* 6979 */       if ((localTreeModel != null) && 
/* 6980 */         (paramInt >= 0) && (paramInt < getAccessibleChildrenCount())) {
/* 6981 */         TreePath localTreePath = getChildTreePath(paramInt);
/* 6982 */         this.tree.addSelectionPath(localTreePath);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void removeAccessibleSelection(int paramInt)
/*      */     {
/* 6996 */       if (this.tree == null)
/* 6997 */         return;
/* 6998 */       TreeModel localTreeModel = this.tree.getModel();
/* 6999 */       if ((localTreeModel != null) && 
/* 7000 */         (paramInt >= 0) && (paramInt < getAccessibleChildrenCount())) {
/* 7001 */         TreePath localTreePath = getChildTreePath(paramInt);
/* 7002 */         this.tree.removeSelectionPath(localTreePath);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void clearAccessibleSelection()
/*      */     {
/* 7012 */       int i = getAccessibleChildrenCount();
/* 7013 */       for (int j = 0; j < i; j++) {
/* 7014 */         removeAccessibleSelection(j);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void selectAllAccessibleSelection()
/*      */     {
/* 7023 */       if (this.tree == null)
/* 7024 */         return;
/* 7025 */       TreeModel localTreeModel = this.tree.getModel();
/* 7026 */       if (localTreeModel != null) {
/* 7027 */         int i = getAccessibleChildrenCount();
/*      */         
/* 7029 */         for (int j = 0; j < i; j++) {
/* 7030 */           TreePath localTreePath = getChildTreePath(j);
/* 7031 */           this.tree.addSelectionPath(localTreePath);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int getAccessibleActionCount()
/*      */     {
/* 7047 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 7048 */       if (localAccessibleContext != null) {
/* 7049 */         AccessibleAction localAccessibleAction = localAccessibleContext.getAccessibleAction();
/* 7050 */         if (localAccessibleAction != null) {
/* 7051 */           return localAccessibleAction.getAccessibleActionCount() + (this.isLeaf ? 0 : 1);
/*      */         }
/*      */       }
/* 7054 */       return this.isLeaf ? 0 : 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public String getAccessibleActionDescription(int paramInt)
/*      */     {
/* 7067 */       if ((paramInt < 0) || (paramInt >= getAccessibleActionCount())) {
/* 7068 */         return null;
/*      */       }
/* 7070 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 7071 */       if (paramInt == 0)
/*      */       {
/*      */ 
/* 7074 */         return "toggle expand"; }
/* 7075 */       if (localAccessibleContext != null) {
/* 7076 */         AccessibleAction localAccessibleAction = localAccessibleContext.getAccessibleAction();
/* 7077 */         if (localAccessibleAction != null) {
/* 7078 */           return localAccessibleAction.getAccessibleActionDescription(paramInt - 1);
/*      */         }
/*      */       }
/* 7081 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean doAccessibleAction(int paramInt)
/*      */     {
/* 7094 */       if ((paramInt < 0) || (paramInt >= getAccessibleActionCount())) {
/* 7095 */         return false;
/*      */       }
/* 7097 */       AccessibleContext localAccessibleContext = getCurrentAccessibleContext();
/* 7098 */       if (paramInt == 0) {
/* 7099 */         if (this.tree.isExpanded(this.path)) {
/* 7100 */           this.tree.collapsePath(this.path);
/*      */         } else {
/* 7102 */           this.tree.expandPath(this.path);
/*      */         }
/* 7104 */         return true; }
/* 7105 */       if (localAccessibleContext != null) {
/* 7106 */         AccessibleAction localAccessibleAction = localAccessibleContext.getAccessibleAction();
/* 7107 */         if (localAccessibleAction != null) {
/* 7108 */           return localAccessibleAction.doAccessibleAction(paramInt - 1);
/*      */         }
/*      */       }
/* 7111 */       return false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class InvocationUtils
/*      */   {
/*      */     public static <T> T invokeAndWait(Callable<T> paramCallable, Accessible paramAccessible)
/*      */     {
/* 7135 */       if ((paramAccessible instanceof Component)) {
/* 7136 */         return (T)invokeAndWait(paramCallable, (Component)paramAccessible);
/*      */       }
/* 7138 */       if ((paramAccessible instanceof AccessibleContext))
/*      */       {
/* 7140 */         return (T)invokeAndWait(paramCallable, (AccessibleContext)paramAccessible);
/*      */       }
/* 7142 */       throw new RuntimeException("Unmapped Accessible used to dispatch event: " + paramAccessible);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public static <T> T invokeAndWait(Callable<T> paramCallable, Component paramComponent)
/*      */     {
/* 7158 */       return (T)invokeAndWait(paramCallable, SunToolkit.targetToAppContext(paramComponent));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public static <T> T invokeAndWait(Callable<T> paramCallable, AccessibleContext paramAccessibleContext)
/*      */     {
/* 7175 */       AppContext localAppContext = sun.awt.AWTAccessor.getAccessibleContextAccessor().getAppContext(paramAccessibleContext);
/* 7176 */       if (localAppContext != null) {
/* 7177 */         return (T)invokeAndWait(paramCallable, localAppContext);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 7183 */       if ((paramAccessibleContext instanceof Translator)) {
/* 7184 */         Object localObject = ((Translator)paramAccessibleContext).getSource();
/* 7185 */         if ((localObject instanceof Component)) {
/* 7186 */           return (T)invokeAndWait(paramCallable, (Component)localObject);
/*      */         }
/*      */       }
/*      */       
/* 7190 */       throw new RuntimeException("Unmapped AccessibleContext used to dispatch event: " + paramAccessibleContext);
/*      */     }
/*      */     
/*      */     private static <T> T invokeAndWait(Callable<T> paramCallable, AppContext paramAppContext)
/*      */     {
/* 7195 */       CallableWrapper localCallableWrapper = new CallableWrapper(paramCallable);
/*      */       try {
/* 7197 */         invokeAndWait(localCallableWrapper, paramAppContext);
/* 7198 */         Object localObject = localCallableWrapper.getResult();
/* 7199 */         updateAppContextMap(localObject, paramAppContext);
/* 7200 */         return (T)localObject;
/*      */       } catch (Exception localException) {
/* 7202 */         throw new RuntimeException(localException);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     private static void invokeAndWait(Runnable paramRunnable, AppContext paramAppContext)
/*      */       throws InterruptedException, InvocationTargetException
/*      */     {
/* 7210 */       EventQueue localEventQueue = SunToolkit.getSystemEventQueueImplPP(paramAppContext);
/* 7211 */       Object localObject1 = new Object();
/* 7212 */       java.awt.Toolkit localToolkit = java.awt.Toolkit.getDefaultToolkit();
/* 7213 */       java.awt.event.InvocationEvent localInvocationEvent = new java.awt.event.InvocationEvent(localToolkit, paramRunnable, localObject1, true);
/*      */       
/* 7215 */       synchronized (localObject1) {
/* 7216 */         localEventQueue.postEvent(localInvocationEvent);
/* 7217 */         localObject1.wait();
/*      */       }
/*      */       
/* 7220 */       ??? = localInvocationEvent.getThrowable();
/* 7221 */       if (??? != null) {
/* 7222 */         throw new InvocationTargetException((Throwable)???);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public static void registerAccessibleContext(AccessibleContext paramAccessibleContext, AppContext paramAppContext)
/*      */     {
/* 7234 */       if (paramAccessibleContext != null) {
/* 7235 */         sun.awt.AWTAccessor.getAccessibleContextAccessor().setAppContext(paramAccessibleContext, paramAppContext);
/*      */       }
/*      */     }
/*      */     
/*      */     private static <T> void updateAppContextMap(T paramT, AppContext paramAppContext)
/*      */     {
/* 7241 */       if ((paramT instanceof AccessibleContext)) {
/* 7242 */         registerAccessibleContext((AccessibleContext)paramT, paramAppContext);
/*      */       }
/*      */     }
/*      */     
/*      */     private static class CallableWrapper<T> implements Runnable {
/*      */       private final Callable<T> callable;
/*      */       private volatile T object;
/*      */       private Exception e;
/*      */       
/*      */       CallableWrapper(Callable<T> paramCallable) {
/* 7252 */         this.callable = paramCallable;
/*      */       }
/*      */       
/*      */       public void run() {
/*      */         try {
/* 7257 */           if (this.callable != null) {
/* 7258 */             this.object = this.callable.call();
/*      */           }
/*      */         } catch (Exception localException) {
/* 7261 */           this.e = localException;
/*      */         }
/*      */       }
/*      */       
/*      */       T getResult() throws Exception {
/* 7266 */         if (this.e != null)
/* 7267 */           throw this.e;
/* 7268 */         return (T)this.object;
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\access-bridge-32.jar!\com\sun\java\accessibility\AccessBridge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */