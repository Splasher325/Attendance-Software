/*     */ package sun.util.resources.cldr.en;
/*     */ 
/*     */ import sun.util.resources.TimeZoneNamesBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeZoneNames_en_NZ
/*     */   extends TimeZoneNamesBundle
/*     */ {
/*     */   protected final Object[][] getContents()
/*     */   {
/*  69 */     String[] arrayOfString1 = { "Chatham Standard Time", "CHAST", "Chatham Daylight Time", "CHADT", "Chatham Time", "CHAT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */     String[] arrayOfString2 = { "Lord Howe Standard Time", "LHST", "Lord Howe Daylight Time", "LHDT", "Lord Howe Time", "LHT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */     String[] arrayOfString3 = { "New Zealand Standard Time", "NZST", "New Zealand Daylight Time", "NZDT", "New Zealand Time", "NZT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     String[] arrayOfString4 = { "Western European Standard Time", "∅∅∅", "Western European Summer Time", "∅∅∅", "Western European Time", "∅∅∅" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */     String[] arrayOfString5 = { "Australian Eastern Standard Time", "AEST", "Australian Eastern Daylight Time", "AEDT", "Eastern Australia Time", "AET" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */     String[] arrayOfString6 = { "Australian Central Western Standard Time", "ACWST", "Australian Central Western Daylight Time", "ACWDT", "Australian Central Western Time", "ACWT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 117 */     String[] arrayOfString7 = { "Australian Western Standard Time", "AWST", "Australian Western Daylight Time", "AWDT", "Western Australia Time", "AWT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */     String[] arrayOfString8 = { "Central European Standard Time", "∅∅∅", "Central European Summer Time", "∅∅∅", "Central European Time", "∅∅∅" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 133 */     String[] arrayOfString9 = { "Australian Central Standard Time", "ACST", "Australian Central Daylight Time", "ACDT", "Central Australia Time", "ACT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 141 */     String[] arrayOfString10 = { "Eastern European Standard Time", "∅∅∅", "Eastern European Summer Time", "∅∅∅", "Eastern European Time", "∅∅∅" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 149 */     String[] arrayOfString11 = { "Atlantic Standard Time", "∅∅∅", "Atlantic Daylight Time", "∅∅∅", "Atlantic Time", "∅∅∅" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 157 */     Object[][] arrayOfObject = { { "Europe/Sofia", arrayOfString10 }, { "Europe/Monaco", arrayOfString8 }, { "Atlantic/Bermuda", arrayOfString11 }, { "America/St_Vincent", arrayOfString11 }, { "Europe/Vienna", arrayOfString8 }, { "Europe/Malta", arrayOfString8 }, { "Europe/Madrid", arrayOfString8 }, { "Australia/Hobart", arrayOfString5 }, { "Europe/Mariehamn", arrayOfString10 }, { "Australia/Melbourne", arrayOfString5 }, { "America/Antigua", arrayOfString11 }, { "Australia/Sydney", arrayOfString5 }, { "Australia/Lord_Howe", arrayOfString2 }, { "Asia/Nicosia", arrayOfString10 }, { "Europe/Lisbon", arrayOfString4 }, { "Europe/Luxembourg", arrayOfString8 }, { "Europe/Zurich", arrayOfString8 }, { "Australia/Currie", arrayOfString5 }, { "America/Anguilla", arrayOfString11 }, { "Asia/Amman", arrayOfString10 }, { "Europe/Brussels", arrayOfString8 }, { "Europe/Zaporozhye", arrayOfString10 }, { "Africa/Tripoli", arrayOfString10 }, { "Europe/Simferopol", arrayOfString10 }, { "Antarctica/McMurdo", arrayOfString3 }, { "Europe/Rome", arrayOfString8 }, { "Europe/Istanbul", arrayOfString10 }, { "America/Thule", arrayOfString11 }, { "Europe/Copenhagen", arrayOfString8 }, { "Europe/Bucharest", arrayOfString10 }, { "Europe/Helsinki", arrayOfString10 }, { "Europe/Amsterdam", arrayOfString8 }, { "Europe/Athens", arrayOfString10 }, { "America/Puerto_Rico", arrayOfString11 }, { "Asia/Hebron", arrayOfString10 }, { "Australia/Broken_Hill", arrayOfString9 }, { "Antarctica/Casey", arrayOfString7 }, { "Australia/Eucla", arrayOfString6 }, { "Europe/Stockholm", arrayOfString8 }, { "Europe/Berlin", arrayOfString8 }, { "Europe/Chisinau", arrayOfString10 }, { "America/St_Kitts", arrayOfString11 }, { "America/Curacao", arrayOfString11 }, { "Europe/Budapest", arrayOfString8 }, { "Africa/Tunis", arrayOfString8 }, { "Europe/San_Marino", arrayOfString8 }, { "Europe/Vaduz", arrayOfString8 }, { "Europe/Prague", arrayOfString8 }, { "Europe/Ljubljana", arrayOfString8 }, { "America/Montserrat", arrayOfString11 }, { "Africa/Algiers", arrayOfString8 }, { "America/Martinique", arrayOfString11 }, { "America/St_Lucia", arrayOfString11 }, { "Europe/Gibraltar", arrayOfString8 }, { "America/Aruba", arrayOfString11 }, { "America/Tortola", arrayOfString11 }, { "Asia/Damascus", arrayOfString10 }, { "America/Port_of_Spain", arrayOfString11 }, { "America/St_Thomas", arrayOfString11 }, { "Australia/Lindeman", arrayOfString5 }, { "Europe/Minsk", arrayOfString10 }, { "Europe/Vilnius", arrayOfString10 }, { "America/Halifax", arrayOfString11 }, { "America/Moncton", arrayOfString11 }, { "Atlantic/Faeroe", arrayOfString4 }, { "Australia/Perth", arrayOfString7 }, { "Europe/Podgorica", arrayOfString8 }, { "Europe/Riga", arrayOfString10 }, { "Atlantic/Canary", arrayOfString4 }, { "America/Santo_Domingo", arrayOfString11 }, { "America/Goose_Bay", arrayOfString11 }, { "Europe/Oslo", arrayOfString8 }, { "Europe/Vatican", arrayOfString8 }, { "Europe/Tirane", arrayOfString8 }, { "America/Glace_Bay", arrayOfString11 }, { "Europe/Tallinn", arrayOfString10 }, { "America/Dominica", arrayOfString11 }, { "Australia/Brisbane", arrayOfString5 }, { "America/Barbados", arrayOfString11 }, { "Europe/Uzhgorod", arrayOfString10 }, { "America/Grenada", arrayOfString11 }, { "Australia/Darwin", arrayOfString9 }, { "Europe/Skopje", arrayOfString8 }, { "Australia/Adelaide", arrayOfString9 }, { "Arctic/Longyearbyen", arrayOfString8 }, { "Africa/Ceuta", arrayOfString8 }, { "Africa/El_Aaiun", arrayOfString4 }, { "Europe/Andorra", arrayOfString8 }, { "Pacific/Auckland", arrayOfString3 }, { "Africa/Casablanca", arrayOfString4 }, { "America/St_Barthelemy", arrayOfString11 }, { "Asia/Gaza", arrayOfString10 }, { "America/Kralendijk", arrayOfString11 }, { "Asia/Beirut", arrayOfString10 }, { "Europe/Paris", arrayOfString8 }, { "America/Lower_Princes", arrayOfString11 }, { "Pacific/Chatham", arrayOfString1 }, { "Europe/Sarajevo", arrayOfString8 }, { "America/Blanc-Sablon", arrayOfString11 }, { "Europe/Bratislava", arrayOfString8 }, { "America/Guadeloupe", arrayOfString11 }, { "America/Marigot", arrayOfString11 }, { "Europe/Zagreb", arrayOfString8 }, { "Europe/Warsaw", arrayOfString8 }, { "Europe/Kiev", arrayOfString10 }, { "Africa/Cairo", arrayOfString10 }, { "Europe/Belgrade", arrayOfString8 }, { "Atlantic/Madeira", arrayOfString4 } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 267 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\en\TimeZoneNames_en_NZ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */