/*     */ package sun.util.resources.cldr.en;
/*     */ 
/*     */ import sun.util.resources.TimeZoneNamesBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeZoneNames_en_GB
/*     */   extends TimeZoneNamesBundle
/*     */ {
/*     */   protected final Object[][] getContents()
/*     */   {
/*  69 */     String[] arrayOfString1 = { "Western European Standard Time", "WET", "Western European Summer Time", "WEST", "Western European Time", "WET" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */     String[] arrayOfString2 = { "Central European Standard Time", "CET", "Central European Summer Time", "CEST", "Central European Time", "CET" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */     String[] arrayOfString3 = { "Eastern European Standard Time", "EET", "Eastern European Summer Time", "EEST", "Eastern European Time", "EET" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     Object[][] arrayOfObject = { { "Europe/Sofia", arrayOfString3 }, { "Europe/Monaco", arrayOfString2 }, { "Europe/Gibraltar", arrayOfString2 }, { "Europe/Vienna", arrayOfString2 }, { "Asia/Damascus", arrayOfString3 }, { "Europe/Malta", arrayOfString2 }, { "Europe/Madrid", arrayOfString2 }, { "Europe/Minsk", arrayOfString3 }, { "Europe/Vilnius", arrayOfString3 }, { "Europe/Mariehamn", arrayOfString3 }, { "Atlantic/Faeroe", arrayOfString1 }, { "Europe/Podgorica", arrayOfString2 }, { "Asia/Nicosia", arrayOfString3 }, { "Europe/Lisbon", arrayOfString1 }, { "Europe/Riga", arrayOfString3 }, { "Europe/Luxembourg", arrayOfString2 }, { "Europe/Zurich", arrayOfString2 }, { "Atlantic/Canary", arrayOfString1 }, { "Asia/Amman", arrayOfString3 }, { "Europe/Brussels", arrayOfString2 }, { "Europe/Zaporozhye", arrayOfString3 }, { "Africa/Tripoli", arrayOfString3 }, { "Europe/Simferopol", arrayOfString3 }, { "Europe/Oslo", arrayOfString2 }, { "Europe/Rome", arrayOfString2 }, { "Europe/Vatican", arrayOfString2 }, { "Europe/Tirane", arrayOfString2 }, { "Europe/Istanbul", arrayOfString3 }, { "Europe/Copenhagen", arrayOfString2 }, { "Europe/Bucharest", arrayOfString3 }, { "Europe/Helsinki", arrayOfString3 }, { "Europe/Tallinn", arrayOfString3 }, { "Europe/Amsterdam", arrayOfString2 }, { "Europe/Athens", arrayOfString3 }, { "Asia/Hebron", arrayOfString3 }, { "Europe/Uzhgorod", arrayOfString3 }, { "Europe/Stockholm", arrayOfString2 }, { "Europe/Berlin", arrayOfString2 }, { "Europe/Skopje", arrayOfString2 }, { "Arctic/Longyearbyen", arrayOfString2 }, { "Africa/Ceuta", arrayOfString2 }, { "Africa/El_Aaiun", arrayOfString1 }, { "Europe/Andorra", arrayOfString2 }, { "Europe/Chisinau", arrayOfString3 }, { "Africa/Casablanca", arrayOfString1 }, { "Asia/Gaza", arrayOfString3 }, { "Europe/Budapest", arrayOfString2 }, { "Africa/Tunis", arrayOfString2 }, { "Asia/Beirut", arrayOfString3 }, { "Europe/Paris", arrayOfString2 }, { "Europe/San_Marino", arrayOfString2 }, { "Europe/Vaduz", arrayOfString2 }, { "Europe/Sarajevo", arrayOfString2 }, { "Europe/Prague", arrayOfString2 }, { "Europe/Bratislava", arrayOfString2 }, { "Europe/Ljubljana", arrayOfString2 }, { "Europe/Zagreb", arrayOfString2 }, { "Africa/Algiers", arrayOfString2 }, { "Europe/Warsaw", arrayOfString2 }, { "Europe/Kiev", arrayOfString3 }, { "Africa/Cairo", arrayOfString3 }, { "Europe/Belgrade", arrayOfString2 }, { "Europe/London", { "Greenwich Mean Time", "GMT", "British Summer Time", "BST", "Greenwich Time", "GT" } }, { "Atlantic/Madeira", arrayOfString1 } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 168 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\en\TimeZoneNames_en_GB.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */