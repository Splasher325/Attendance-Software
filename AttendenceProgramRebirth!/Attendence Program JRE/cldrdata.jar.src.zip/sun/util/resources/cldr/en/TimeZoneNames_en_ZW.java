/*     */ package sun.util.resources.cldr.en;
/*     */ 
/*     */ import sun.util.resources.TimeZoneNamesBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeZoneNames_en_ZW
/*     */   extends TimeZoneNamesBundle
/*     */ {
/*     */   protected final Object[][] getContents()
/*     */   {
/*  69 */     String[] arrayOfString1 = { "West Africa Standard Time", "WAT", "West Africa Summer Time", "WAST", "West Africa Time", "WAT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */     String[] arrayOfString2 = { "Central Africa Time", "CAT", "Central Africa Summer Time", "CAST", "Central Africa Time", "CAT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */     String[] arrayOfString3 = { "South Africa Standard Time", "SAST", "South Africa Daylight Time", "SADT", "South Africa Time", "SAT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     String[] arrayOfString4 = { "East Africa Time", "EAT", "East Africa Summer Time", "EAST", "East Africa Time", "EAT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */     Object[][] arrayOfObject = { { "Africa/Ndjamena", arrayOfString1 }, { "Africa/Douala", arrayOfString1 }, { "Africa/Johannesburg", arrayOfString3 }, { "Africa/Lusaka", arrayOfString2 }, { "Africa/Windhoek", arrayOfString1 }, { "Africa/Libreville", arrayOfString1 }, { "Indian/Comoro", arrayOfString4 }, { "Africa/Asmera", arrayOfString4 }, { "Africa/Kampala", arrayOfString4 }, { "Africa/Blantyre", arrayOfString2 }, { "Africa/Luanda", arrayOfString1 }, { "Africa/Kinshasa", arrayOfString1 }, { "Africa/Addis_Ababa", arrayOfString4 }, { "Africa/Dar_es_Salaam", arrayOfString4 }, { "Africa/Mogadishu", arrayOfString4 }, { "Africa/Bujumbura", arrayOfString2 }, { "Africa/Nairobi", arrayOfString4 }, { "Africa/Malabo", arrayOfString1 }, { "Indian/Antananarivo", arrayOfString4 }, { "Africa/Gaborone", arrayOfString2 }, { "Africa/Maseru", arrayOfString3 }, { "Africa/Brazzaville", arrayOfString1 }, { "Africa/Mbabane", arrayOfString3 }, { "Africa/Lagos", arrayOfString1 }, { "Africa/Porto-Novo", arrayOfString1 }, { "Africa/Niamey", arrayOfString1 }, { "Africa/Maputo", arrayOfString2 }, { "Africa/Juba", arrayOfString4 }, { "Africa/Djibouti", arrayOfString4 }, { "Africa/Harare", arrayOfString2 }, { "Africa/Bangui", arrayOfString1 }, { "Africa/Lubumbashi", arrayOfString2 }, { "Africa/Kigali", arrayOfString2 }, { "Africa/Khartoum", arrayOfString4 }, { "Indian/Mayotte", arrayOfString4 } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 138 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\en\TimeZoneNames_en_ZW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */