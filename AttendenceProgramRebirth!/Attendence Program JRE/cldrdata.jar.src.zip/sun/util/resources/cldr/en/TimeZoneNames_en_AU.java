/*     */ package sun.util.resources.cldr.en;
/*     */ 
/*     */ import sun.util.resources.TimeZoneNamesBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeZoneNames_en_AU
/*     */   extends TimeZoneNamesBundle
/*     */ {
/*     */   protected final Object[][] getContents()
/*     */   {
/*  69 */     String[] arrayOfString1 = { "Lord Howe Standard Time", "LHST", "Lord Howe Daylight Time", "LHDT", "Lord Howe Time", "LHT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */     String[] arrayOfString2 = { "New Zealand Standard Time", "NZST", "New Zealand Daylight Time", "NZDT", "New Zealand Time", "NZT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */     String[] arrayOfString3 = { "Western European Standard Time", "∅∅∅", "Western European Summer Time", "∅∅∅", "Western European Time", "∅∅∅" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     String[] arrayOfString4 = { "Australian Eastern Standard Time", "AEST", "Australian Eastern Daylight Time", "AEDT", "Eastern Australia Time", "AET" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */     String[] arrayOfString5 = { "Australian Central Western Standard Time", "ACWST", "Australian Central Western Daylight Time", "ACWDT", "Australian Central Western Time", "ACWT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */     String[] arrayOfString6 = { "Australian Western Standard Time", "AWST", "Australian Western Daylight Time", "AWDT", "Western Australia Time", "AWT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 117 */     String[] arrayOfString7 = { "Central European Standard Time", "∅∅∅", "Central European Summer Time", "∅∅∅", "Central European Time", "∅∅∅" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */     String[] arrayOfString8 = { "Australian Central Standard Time", "ACST", "Australian Central Daylight Time", "ACDT", "Central Australia Time", "ACT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 133 */     String[] arrayOfString9 = { "Eastern European Standard Time", "∅∅∅", "Eastern European Summer Time", "∅∅∅", "Eastern European Time", "∅∅∅" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 141 */     String[] arrayOfString10 = { "Atlantic Standard Time", "∅∅∅", "Atlantic Daylight Time", "∅∅∅", "Atlantic Time", "∅∅∅" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 149 */     Object[][] arrayOfObject = { { "Europe/Sofia", arrayOfString9 }, { "Europe/Monaco", arrayOfString7 }, { "Atlantic/Bermuda", arrayOfString10 }, { "America/St_Vincent", arrayOfString10 }, { "Europe/Vienna", arrayOfString7 }, { "Europe/Malta", arrayOfString7 }, { "Europe/Madrid", arrayOfString7 }, { "Australia/Hobart", arrayOfString4 }, { "Europe/Mariehamn", arrayOfString9 }, { "Australia/Melbourne", arrayOfString4 }, { "America/Antigua", arrayOfString10 }, { "Australia/Sydney", arrayOfString4 }, { "Australia/Lord_Howe", arrayOfString1 }, { "Asia/Nicosia", arrayOfString9 }, { "Europe/Lisbon", arrayOfString3 }, { "Europe/Luxembourg", arrayOfString7 }, { "Europe/Zurich", arrayOfString7 }, { "Australia/Currie", arrayOfString4 }, { "America/Anguilla", arrayOfString10 }, { "Asia/Amman", arrayOfString9 }, { "Europe/Brussels", arrayOfString7 }, { "Europe/Zaporozhye", arrayOfString9 }, { "Africa/Tripoli", arrayOfString9 }, { "Europe/Simferopol", arrayOfString9 }, { "Antarctica/McMurdo", arrayOfString2 }, { "Europe/Rome", arrayOfString7 }, { "Europe/Istanbul", arrayOfString9 }, { "America/Thule", arrayOfString10 }, { "Europe/Copenhagen", arrayOfString7 }, { "Europe/Bucharest", arrayOfString9 }, { "Europe/Helsinki", arrayOfString9 }, { "Europe/Amsterdam", arrayOfString7 }, { "Europe/Athens", arrayOfString9 }, { "America/Puerto_Rico", arrayOfString10 }, { "Asia/Hebron", arrayOfString9 }, { "Australia/Broken_Hill", arrayOfString8 }, { "Antarctica/Casey", arrayOfString6 }, { "Australia/Eucla", arrayOfString5 }, { "Europe/Stockholm", arrayOfString7 }, { "Europe/Berlin", arrayOfString7 }, { "Europe/Chisinau", arrayOfString9 }, { "America/St_Kitts", arrayOfString10 }, { "America/Curacao", arrayOfString10 }, { "Europe/Budapest", arrayOfString7 }, { "Africa/Tunis", arrayOfString7 }, { "Europe/San_Marino", arrayOfString7 }, { "Europe/Vaduz", arrayOfString7 }, { "Europe/Prague", arrayOfString7 }, { "Europe/Ljubljana", arrayOfString7 }, { "America/Montserrat", arrayOfString10 }, { "Africa/Algiers", arrayOfString7 }, { "America/Martinique", arrayOfString10 }, { "America/St_Lucia", arrayOfString10 }, { "Europe/Gibraltar", arrayOfString7 }, { "America/Aruba", arrayOfString10 }, { "America/Tortola", arrayOfString10 }, { "Asia/Damascus", arrayOfString9 }, { "America/Port_of_Spain", arrayOfString10 }, { "America/St_Thomas", arrayOfString10 }, { "Australia/Lindeman", arrayOfString4 }, { "Europe/Minsk", arrayOfString9 }, { "Europe/Vilnius", arrayOfString9 }, { "America/Halifax", arrayOfString10 }, { "America/Moncton", arrayOfString10 }, { "Atlantic/Faeroe", arrayOfString3 }, { "Australia/Perth", arrayOfString6 }, { "Europe/Podgorica", arrayOfString7 }, { "Europe/Riga", arrayOfString9 }, { "Atlantic/Canary", arrayOfString3 }, { "America/Santo_Domingo", arrayOfString10 }, { "America/Goose_Bay", arrayOfString10 }, { "Europe/Oslo", arrayOfString7 }, { "Europe/Vatican", arrayOfString7 }, { "Europe/Tirane", arrayOfString7 }, { "America/Glace_Bay", arrayOfString10 }, { "Europe/Tallinn", arrayOfString9 }, { "America/Dominica", arrayOfString10 }, { "Australia/Brisbane", arrayOfString4 }, { "America/Barbados", arrayOfString10 }, { "Europe/Uzhgorod", arrayOfString9 }, { "America/Grenada", arrayOfString10 }, { "Australia/Darwin", arrayOfString8 }, { "Europe/Skopje", arrayOfString7 }, { "Australia/Adelaide", arrayOfString8 }, { "Arctic/Longyearbyen", arrayOfString7 }, { "Africa/Ceuta", arrayOfString7 }, { "Africa/El_Aaiun", arrayOfString3 }, { "Europe/Andorra", arrayOfString7 }, { "Pacific/Auckland", arrayOfString2 }, { "Africa/Casablanca", arrayOfString3 }, { "America/St_Barthelemy", arrayOfString10 }, { "Asia/Gaza", arrayOfString9 }, { "America/Kralendijk", arrayOfString10 }, { "Asia/Beirut", arrayOfString9 }, { "Europe/Paris", arrayOfString7 }, { "America/Lower_Princes", arrayOfString10 }, { "Europe/Sarajevo", arrayOfString7 }, { "America/Blanc-Sablon", arrayOfString10 }, { "Europe/Bratislava", arrayOfString7 }, { "America/Guadeloupe", arrayOfString10 }, { "America/Marigot", arrayOfString10 }, { "Europe/Zagreb", arrayOfString7 }, { "Europe/Warsaw", arrayOfString7 }, { "Europe/Kiev", arrayOfString9 }, { "Africa/Cairo", arrayOfString9 }, { "Europe/Belgrade", arrayOfString7 }, { "Atlantic/Madeira", arrayOfString3 } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 258 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\en\TimeZoneNames_en_AU.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */