/*    */ package sun.util.resources.cldr.bn;
/*    */ 
/*    */ import sun.util.resources.OpenListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocaleNames_bn_IN
/*    */   extends OpenListResourceBundle
/*    */ {
/*    */   protected final Object[][] getContents()
/*    */   {
/* 69 */     Object[][] arrayOfObject = { { "ab", "আবখাজিয়ান" }, { "ch", "চামোরো" }, { "cu", "চার্চ স্লাভিক" }, { "ace", "অ্যাচাইনিজ" }, { "ach", "আকোলি" }, { "afa", "আফ্রো-এশিয়াটিক ভাষা" }, { "alg", "আলগোনকিউয়ান ভাষা" }, { "anp", "আঙ্গিকা" }, { "chn", "চিনুক জার্গন" }, { "cho", "চকটোও" }, { "chp", "চিপেওয়াইয়ান" }, { "chy", "চেয়েনি" }, { "doi", "ডোগরি" }, { "map", "অস্ট্রোনেসিয়ান" }, { "rup", "আরমেনিয়ান" }, { "tut", "আলটাইক" }, { "zbl", "ব্লিসসিম্বলস" }, { "de_AT", "অস্ট্রিয়ান জারমান" }, { "en_AU", "অস্ট্রেলিয়ান ইংরাজী" }, { "en_CA", "ক্যানাডিয়ান ইংরেজি" }, { "en_GB", "ব্রিটিশ ইংরেজী" }, { "fr_CA", "ক্যানাডিয়ান ফরাসী" } };
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 93 */     return arrayOfObject;
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\bn\LocaleNames_bn_IN.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */