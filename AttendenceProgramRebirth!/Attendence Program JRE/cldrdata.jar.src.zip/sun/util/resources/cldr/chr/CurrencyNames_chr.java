/*    */ package sun.util.resources.cldr.chr;
/*    */ 
/*    */ import sun.util.resources.OpenListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CurrencyNames_chr
/*    */   extends OpenListResourceBundle
/*    */ {
/*    */   protected final Object[][] getContents()
/*    */   {
/* 69 */     Object[][] arrayOfObject = { { "USD", "$" }, { "brl", "ᏆᏏᎵᎢ ᎠᏕᎳ" }, { "cad", "ᎧᎾᏓ ᎠᏕᎳ" }, { "cny", "ᏓᎶᏂᎨ ᎠᏕᎳ" }, { "eur", "ᏳᎳᏛ" }, { "gbp", "ᎩᎵᏏᏲ ᎠᏕᎳ" }, { "inr", "ᎢᏅᏗᎾ ᎠᏕᎳ" }, { "jpy", "ᏣᏩᏂᏏ ᎠᏕᎳ" }, { "mxn", "ᏍᏆᏂ ᎠᏕᎳ" }, { "rub", "ᏲᏂᎢ ᎠᏕᎳ" }, { "usd", "ᎤᏃᏍᏗ" } };
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 82 */     return arrayOfObject;
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\chr\CurrencyNames_chr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */