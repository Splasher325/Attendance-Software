/*     */ package sun.util.resources.cldr.chr;
/*     */ 
/*     */ import sun.util.resources.TimeZoneNamesBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeZoneNames_chr
/*     */   extends TimeZoneNamesBundle
/*     */ {
/*     */   protected final Object[][] getContents()
/*     */   {
/*  69 */     String[] arrayOfString1 = { "ᎢᏤ ᎢᏳᏍᏗ ᎢᏳᏩᎪᏗ", "GMT", "Greenwich Summer Time", "GST", "Greenwich Time", "GT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */     String[] arrayOfString2 = { "ᎧᎸᎬᎢᏗᏢ ᏰᎵᏊ ᏗᏙᎳᎩ ᎢᏳᏩᎪᏗ", "EST", "ᎧᎸᎬᎢᏗᏢ ᎢᎦ ᎢᏳᏩᎪᏗ", "EDT", "ᎧᎸᎬᎢᏗᏢ ᎢᏳᏩᎪᏗ", "ET" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */     String[] arrayOfString3 = { "ᎣᏓᎸ ᏰᎵᏊ ᏗᏙᎳᎩ ᎢᏳᏩᎪᏗ", "MST", "ᎣᏓᎸ ᎢᎦ ᎢᏳᏩᎪᏗ", "MDT", "ᎣᏓᎸ ᎢᏳᏩᎪᏗ", "MT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     String[] arrayOfString4 = { "ᏭᏕᎵᎬ ᏰᎵᏊ ᏗᏙᎳᎩ ᎢᏳᏩᎪᏗ", "PST", "ᏭᏕᎵᎬ ᎢᎦ ᎢᏳᏩᎪᏗ", "PDT", "ᏭᏕᎵᎬ ᎢᏳᏩᎪᏗ", "PT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */     String[] arrayOfString5 = { "ᎠᏰᎵ ᏰᎵᏊ ᏗᏙᎳᎩ ᎢᏳᏩᎪᏗ", "CST", "ᎠᏰᎵ ᎢᎦ ᎢᏳᏩᎪᏗ", "CDT", "ᎠᏰᎵ ᎢᏳᏩᎪᏗ", "CT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */     Object[][] arrayOfObject = { { "America/Inuvik", arrayOfString3 }, { "Africa/Bissau", arrayOfString1 }, { "America/Jamaica", arrayOfString2 }, { "America/Dawson", arrayOfString4 }, { "Africa/Abidjan", arrayOfString1 }, { "America/Port-au-Prince", arrayOfString2 }, { "America/New_York", arrayOfString2 }, { "Atlantic/Reykjavik", arrayOfString1 }, { "America/Indiana/Vevay", arrayOfString2 }, { "Atlantic/St_Helena", arrayOfString1 }, { "America/Indiana/Marengo", arrayOfString2 }, { "America/Phoenix", arrayOfString3 }, { "Africa/Banjul", arrayOfString1 }, { "America/Resolute", arrayOfString5 }, { "America/Winnipeg", arrayOfString5 }, { "America/Danmarkshavn", arrayOfString1 }, { "Europe/Dublin", arrayOfString1 }, { "America/Regina", arrayOfString5 }, { "America/Cancun", arrayOfString5 }, { "America/North_Dakota/Center", arrayOfString5 }, { "America/Tijuana", arrayOfString4 }, { "Africa/Monrovia", arrayOfString1 }, { "America/Dawson_Creek", arrayOfString3 }, { "America/Bahia_Banderas", arrayOfString5 }, { "America/Matamoros", arrayOfString5 }, { "America/Denver", arrayOfString3 }, { "America/Chihuahua", arrayOfString3 }, { "America/Coral_Harbour", arrayOfString2 }, { "America/Yellowknife", arrayOfString3 }, { "PST8PDT", arrayOfString4 }, { "America/Cayman", arrayOfString2 }, { "Africa/Bamako", arrayOfString1 }, { "America/Detroit", arrayOfString2 }, { "America/Indiana/Tell_City", arrayOfString5 }, { "America/Swift_Current", arrayOfString5 }, { "America/Nassau", arrayOfString2 }, { "America/Hermosillo", arrayOfString3 }, { "America/Whitehorse", arrayOfString4 }, { "America/Boise", arrayOfString3 }, { "Europe/Guernsey", arrayOfString1 }, { "America/Indiana/Winamac", arrayOfString2 }, { "America/Pangnirtung", arrayOfString2 }, { "Europe/Jersey", arrayOfString1 }, { "America/Thunder_Bay", arrayOfString2 }, { "America/Santa_Isabel", arrayOfString4 }, { "America/Toronto", arrayOfString2 }, { "America/Rainy_River", arrayOfString5 }, { "America/Chicago", arrayOfString5 }, { "America/Merida", arrayOfString5 }, { "America/Menominee", arrayOfString5 }, { "America/Mazatlan", arrayOfString3 }, { "Africa/Sao_Tome", arrayOfString1 }, { "America/Indiana/Petersburg", arrayOfString2 }, { "America/Iqaluit", arrayOfString2 }, { "America/Costa_Rica", arrayOfString5 }, { "Africa/Conakry", arrayOfString1 }, { "America/Indianapolis", arrayOfString2 }, { "America/Mexico_City", arrayOfString5 }, { "America/Panama", arrayOfString2 }, { "America/El_Salvador", arrayOfString5 }, { "America/North_Dakota/New_Salem", arrayOfString5 }, { "Africa/Freetown", arrayOfString1 }, { "Europe/Kaliningrad", arrayOfString1 }, { "Africa/Ouagadougou", arrayOfString1 }, { "America/Tegucigalpa", arrayOfString5 }, { "America/Kentucky/Monticello", arrayOfString2 }, { "CST6CDT", arrayOfString5 }, { "America/North_Dakota/Beulah", arrayOfString5 }, { "America/Managua", arrayOfString5 }, { "EST5EDT", arrayOfString2 }, { "America/Shiprock", arrayOfString3 }, { "Africa/Dakar", arrayOfString1 }, { "America/Belize", arrayOfString5 }, { "America/Grand_Turk", arrayOfString2 }, { "America/Vancouver", arrayOfString4 }, { "America/Edmonton", arrayOfString3 }, { "America/Rankin_Inlet", arrayOfString5 }, { "America/Los_Angeles", arrayOfString4 }, { "America/Indiana/Vincennes", arrayOfString2 }, { "America/Creston", arrayOfString3 }, { "America/Guatemala", arrayOfString5 }, { "Africa/Nouakchott", arrayOfString1 }, { "America/Montreal", arrayOfString2 }, { "America/Nipigon", arrayOfString2 }, { "America/Cambridge_Bay", arrayOfString3 }, { "America/Ojinaga", arrayOfString3 }, { "MST7MDT", arrayOfString3 }, { "America/Louisville", arrayOfString2 }, { "Africa/Accra", arrayOfString1 }, { "America/Metlakatla", arrayOfString4 }, { "America/Indiana/Knox", arrayOfString5 }, { "Africa/Lome", arrayOfString1 }, { "America/Monterrey", arrayOfString5 }, { "Europe/London", arrayOfString1 }, { "Europe/Isle_of_Man", arrayOfString1 } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 206 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\chr\TimeZoneNames_chr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */