/*     */ package sun.util.resources.cldr.agq;
/*     */ 
/*     */ import sun.util.resources.OpenListResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CurrencyNames_agq
/*     */   extends OpenListResourceBundle
/*     */ {
/*     */   protected final Object[][] getContents()
/*     */   {
/*  69 */     Object[][] arrayOfObject = { { "aed", "Dilàm è Yùnaetɛ Alab Emelɛ̀" }, { "aoa", "Kwanzà è Àŋgolà" }, { "aud", "Dɔlà e Ùsɨ̀tɛ̀lɛlìa" }, { "bhd", "Dinà è Balae" }, { "bif", "Fàlâŋ è Bùlundì" }, { "bwp", "Kpuwlà è Botɨshǔanà" }, { "cad", "Dɔlà è Kanadà" }, { "cdf", "Fàlâŋ è Kuŋgùlê" }, { "chf", "Fàlâŋ è Sues" }, { "cny", "Yùwân Lèmembi è Chaenî" }, { "cve", "Kàbòvàdianù è Èsùkudò" }, { "djf", "Fàlâŋ è Dzìbutì" }, { "dzd", "Dinà è Àdzɛlìa" }, { "egp", "Bɔ̀ŋ è Edzì" }, { "ern", "Nakafa è Èletɨ̀làe" }, { "etb", "Bîi è Etyǒkpìa" }, { "eur", "Yulù" }, { "gbp", "Bɔ̀ŋ Sɨ̀telè è Bèletì" }, { "ghc", "Sɛ̀di è Gaanà" }, { "gmd", "Dàlasì è Gambìa" }, { "gns", "Fàlâŋ è Ginè" }, { "inr", "Lukpì è Endìa" }, { "jpy", "Ghɨ̂n Dzàkpànê" }, { "kes", "Shwɨlà tɨ Kenyà" }, { "kmf", "Fàlâŋ è Komolìa" }, { "lrd", "Dɔlà Làebɛlìa" }, { "lsl", "Lɔtì Lèsutù" }, { "lyd", "Dinà è Lebìa" }, { "mad", "Dilàm è Mòlokò" }, { "mga", "Àlǐalè è Màlàgasì" }, { "mro", "Ùgueya è Mùlètenyìa" }, { "mur", "Lukpìi è Mùleshòs" }, { "mwk", "Kwachà è Màlawè" }, { "mzm", "Mètikà è Mùzàmbî" }, { "nad", "Dɔlà è Nàmibìa" }, { "ngn", "Naelà è Gɨ̀anyɨ" }, { "rwf", "Fàlâŋ è Lùwandà" }, { "sar", "Leyà è Sàwudì" }, { "scr", "Lukpìi è Sɛchɛ̀lɛ̀" }, { "sdg", "Bɔ̀ŋ è Sùdànê" }, { "shp", "Bɔ̀ŋ è Sɛ̀n Èlenà" }, { "sll", "Lyɔ̂ŋ" }, { "sos", "Shwɨlà è Sùmalìa" }, { "std", "Dɔbàlà è Sàwu Tɔ̀me à Pèlènsipè" }, { "szl", "Lèlàŋgenè" }, { "tnd", "Dinà è Tùwneshìa" }, { "tzs", "Shwɨlà è Tàanzanyìa" }, { "ugx", "Shwɨlà è Yùgandà" }, { "usd", "Dɔlà è US" }, { "xaf", "CFA Fàlâŋ BEAC" }, { "xof", "CFA Fàlâŋ BCEAO" }, { "zar", "Lân è Afɨlekà ghɨ Emàm ghò" }, { "zmk", "Kwachà è Zambìa" }, { "zwd", "Dɔlà è Zìmbagbɛ̀" } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\agq\CurrencyNames_agq.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */