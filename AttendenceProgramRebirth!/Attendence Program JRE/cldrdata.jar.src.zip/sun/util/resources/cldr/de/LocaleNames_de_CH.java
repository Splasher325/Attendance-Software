/*    */ package sun.util.resources.cldr.de;
/*    */ 
/*    */ import sun.util.resources.OpenListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocaleNames_de_CH
/*    */   extends OpenListResourceBundle
/*    */ {
/*    */   protected final Object[][] getContents()
/*    */   {
/* 69 */     Object[][] arrayOfObject = { { "BD", "Bangladesh" }, { "BN", "Brunei" }, { "BW", "Botswana" }, { "BY", "Weissrussland" }, { "CV", "Kapverden" }, { "DJ", "Djibouti" }, { "GB", "Grossbritannien" }, { "MH", "Marshall-Inseln" }, { "QO", "Äusseres Ozeanien" }, { "RW", "Rwanda" }, { "SB", "Salomon-Inseln" }, { "ST", "Sao Tomé und Principe" }, { "ZW", "Zimbabwe" }, { "be", "Weissrussisch" } };
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 85 */     return arrayOfObject;
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\de\LocaleNames_de_CH.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */