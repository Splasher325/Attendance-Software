/*    */ package sun.util.resources.cldr.bo;
/*    */ 
/*    */ import sun.util.resources.OpenListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocaleNames_bo
/*    */   extends OpenListResourceBundle
/*    */ {
/*    */   protected final Object[][] getContents()
/*    */   {
/* 69 */     Object[][] arrayOfObject = { { "CN", "རྒྱ་ནག" }, { "DE", "འཇར་མན་" }, { "GB", "དབྱིན་ཇི་" }, { "IN", "རྒྱ་གར་" }, { "IT", "ཨི་ཀྲར་ལི་" }, { "JP", "རི་པིན་" }, { "NP", "བར་ཡུལ་" }, { "RU", "ཨུ་རུ་སུ་" }, { "US", "ཨ་མེ་རི་ཀ་" }, { "ZZ", "མིའི་ཤེས་རྟོགས་མ་བྱུང་བའི་ཁོར་ཡུག" }, { "bo", "པོད་སྐད་" }, { "dz", "རྫོང་ཁ" }, { "hi", "ཧིན་དི" }, { "ja", "རི་པིན་སྐད་" }, { "ne", "ནེ་པ་ལི" }, { "ru", "ཨུ་རུ་སུ་སྐད་" }, { "zh", "རྒྱ་སྐད་" }, { "Tibt", "བོད་ཡིག་" } };
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 89 */     return arrayOfObject;
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\bo\LocaleNames_bo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */