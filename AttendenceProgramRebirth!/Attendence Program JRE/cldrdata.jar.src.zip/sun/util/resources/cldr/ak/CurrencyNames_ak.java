/*     */ package sun.util.resources.cldr.ak;
/*     */ 
/*     */ import sun.util.resources.OpenListResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CurrencyNames_ak
/*     */   extends OpenListResourceBundle
/*     */ {
/*     */   protected final Object[][] getContents()
/*     */   {
/*  69 */     Object[][] arrayOfObject = { { "aed", "Ɛmirete Arab Nkabɔmu Deram" }, { "aoa", "Angola Kwanza" }, { "aud", "Ɔstrelia Dɔla" }, { "bhd", "Baren Dina" }, { "bif", "Burundi Frank" }, { "bwp", "Botswana Pula" }, { "cad", "Kanada Dɔla" }, { "cdf", "Kongo Frank" }, { "chf", "Sweden Frank" }, { "cny", "Yuan" }, { "cve", "Ɛskudo" }, { "djf", "Gyebuti Frank" }, { "dzd", "Ɔlgyeria Dina" }, { "egp", "Egypt Pɔn" }, { "ern", "Ɛretereya Nakfa" }, { "etb", "Itiopia Bir" }, { "eur", "Iro" }, { "gbp", "Breten Pɔn" }, { "ghc", "Ghana Sidi" }, { "gmd", "Gambia Dalasi" }, { "gns", "Gini Frank" }, { "inr", "India Rupi" }, { "jpy", "Gyapan Yɛn" }, { "kes", "Kenya Hyelen" }, { "kmf", "Komoro Frank" }, { "lrd", "Laeberia Dɔla" }, { "lsl", "Lesoto Loti" }, { "lyd", "Libya Dina" }, { "mad", "Moroko Diram" }, { "mga", "Madagasi Frank" }, { "mro", "Mɔretenia Ouguiya" }, { "mur", "Mɔrehyeɔs Rupi" }, { "mwk", "Malawi Kwacha" }, { "mzm", "Mozambik Metical" }, { "nad", "Namibia Dɔla" }, { "ngn", "Naegyeria Naira" }, { "rwf", "Rewanda Frank" }, { "sar", "Saudi Riyal" }, { "scr", "Seyhyɛls Rupi" }, { "sdg", "Sudan Dina" }, { "sdp", "Sudan Pɔn" }, { "shp", "St Helena Pɔn" }, { "sll", "Leone" }, { "sos", "Somailia Hyelen" }, { "std", "Sao Tome ne Principe Dobra" }, { "szl", "Lilangeni" }, { "tnd", "Tunisia Dina" }, { "tzs", "Tanzania Hyelen" }, { "ugx", "Uganda Hyelen" }, { "usd", "Amɛrika Dɔla" }, { "xaf", "Sefa" }, { "zar", "Afrika Anaafo Rand" }, { "zmk", "Zambia Kwacha" }, { "zwd", "Zimbabwe Dɔla" } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\ak\CurrencyNames_ak.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */