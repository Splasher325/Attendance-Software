/*     */ package sun.util.resources.cldr.bm;
/*     */ 
/*     */ import sun.util.resources.OpenListResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CurrencyNames_bm
/*     */   extends OpenListResourceBundle
/*     */ {
/*     */   protected final Object[][] getContents()
/*     */   {
/*  69 */     Object[][] arrayOfObject = { { "aed", "arabu mara kafoli Diram" }, { "aoa", "angola Kwanza" }, { "aud", "ositirali Dolar" }, { "bhd", "bareyini Dinar" }, { "bif", "burundi Fraŋ" }, { "bwp", "bɔtisiwana Pula" }, { "cad", "kanada Dolar" }, { "cdf", "kongole Fraŋ" }, { "chf", "suwisi Fraŋ" }, { "cny", "siniwa Yuwan" }, { "cve", "capivɛrdi Esekudo" }, { "djf", "jibuti Fraŋ" }, { "dzd", "alizeri Dinar" }, { "egp", "eziputi Livri" }, { "ern", "eritere Nafika" }, { "etb", "etiopi Bir" }, { "eur", "ero" }, { "gbp", "angilɛ Livri Siterlingi" }, { "ghc", "gana Sedi" }, { "gmd", "gambi Dalasi" }, { "gns", "gine Fraŋ" }, { "inr", "Ɛndu Rupi" }, { "jpy", "zapɔne Yɛn" }, { "kes", "keniya Siling" }, { "kmf", "komɔri Fraŋ" }, { "lrd", "liberiya Dolar" }, { "lsl", "lesoto Loti" }, { "lyd", "libi Dinar" }, { "mad", "marɔku Diram" }, { "mga", "madagasikari Fraŋ" }, { "mro", "mɔritani Uguwiya" }, { "mur", "morisi Rupi" }, { "mwk", "malawi Kwaca" }, { "mzm", "mozanbiki Metikali" }, { "nad", "namibi Dolar" }, { "ngn", "nizeriya Nɛra" }, { "rwf", "ruwanda Fraŋ" }, { "sar", "sawudiya Riyal" }, { "scr", "sesɛli Rupi" }, { "sdg", "sudani Dinar" }, { "sdp", "sudani Livri" }, { "shp", "Ɛlɛni-Senu Livri" }, { "sll", "siyeralewɔni Lewɔni" }, { "sos", "somali Siling" }, { "std", "sawotome Dobra" }, { "szl", "swazilandi Lilangeni" }, { "tnd", "tunizi Dinar" }, { "tzs", "tanzani Siling" }, { "ugx", "uganda Siling" }, { "usd", "ameriki Dolar" }, { "xaf", "sefa Fraŋ (BEAC)" }, { "xof", "sefa Fraŋ (BCEAO)" }, { "zar", "sudafriki Randi" }, { "zmk", "zambi Kwaca" }, { "zwd", "zimbabuwe Dolar" } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\bm\CurrencyNames_bm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */