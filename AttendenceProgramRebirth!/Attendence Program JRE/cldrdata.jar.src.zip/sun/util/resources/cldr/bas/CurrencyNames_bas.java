/*     */ package sun.util.resources.cldr.bas;
/*     */ 
/*     */ import sun.util.resources.OpenListResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CurrencyNames_bas
/*     */   extends OpenListResourceBundle
/*     */ {
/*     */   protected final Object[][] getContents()
/*     */   {
/*  69 */     Object[][] arrayOfObject = { { "aed", "Dirhàm èmìrâ" }, { "aoa", "Kwànza àŋgolà" }, { "aud", "Dɔ̀lâr òstralìà" }, { "bhd", "Dinâr Bàraìn" }, { "bif", "Frǎŋ bùrundì" }, { "bwp", "Pùla Bòtswanà" }, { "cad", "Dɔ̀lâr kànadà" }, { "cdf", "Frǎŋ kòŋgo" }, { "chf", "Frǎŋ sùwîs" }, { "cny", "Yùan kinà" }, { "cve", "Èskudò kabwe᷆r" }, { "djf", "Frǎŋ jìbutì" }, { "dzd", "Dìnâr àlgerìà" }, { "egp", "Paùnd ègîptò" }, { "ern", "Nafkà èrìtrěà" }, { "etb", "Bîr ètìopìà" }, { "eur", "Èrô" }, { "gbp", "Stɛrlìŋ ŋgìsì" }, { "ghc", "Sèdi gānà" }, { "gmd", "Dalasì gambìà" }, { "gns", "Frǎŋ gìnê" }, { "inr", "Rùpi īndìà" }, { "jpy", "Yɛ̂n yàpân" }, { "kes", "Silîŋ kenìà" }, { "kmf", "Frǎŋ kòmorà" }, { "lrd", "Dɔ̀lâr lìberìà" }, { "lsl", "Lotì lèsòtò" }, { "lyd", "Dìnâr libìà" }, { "mad", "Dìrham màrôk" }, { "mga", "Frǎŋ màlàgasì" }, { "mro", "Ùgwiya mòrìtanìa" }, { "mur", "Rupìɛ̀ mòrîs" }, { "mwk", "Kwaca màlawì" }, { "mzm", "Mètìkal mòsàmbîk" }, { "nad", "Dɔ̀lâr nàmibìà" }, { "ngn", "Nayrà nìgerìà" }, { "rwf", "Frǎŋ Rùandà" }, { "sar", "Rìal sàudì" }, { "scr", "Rùpiɛ̀ sèsɛ̂l" }, { "sdg", "Dìnâr sùdân" }, { "sdp", "Paùnd sùdân" }, { "shp", "Paùnd hèlenà" }, { "sll", "Lèonɛ̀" }, { "sos", "Silîŋ sòmàli" }, { "std", "Dobrà sàotòme" }, { "szl", "Lìlàŋgeni swàzì" }, { "tnd", "Dìnâr tùnîs" }, { "tzs", "Silîŋ tànzànià" }, { "ugx", "Silîŋ ùgàndà" }, { "usd", "Dɔla àmerkà" }, { "xaf", "Frǎŋ CFA (BEAC)" }, { "xof", "Frǎŋ CFA (BCEAO)" }, { "zar", "Rân àfrǐkàsɔ̀" }, { "zmk", "Kwàca sàmbià" }, { "zwd", "Dɔ̀lâr sìmbàbwê" } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\bas\CurrencyNames_bas.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */