/*    */ package sun.util.resources.cldr.as;
/*    */ 
/*    */ import sun.util.resources.OpenListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocaleNames_as
/*    */   extends OpenListResourceBundle
/*    */ {
/*    */   protected final Object[][] getContents()
/*    */   {
/* 69 */     Object[][] arrayOfObject = { { "AQ", "এন্টাৰ্টিকা" }, { "BR", "ব্ৰাজিল" }, { "BV", "বভেট দ্বীপ" }, { "CN", "চীন" }, { "DE", "জাৰ্মানি" }, { "FR", "ফ্ৰান্স" }, { "GB", "সংযুক্ত ৰাজ্য" }, { "GS", "দক্ষিণ জৰ্জিয়া আৰু দক্ষিণ চেণ্ডৱিচ্‌ দ্বীপ" }, { "HM", "হাৰ্ড দ্বীপ আৰু মেক্‌ডোনাল্ড দ্বীপ" }, { "IN", "ভাৰত" }, { "IO", "ব্ৰিটিশ্ব ইণ্ডিয়ান মহাসাগৰৰ অঞ্চল" }, { "IT", "ইটালি" }, { "JP", "জাপান" }, { "RU", "ৰুচ" }, { "TF", "দক্ষিণ ফ্ৰান্সৰ অঞ্চল" }, { "US", "যুক্তৰাষ্ট্ৰ" }, { "ZZ", "অজ্ঞাত বা অবৈধ অঞ্চল" }, { "as", "অসমীয়া" }, { "Beng", "বঙালী" } };
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 90 */     return arrayOfObject;
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\as\LocaleNames_as.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */