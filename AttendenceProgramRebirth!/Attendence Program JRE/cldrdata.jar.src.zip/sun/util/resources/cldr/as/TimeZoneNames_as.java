/*    */ package sun.util.resources.cldr.as;
/*    */ 
/*    */ import sun.util.resources.TimeZoneNamesBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimeZoneNames_as
/*    */   extends TimeZoneNamesBundle
/*    */ {
/*    */   protected final Object[][] getContents()
/*    */   {
/* 69 */     String[] arrayOfString = { "ভাৰতীয় সময়", "ভা. স.", "India Daylight Time", "IDT", "India Time", "IT" };
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 77 */     Object[][] arrayOfObject = { { "Asia/Calcutta", arrayOfString }, { "Asia/Colombo", arrayOfString } };
/*    */     
/*    */ 
/*    */ 
/* 81 */     return arrayOfObject;
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\as\TimeZoneNames_as.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */