/*     */ package sun.util.resources.cldr.dav;
/*     */ 
/*     */ import sun.util.resources.OpenListResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CurrencyNames_dav
/*     */   extends OpenListResourceBundle
/*     */ {
/*     */   protected final Object[][] getContents()
/*     */   {
/*  69 */     Object[][] arrayOfObject = { { "KES", "Ksh" }, { "aed", "Dirham ya Falme za Kiarabu" }, { "aoa", "Kwanza ya Angola" }, { "aud", "Dola ya Australia" }, { "bhd", "Dinari ya Bahareni" }, { "bif", "Faranga ya Burundi" }, { "bwp", "Pula ya Botswana" }, { "cad", "Dola ya Kanada" }, { "cdf", "Faranga ya Kongo" }, { "chf", "Faranga ya Uswisi" }, { "cny", "Yuan Renminbi ya China" }, { "cve", "Eskudo ya Kepuvede" }, { "djf", "Faranga ya Jibuti" }, { "dzd", "Dinari ya Aljeria" }, { "egp", "Pauni ya Misri" }, { "ern", "Nakfa ya Eritrea" }, { "etb", "Bir ya Uhabeshi" }, { "eur", "Yuro" }, { "gbp", "Pauni ya Uingereza" }, { "ghc", "Sedi ya Ghana" }, { "gmd", "Dalasi ya Gambia" }, { "gns", "Faranga ya Gine" }, { "inr", "Rupia ya India" }, { "jpy", "Sarafu ya Kijapani" }, { "kes", "Shilingi ya Kenya" }, { "kmf", "Faranga ya Komoro" }, { "lrd", "Dola ya Liberia" }, { "lsl", "Loti ya Lesoto" }, { "lyd", "Dinari ya Libya" }, { "mad", "Dirham ya Moroko" }, { "mga", "Ariary ya Bukini" }, { "mro", "Ugwiya ya Moritania" }, { "mur", "Rupia ya Morisi" }, { "mwk", "Kwacha ya Malawi" }, { "mzm", "Metikali ya Msumbiji" }, { "nad", "Dola ya Namibia" }, { "ngn", "Naira ya Nijeria" }, { "rwf", "Faranga ya Rwanda" }, { "sar", "Riyal ya Saudia" }, { "scr", "Rupia ya Shelisheli" }, { "sdg", "Pauni ya Sudani" }, { "shp", "Pauni ya Santahelena" }, { "sll", "Leoni" }, { "sos", "Shilingi ya Somalia" }, { "std", "Dobra ya Sao Tome na Principe" }, { "szl", "Lilangeni" }, { "tnd", "Dinari ya Tunisia" }, { "tzs", "Shilingi ya Tanzania" }, { "ugx", "Shilingi ya Uganda" }, { "usd", "Dola ya Marekani" }, { "xaf", "Faranga CFA BEAC" }, { "xof", "Faranga CFA BCEAO" }, { "zar", "Randi ya Afrika Kusini" }, { "zmk", "Kwacha ya Zambia" }, { "zwd", "Dola ya Zimbabwe" } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\dav\CurrencyNames_dav.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */