/*    */ package sun.util.resources.cldr.az;
/*    */ 
/*    */ import sun.util.resources.OpenListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocaleNames_az_Cyrl
/*    */   extends OpenListResourceBundle
/*    */ {
/*    */   protected final Object[][] getContents()
/*    */   {
/* 69 */     Object[][] arrayOfObject = { { "AZ", "Азәрбајҹан" }, { "BR", "Бразилија" }, { "CN", "Чин" }, { "DE", "Алманија" }, { "FR", "Франса" }, { "IN", "Һиндистан" }, { "IT", "Италија" }, { "JP", "Јапонија" }, { "RU", "Русија" }, { "US", "Америка Бирләшмиш Штатлары" }, { "az", "Азәрбајҹан" }, { "de", "алманҹа" }, { "en", "инҝилисҹә" }, { "es", "испанҹа" }, { "fr", "франсызҹа" }, { "it", "италјанҹа" }, { "ja", "јапонҹа" }, { "pt", "португалҹа" }, { "ru", "русҹа" }, { "zh", "чинҹә" } };
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 91 */     return arrayOfObject;
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\az\LocaleNames_az_Cyrl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */