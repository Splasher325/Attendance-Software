/*     */ package sun.util.resources.cldr.az;
/*     */ 
/*     */ import sun.util.resources.TimeZoneNamesBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeZoneNames_az
/*     */   extends TimeZoneNamesBundle
/*     */ {
/*     */   protected final Object[][] getContents()
/*     */   {
/*  69 */     String[] arrayOfString1 = { "Moskva/standart", "MST", "Moskva/yay", "MST", "Moskva", "MT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */     String[] arrayOfString2 = { "Orta Avropa", "CEST", "Orta Avropa/yay", "CEST", "Orta Avropa", "CET" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */     String[] arrayOfString3 = { "Şərq Avropa", "EEST", "Şərq Avropa/yay", "EEST", "Şərq Avropa", "EET" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     String[] arrayOfString4 = { "Volqoqrad", "VST", "Volqoqrad/yay", "VST", "Volqoqrad", "VT" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */     Object[][] arrayOfObject = { { "Europe/Samara", arrayOfString1 }, { "Europe/Sofia", arrayOfString3 }, { "Europe/Monaco", arrayOfString2 }, { "Europe/Gibraltar", arrayOfString2 }, { "Europe/Vienna", arrayOfString2 }, { "Asia/Damascus", arrayOfString3 }, { "Europe/Malta", arrayOfString2 }, { "Europe/Madrid", arrayOfString2 }, { "Europe/Volgograd", arrayOfString4 }, { "Europe/Minsk", arrayOfString3 }, { "Europe/Vilnius", arrayOfString3 }, { "Europe/Mariehamn", arrayOfString3 }, { "Europe/Podgorica", arrayOfString2 }, { "Asia/Nicosia", arrayOfString3 }, { "Europe/Riga", arrayOfString3 }, { "Europe/Luxembourg", arrayOfString2 }, { "Europe/Zurich", arrayOfString2 }, { "Asia/Amman", arrayOfString3 }, { "Europe/Brussels", arrayOfString2 }, { "Europe/Zaporozhye", arrayOfString3 }, { "Africa/Tripoli", arrayOfString3 }, { "Europe/Simferopol", arrayOfString3 }, { "Europe/Oslo", arrayOfString2 }, { "Europe/Rome", arrayOfString2 }, { "Europe/Vatican", arrayOfString2 }, { "Europe/Tirane", arrayOfString2 }, { "Europe/Istanbul", arrayOfString3 }, { "Europe/Copenhagen", arrayOfString2 }, { "Europe/Bucharest", arrayOfString3 }, { "Europe/Helsinki", arrayOfString3 }, { "Europe/Tallinn", arrayOfString3 }, { "Europe/Amsterdam", arrayOfString2 }, { "Europe/Athens", arrayOfString3 }, { "Asia/Hebron", arrayOfString3 }, { "Europe/Uzhgorod", arrayOfString3 }, { "Europe/Stockholm", arrayOfString2 }, { "Europe/Berlin", arrayOfString2 }, { "Europe/Skopje", arrayOfString2 }, { "Arctic/Longyearbyen", arrayOfString2 }, { "Africa/Ceuta", arrayOfString2 }, { "Europe/Andorra", arrayOfString2 }, { "Europe/Chisinau", arrayOfString3 }, { "Asia/Gaza", arrayOfString3 }, { "Europe/Budapest", arrayOfString2 }, { "Africa/Tunis", arrayOfString2 }, { "Asia/Beirut", arrayOfString3 }, { "Europe/Paris", arrayOfString2 }, { "Europe/San_Marino", arrayOfString2 }, { "Europe/Vaduz", arrayOfString2 }, { "Europe/Sarajevo", arrayOfString2 }, { "Europe/Prague", arrayOfString2 }, { "Europe/Bratislava", arrayOfString2 }, { "Europe/Ljubljana", arrayOfString2 }, { "Europe/Zagreb", arrayOfString2 }, { "Africa/Algiers", arrayOfString2 }, { "Europe/Warsaw", arrayOfString2 }, { "Europe/Kiev", arrayOfString3 }, { "Africa/Cairo", arrayOfString3 }, { "Europe/Belgrade", arrayOfString2 }, { "Europe/Moscow", arrayOfString1 } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 163 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\az\TimeZoneNames_az.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */