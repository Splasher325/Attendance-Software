/*     */ package sun.util.resources.cldr.dyo;
/*     */ 
/*     */ import sun.util.resources.OpenListResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CurrencyNames_dyo
/*     */   extends OpenListResourceBundle
/*     */ {
/*     */   protected final Object[][] getContents()
/*     */   {
/*  69 */     Object[][] arrayOfObject = { { "aoa", "kwanza yati Angola" }, { "aud", "dolaar yati Ostraalia" }, { "bhd", "dinaar yati Bahrayn" }, { "bif", "fraaŋ yati Burundi" }, { "bwp", "pula yati Boswana" }, { "cad", "dolaar yati Kanada" }, { "cdf", "fraaŋ yati Kongo" }, { "cny", "yuan yati Siin" }, { "cve", "eskuudo yati Kap Ver" }, { "djf", "fraaŋ yati Jibuti" }, { "dzd", "dinaar yati Alseri" }, { "egp", "liiverey yati Esípt" }, { "ern", "nafka yati Eritree" }, { "etb", "birr yati Ecoopi" }, { "eur", "euro" }, { "ghc", "cedi yati Gaana" }, { "gmd", "dalasi yati Gambi" }, { "gns", "sili yati Giné" }, { "inr", "rupii yati End" }, { "jpy", "yen yati Sapoŋ" }, { "kes", "silliŋ yati Keniya" }, { "kmf", "fraaŋ yati Komor" }, { "lrd", "dolaar yati Liberia" }, { "lyd", "dinaar yati Libia" }, { "mga", "ariari yati Madagaskaar" }, { "mro", "ugiiya yati Mooritanii" }, { "mwk", "kwacha yati Malawi" }, { "xaf", "seefa BEAC" }, { "xof", "seefa yati BCEAO" } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\dyo\CurrencyNames_dyo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */