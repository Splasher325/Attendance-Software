/*    */ package sun.util.resources.cldr.be;
/*    */ 
/*    */ import sun.util.resources.OpenListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CurrencyNames_be
/*    */   extends OpenListResourceBundle
/*    */ {
/*    */   protected final Object[][] getContents()
/*    */   {
/* 69 */     Object[][] arrayOfObject = { { "BYB", "Руб" }, { "JPY", "¥" }, { "RUB", "рас. руб." }, { "USD", "$" }, { "aud", "аўстралійскі даляр" }, { "brl", "бразільскі рэал" }, { "byr", "беларускі рубель" }, { "cny", "кітайскі юань" }, { "ern", "эрытрэйская накфа" }, { "eur", "еўра" }, { "gbp", "англійскі фунт" }, { "inr", "індыйская рупія" }, { "jpy", "японская іена" }, { "nok", "нарвэская крона" }, { "rub", "рускі рубель" }, { "usd", "долар ЗША" }, { "xxx", "невядомая або недапушчальная валюта" } };
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 88 */     return arrayOfObject;
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\be\CurrencyNames_be.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */