/*     */ package sun.util.resources.cldr.dje;
/*     */ 
/*     */ import sun.util.resources.OpenListResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CurrencyNames_dje
/*     */   extends OpenListResourceBundle
/*     */ {
/*     */   protected final Object[][] getContents()
/*     */   {
/*  69 */     Object[][] arrayOfObject = { { "aed", "Laaraw Immaara Margantey Dirham" }, { "aoa", "Angoola Kwanza" }, { "aud", "Ostraali Dollar" }, { "bhd", "Bahareen Dinar" }, { "bif", "Burundi Fraŋ" }, { "bwp", "Botswaana Pund" }, { "cad", "Kanaada Dollar" }, { "cdf", "Kongo Fraŋ" }, { "chf", "Swisu Fraŋ" }, { "cny", "Sinwa Yuan Renminbi" }, { "cve", "Kapuver Escudo" }, { "djf", "Jibuuti Fraŋ" }, { "dzd", "Alžeeri Dinar" }, { "egp", "Misra Pund" }, { "ern", "Eritree Nafka" }, { "etb", "Ecioopi Birr" }, { "eur", "Eero" }, { "gbp", "Britin Pund" }, { "ghc", "Gaana Šiidi" }, { "gmd", "Gambi Dalasi" }, { "gns", "Ginee Fraŋ" }, { "inr", "Indu Rupii" }, { "jpy", "Jaapoŋ Yen" }, { "kes", "Keeniya Šiiliŋ" }, { "kmf", "Komoor Fraŋ" }, { "lrd", "Liberia Dollar" }, { "lsl", "Leezoto Loti" }, { "lyd", "Liibi Dinar" }, { "mad", "Maarok Dirham" }, { "mga", "Malgaaši Fraŋ" }, { "mro", "Mooritaani Ugiya" }, { "mur", "Mooris Rupii" }, { "mwk", "Malaawi Kwaca" }, { "mzm", "Mozambik Metikal" }, { "nad", "Naamibi Dollar" }, { "ngn", "Naajiriya Neera" }, { "rwf", "Rwanda Fraŋ" }, { "sar", "Saudiya Riyal" }, { "scr", "Seešel Rupii" }, { "sdg", "Suudaŋ Dinar" }, { "sdp", "Suudaŋ Pund" }, { "shp", "Seŋ Helena Fraŋ" }, { "sll", "Leeon" }, { "sos", "Somaali Šiiliŋ" }, { "std", "Sao Tome nda Prinsipe Dobra" }, { "szl", "Lilangeni" }, { "tnd", "Tunizi Dinar" }, { "tzs", "Tanzaani Šiiliŋ" }, { "ugx", "Uganda Šiiliŋ" }, { "usd", "Ameriki Dollar" }, { "xaf", "CFA Fraŋ (BEAC)" }, { "xof", "CFA Fraŋ (BCEAO)" }, { "zar", "Hawasa Afriki Rand" }, { "zmk", "Zambi Kwaca" }, { "zwd", "Zimbabwe Dollar" } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\util\resources\cldr\dje\CurrencyNames_dje.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */