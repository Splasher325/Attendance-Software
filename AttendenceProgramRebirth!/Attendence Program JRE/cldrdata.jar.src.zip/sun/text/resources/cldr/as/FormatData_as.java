/*     */ package sun.text.resources.cldr.as;
/*     */ 
/*     */ import java.util.ListResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormatData_as
/*     */   extends ListResourceBundle
/*     */ {
/*     */   protected final Object[][] getContents()
/*     */   {
/*  69 */     Object[][] arrayOfObject = { { "MonthNames", { "জানুৱাৰী", "ফেব্ৰুৱাৰী", "মাৰ্চ", "এপ্ৰিল", "মে", "জুন", "জুলাই", "আগষ্ট", "ছেপ্তেম্বৰ", "অক্টোবৰ", "নৱেম্বৰ", "ডিচেম্বৰ", "" } }, { "MonthAbbreviations", { "জানু", "ফেব্ৰু", "মাৰ্চ", "এপ্ৰিল", "মে", "জুন", "জুলাই", "আগ", "সেপ্ট", "অক্টো", "নভে", "ডিসে", "" } }, { "DayNames", { "দেওবাৰ", "সোমবাৰ", "মঙ্গলবাৰ", "বুধবাৰ", "বৃহষ্পতিবাৰ", "শুক্ৰবাৰ", "শনিবাৰ" } }, { "DayAbbreviations", { "ৰবি", "সোম", "মঙ্গল", "বুধ", "বৃহষ্পতি", "শুক্ৰ", "শনি" } }, { "QuarterNames", { "প্ৰথম প্ৰহৰ", "দ্বিতীয় প্ৰহৰ", "তৃতীয় প্ৰহৰ", "চতুৰ্থ প্ৰহৰ" } }, { "AmPmMarkers", { "পূৰ্বাহ্ণ", "অপৰাহ্ণ" } }, { "field.era", "যুগ" }, { "field.year", "বছৰ" }, { "field.month", "মাহ" }, { "field.week", "সপ্তাহ" }, { "field.hour", "ঘণ্টা" }, { "field.minute", "মিনিট" }, { "field.second", "ছেকেণ্ড" }, { "field.zone", "ক্ষেত্ৰ" }, { "calendarname.japanese", "জাপানী পঞ্জিকা" }, { "calendarname.roc", "চীনা গণৰাজ্যৰ পঞ্জিকা" }, { "calendarname.gregorian", "গ্ৰিগোৰীয় পঞ্জিকা" }, { "calendarname.gregory", "গ্ৰিগোৰীয় পঞ্জিকা" }, { "calendarname.islamic-civil", "ইচলামী-নাগৰিকৰ পঞ্জিকা" }, { "calendarname.islamicc", "ইচলামী-নাগৰিকৰ পঞ্জিকা" }, { "calendarname.islamic", "ইচলামী পঞ্জিকা" }, { "calendarname.buddhist", "বৌদ্ধ পঞ্জিকা" }, { "DefaultNumberingSystem", "latn" }, { "NumberPatterns", { "#,##,##0.###", "¤ #,##,##0.00", "#,##,##0%" } } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 165 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\text\resources\cldr\as\FormatData_as.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */