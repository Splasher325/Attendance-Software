/*     */ package sun.text.resources.cldr.ne;
/*     */ 
/*     */ import java.util.ListResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormatData_ne
/*     */   extends ListResourceBundle
/*     */ {
/*     */   protected final Object[][] getContents()
/*     */   {
/*  69 */     Object[][] arrayOfObject = { { "MonthNarrows", { "१", "२", "३", "४", "५", "६", "७", "८", "९", "१०", "११", "१२", "" } }, { "DayNarrows", { "१", "२", "३", "४", "५", "६", "७" } }, { "QuarterNarrows", { "१", "२", "३", "४" } }, { "AmPmMarkers", { "पूर्व मध्यान्ह", "उत्तर मध्यान्ह" } }, { "Eras", { "ईसा पूर्व", "सन्" } }, { "field.era", "काल" }, { "field.year", "बर्ष" }, { "field.month", "महिना" }, { "field.week", "हप्ता" }, { "field.weekday", "हप्ताको बार" }, { "field.dayperiod", "पूर्व मध्यान्ह/उत्तर मध्यान्ह" }, { "field.hour", "घण्टा" }, { "field.minute", "मिनेट" }, { "field.second", "दोस्रो" }, { "field.zone", "क्षेत्र" }, { "calendarname.islamic", "इस्लामी पात्रो" }, { "calendarname.roc", "चिनिँया गणतन्त्र पात्रो" }, { "calendarname.buddhist", "बुद्धिष्ट पात्रो" }, { "calendarname.japanese", "जापानी पात्रो" }, { "calendarname.gregorian", "ग्रेगोरियन पात्रो" }, { "calendarname.gregory", "ग्रेगोरियन पात्रो" }, { "calendarname.islamic-civil", "इस्लामी नागरिक पात्रो" }, { "calendarname.islamicc", "इस्लामी नागरिक पात्रो" }, { "DefaultNumberingSystem", "latn" }, { "latn.NumberElements", { ".", ",", ";", "%", "0", "#", "-", "E", "‰", "∞", "NaN" } } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 153 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\text\resources\cldr\ne\FormatData_ne.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */