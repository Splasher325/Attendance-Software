/*    */ package sun.text.resources.cldr.en;
/*    */ 
/*    */ import java.util.ListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormatData_en_ZA
/*    */   extends ListResourceBundle
/*    */ {
/*    */   protected final Object[][] getContents()
/*    */   {
/* 69 */     Object[][] arrayOfObject = { { "DatePatterns", { "EEEE dd MMMM y", "dd MMMM y", "dd MMM y", "yyyy/MM/dd" } }, { "DefaultNumberingSystem", "latn" }, { "latn.NumberElements", { ",", " ", ";", "%", "0", "#", "-", "E", "‰", "∞", "NaN" } } };
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 95 */     return arrayOfObject;
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\text\resources\cldr\en\FormatData_en_ZA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */