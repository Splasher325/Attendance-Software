/*     */ package sun.text.resources.cldr.kw;
/*     */ 
/*     */ import java.util.ListResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormatData_kw
/*     */   extends ListResourceBundle
/*     */ {
/*     */   protected final Object[][] getContents()
/*     */   {
/*  69 */     Object[][] arrayOfObject = { { "MonthNames", { "Mys Genver", "Mys Whevrel", "Mys Merth", "Mys Ebrel", "Mys Me", "Mys Efan", "Mys Gortheren", "Mye Est", "Mys Gwyngala", "Mys Hedra", "Mys Du", "Mys Kevardhu", "" } }, { "MonthAbbreviations", { "Gen", "Whe", "Mer", "Ebr", "Me", "Efn", "Gor", "Est", "Gwn", "Hed", "Du", "Kev", "" } }, { "DayNames", { "De Sul", "De Lun", "De Merth", "De Merher", "De Yow", "De Gwener", "De Sadorn" } }, { "DayAbbreviations", { "Sul", "Lun", "Mth", "Mhr", "Yow", "Gwe", "Sad" } }, { "AmPmMarkers", { "a.m.", "p.m." } }, { "Eras", { "RC", "AD" } }, { "NumberPatterns", { "#,##0.###", "¤#,##0.00", "#,##0%" } } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 146 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\cldrdata.jar!\sun\text\resources\cldr\kw\FormatData_kw.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */