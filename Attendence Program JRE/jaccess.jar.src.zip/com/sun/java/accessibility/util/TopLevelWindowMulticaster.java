/*    */ package com.sun.java.accessibility.util;
/*    */ 
/*    */ import java.awt.AWTEventMulticaster;
/*    */ import java.awt.Window;
/*    */ import java.util.EventListener;
/*    */ import jdk.Exported;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Exported(false)
/*    */ public class TopLevelWindowMulticaster
/*    */   extends AWTEventMulticaster
/*    */   implements TopLevelWindowListener
/*    */ {
/*    */   protected TopLevelWindowMulticaster(EventListener paramEventListener1, EventListener paramEventListener2)
/*    */   {
/* 49 */     super(paramEventListener1, paramEventListener2);
/*    */   }
/*    */   
/*    */   public void topLevelWindowCreated(Window paramWindow) {
/* 53 */     ((TopLevelWindowListener)this.a).topLevelWindowCreated(paramWindow);
/* 54 */     ((TopLevelWindowListener)this.b).topLevelWindowCreated(paramWindow);
/*    */   }
/*    */   
/*    */   public void topLevelWindowDestroyed(Window paramWindow) {
/* 58 */     ((TopLevelWindowListener)this.a).topLevelWindowDestroyed(paramWindow);
/* 59 */     ((TopLevelWindowListener)this.b).topLevelWindowDestroyed(paramWindow);
/*    */   }
/*    */   
/*    */   public static TopLevelWindowListener add(TopLevelWindowListener paramTopLevelWindowListener1, TopLevelWindowListener paramTopLevelWindowListener2) {
/* 63 */     return (TopLevelWindowListener)addInternal(paramTopLevelWindowListener1, paramTopLevelWindowListener2);
/*    */   }
/*    */   
/*    */   public static TopLevelWindowListener remove(TopLevelWindowListener paramTopLevelWindowListener1, TopLevelWindowListener paramTopLevelWindowListener2) {
/* 67 */     return (TopLevelWindowListener)removeInternal(paramTopLevelWindowListener1, paramTopLevelWindowListener2);
/*    */   }
/*    */   
/*    */   protected static EventListener addInternal(EventListener paramEventListener1, EventListener paramEventListener2) {
/* 71 */     if (paramEventListener1 == null) return paramEventListener2;
/* 72 */     if (paramEventListener2 == null) return paramEventListener1;
/* 73 */     return new TopLevelWindowMulticaster(paramEventListener1, paramEventListener2);
/*    */   }
/*    */   
/*    */   protected static EventListener removeInternal(EventListener paramEventListener1, EventListener paramEventListener2) {
/* 77 */     if ((paramEventListener1 == paramEventListener2) || (paramEventListener1 == null))
/* 78 */       return null;
/* 79 */     if ((paramEventListener1 instanceof TopLevelWindowMulticaster)) {
/* 80 */       return ((TopLevelWindowMulticaster)paramEventListener1).remove(paramEventListener2);
/*    */     }
/* 82 */     return paramEventListener1;
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jaccess.jar!\com\sun\java\accessibility\util\TopLevelWindowMulticaster.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */