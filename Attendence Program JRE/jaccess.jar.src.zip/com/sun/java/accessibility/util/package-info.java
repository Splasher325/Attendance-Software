package com.sun.java.accessibility.util;

import jdk.Exported;

@Exported
abstract interface package-info {}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jaccess.jar!\com\sun\java\accessibility\util\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */