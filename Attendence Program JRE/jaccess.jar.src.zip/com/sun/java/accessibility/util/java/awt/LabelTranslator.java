/*    */ package com.sun.java.accessibility.util.java.awt;
/*    */ 
/*    */ import com.sun.java.accessibility.util.Translator;
/*    */ import java.awt.Label;
/*    */ import javax.accessibility.AccessibleRole;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LabelTranslator
/*    */   extends Translator
/*    */ {
/*    */   public String getAccessibleName()
/*    */   {
/* 60 */     return ((Label)this.source).getText();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setAccessibleName(String paramString)
/*    */   {
/* 67 */     ((Label)this.source).setText(paramString);
/*    */   }
/*    */   
/*    */   public AccessibleRole getAccessibleRole() {
/* 71 */     return AccessibleRole.LABEL;
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jaccess.jar!\com\sun\java\accessibility\util\java\awt\LabelTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */