/*    */ package com.sun.java.accessibility.util.java.awt;
/*    */ 
/*    */ import com.sun.java.accessibility.util.Translator;
/*    */ import java.awt.List;
/*    */ import javax.accessibility.AccessibleRole;
/*    */ import javax.accessibility.AccessibleState;
/*    */ import javax.accessibility.AccessibleStateSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ListTranslator
/*    */   extends Translator
/*    */ {
/*    */   public AccessibleStateSet getAccessibleStateSet()
/*    */   {
/* 65 */     AccessibleStateSet localAccessibleStateSet = super.getAccessibleStateSet();
/* 66 */     if (((List)this.source).isMultipleMode()) {
/* 67 */       localAccessibleStateSet.add(AccessibleState.MULTISELECTABLE);
/*    */     }
/* 69 */     if (((List)this.source).getSelectedItems().length > 0) {
/* 70 */       localAccessibleStateSet.add(AccessibleState.SELECTED);
/*    */     }
/* 72 */     return localAccessibleStateSet;
/*    */   }
/*    */   
/*    */   public AccessibleRole getAccessibleRole() {
/* 76 */     return AccessibleRole.LIST;
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jaccess.jar!\com\sun\java\accessibility\util\java\awt\ListTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */