/*    */ package com.sun.java.accessibility.util.java.awt;
/*    */ 
/*    */ import com.sun.java.accessibility.util.Translator;
/*    */ import java.awt.Button;
/*    */ import javax.accessibility.AccessibleRole;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ButtonTranslator
/*    */   extends Translator
/*    */ {
/*    */   public String getAccessibleName()
/*    */   {
/* 65 */     return ((Button)this.source).getLabel();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setAccessibleName(String paramString)
/*    */   {
/* 72 */     ((Button)this.source).setLabel(paramString);
/*    */   }
/*    */   
/*    */   public AccessibleRole getAccessibleRole() {
/* 76 */     return AccessibleRole.PUSH_BUTTON;
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jaccess.jar!\com\sun\java\accessibility\util\java\awt\ButtonTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */