/*    */ package com.sun.java.accessibility.util.java.awt;
/*    */ 
/*    */ import com.sun.java.accessibility.util.Translator;
/*    */ import javax.accessibility.AccessibleRole;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextComponentTranslator
/*    */   extends Translator
/*    */ {
/*    */   public AccessibleRole getAccessibleRole()
/*    */   {
/* 60 */     return AccessibleRole.TEXT;
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jaccess.jar!\com\sun\java\accessibility\util\java\awt\TextComponentTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */