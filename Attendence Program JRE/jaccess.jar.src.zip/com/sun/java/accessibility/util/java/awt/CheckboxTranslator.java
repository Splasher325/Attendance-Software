/*    */ package com.sun.java.accessibility.util.java.awt;
/*    */ 
/*    */ import com.sun.java.accessibility.util.Translator;
/*    */ import java.awt.Checkbox;
/*    */ import javax.accessibility.AccessibleRole;
/*    */ import javax.accessibility.AccessibleState;
/*    */ import javax.accessibility.AccessibleStateSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CheckboxTranslator
/*    */   extends Translator
/*    */ {
/*    */   public AccessibleStateSet getAccessibleStateSet()
/*    */   {
/* 65 */     AccessibleStateSet localAccessibleStateSet = super.getAccessibleStateSet();
/* 66 */     if (((Checkbox)this.source).getState()) {
/* 67 */       localAccessibleStateSet.add(AccessibleState.CHECKED);
/*    */     }
/* 69 */     return localAccessibleStateSet;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getAccessibleName()
/*    */   {
/* 78 */     return ((Checkbox)this.source).getLabel();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setAccessibleName(String paramString)
/*    */   {
/* 85 */     ((Checkbox)this.source).setLabel(paramString);
/*    */   }
/*    */   
/*    */   public AccessibleRole getAccessibleRole() {
/* 89 */     return AccessibleRole.CHECK_BOX;
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jaccess.jar!\com\sun\java\accessibility\util\java\awt\CheckboxTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */