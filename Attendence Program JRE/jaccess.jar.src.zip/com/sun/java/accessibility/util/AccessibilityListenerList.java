/*     */ package com.sun.java.accessibility.util;
/*     */ 
/*     */ import java.util.EventListener;
/*     */ import jdk.Exported;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Exported
/*     */ public class AccessibilityListenerList
/*     */ {
/*  43 */   private static final Object[] NULL_ARRAY = new Object[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  48 */   protected transient Object[] listenerList = NULL_ARRAY;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object[] getListenerList()
/*     */   {
/*  65 */     return this.listenerList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getListenerCount()
/*     */   {
/*  74 */     return this.listenerList.length / 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getListenerCount(Class paramClass)
/*     */   {
/*  85 */     int i = 0;
/*  86 */     Object[] arrayOfObject = this.listenerList;
/*  87 */     for (int j = 0; j < arrayOfObject.length; j += 2) {
/*  88 */       if (paramClass == (Class)arrayOfObject[j])
/*  89 */         i++;
/*     */     }
/*  91 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void add(Class paramClass, EventListener paramEventListener)
/*     */   {
/* 101 */     if (!paramClass.isInstance(paramEventListener)) {
/* 102 */       throw new IllegalArgumentException("Listener " + paramEventListener + " is not of type " + paramClass);
/*     */     }
/*     */     
/* 105 */     if (paramEventListener == null) {
/* 106 */       throw new IllegalArgumentException("Listener " + paramEventListener + " is null");
/*     */     }
/*     */     
/* 109 */     if (this.listenerList == NULL_ARRAY)
/*     */     {
/*     */ 
/* 112 */       this.listenerList = new Object[] { paramClass, paramEventListener };
/*     */     }
/*     */     else {
/* 115 */       int i = this.listenerList.length;
/* 116 */       Object[] arrayOfObject = new Object[i + 2];
/* 117 */       System.arraycopy(this.listenerList, 0, arrayOfObject, 0, i);
/*     */       
/* 119 */       arrayOfObject[i] = paramClass;
/* 120 */       arrayOfObject[(i + 1)] = paramEventListener;
/*     */       
/* 122 */       this.listenerList = arrayOfObject;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void remove(Class paramClass, EventListener paramEventListener)
/*     */   {
/* 133 */     if (!paramClass.isInstance(paramEventListener)) {
/* 134 */       throw new IllegalArgumentException("Listener " + paramEventListener + " is not of type " + paramClass);
/*     */     }
/*     */     
/* 137 */     if (paramEventListener == null) {
/* 138 */       throw new IllegalArgumentException("Listener " + paramEventListener + " is null");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 143 */     int i = -1;
/* 144 */     for (int j = this.listenerList.length - 2; j >= 0; j -= 2) {
/* 145 */       if ((this.listenerList[j] == paramClass) && (this.listenerList[(j + 1)] == paramEventListener)) {
/* 146 */         i = j;
/* 147 */         break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 152 */     if (i != -1) {
/* 153 */       Object[] arrayOfObject = new Object[this.listenerList.length - 2];
/*     */       
/* 155 */       System.arraycopy(this.listenerList, 0, arrayOfObject, 0, i);
/*     */       
/*     */ 
/*     */ 
/* 159 */       if (i < arrayOfObject.length) {
/* 160 */         System.arraycopy(this.listenerList, i + 2, arrayOfObject, i, arrayOfObject.length - i);
/*     */       }
/*     */       
/* 163 */       this.listenerList = (arrayOfObject.length == 0 ? NULL_ARRAY : arrayOfObject);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 173 */     Object[] arrayOfObject = this.listenerList;
/* 174 */     String str = "EventListenerList: ";
/* 175 */     str = str + arrayOfObject.length / 2 + " listeners: ";
/* 176 */     for (int i = 0; i <= arrayOfObject.length - 2; i += 2) {
/* 177 */       str = str + " type " + ((Class)arrayOfObject[i]).getName();
/* 178 */       str = str + " listener " + arrayOfObject[(i + 1)];
/*     */     }
/* 180 */     return str;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jaccess.jar!\com\sun\java\accessibility\util\AccessibilityListenerList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */