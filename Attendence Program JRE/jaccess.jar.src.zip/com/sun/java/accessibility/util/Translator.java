/*     */ package com.sun.java.accessibility.util;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.IllegalComponentStateException;
/*     */ import java.awt.MenuComponent;
/*     */ import java.awt.MenuItem;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.util.Locale;
/*     */ import javax.accessibility.Accessible;
/*     */ import javax.accessibility.AccessibleComponent;
/*     */ import javax.accessibility.AccessibleContext;
/*     */ import javax.accessibility.AccessibleRole;
/*     */ import javax.accessibility.AccessibleState;
/*     */ import javax.accessibility.AccessibleStateSet;
/*     */ import jdk.Exported;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Exported
/*     */ public class Translator
/*     */   extends AccessibleContext
/*     */   implements Accessible, AccessibleComponent
/*     */ {
/*     */   protected Object source;
/*     */   
/*     */   protected static Class getTranslatorClass(Class paramClass)
/*     */   {
/*  76 */     Class localClass = null;
/*  77 */     if (paramClass == null) {
/*  78 */       return null;
/*     */     }
/*     */     try {
/*  81 */       return Class.forName("com.sun.java.accessibility.util." + paramClass
/*  82 */         .getName() + "Translator");
/*     */     }
/*     */     catch (Exception localException) {}
/*     */     
/*  86 */     return getTranslatorClass(paramClass.getSuperclass());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Accessible getAccessible(Object paramObject)
/*     */   {
/* 101 */     Object localObject = null;
/*     */     
/* 103 */     if (paramObject == null) {
/* 104 */       return null;
/*     */     }
/* 106 */     if ((paramObject instanceof Accessible)) {
/* 107 */       localObject = (Accessible)paramObject;
/*     */     } else {
/* 109 */       Class localClass = getTranslatorClass(paramObject.getClass());
/* 110 */       if (localClass != null) {
/*     */         try {
/* 112 */           Translator localTranslator = (Translator)localClass.newInstance();
/* 113 */           localTranslator.setSource(paramObject);
/* 114 */           localObject = localTranslator;
/*     */         }
/*     */         catch (Exception localException) {}
/*     */       }
/*     */     }
/* 119 */     if (localObject == null) {
/* 120 */       localObject = new Translator(paramObject);
/*     */     }
/* 122 */     return (Accessible)localObject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Translator() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Translator(Object paramObject)
/*     */   {
/* 139 */     this.source = paramObject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getSource()
/*     */   {
/* 148 */     return this.source;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSource(Object paramObject)
/*     */   {
/* 157 */     this.source = paramObject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object paramObject)
/*     */   {
/* 167 */     return this.source.equals(paramObject);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AccessibleContext getAccessibleContext()
/*     */   {
/* 177 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAccessibleName()
/*     */   {
/* 189 */     if ((this.source instanceof MenuItem))
/* 190 */       return ((MenuItem)this.source).getLabel();
/* 191 */     if ((this.source instanceof Component)) {
/* 192 */       return ((Component)this.source).getName();
/*     */     }
/* 194 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAccessibleName(String paramString)
/*     */   {
/* 202 */     if ((this.source instanceof MenuItem)) {
/* 203 */       ((MenuItem)this.source).setLabel(paramString);
/* 204 */     } else if ((this.source instanceof Component)) {
/* 205 */       ((Component)this.source).setName(paramString);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAccessibleDescription()
/*     */   {
/* 216 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAccessibleDescription(String paramString) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AccessibleRole getAccessibleRole()
/*     */   {
/* 233 */     return AccessibleRole.UNKNOWN;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AccessibleStateSet getAccessibleStateSet()
/*     */   {
/* 246 */     AccessibleStateSet localAccessibleStateSet = new AccessibleStateSet();
/* 247 */     if ((this.source instanceof Component)) {
/* 248 */       Component localComponent = (Component)this.source;
/* 249 */       for (Container localContainer = localComponent.getParent(); localContainer != null; localContainer = localContainer.getParent()) {
/* 250 */         if (((localContainer instanceof Window)) && 
/* 251 */           (((Window)localContainer).getFocusOwner() == localComponent)) {
/* 252 */           localAccessibleStateSet.add(AccessibleState.FOCUSED);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 257 */     if (isEnabled()) {
/* 258 */       localAccessibleStateSet.add(AccessibleState.ENABLED);
/*     */     }
/* 260 */     if (isFocusTraversable()) {
/* 261 */       localAccessibleStateSet.add(AccessibleState.FOCUSABLE);
/*     */     }
/* 263 */     if ((this.source instanceof MenuItem)) {
/* 264 */       localAccessibleStateSet.add(AccessibleState.FOCUSABLE);
/*     */     }
/* 266 */     return localAccessibleStateSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Accessible getAccessibleParent()
/*     */   {
/* 276 */     if (this.accessibleParent != null)
/* 277 */       return this.accessibleParent;
/* 278 */     if ((this.source instanceof Component)) {
/* 279 */       return getAccessible(((Component)this.source).getParent());
/*     */     }
/* 281 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getAccessibleIndexInParent()
/*     */   {
/* 292 */     if ((this.source instanceof Component)) {
/* 293 */       Container localContainer = ((Component)this.source).getParent();
/* 294 */       if (localContainer != null) {
/* 295 */         Component[] arrayOfComponent = localContainer.getComponents();
/* 296 */         for (int i = 0; i < arrayOfComponent.length; i++) {
/* 297 */           if (this.source.equals(arrayOfComponent[i])) {
/* 298 */             return i;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 303 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getAccessibleChildrenCount()
/*     */   {
/* 312 */     if ((this.source instanceof Container)) {
/* 313 */       Component[] arrayOfComponent = ((Container)this.source).getComponents();
/* 314 */       int i = 0;
/* 315 */       for (int j = 0; j < arrayOfComponent.length; j++) {
/* 316 */         Accessible localAccessible = getAccessible(arrayOfComponent[j]);
/* 317 */         if (localAccessible != null) {
/* 318 */           i++;
/*     */         }
/*     */       }
/* 321 */       return i;
/*     */     }
/* 323 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Accessible getAccessibleChild(int paramInt)
/*     */   {
/* 334 */     if ((this.source instanceof Container)) {
/* 335 */       Component[] arrayOfComponent = ((Container)this.source).getComponents();
/* 336 */       int i = 0;
/*     */       
/* 338 */       for (int j = 0; j < arrayOfComponent.length; j++) {
/* 339 */         Accessible localAccessible = getAccessible(arrayOfComponent[j]);
/* 340 */         if (localAccessible != null) {
/* 341 */           if (i == paramInt) {
/* 342 */             AccessibleContext localAccessibleContext = localAccessible.getAccessibleContext();
/* 343 */             if (localAccessibleContext != null) {
/* 344 */               localAccessibleContext.setAccessibleParent(this);
/*     */             }
/* 346 */             return localAccessible;
/*     */           }
/* 348 */           i++;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 353 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Locale getLocale()
/*     */     throws IllegalComponentStateException
/*     */   {
/* 363 */     if ((this.source instanceof Component)) {
/* 364 */       return ((Component)this.source).getLocale();
/*     */     }
/* 366 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color getBackground()
/*     */   {
/* 393 */     if ((this.source instanceof Component)) {
/* 394 */       return ((Component)this.source).getBackground();
/*     */     }
/* 396 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBackground(Color paramColor)
/*     */   {
/* 406 */     if ((this.source instanceof Component)) {
/* 407 */       ((Component)this.source).setBackground(paramColor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color getForeground()
/*     */   {
/* 417 */     if ((this.source instanceof Component)) {
/* 418 */       return ((Component)this.source).getForeground();
/*     */     }
/* 420 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setForeground(Color paramColor)
/*     */   {
/* 430 */     if ((this.source instanceof Component)) {
/* 431 */       ((Component)this.source).setForeground(paramColor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cursor getCursor()
/*     */   {
/* 441 */     if ((this.source instanceof Component)) {
/* 442 */       return ((Component)this.source).getCursor();
/*     */     }
/* 444 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCursor(Cursor paramCursor)
/*     */   {
/* 453 */     if ((this.source instanceof Component)) {
/* 454 */       ((Component)this.source).setCursor(paramCursor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Font getFont()
/*     */   {
/* 464 */     if ((this.source instanceof Component))
/* 465 */       return ((Component)this.source).getFont();
/* 466 */     if ((this.source instanceof MenuComponent)) {
/* 467 */       return ((MenuComponent)this.source).getFont();
/*     */     }
/* 469 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFont(Font paramFont)
/*     */   {
/* 479 */     if ((this.source instanceof Component)) {
/* 480 */       ((Component)this.source).setFont(paramFont);
/* 481 */     } else if ((this.source instanceof MenuComponent)) {
/* 482 */       ((MenuComponent)this.source).setFont(paramFont);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FontMetrics getFontMetrics(Font paramFont)
/*     */   {
/* 494 */     if ((this.source instanceof Component)) {
/* 495 */       return ((Component)this.source).getFontMetrics(paramFont);
/*     */     }
/* 497 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEnabled()
/*     */   {
/* 507 */     if ((this.source instanceof Component))
/* 508 */       return ((Component)this.source).isEnabled();
/* 509 */     if ((this.source instanceof MenuItem)) {
/* 510 */       return ((MenuItem)this.source).isEnabled();
/*     */     }
/* 512 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnabled(boolean paramBoolean)
/*     */   {
/* 522 */     if ((this.source instanceof Component)) {
/* 523 */       ((Component)this.source).setEnabled(paramBoolean);
/* 524 */     } else if ((this.source instanceof MenuItem)) {
/* 525 */       ((MenuItem)this.source).setEnabled(paramBoolean);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isVisible()
/*     */   {
/* 535 */     if ((this.source instanceof Component)) {
/* 536 */       return ((Component)this.source).isVisible();
/*     */     }
/* 538 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVisible(boolean paramBoolean)
/*     */   {
/* 548 */     if ((this.source instanceof Component)) {
/* 549 */       ((Component)this.source).setVisible(paramBoolean);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isShowing()
/*     */   {
/* 560 */     if ((this.source instanceof Component)) {
/* 561 */       return ((Component)this.source).isShowing();
/*     */     }
/* 563 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean contains(Point paramPoint)
/*     */   {
/* 576 */     if ((this.source instanceof Component)) {
/* 577 */       return ((Component)this.source).contains(paramPoint);
/*     */     }
/* 579 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Point getLocationOnScreen()
/*     */   {
/* 590 */     if ((this.source instanceof Component)) {
/* 591 */       return ((Component)this.source).getLocationOnScreen();
/*     */     }
/* 593 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Point getLocation()
/*     */   {
/* 604 */     if ((this.source instanceof Component)) {
/* 605 */       return ((Component)this.source).getLocation();
/*     */     }
/* 607 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocation(Point paramPoint)
/*     */   {
/* 615 */     if ((this.source instanceof Component)) {
/* 616 */       ((Component)this.source).setLocation(paramPoint);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle getBounds()
/*     */   {
/* 627 */     if ((this.source instanceof Component)) {
/* 628 */       return ((Component)this.source).getBounds();
/*     */     }
/* 630 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBounds(Rectangle paramRectangle)
/*     */   {
/* 638 */     if ((this.source instanceof Component)) {
/* 639 */       ((Component)this.source).setBounds(paramRectangle);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Dimension getSize()
/*     */   {
/* 650 */     if ((this.source instanceof Component)) {
/* 651 */       return ((Component)this.source).getSize();
/*     */     }
/* 653 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSize(Dimension paramDimension)
/*     */   {
/* 661 */     if ((this.source instanceof Component)) {
/* 662 */       ((Component)this.source).setSize(paramDimension);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Accessible getAccessibleAt(Point paramPoint)
/*     */   {
/* 673 */     if ((this.source instanceof Component)) {
/* 674 */       Component localComponent = ((Component)this.source).getComponentAt(paramPoint);
/* 675 */       if (localComponent != null) {
/* 676 */         return getAccessible(localComponent);
/*     */       }
/*     */     }
/* 679 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFocusTraversable()
/*     */   {
/* 688 */     if ((this.source instanceof Component)) {
/* 689 */       return ((Component)this.source).isFocusTraversable();
/*     */     }
/* 691 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void requestFocus()
/*     */   {
/* 699 */     if ((this.source instanceof Component)) {
/* 700 */       ((Component)this.source).requestFocus();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void addFocusListener(FocusListener paramFocusListener)
/*     */   {
/* 711 */     if ((this.source instanceof Component)) {
/* 712 */       ((Component)this.source).addFocusListener(paramFocusListener);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void removeFocusListener(FocusListener paramFocusListener)
/*     */   {
/* 726 */     if ((this.source instanceof Component)) {
/* 727 */       ((Component)this.source).removeFocusListener(paramFocusListener);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jaccess.jar!\com\sun\java\accessibility\util\Translator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */