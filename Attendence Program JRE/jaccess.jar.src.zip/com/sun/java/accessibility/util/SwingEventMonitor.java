/*      */ package com.sun.java.accessibility.util;
/*      */ 
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.event.ContainerEvent;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyVetoException;
/*      */ import java.beans.VetoableChangeListener;
/*      */ import java.io.PrintStream;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import javax.swing.CellEditor;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.ListModel;
/*      */ import javax.swing.ListSelectionModel;
/*      */ import javax.swing.event.AncestorEvent;
/*      */ import javax.swing.event.AncestorListener;
/*      */ import javax.swing.event.CaretEvent;
/*      */ import javax.swing.event.CaretListener;
/*      */ import javax.swing.event.CellEditorListener;
/*      */ import javax.swing.event.ChangeEvent;
/*      */ import javax.swing.event.ChangeListener;
/*      */ import javax.swing.event.DocumentEvent;
/*      */ import javax.swing.event.DocumentListener;
/*      */ import javax.swing.event.EventListenerList;
/*      */ import javax.swing.event.InternalFrameEvent;
/*      */ import javax.swing.event.InternalFrameListener;
/*      */ import javax.swing.event.ListDataEvent;
/*      */ import javax.swing.event.ListDataListener;
/*      */ import javax.swing.event.ListSelectionEvent;
/*      */ import javax.swing.event.ListSelectionListener;
/*      */ import javax.swing.event.MenuEvent;
/*      */ import javax.swing.event.MenuListener;
/*      */ import javax.swing.event.PopupMenuEvent;
/*      */ import javax.swing.event.PopupMenuListener;
/*      */ import javax.swing.event.TableColumnModelEvent;
/*      */ import javax.swing.event.TableColumnModelListener;
/*      */ import javax.swing.event.TableModelEvent;
/*      */ import javax.swing.event.TableModelListener;
/*      */ import javax.swing.event.TreeExpansionEvent;
/*      */ import javax.swing.event.TreeExpansionListener;
/*      */ import javax.swing.event.TreeModelEvent;
/*      */ import javax.swing.event.TreeModelListener;
/*      */ import javax.swing.event.TreeSelectionEvent;
/*      */ import javax.swing.event.TreeSelectionListener;
/*      */ import javax.swing.event.UndoableEditEvent;
/*      */ import javax.swing.event.UndoableEditListener;
/*      */ import javax.swing.table.TableColumnModel;
/*      */ import javax.swing.table.TableModel;
/*      */ import javax.swing.text.Document;
/*      */ import javax.swing.text.JTextComponent;
/*      */ import javax.swing.tree.TreeModel;
/*      */ import javax.swing.tree.TreeSelectionModel;
/*      */ import jdk.Exported;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Exported
/*      */ public class SwingEventMonitor
/*      */   extends AWTEventMonitor
/*      */ {
/*   67 */   protected static final EventListenerList listenerList = new EventListenerList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   75 */   protected static final SwingEventListener swingListener = new SwingEventListener();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addAncestorListener(AncestorListener paramAncestorListener)
/*      */   {
/*   88 */     if (listenerList.getListenerCount(AncestorListener.class) == 0) {
/*   89 */       swingListener.installListeners(12);
/*      */     }
/*   91 */     listenerList.add(AncestorListener.class, paramAncestorListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeAncestorListener(AncestorListener paramAncestorListener)
/*      */   {
/*  102 */     listenerList.remove(AncestorListener.class, paramAncestorListener);
/*  103 */     if (listenerList.getListenerCount(AncestorListener.class) == 0) {
/*  104 */       swingListener.removeListeners(12);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addCaretListener(CaretListener paramCaretListener)
/*      */   {
/*  119 */     if (listenerList.getListenerCount(CaretListener.class) == 0) {
/*  120 */       swingListener.installListeners(13);
/*      */     }
/*  122 */     listenerList.add(CaretListener.class, paramCaretListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeCaretListener(CaretListener paramCaretListener)
/*      */   {
/*  133 */     listenerList.remove(CaretListener.class, paramCaretListener);
/*  134 */     if (listenerList.getListenerCount(CaretListener.class) == 0) {
/*  135 */       swingListener.removeListeners(13);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addCellEditorListener(CellEditorListener paramCellEditorListener)
/*      */   {
/*  151 */     if (listenerList.getListenerCount(CellEditorListener.class) == 0) {
/*  152 */       swingListener.installListeners(14);
/*      */     }
/*  154 */     listenerList.add(CellEditorListener.class, paramCellEditorListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeCellEditorListener(CellEditorListener paramCellEditorListener)
/*      */   {
/*  165 */     listenerList.remove(CellEditorListener.class, paramCellEditorListener);
/*  166 */     if (listenerList.getListenerCount(CellEditorListener.class) == 0) {
/*  167 */       swingListener.removeListeners(14);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addChangeListener(ChangeListener paramChangeListener)
/*      */   {
/*  182 */     if (listenerList.getListenerCount(ChangeListener.class) == 0) {
/*  183 */       swingListener.installListeners(15);
/*      */     }
/*  185 */     listenerList.add(ChangeListener.class, paramChangeListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeChangeListener(ChangeListener paramChangeListener)
/*      */   {
/*  196 */     listenerList.remove(ChangeListener.class, paramChangeListener);
/*  197 */     if (listenerList.getListenerCount(ChangeListener.class) == 0) {
/*  198 */       swingListener.removeListeners(15);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addColumnModelListener(TableColumnModelListener paramTableColumnModelListener)
/*      */   {
/*  213 */     if (listenerList.getListenerCount(TableColumnModelListener.class) == 0) {
/*  214 */       swingListener.installListeners(16);
/*      */     }
/*  216 */     listenerList.add(TableColumnModelListener.class, paramTableColumnModelListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeColumnModelListener(TableColumnModelListener paramTableColumnModelListener)
/*      */   {
/*  227 */     listenerList.remove(TableColumnModelListener.class, paramTableColumnModelListener);
/*  228 */     if (listenerList.getListenerCount(TableColumnModelListener.class) == 0) {
/*  229 */       swingListener.removeListeners(16);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addDocumentListener(DocumentListener paramDocumentListener)
/*      */   {
/*  244 */     if (listenerList.getListenerCount(DocumentListener.class) == 0) {
/*  245 */       swingListener.installListeners(17);
/*      */     }
/*  247 */     listenerList.add(DocumentListener.class, paramDocumentListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeDocumentListener(DocumentListener paramDocumentListener)
/*      */   {
/*  258 */     listenerList.remove(DocumentListener.class, paramDocumentListener);
/*  259 */     if (listenerList.getListenerCount(DocumentListener.class) == 0) {
/*  260 */       swingListener.removeListeners(17);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addListDataListener(ListDataListener paramListDataListener)
/*      */   {
/*  275 */     if (listenerList.getListenerCount(ListDataListener.class) == 0) {
/*  276 */       swingListener.installListeners(18);
/*      */     }
/*  278 */     listenerList.add(ListDataListener.class, paramListDataListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeListDataListener(ListDataListener paramListDataListener)
/*      */   {
/*  289 */     listenerList.remove(ListDataListener.class, paramListDataListener);
/*  290 */     if (listenerList.getListenerCount(ListDataListener.class) == 0) {
/*  291 */       swingListener.removeListeners(18);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addListSelectionListener(ListSelectionListener paramListSelectionListener)
/*      */   {
/*  306 */     if (listenerList.getListenerCount(ListSelectionListener.class) == 0) {
/*  307 */       swingListener.installListeners(19);
/*      */     }
/*  309 */     listenerList.add(ListSelectionListener.class, paramListSelectionListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeListSelectionListener(ListSelectionListener paramListSelectionListener)
/*      */   {
/*  320 */     listenerList.remove(ListSelectionListener.class, paramListSelectionListener);
/*  321 */     if (listenerList.getListenerCount(ListSelectionListener.class) == 0) {
/*  322 */       swingListener.removeListeners(19);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addMenuListener(MenuListener paramMenuListener)
/*      */   {
/*  337 */     if (listenerList.getListenerCount(MenuListener.class) == 0) {
/*  338 */       swingListener.installListeners(20);
/*      */     }
/*  340 */     listenerList.add(MenuListener.class, paramMenuListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeMenuListener(MenuListener paramMenuListener)
/*      */   {
/*  351 */     listenerList.remove(MenuListener.class, paramMenuListener);
/*  352 */     if (listenerList.getListenerCount(MenuListener.class) == 0) {
/*  353 */       swingListener.removeListeners(20);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addPopupMenuListener(PopupMenuListener paramPopupMenuListener)
/*      */   {
/*  368 */     if (listenerList.getListenerCount(PopupMenuListener.class) == 0) {
/*  369 */       swingListener.installListeners(21);
/*      */     }
/*  371 */     listenerList.add(PopupMenuListener.class, paramPopupMenuListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removePopupMenuListener(PopupMenuListener paramPopupMenuListener)
/*      */   {
/*  382 */     listenerList.remove(PopupMenuListener.class, paramPopupMenuListener);
/*  383 */     if (listenerList.getListenerCount(PopupMenuListener.class) == 0) {
/*  384 */       swingListener.removeListeners(21);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addTableModelListener(TableModelListener paramTableModelListener)
/*      */   {
/*  399 */     if (listenerList.getListenerCount(TableModelListener.class) == 0) {
/*  400 */       swingListener.installListeners(22);
/*      */     }
/*  402 */     listenerList.add(TableModelListener.class, paramTableModelListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeTableModelListener(TableModelListener paramTableModelListener)
/*      */   {
/*  413 */     listenerList.remove(TableModelListener.class, paramTableModelListener);
/*  414 */     if (listenerList.getListenerCount(TableModelListener.class) == 0) {
/*  415 */       swingListener.removeListeners(22);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addTreeExpansionListener(TreeExpansionListener paramTreeExpansionListener)
/*      */   {
/*  430 */     if (listenerList.getListenerCount(TreeExpansionListener.class) == 0) {
/*  431 */       swingListener.installListeners(23);
/*      */     }
/*  433 */     listenerList.add(TreeExpansionListener.class, paramTreeExpansionListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeTreeExpansionListener(TreeExpansionListener paramTreeExpansionListener)
/*      */   {
/*  444 */     listenerList.remove(TreeExpansionListener.class, paramTreeExpansionListener);
/*  445 */     if (listenerList.getListenerCount(TreeExpansionListener.class) == 0) {
/*  446 */       swingListener.removeListeners(23);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addTreeModelListener(TreeModelListener paramTreeModelListener)
/*      */   {
/*  461 */     if (listenerList.getListenerCount(TreeModelListener.class) == 0) {
/*  462 */       swingListener.installListeners(24);
/*      */     }
/*  464 */     listenerList.add(TreeModelListener.class, paramTreeModelListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeTreeModelListener(TreeModelListener paramTreeModelListener)
/*      */   {
/*  475 */     listenerList.remove(TreeModelListener.class, paramTreeModelListener);
/*  476 */     if (listenerList.getListenerCount(TreeModelListener.class) == 0) {
/*  477 */       swingListener.removeListeners(24);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addTreeSelectionListener(TreeSelectionListener paramTreeSelectionListener)
/*      */   {
/*  492 */     if (listenerList.getListenerCount(TreeSelectionListener.class) == 0) {
/*  493 */       swingListener.installListeners(25);
/*      */     }
/*  495 */     listenerList.add(TreeSelectionListener.class, paramTreeSelectionListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeTreeSelectionListener(TreeSelectionListener paramTreeSelectionListener)
/*      */   {
/*  505 */     listenerList.remove(TreeSelectionListener.class, paramTreeSelectionListener);
/*  506 */     if (listenerList.getListenerCount(TreeSelectionListener.class) == 0) {
/*  507 */       swingListener.removeListeners(25);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addUndoableEditListener(UndoableEditListener paramUndoableEditListener)
/*      */   {
/*  522 */     if (listenerList.getListenerCount(UndoableEditListener.class) == 0) {
/*  523 */       swingListener.installListeners(26);
/*      */     }
/*  525 */     listenerList.add(UndoableEditListener.class, paramUndoableEditListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeUndoableEditListener(UndoableEditListener paramUndoableEditListener)
/*      */   {
/*  536 */     listenerList.remove(UndoableEditListener.class, paramUndoableEditListener);
/*  537 */     if (listenerList.getListenerCount(UndoableEditListener.class) == 0) {
/*  538 */       swingListener.removeListeners(26);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addInternalFrameListener(InternalFrameListener paramInternalFrameListener)
/*      */   {
/*  553 */     if (listenerList.getListenerCount(InternalFrameListener.class) == 0) {
/*  554 */       swingListener.installListeners(29);
/*      */     }
/*  556 */     listenerList.add(InternalFrameListener.class, paramInternalFrameListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeInternalFrameListener(InternalFrameListener paramInternalFrameListener)
/*      */   {
/*  567 */     listenerList.remove(InternalFrameListener.class, paramInternalFrameListener);
/*  568 */     if (listenerList.getListenerCount(InternalFrameListener.class) == 0) {
/*  569 */       swingListener.removeListeners(29);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener)
/*      */   {
/*  584 */     if (listenerList.getListenerCount(PropertyChangeListener.class) == 0) {
/*  585 */       swingListener.installListeners(27);
/*      */     }
/*  587 */     listenerList.add(PropertyChangeListener.class, paramPropertyChangeListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener)
/*      */   {
/*  597 */     listenerList.remove(PropertyChangeListener.class, paramPropertyChangeListener);
/*  598 */     if (listenerList.getListenerCount(PropertyChangeListener.class) == 0) {
/*  599 */       swingListener.removeListeners(27);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addVetoableChangeListener(VetoableChangeListener paramVetoableChangeListener)
/*      */   {
/*  614 */     if (listenerList.getListenerCount(VetoableChangeListener.class) == 0) {
/*  615 */       swingListener.installListeners(28);
/*      */     }
/*  617 */     listenerList.add(VetoableChangeListener.class, paramVetoableChangeListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeVetoableChangeListener(VetoableChangeListener paramVetoableChangeListener)
/*      */   {
/*  628 */     listenerList.remove(VetoableChangeListener.class, paramVetoableChangeListener);
/*  629 */     if (listenerList.getListenerCount(VetoableChangeListener.class) == 0) {
/*  630 */       swingListener.removeListeners(28);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static class SwingEventListener
/*      */     extends AWTEventMonitor.AWTEventsListener
/*      */     implements AncestorListener, CaretListener, CellEditorListener, ChangeListener, DocumentListener, ListDataListener, ListSelectionListener, MenuListener, PopupMenuListener, TableColumnModelListener, TableModelListener, TreeExpansionListener, TreeModelListener, TreeSelectionListener, UndoableEditListener, InternalFrameListener, PropertyChangeListener, VetoableChangeListener
/*      */   {
/*      */     private Class[] caretListeners;
/*      */     
/*      */ 
/*      */     private Method removeCaretMethod;
/*      */     
/*      */ 
/*      */     private Method addCaretMethod;
/*      */     
/*      */ 
/*      */     private Object[] caretArgs;
/*      */     
/*      */ 
/*      */     private Class[] cellEditorListeners;
/*      */     
/*      */ 
/*      */     private Method removeCellEditorMethod;
/*      */     
/*      */ 
/*      */     private Method addCellEditorMethod;
/*      */     
/*      */ 
/*      */     private Object[] cellEditorArgs;
/*      */     
/*      */ 
/*      */     private Method getCellEditorMethod;
/*      */     
/*      */ 
/*      */     private Class[] changeListeners;
/*      */     
/*      */ 
/*      */     private Method removeChangeMethod;
/*      */     
/*      */ 
/*      */     private Method addChangeMethod;
/*      */     
/*      */ 
/*      */     private Object[] changeArgs;
/*      */     
/*      */ 
/*      */     private Method getColumnModelMethod;
/*      */     
/*      */ 
/*      */     private Class[] documentListeners;
/*      */     
/*      */ 
/*      */     private Method removeDocumentMethod;
/*      */     
/*      */ 
/*      */     private Method addDocumentMethod;
/*      */     
/*      */ 
/*      */     private Object[] documentArgs;
/*      */     
/*      */ 
/*      */     private Method getDocumentMethod;
/*      */     
/*      */ 
/*      */     private Method getModelMethod;
/*      */     
/*      */ 
/*      */     private Class[] listSelectionListeners;
/*      */     
/*      */ 
/*      */     private Method removeListSelectionMethod;
/*      */     
/*      */     private Method addListSelectionMethod;
/*      */     
/*      */     private Object[] listSelectionArgs;
/*      */     
/*      */     private Method getSelectionModelMethod;
/*      */     
/*      */     private Class[] menuListeners;
/*      */     
/*      */     private Method removeMenuMethod;
/*      */     
/*      */     private Method addMenuMethod;
/*      */     
/*      */     private Object[] menuArgs;
/*      */     
/*      */     private Class[] popupMenuListeners;
/*      */     
/*      */     private Method removePopupMenuMethod;
/*      */     
/*      */     private Method addPopupMenuMethod;
/*      */     
/*      */     private Object[] popupMenuArgs;
/*      */     
/*      */     private Method getPopupMenuMethod;
/*      */     
/*      */     private Class[] treeExpansionListeners;
/*      */     
/*      */     private Method removeTreeExpansionMethod;
/*      */     
/*      */     private Method addTreeExpansionMethod;
/*      */     
/*      */     private Object[] treeExpansionArgs;
/*      */     
/*      */     private Class[] treeSelectionListeners;
/*      */     
/*      */     private Method removeTreeSelectionMethod;
/*      */     
/*      */     private Method addTreeSelectionMethod;
/*      */     
/*      */     private Object[] treeSelectionArgs;
/*      */     
/*      */     private Class[] undoableEditListeners;
/*      */     
/*      */     private Method removeUndoableEditMethod;
/*      */     
/*      */     private Method addUndoableEditMethod;
/*      */     
/*      */     private Object[] undoableEditArgs;
/*      */     
/*      */     private Class[] internalFrameListeners;
/*      */     
/*      */     private Method removeInternalFrameMethod;
/*      */     
/*      */     private Method addInternalFrameMethod;
/*      */     
/*      */     private Object[] internalFrameArgs;
/*      */     
/*      */     private Class[] propertyChangeListeners;
/*      */     
/*      */     private Method removePropertyChangeMethod;
/*      */     
/*      */     private Method addPropertyChangeMethod;
/*      */     
/*      */     private Object[] propertyChangeArgs;
/*      */     
/*      */     private Class[] nullClass;
/*      */     
/*      */     private Object[] nullArgs;
/*      */     
/*      */ 
/*      */     public SwingEventListener()
/*      */     {
/*  776 */       initializeIntrospection();
/*  777 */       installListeners();
/*  778 */       EventQueueMonitor.addTopLevelWindowListener(this);
/*      */     }
/*      */     
/*      */ 
/*      */     private boolean initializeIntrospection()
/*      */     {
/*      */       try
/*      */       {
/*  786 */         this.caretListeners = new Class[1];
/*  787 */         this.caretArgs = new Object[1];
/*  788 */         this.caretListeners[0] = Class.forName("javax.swing.event.CaretListener");
/*  789 */         this.caretArgs[0] = this;
/*      */         
/*  791 */         this.cellEditorListeners = new Class[1];
/*  792 */         this.cellEditorArgs = new Object[1];
/*  793 */         this.cellEditorListeners[0] = Class.forName("javax.swing.event.CellEditorListener");
/*  794 */         this.cellEditorArgs[0] = this;
/*      */         
/*  796 */         this.changeListeners = new Class[1];
/*  797 */         this.changeArgs = new Object[1];
/*  798 */         this.changeListeners[0] = Class.forName("javax.swing.event.ChangeListener");
/*  799 */         this.changeArgs[0] = this;
/*      */         
/*  801 */         this.documentListeners = new Class[1];
/*  802 */         this.documentArgs = new Object[1];
/*  803 */         this.documentListeners[0] = Class.forName("javax.swing.event.DocumentListener");
/*  804 */         this.documentArgs[0] = this;
/*      */         
/*  806 */         this.listSelectionListeners = new Class[1];
/*  807 */         this.listSelectionArgs = new Object[1];
/*  808 */         this.listSelectionListeners[0] = Class.forName("javax.swing.event.ListSelectionListener");
/*  809 */         this.listSelectionArgs[0] = this;
/*      */         
/*  811 */         this.menuListeners = new Class[1];
/*  812 */         this.menuArgs = new Object[1];
/*  813 */         this.menuListeners[0] = Class.forName("javax.swing.event.MenuListener");
/*  814 */         this.menuArgs[0] = this;
/*      */         
/*  816 */         this.popupMenuListeners = new Class[1];
/*  817 */         this.popupMenuArgs = new Object[1];
/*  818 */         this.popupMenuListeners[0] = Class.forName("javax.swing.event.PopupMenuListener");
/*  819 */         this.popupMenuArgs[0] = this;
/*      */         
/*  821 */         this.treeExpansionListeners = new Class[1];
/*  822 */         this.treeExpansionArgs = new Object[1];
/*  823 */         this.treeExpansionListeners[0] = Class.forName("javax.swing.event.TreeExpansionListener");
/*  824 */         this.treeExpansionArgs[0] = this;
/*      */         
/*  826 */         this.treeSelectionListeners = new Class[1];
/*  827 */         this.treeSelectionArgs = new Object[1];
/*  828 */         this.treeSelectionListeners[0] = Class.forName("javax.swing.event.TreeSelectionListener");
/*  829 */         this.treeSelectionArgs[0] = this;
/*      */         
/*  831 */         this.undoableEditListeners = new Class[1];
/*  832 */         this.undoableEditArgs = new Object[1];
/*  833 */         this.undoableEditListeners[0] = Class.forName("javax.swing.event.UndoableEditListener");
/*  834 */         this.undoableEditArgs[0] = this;
/*      */         
/*  836 */         this.internalFrameListeners = new Class[1];
/*  837 */         this.internalFrameArgs = new Object[1];
/*  838 */         this.internalFrameListeners[0] = Class.forName("javax.swing.event.InternalFrameListener");
/*  839 */         this.internalFrameArgs[0] = this;
/*      */         
/*  841 */         this.nullClass = new Class[0];
/*  842 */         this.nullArgs = new Object[0];
/*      */       }
/*      */       catch (ClassNotFoundException localClassNotFoundException1) {
/*  845 */         System.out.println("EXCEPTION - Class 'javax.swing.event.*' not in CLASSPATH");
/*  846 */         return false;
/*      */       }
/*      */       try
/*      */       {
/*  850 */         this.propertyChangeListeners = new Class[1];
/*  851 */         this.propertyChangeArgs = new Object[1];
/*  852 */         this.propertyChangeListeners[0] = Class.forName("java.beans.PropertyChangeListener");
/*  853 */         this.propertyChangeArgs[0] = this;
/*      */       }
/*      */       catch (ClassNotFoundException localClassNotFoundException2) {
/*  856 */         System.out.println("EXCEPTION - Class 'java.beans.*' not in CLASSPATH");
/*  857 */         return false;
/*      */       }
/*      */       
/*  860 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void installListeners(Component paramComponent)
/*      */     {
/*  876 */       installListeners(paramComponent, 3);
/*      */       
/*      */ 
/*      */ 
/*  880 */       if (SwingEventMonitor.listenerList.getListenerCount(AncestorListener.class) > 0) {
/*  881 */         installListeners(paramComponent, 12);
/*      */       }
/*  883 */       if (SwingEventMonitor.listenerList.getListenerCount(CaretListener.class) > 0) {
/*  884 */         installListeners(paramComponent, 13);
/*      */       }
/*  886 */       if (SwingEventMonitor.listenerList.getListenerCount(CellEditorListener.class) > 0) {
/*  887 */         installListeners(paramComponent, 14);
/*      */       }
/*  889 */       if (SwingEventMonitor.listenerList.getListenerCount(ChangeListener.class) > 0) {
/*  890 */         installListeners(paramComponent, 15);
/*      */       }
/*  892 */       if (SwingEventMonitor.listenerList.getListenerCount(TableColumnModelListener.class) > 0) {
/*  893 */         installListeners(paramComponent, 16);
/*      */       }
/*  895 */       if (SwingEventMonitor.listenerList.getListenerCount(DocumentListener.class) > 0) {
/*  896 */         installListeners(paramComponent, 17);
/*      */       }
/*  898 */       if (SwingEventMonitor.listenerList.getListenerCount(ListDataListener.class) > 0) {
/*  899 */         installListeners(paramComponent, 18);
/*      */       }
/*  901 */       if (SwingEventMonitor.listenerList.getListenerCount(ListSelectionListener.class) > 0) {
/*  902 */         installListeners(paramComponent, 19);
/*      */       }
/*  904 */       if (SwingEventMonitor.listenerList.getListenerCount(MenuListener.class) > 0) {
/*  905 */         installListeners(paramComponent, 20);
/*      */       }
/*  907 */       if (SwingEventMonitor.listenerList.getListenerCount(PopupMenuListener.class) > 0) {
/*  908 */         installListeners(paramComponent, 21);
/*      */       }
/*  910 */       if (SwingEventMonitor.listenerList.getListenerCount(TableModelListener.class) > 0) {
/*  911 */         installListeners(paramComponent, 22);
/*      */       }
/*  913 */       if (SwingEventMonitor.listenerList.getListenerCount(TreeExpansionListener.class) > 0) {
/*  914 */         installListeners(paramComponent, 23);
/*      */       }
/*  916 */       if (SwingEventMonitor.listenerList.getListenerCount(TreeModelListener.class) > 0) {
/*  917 */         installListeners(paramComponent, 24);
/*      */       }
/*  919 */       if (SwingEventMonitor.listenerList.getListenerCount(TreeSelectionListener.class) > 0) {
/*  920 */         installListeners(paramComponent, 25);
/*      */       }
/*  922 */       if (SwingEventMonitor.listenerList.getListenerCount(UndoableEditListener.class) > 0) {
/*  923 */         installListeners(paramComponent, 26);
/*      */       }
/*  925 */       if (SwingEventMonitor.listenerList.getListenerCount(InternalFrameListener.class) > 0) {
/*  926 */         installListeners(paramComponent, 29);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  931 */       if (SwingEventMonitor.listenerList.getListenerCount(PropertyChangeListener.class) > 0) {
/*  932 */         installListeners(paramComponent, 27);
/*      */       }
/*  934 */       if (SwingEventMonitor.listenerList.getListenerCount(VetoableChangeListener.class) > 0) {
/*  935 */         installListeners(paramComponent, 28);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  940 */       super.installListeners(paramComponent);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void installListeners(Component paramComponent, int paramInt)
/*      */     {
/*  955 */       switch (paramInt)
/*      */       {
/*      */       case 3: 
/*  958 */         if ((paramComponent instanceof Container)) {
/*  959 */           ((Container)paramComponent).removeContainerListener(this);
/*  960 */           ((Container)paramComponent).addContainerListener(this);
/*      */         }
/*      */         
/*      */         break;
/*      */       case 12: 
/*  965 */         if ((paramComponent instanceof JComponent)) {
/*  966 */           ((JComponent)paramComponent).removeAncestorListener(this);
/*  967 */           ((JComponent)paramComponent).addAncestorListener(this);
/*      */         }
/*      */         break;
/*      */       case 13: 
/*      */         try
/*      */         {
/*  973 */           this.removeCaretMethod = paramComponent.getClass().getMethod("removeCaretListener", this.caretListeners);
/*      */           
/*  975 */           this.addCaretMethod = paramComponent.getClass().getMethod("addCaretListener", this.caretListeners);
/*      */           try
/*      */           {
/*  978 */             this.removeCaretMethod.invoke(paramComponent, this.caretArgs);
/*  979 */             this.addCaretMethod.invoke(paramComponent, this.caretArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException1) {
/*  981 */             System.out.println("Exception: " + localInvocationTargetException1.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException1) {
/*  983 */             System.out.println("Exception: " + localIllegalAccessException1.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException1) {}catch (SecurityException localSecurityException1)
/*      */         {
/*  988 */           System.out.println("Exception: " + localSecurityException1.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 14: 
/*      */         try
/*      */         {
/*  997 */           this.getCellEditorMethod = paramComponent.getClass().getMethod("getCellEditorMethod", this.nullClass);
/*      */           try
/*      */           {
/* 1000 */             Object localObject1 = this.getCellEditorMethod.invoke(paramComponent, this.nullArgs);
/* 1001 */             if ((localObject1 != null) && ((localObject1 instanceof CellEditor))) {
/* 1002 */               ((CellEditor)localObject1).removeCellEditorListener(this);
/* 1003 */               ((CellEditor)localObject1).addCellEditorListener(this);
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException2) {
/* 1006 */             System.out.println("Exception: " + localInvocationTargetException2.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException2) {
/* 1008 */             System.out.println("Exception: " + localIllegalAccessException2.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException2) {}catch (SecurityException localSecurityException2)
/*      */         {
/* 1013 */           System.out.println("Exception: " + localSecurityException2.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1020 */           this.removeCellEditorMethod = paramComponent.getClass().getMethod("removeCellEditorListener", this.cellEditorListeners);
/*      */           
/* 1022 */           this.addCellEditorMethod = paramComponent.getClass().getMethod("addCellEditorListener", this.cellEditorListeners);
/*      */           try
/*      */           {
/* 1025 */             this.removeCellEditorMethod.invoke(paramComponent, this.cellEditorArgs);
/* 1026 */             this.addCellEditorMethod.invoke(paramComponent, this.cellEditorArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException3) {
/* 1028 */             System.out.println("Exception: " + localInvocationTargetException3.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException3) {
/* 1030 */             System.out.println("Exception: " + localIllegalAccessException3.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException3) {}catch (SecurityException localSecurityException3)
/*      */         {
/* 1035 */           System.out.println("Exception: " + localSecurityException3.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case 15: 
/*      */         try
/*      */         {
/* 1047 */           this.removeChangeMethod = paramComponent.getClass().getMethod("removeChangeListener", this.changeListeners);
/*      */           
/* 1049 */           this.addChangeMethod = paramComponent.getClass().getMethod("addChangeListener", this.changeListeners);
/*      */           try
/*      */           {
/* 1052 */             this.removeChangeMethod.invoke(paramComponent, this.changeArgs);
/* 1053 */             this.addChangeMethod.invoke(paramComponent, this.changeArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException4) {
/* 1055 */             System.out.println("Exception: " + localInvocationTargetException4.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException4) {
/* 1057 */             System.out.println("Exception: " + localIllegalAccessException4.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException4) {}catch (SecurityException localSecurityException4)
/*      */         {
/* 1062 */           System.out.println("Exception: " + localSecurityException4.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1070 */           this.getModelMethod = paramComponent.getClass().getMethod("getModel", this.nullClass);
/*      */           try
/*      */           {
/* 1073 */             Object localObject2 = this.getModelMethod.invoke(paramComponent, this.nullArgs);
/* 1074 */             if (localObject2 != null) {
/* 1075 */               this.removeChangeMethod = localObject2.getClass().getMethod("removeChangeListener", this.changeListeners);
/*      */               
/* 1077 */               this.addChangeMethod = localObject2.getClass().getMethod("addChangeListener", this.changeListeners);
/*      */               
/* 1079 */               this.removeChangeMethod.invoke(localObject2, this.changeArgs);
/* 1080 */               this.addChangeMethod.invoke(localObject2, this.changeArgs);
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException5) {
/* 1083 */             System.out.println("Exception: " + localInvocationTargetException5.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException5) {
/* 1085 */             System.out.println("Exception: " + localIllegalAccessException5.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException5) {}catch (SecurityException localSecurityException5)
/*      */         {
/* 1090 */           System.out.println("Exception: " + localSecurityException5.toString());
/*      */         }
/*      */       
/*      */ 
/*      */       case 16: 
/*      */         try
/*      */         {
/* 1097 */           this.getColumnModelMethod = paramComponent.getClass().getMethod("getTableColumnModel", this.nullClass);
/*      */           try
/*      */           {
/* 1100 */             Object localObject3 = this.getColumnModelMethod.invoke(paramComponent, this.nullArgs);
/* 1101 */             if ((localObject3 != null) && ((localObject3 instanceof TableColumnModel))) {
/* 1102 */               ((TableColumnModel)localObject3).removeColumnModelListener(this);
/* 1103 */               ((TableColumnModel)localObject3).addColumnModelListener(this);
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException6) {
/* 1106 */             System.out.println("Exception: " + localInvocationTargetException6.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException6) {
/* 1108 */             System.out.println("Exception: " + localIllegalAccessException6.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException6) {}catch (SecurityException localSecurityException6)
/*      */         {
/* 1113 */           System.out.println("Exception: " + localSecurityException6.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 17: 
/*      */         try
/*      */         {
/* 1122 */           this.getDocumentMethod = paramComponent.getClass().getMethod("getDocument", this.nullClass);
/*      */           try
/*      */           {
/* 1125 */             Object localObject4 = this.getDocumentMethod.invoke(paramComponent, this.nullArgs);
/* 1126 */             if ((localObject4 != null) && ((localObject4 instanceof Document))) {
/* 1127 */               ((Document)localObject4).removeDocumentListener(this);
/* 1128 */               ((Document)localObject4).addDocumentListener(this);
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException7) {
/* 1131 */             System.out.println("Exception: " + localInvocationTargetException7.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException7) {
/* 1133 */             System.out.println("Exception: " + localIllegalAccessException7.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException7) {}catch (SecurityException localSecurityException7)
/*      */         {
/* 1138 */           System.out.println("Exception: " + localSecurityException7.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1145 */           this.removeDocumentMethod = paramComponent.getClass().getMethod("removeDocumentListener", this.documentListeners);
/*      */           
/* 1147 */           this.addDocumentMethod = paramComponent.getClass().getMethod("addDocumentListener", this.documentListeners);
/*      */           try
/*      */           {
/* 1150 */             this.removeDocumentMethod.invoke(paramComponent, this.documentArgs);
/* 1151 */             this.addDocumentMethod.invoke(paramComponent, this.documentArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException8) {
/* 1153 */             System.out.println("Exception: " + localInvocationTargetException8.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException8) {
/* 1155 */             System.out.println("Exception: " + localIllegalAccessException8.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException8) {}catch (SecurityException localSecurityException8)
/*      */         {
/* 1160 */           System.out.println("Exception: " + localSecurityException8.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1165 */         if ((paramComponent instanceof JTextComponent)) {
/*      */           try {
/* 1167 */             this.removePropertyChangeMethod = paramComponent.getClass().getMethod("removePropertyChangeListener", this.propertyChangeListeners);
/*      */             
/*      */ 
/* 1170 */             this.addPropertyChangeMethod = paramComponent.getClass().getMethod("addPropertyChangeListener", this.propertyChangeListeners);
/*      */             
/*      */             try
/*      */             {
/* 1174 */               this.removePropertyChangeMethod.invoke(paramComponent, this.propertyChangeArgs);
/*      */               
/* 1176 */               this.addPropertyChangeMethod.invoke(paramComponent, this.propertyChangeArgs);
/*      */             }
/*      */             catch (InvocationTargetException localInvocationTargetException9) {
/* 1179 */               System.out.println("Exception: " + localInvocationTargetException9.toString());
/*      */             } catch (IllegalAccessException localIllegalAccessException9) {
/* 1181 */               System.out.println("Exception: " + localIllegalAccessException9.toString());
/*      */             }
/*      */           }
/*      */           catch (NoSuchMethodException localNoSuchMethodException9) {}catch (SecurityException localSecurityException9)
/*      */           {
/* 1186 */             System.out.println("Exception: " + localSecurityException9.toString());
/*      */           }
/*      */         }
/*      */         break;
/*      */       case 18: 
/*      */       case 22: 
/*      */       case 24: 
/*      */         try
/*      */         {
/* 1195 */           this.getModelMethod = paramComponent.getClass().getMethod("getModel", this.nullClass);
/*      */           try
/*      */           {
/* 1198 */             Object localObject5 = this.getModelMethod.invoke(paramComponent, this.nullArgs);
/* 1199 */             if (localObject5 != null) {
/* 1200 */               if ((paramInt == 18) && ((localObject5 instanceof ListModel)))
/*      */               {
/* 1202 */                 ((ListModel)localObject5).removeListDataListener(this);
/* 1203 */                 ((ListModel)localObject5).addListDataListener(this);
/* 1204 */               } else if ((paramInt == 22) && ((localObject5 instanceof TableModel)))
/*      */               {
/* 1206 */                 ((TableModel)localObject5).removeTableModelListener(this);
/* 1207 */                 ((TableModel)localObject5).addTableModelListener(this);
/* 1208 */               } else if ((localObject5 instanceof TreeModel))
/*      */               {
/* 1210 */                 ((TreeModel)localObject5).removeTreeModelListener(this);
/* 1211 */                 ((TreeModel)localObject5).addTreeModelListener(this);
/*      */               }
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException10) {
/* 1215 */             System.out.println("Exception: " + localInvocationTargetException10.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException10) {
/* 1217 */             System.out.println("Exception: " + localIllegalAccessException10.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException10) {}catch (SecurityException localSecurityException10)
/*      */         {
/* 1222 */           System.out.println("Exception: " + localSecurityException10.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 19: 
/*      */         try
/*      */         {
/* 1231 */           this.removeListSelectionMethod = paramComponent.getClass().getMethod("removeListSelectionListener", this.listSelectionListeners);
/*      */           
/* 1233 */           this.addListSelectionMethod = paramComponent.getClass().getMethod("addListSelectionListener", this.listSelectionListeners);
/*      */           try
/*      */           {
/* 1236 */             this.removeListSelectionMethod.invoke(paramComponent, this.listSelectionArgs);
/* 1237 */             this.addListSelectionMethod.invoke(paramComponent, this.listSelectionArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException11) {
/* 1239 */             System.out.println("Exception: " + localInvocationTargetException11.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException11) {
/* 1241 */             System.out.println("Exception: " + localIllegalAccessException11.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException11) {}catch (SecurityException localSecurityException11)
/*      */         {
/* 1246 */           System.out.println("Exception: " + localSecurityException11.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1253 */           this.getSelectionModelMethod = paramComponent.getClass().getMethod("getSelectionModel", this.nullClass);
/*      */           try
/*      */           {
/* 1256 */             Object localObject6 = this.getSelectionModelMethod.invoke(paramComponent, this.nullArgs);
/* 1257 */             if ((localObject6 != null) && ((localObject6 instanceof ListSelectionModel))) {
/* 1258 */               ((ListSelectionModel)localObject6).removeListSelectionListener(this);
/* 1259 */               ((ListSelectionModel)localObject6).addListSelectionListener(this);
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException12) {
/* 1262 */             System.out.println("Exception: " + localInvocationTargetException12.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException12) {
/* 1264 */             System.out.println("Exception: " + localIllegalAccessException12.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException12) {}catch (SecurityException localSecurityException12)
/*      */         {
/* 1269 */           System.out.println("Exception: " + localSecurityException12.toString());
/*      */         }
/*      */       
/*      */       case 20: 
/*      */         try
/*      */         {
/* 1275 */           this.removeMenuMethod = paramComponent.getClass().getMethod("removeMenuListener", this.menuListeners);
/*      */           
/* 1277 */           this.addMenuMethod = paramComponent.getClass().getMethod("addMenuListener", this.menuListeners);
/*      */           try
/*      */           {
/* 1280 */             this.removeMenuMethod.invoke(paramComponent, this.menuArgs);
/* 1281 */             this.addMenuMethod.invoke(paramComponent, this.menuArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException13) {
/* 1283 */             System.out.println("Exception: " + localInvocationTargetException13.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException13) {
/* 1285 */             System.out.println("Exception: " + localIllegalAccessException13.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException13) {}catch (SecurityException localSecurityException13)
/*      */         {
/* 1290 */           System.out.println("Exception: " + localSecurityException13.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 21: 
/*      */         try
/*      */         {
/* 1299 */           this.removePopupMenuMethod = paramComponent.getClass().getMethod("removePopupMenuListener", this.popupMenuListeners);
/*      */           
/* 1301 */           this.addPopupMenuMethod = paramComponent.getClass().getMethod("addPopupMenuListener", this.popupMenuListeners);
/*      */           try
/*      */           {
/* 1304 */             this.removePopupMenuMethod.invoke(paramComponent, this.popupMenuArgs);
/* 1305 */             this.addPopupMenuMethod.invoke(paramComponent, this.popupMenuArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException14) {
/* 1307 */             System.out.println("Exception: " + localInvocationTargetException14.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException14) {
/* 1309 */             System.out.println("Exception: " + localIllegalAccessException14.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException14) {}catch (SecurityException localSecurityException14)
/*      */         {
/* 1314 */           System.out.println("Exception: " + localSecurityException14.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1321 */           this.getPopupMenuMethod = paramComponent.getClass().getMethod("getPopupMenu", this.nullClass);
/*      */           try
/*      */           {
/* 1324 */             Object localObject7 = this.getPopupMenuMethod.invoke(paramComponent, this.nullArgs);
/* 1325 */             if (localObject7 != null) {
/* 1326 */               this.removePopupMenuMethod = localObject7.getClass().getMethod("removePopupMenuListener", this.popupMenuListeners);
/*      */               
/* 1328 */               this.addPopupMenuMethod = localObject7.getClass().getMethod("addPopupMenuListener", this.popupMenuListeners);
/*      */               
/* 1330 */               this.removePopupMenuMethod.invoke(localObject7, this.popupMenuArgs);
/* 1331 */               this.addPopupMenuMethod.invoke(localObject7, this.popupMenuArgs);
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException15) {
/* 1334 */             System.out.println("Exception: " + localInvocationTargetException15.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException15) {
/* 1336 */             System.out.println("Exception: " + localIllegalAccessException15.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException15) {}catch (SecurityException localSecurityException15)
/*      */         {
/* 1341 */           System.out.println("Exception: " + localSecurityException15.toString());
/*      */         }
/*      */       
/*      */       case 23: 
/*      */         try
/*      */         {
/* 1347 */           this.removeTreeExpansionMethod = paramComponent.getClass().getMethod("removeTreeExpansionListener", this.treeExpansionListeners);
/*      */           
/* 1349 */           this.addTreeExpansionMethod = paramComponent.getClass().getMethod("addTreeExpansionListener", this.treeExpansionListeners);
/*      */           try
/*      */           {
/* 1352 */             this.removeTreeExpansionMethod.invoke(paramComponent, this.treeExpansionArgs);
/* 1353 */             this.addTreeExpansionMethod.invoke(paramComponent, this.treeExpansionArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException16) {
/* 1355 */             System.out.println("Exception: " + localInvocationTargetException16.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException16) {
/* 1357 */             System.out.println("Exception: " + localIllegalAccessException16.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException16) {}catch (SecurityException localSecurityException16)
/*      */         {
/* 1362 */           System.out.println("Exception: " + localSecurityException16.toString());
/*      */         }
/*      */       
/*      */       case 25: 
/*      */         try
/*      */         {
/* 1368 */           this.removeTreeSelectionMethod = paramComponent.getClass().getMethod("removeTreeSelectionListener", this.treeSelectionListeners);
/*      */           
/* 1370 */           this.addTreeSelectionMethod = paramComponent.getClass().getMethod("addTreeSelectionListener", this.treeSelectionListeners);
/*      */           try
/*      */           {
/* 1373 */             this.removeTreeSelectionMethod.invoke(paramComponent, this.treeSelectionArgs);
/* 1374 */             this.addTreeSelectionMethod.invoke(paramComponent, this.treeSelectionArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException17) {
/* 1376 */             System.out.println("Exception: " + localInvocationTargetException17.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException17) {
/* 1378 */             System.out.println("Exception: " + localIllegalAccessException17.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException17) {}catch (SecurityException localSecurityException17)
/*      */         {
/* 1383 */           System.out.println("Exception: " + localSecurityException17.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 26: 
/*      */         try
/*      */         {
/* 1392 */           this.getDocumentMethod = paramComponent.getClass().getMethod("getDocument", this.nullClass);
/*      */           try
/*      */           {
/* 1395 */             Object localObject8 = this.getDocumentMethod.invoke(paramComponent, this.nullArgs);
/* 1396 */             if ((localObject8 != null) && ((localObject8 instanceof Document))) {
/* 1397 */               ((Document)localObject8).removeUndoableEditListener(this);
/* 1398 */               ((Document)localObject8).addUndoableEditListener(this);
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException18) {
/* 1401 */             System.out.println("Exception: " + localInvocationTargetException18.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException18) {
/* 1403 */             System.out.println("Exception: " + localIllegalAccessException18.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException18) {}catch (SecurityException localSecurityException18)
/*      */         {
/* 1408 */           System.out.println("Exception: " + localSecurityException18.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1415 */           this.removeUndoableEditMethod = paramComponent.getClass().getMethod("removeUndoableEditListener", this.undoableEditListeners);
/*      */           
/* 1417 */           this.addUndoableEditMethod = paramComponent.getClass().getMethod("addUndoableEditListener", this.undoableEditListeners);
/*      */           try
/*      */           {
/* 1420 */             this.removeUndoableEditMethod.invoke(paramComponent, this.undoableEditArgs);
/* 1421 */             this.addUndoableEditMethod.invoke(paramComponent, this.undoableEditArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException19) {
/* 1423 */             System.out.println("Exception: " + localInvocationTargetException19.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException19) {
/* 1425 */             System.out.println("Exception: " + localIllegalAccessException19.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException19) {}catch (SecurityException localSecurityException19)
/*      */         {
/* 1430 */           System.out.println("Exception: " + localSecurityException19.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 29: 
/*      */         try
/*      */         {
/* 1439 */           this.removeInternalFrameMethod = paramComponent.getClass().getMethod("removeInternalFrameListener", this.internalFrameListeners);
/*      */           
/* 1441 */           this.addInternalFrameMethod = paramComponent.getClass().getMethod("addInternalFrameListener", this.internalFrameListeners);
/*      */           try
/*      */           {
/* 1444 */             this.removeInternalFrameMethod.invoke(paramComponent, this.internalFrameArgs);
/* 1445 */             this.addInternalFrameMethod.invoke(paramComponent, this.internalFrameArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException20) {
/* 1447 */             System.out.println("Exception: " + localInvocationTargetException20.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException20) {
/* 1449 */             System.out.println("Exception: " + localIllegalAccessException20.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException20) {}catch (SecurityException localSecurityException20)
/*      */         {
/* 1454 */           System.out.println("Exception: " + localSecurityException20.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 27: 
/*      */         try
/*      */         {
/* 1463 */           this.removePropertyChangeMethod = paramComponent.getClass().getMethod("removePropertyChangeListener", this.propertyChangeListeners);
/*      */           
/* 1465 */           this.addPropertyChangeMethod = paramComponent.getClass().getMethod("addPropertyChangeListener", this.propertyChangeListeners);
/*      */           try
/*      */           {
/* 1468 */             this.removePropertyChangeMethod.invoke(paramComponent, this.propertyChangeArgs);
/* 1469 */             this.addPropertyChangeMethod.invoke(paramComponent, this.propertyChangeArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException21) {
/* 1471 */             System.out.println("Exception: " + localInvocationTargetException21.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException21) {
/* 1473 */             System.out.println("Exception: " + localIllegalAccessException21.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException21) {}catch (SecurityException localSecurityException21)
/*      */         {
/* 1478 */           System.out.println("Exception: " + localSecurityException21.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1485 */           this.getSelectionModelMethod = paramComponent.getClass().getMethod("getSelectionModel", this.nullClass);
/*      */           try
/*      */           {
/* 1488 */             Object localObject9 = this.getSelectionModelMethod.invoke(paramComponent, this.nullArgs);
/* 1489 */             if ((localObject9 != null) && ((localObject9 instanceof TreeSelectionModel))) {
/* 1490 */               ((TreeSelectionModel)localObject9).removePropertyChangeListener(this);
/* 1491 */               ((TreeSelectionModel)localObject9).addPropertyChangeListener(this);
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException22) {
/* 1494 */             System.out.println("Exception: " + localInvocationTargetException22.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException22) {
/* 1496 */             System.out.println("Exception: " + localIllegalAccessException22.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException22) {}catch (SecurityException localSecurityException22)
/*      */         {
/* 1501 */           System.out.println("Exception: " + localSecurityException22.toString());
/*      */         }
/*      */       
/*      */ 
/*      */       case 28: 
/* 1506 */         if ((paramComponent instanceof JComponent)) {
/* 1507 */           ((JComponent)paramComponent).removeVetoableChangeListener(this);
/* 1508 */           ((JComponent)paramComponent).addVetoableChangeListener(this);
/*      */         }
/*      */         break;
/*      */       case 4: case 5: 
/*      */       case 6: case 7: 
/*      */       case 8: case 9: 
/*      */       case 10: case 11: 
/*      */       default: 
/* 1516 */         return;
/*      */       }
/*      */       
/* 1519 */       if ((paramComponent instanceof Container)) {
/* 1520 */         int i = ((Container)paramComponent).getComponentCount();
/* 1521 */         for (int j = 0; j < i; j++) {
/* 1522 */           installListeners(((Container)paramComponent).getComponent(j), paramInt);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void removeListeners(Component paramComponent)
/*      */     {
/* 1535 */       if (SwingEventMonitor.listenerList.getListenerCount(AncestorListener.class) > 0) {
/* 1536 */         removeListeners(paramComponent, 12);
/*      */       }
/* 1538 */       if (SwingEventMonitor.listenerList.getListenerCount(CaretListener.class) > 0) {
/* 1539 */         removeListeners(paramComponent, 13);
/*      */       }
/* 1541 */       if (SwingEventMonitor.listenerList.getListenerCount(CellEditorListener.class) > 0) {
/* 1542 */         removeListeners(paramComponent, 14);
/*      */       }
/* 1544 */       if (SwingEventMonitor.listenerList.getListenerCount(ChangeListener.class) > 0) {
/* 1545 */         removeListeners(paramComponent, 15);
/*      */       }
/* 1547 */       if (SwingEventMonitor.listenerList.getListenerCount(TableColumnModelListener.class) > 0) {
/* 1548 */         removeListeners(paramComponent, 16);
/*      */       }
/* 1550 */       if (SwingEventMonitor.listenerList.getListenerCount(DocumentListener.class) > 0) {
/* 1551 */         removeListeners(paramComponent, 17);
/*      */       }
/* 1553 */       if (SwingEventMonitor.listenerList.getListenerCount(ListDataListener.class) > 0) {
/* 1554 */         removeListeners(paramComponent, 18);
/*      */       }
/* 1556 */       if (SwingEventMonitor.listenerList.getListenerCount(ListSelectionListener.class) > 0) {
/* 1557 */         removeListeners(paramComponent, 19);
/*      */       }
/* 1559 */       if (SwingEventMonitor.listenerList.getListenerCount(MenuListener.class) > 0) {
/* 1560 */         removeListeners(paramComponent, 20);
/*      */       }
/* 1562 */       if (SwingEventMonitor.listenerList.getListenerCount(PopupMenuListener.class) > 0) {
/* 1563 */         removeListeners(paramComponent, 21);
/*      */       }
/* 1565 */       if (SwingEventMonitor.listenerList.getListenerCount(TableModelListener.class) > 0) {
/* 1566 */         removeListeners(paramComponent, 22);
/*      */       }
/* 1568 */       if (SwingEventMonitor.listenerList.getListenerCount(TreeExpansionListener.class) > 0) {
/* 1569 */         removeListeners(paramComponent, 23);
/*      */       }
/* 1571 */       if (SwingEventMonitor.listenerList.getListenerCount(TreeModelListener.class) > 0) {
/* 1572 */         removeListeners(paramComponent, 24);
/*      */       }
/* 1574 */       if (SwingEventMonitor.listenerList.getListenerCount(TreeSelectionListener.class) > 0) {
/* 1575 */         removeListeners(paramComponent, 25);
/*      */       }
/* 1577 */       if (SwingEventMonitor.listenerList.getListenerCount(UndoableEditListener.class) > 0) {
/* 1578 */         removeListeners(paramComponent, 26);
/*      */       }
/* 1580 */       if (SwingEventMonitor.listenerList.getListenerCount(InternalFrameListener.class) > 0) {
/* 1581 */         removeListeners(paramComponent, 29);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1586 */       if (SwingEventMonitor.listenerList.getListenerCount(PropertyChangeListener.class) > 0) {
/* 1587 */         removeListeners(paramComponent, 27);
/*      */       }
/* 1589 */       if (SwingEventMonitor.listenerList.getListenerCount(VetoableChangeListener.class) > 0) {
/* 1590 */         removeListeners(paramComponent, 28);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1595 */       super.removeListeners(paramComponent);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void removeListeners(Component paramComponent, int paramInt)
/*      */     {
/* 1607 */       switch (paramInt)
/*      */       {
/*      */       case 3: 
/*      */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       case 12: 
/* 1615 */         if ((paramComponent instanceof JComponent)) {
/* 1616 */           ((JComponent)paramComponent).removeAncestorListener(this);
/*      */         }
/*      */         break;
/*      */       case 13: 
/*      */         try
/*      */         {
/* 1622 */           this.removeCaretMethod = paramComponent.getClass().getMethod("removeCaretListener", this.caretListeners);
/*      */           try
/*      */           {
/* 1625 */             this.removeCaretMethod.invoke(paramComponent, this.caretArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException1) {
/* 1627 */             System.out.println("Exception: " + localInvocationTargetException1.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException1) {
/* 1629 */             System.out.println("Exception: " + localIllegalAccessException1.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException1) {}catch (SecurityException localSecurityException1)
/*      */         {
/* 1634 */           System.out.println("Exception: " + localSecurityException1.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 14: 
/*      */         try
/*      */         {
/* 1643 */           this.getCellEditorMethod = paramComponent.getClass().getMethod("getCellEditorMethod", this.nullClass);
/*      */           try
/*      */           {
/* 1646 */             Object localObject1 = this.getCellEditorMethod.invoke(paramComponent, this.nullArgs);
/* 1647 */             if ((localObject1 != null) && ((localObject1 instanceof CellEditor))) {
/* 1648 */               ((CellEditor)localObject1).removeCellEditorListener(this);
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException2) {
/* 1651 */             System.out.println("Exception: " + localInvocationTargetException2.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException2) {
/* 1653 */             System.out.println("Exception: " + localIllegalAccessException2.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException2) {}catch (SecurityException localSecurityException2)
/*      */         {
/* 1658 */           System.out.println("Exception: " + localSecurityException2.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1665 */           this.removeCellEditorMethod = paramComponent.getClass().getMethod("removeCellEditorListener", this.cellEditorListeners);
/*      */           try
/*      */           {
/* 1668 */             this.removeCellEditorMethod.invoke(paramComponent, this.cellEditorArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException3) {
/* 1670 */             System.out.println("Exception: " + localInvocationTargetException3.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException3) {
/* 1672 */             System.out.println("Exception: " + localIllegalAccessException3.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException3) {}catch (SecurityException localSecurityException3)
/*      */         {
/* 1677 */           System.out.println("Exception: " + localSecurityException3.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case 15: 
/*      */         try
/*      */         {
/* 1689 */           this.removeChangeMethod = paramComponent.getClass().getMethod("removeChangeListener", this.changeListeners);
/*      */           try
/*      */           {
/* 1692 */             this.removeChangeMethod.invoke(paramComponent, this.changeArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException4) {
/* 1694 */             System.out.println("Exception: " + localInvocationTargetException4.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException4) {
/* 1696 */             System.out.println("Exception: " + localIllegalAccessException4.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException4) {}catch (SecurityException localSecurityException4)
/*      */         {
/* 1701 */           System.out.println("Exception: " + localSecurityException4.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1709 */           this.getModelMethod = paramComponent.getClass().getMethod("getModel", this.nullClass);
/*      */           try
/*      */           {
/* 1712 */             Object localObject2 = this.getModelMethod.invoke(paramComponent, this.nullArgs);
/* 1713 */             if (localObject2 != null) {
/* 1714 */               this.removeChangeMethod = localObject2.getClass().getMethod("removeChangeListener", this.changeListeners);
/*      */               
/* 1716 */               this.removeChangeMethod.invoke(localObject2, this.changeArgs);
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException5) {
/* 1719 */             System.out.println("Exception: " + localInvocationTargetException5.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException5) {
/* 1721 */             System.out.println("Exception: " + localIllegalAccessException5.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException5) {}catch (SecurityException localSecurityException5)
/*      */         {
/* 1726 */           System.out.println("Exception: " + localSecurityException5.toString());
/*      */         }
/*      */       
/*      */       case 16: 
/*      */         try
/*      */         {
/* 1732 */           this.getColumnModelMethod = paramComponent.getClass().getMethod("getTableColumnModel", this.nullClass);
/*      */           try
/*      */           {
/* 1735 */             Object localObject3 = this.getColumnModelMethod.invoke(paramComponent, this.nullArgs);
/* 1736 */             if ((localObject3 != null) && ((localObject3 instanceof TableColumnModel))) {
/* 1737 */               ((TableColumnModel)localObject3).removeColumnModelListener(this);
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException6) {
/* 1740 */             System.out.println("Exception: " + localInvocationTargetException6.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException6) {
/* 1742 */             System.out.println("Exception: " + localIllegalAccessException6.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException6) {}catch (SecurityException localSecurityException6)
/*      */         {
/* 1747 */           System.out.println("Exception: " + localSecurityException6.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 17: 
/*      */         try
/*      */         {
/* 1756 */           this.getDocumentMethod = paramComponent.getClass().getMethod("getDocument", this.nullClass);
/*      */           try
/*      */           {
/* 1759 */             Object localObject4 = this.getDocumentMethod.invoke(paramComponent, this.nullArgs);
/* 1760 */             if ((localObject4 != null) && ((localObject4 instanceof Document))) {
/* 1761 */               ((Document)localObject4).removeDocumentListener(this);
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException7) {
/* 1764 */             System.out.println("Exception: " + localInvocationTargetException7.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException7) {
/* 1766 */             System.out.println("Exception: " + localIllegalAccessException7.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException7) {}catch (SecurityException localSecurityException7)
/*      */         {
/* 1771 */           System.out.println("Exception: " + localSecurityException7.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1778 */           this.removeDocumentMethod = paramComponent.getClass().getMethod("removeDocumentListener", this.documentListeners);
/*      */           try
/*      */           {
/* 1781 */             this.removeDocumentMethod.invoke(paramComponent, this.documentArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException8) {
/* 1783 */             System.out.println("Exception: " + localInvocationTargetException8.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException8) {
/* 1785 */             System.out.println("Exception: " + localIllegalAccessException8.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException8) {}catch (SecurityException localSecurityException8)
/*      */         {
/* 1790 */           System.out.println("Exception: " + localSecurityException8.toString());
/*      */         }
/*      */       
/*      */       case 18: 
/*      */       case 22: 
/*      */       case 24: 
/*      */         try
/*      */         {
/* 1798 */           this.getModelMethod = paramComponent.getClass().getMethod("getModel", this.nullClass);
/*      */           try
/*      */           {
/* 1801 */             Object localObject5 = this.getModelMethod.invoke(paramComponent, this.nullArgs);
/* 1802 */             if (localObject5 != null) {
/* 1803 */               if ((paramInt == 18) && ((localObject5 instanceof ListModel)))
/*      */               {
/* 1805 */                 ((ListModel)localObject5).removeListDataListener(this);
/* 1806 */               } else if ((paramInt == 22) && ((localObject5 instanceof TableModel)))
/*      */               {
/* 1808 */                 ((TableModel)localObject5).removeTableModelListener(this);
/* 1809 */               } else if ((localObject5 instanceof TreeModel))
/*      */               {
/* 1811 */                 ((TreeModel)localObject5).removeTreeModelListener(this);
/*      */               }
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException9) {
/* 1815 */             System.out.println("Exception: " + localInvocationTargetException9.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException9) {
/* 1817 */             System.out.println("Exception: " + localIllegalAccessException9.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException9) {}catch (SecurityException localSecurityException9)
/*      */         {
/* 1822 */           System.out.println("Exception: " + localSecurityException9.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 19: 
/*      */         try
/*      */         {
/* 1831 */           this.removeListSelectionMethod = paramComponent.getClass().getMethod("removeListSelectionListener", this.listSelectionListeners);
/*      */           try
/*      */           {
/* 1834 */             this.removeListSelectionMethod.invoke(paramComponent, this.listSelectionArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException10) {
/* 1836 */             System.out.println("Exception: " + localInvocationTargetException10.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException10) {
/* 1838 */             System.out.println("Exception: " + localIllegalAccessException10.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException10) {}catch (SecurityException localSecurityException10)
/*      */         {
/* 1843 */           System.out.println("Exception: " + localSecurityException10.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1850 */           this.getSelectionModelMethod = paramComponent.getClass().getMethod("getSelectionModel", this.nullClass);
/*      */           try
/*      */           {
/* 1853 */             Object localObject6 = this.getSelectionModelMethod.invoke(paramComponent, this.nullArgs);
/* 1854 */             if ((localObject6 != null) && ((localObject6 instanceof ListSelectionModel))) {
/* 1855 */               ((ListSelectionModel)localObject6).removeListSelectionListener(this);
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException11) {
/* 1858 */             System.out.println("Exception: " + localInvocationTargetException11.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException11) {
/* 1860 */             System.out.println("Exception: " + localIllegalAccessException11.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException11) {}catch (SecurityException localSecurityException11)
/*      */         {
/* 1865 */           System.out.println("Exception: " + localSecurityException11.toString());
/*      */         }
/*      */       
/*      */       case 20: 
/*      */         try
/*      */         {
/* 1871 */           this.removeMenuMethod = paramComponent.getClass().getMethod("removeMenuListener", this.menuListeners);
/*      */           try
/*      */           {
/* 1874 */             this.removeMenuMethod.invoke(paramComponent, this.menuArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException12) {
/* 1876 */             System.out.println("Exception: " + localInvocationTargetException12.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException12) {
/* 1878 */             System.out.println("Exception: " + localIllegalAccessException12.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException12) {}catch (SecurityException localSecurityException12)
/*      */         {
/* 1883 */           System.out.println("Exception: " + localSecurityException12.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 21: 
/*      */         try
/*      */         {
/* 1892 */           this.removePopupMenuMethod = paramComponent.getClass().getMethod("removePopupMenuListener", this.popupMenuListeners);
/*      */           try
/*      */           {
/* 1895 */             this.removePopupMenuMethod.invoke(paramComponent, this.popupMenuArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException13) {
/* 1897 */             System.out.println("Exception: " + localInvocationTargetException13.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException13) {
/* 1899 */             System.out.println("Exception: " + localIllegalAccessException13.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException13) {}catch (SecurityException localSecurityException13)
/*      */         {
/* 1904 */           System.out.println("Exception: " + localSecurityException13.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1911 */           this.getPopupMenuMethod = paramComponent.getClass().getMethod("getPopupMenu", this.nullClass);
/*      */           try
/*      */           {
/* 1914 */             Object localObject7 = this.getPopupMenuMethod.invoke(paramComponent, this.nullArgs);
/* 1915 */             if (localObject7 != null) {
/* 1916 */               this.removePopupMenuMethod = localObject7.getClass().getMethod("removePopupMenuListener", this.popupMenuListeners);
/*      */               
/* 1918 */               this.removePopupMenuMethod.invoke(localObject7, this.popupMenuArgs);
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException14) {
/* 1921 */             System.out.println("Exception: " + localInvocationTargetException14.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException14) {
/* 1923 */             System.out.println("Exception: " + localIllegalAccessException14.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException14) {}catch (SecurityException localSecurityException14)
/*      */         {
/* 1928 */           System.out.println("Exception: " + localSecurityException14.toString());
/*      */         }
/*      */       
/*      */       case 23: 
/*      */         try
/*      */         {
/* 1934 */           this.removeTreeExpansionMethod = paramComponent.getClass().getMethod("removeTreeExpansionListener", this.treeExpansionListeners);
/*      */           try
/*      */           {
/* 1937 */             this.removeTreeExpansionMethod.invoke(paramComponent, this.treeExpansionArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException15) {
/* 1939 */             System.out.println("Exception: " + localInvocationTargetException15.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException15) {
/* 1941 */             System.out.println("Exception: " + localIllegalAccessException15.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException15) {}catch (SecurityException localSecurityException15)
/*      */         {
/* 1946 */           System.out.println("Exception: " + localSecurityException15.toString());
/*      */         }
/*      */       
/*      */       case 25: 
/*      */         try
/*      */         {
/* 1952 */           this.removeTreeSelectionMethod = paramComponent.getClass().getMethod("removeTreeSelectionListener", this.treeSelectionListeners);
/*      */           try
/*      */           {
/* 1955 */             this.removeTreeSelectionMethod.invoke(paramComponent, this.treeSelectionArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException16) {
/* 1957 */             System.out.println("Exception: " + localInvocationTargetException16.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException16) {
/* 1959 */             System.out.println("Exception: " + localIllegalAccessException16.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException16) {}catch (SecurityException localSecurityException16)
/*      */         {
/* 1964 */           System.out.println("Exception: " + localSecurityException16.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 26: 
/*      */         try
/*      */         {
/* 1973 */           this.getDocumentMethod = paramComponent.getClass().getMethod("getDocument", this.nullClass);
/*      */           try
/*      */           {
/* 1976 */             Object localObject8 = this.getDocumentMethod.invoke(paramComponent, this.nullArgs);
/* 1977 */             if ((localObject8 != null) && ((localObject8 instanceof Document))) {
/* 1978 */               ((Document)localObject8).removeUndoableEditListener(this);
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException17) {
/* 1981 */             System.out.println("Exception: " + localInvocationTargetException17.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException17) {
/* 1983 */             System.out.println("Exception: " + localIllegalAccessException17.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException17) {}catch (SecurityException localSecurityException17)
/*      */         {
/* 1988 */           System.out.println("Exception: " + localSecurityException17.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1995 */           this.removeUndoableEditMethod = paramComponent.getClass().getMethod("removeUndoableEditListener", this.undoableEditListeners);
/*      */           try
/*      */           {
/* 1998 */             this.removeUndoableEditMethod.invoke(paramComponent, this.undoableEditArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException18) {
/* 2000 */             System.out.println("Exception: " + localInvocationTargetException18.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException18) {
/* 2002 */             System.out.println("Exception: " + localIllegalAccessException18.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException18) {}catch (SecurityException localSecurityException18)
/*      */         {
/* 2007 */           System.out.println("Exception: " + localSecurityException18.toString());
/*      */         }
/*      */       
/*      */       case 29: 
/*      */         try
/*      */         {
/* 2013 */           this.removeInternalFrameMethod = paramComponent.getClass().getMethod("removeInternalFrameListener", this.internalFrameListeners);
/*      */           try
/*      */           {
/* 2016 */             this.removeInternalFrameMethod.invoke(paramComponent, this.internalFrameArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException19) {
/* 2018 */             System.out.println("Exception: " + localInvocationTargetException19.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException19) {
/* 2020 */             System.out.println("Exception: " + localIllegalAccessException19.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException19) {}catch (SecurityException localSecurityException19)
/*      */         {
/* 2025 */           System.out.println("Exception: " + localSecurityException19.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 27: 
/*      */         try
/*      */         {
/* 2034 */           this.removePropertyChangeMethod = paramComponent.getClass().getMethod("removePropertyChangeListener", this.propertyChangeListeners);
/*      */           try
/*      */           {
/* 2037 */             this.removePropertyChangeMethod.invoke(paramComponent, this.propertyChangeArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException20) {
/* 2039 */             System.out.println("Exception: " + localInvocationTargetException20.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException20) {
/* 2041 */             System.out.println("Exception: " + localIllegalAccessException20.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException20) {}catch (SecurityException localSecurityException20)
/*      */         {
/* 2046 */           System.out.println("Exception: " + localSecurityException20.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 2053 */           this.getSelectionModelMethod = paramComponent.getClass().getMethod("getSelectionModel", this.nullClass);
/*      */           try
/*      */           {
/* 2056 */             Object localObject9 = this.getSelectionModelMethod.invoke(paramComponent, this.nullArgs);
/* 2057 */             if ((localObject9 != null) && ((localObject9 instanceof TreeSelectionModel))) {
/* 2058 */               ((TreeSelectionModel)localObject9).removePropertyChangeListener(this);
/*      */             }
/*      */           } catch (InvocationTargetException localInvocationTargetException21) {
/* 2061 */             System.out.println("Exception: " + localInvocationTargetException21.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException21) {
/* 2063 */             System.out.println("Exception: " + localIllegalAccessException21.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException21) {}catch (SecurityException localSecurityException21)
/*      */         {
/* 2068 */           System.out.println("Exception: " + localSecurityException21.toString());
/*      */         }
/*      */       
/*      */ 
/*      */       case 28: 
/* 2073 */         if ((paramComponent instanceof JComponent)) {
/* 2074 */           ((JComponent)paramComponent).removeVetoableChangeListener(this);
/*      */         }
/*      */         break;
/*      */       case 4: case 5: case 6: case 7: case 8: 
/*      */       case 9: case 10: case 11: default: 
/* 2079 */         return;
/*      */       }
/*      */       
/* 2082 */       if ((paramComponent instanceof Container)) {
/* 2083 */         int i = ((Container)paramComponent).getComponentCount();
/* 2084 */         for (int j = 0; j < i; j++) {
/* 2085 */           removeListeners(((Container)paramComponent).getComponent(j), paramInt);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void componentAdded(ContainerEvent paramContainerEvent)
/*      */     {
/* 2099 */       installListeners(paramContainerEvent.getChild());
/*      */     }
/*      */     
/* 2102 */     public void componentRemoved(ContainerEvent paramContainerEvent) { removeListeners(paramContainerEvent.getChild()); }
/*      */     
/*      */ 
/*      */ 
/*      */     public void ancestorAdded(AncestorEvent paramAncestorEvent)
/*      */     {
/* 2108 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2109 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2110 */         if (arrayOfObject[i] == AncestorListener.class) {
/* 2111 */           ((AncestorListener)arrayOfObject[(i + 1)]).ancestorAdded(paramAncestorEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void ancestorRemoved(AncestorEvent paramAncestorEvent) {
/* 2117 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2118 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2119 */         if (arrayOfObject[i] == AncestorListener.class) {
/* 2120 */           ((AncestorListener)arrayOfObject[(i + 1)]).ancestorRemoved(paramAncestorEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void ancestorMoved(AncestorEvent paramAncestorEvent) {
/* 2126 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2127 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2128 */         if (arrayOfObject[i] == AncestorListener.class) {
/* 2129 */           ((AncestorListener)arrayOfObject[(i + 1)]).ancestorMoved(paramAncestorEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void caretUpdate(CaretEvent paramCaretEvent)
/*      */     {
/* 2137 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2138 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2139 */         if (arrayOfObject[i] == CaretListener.class) {
/* 2140 */           ((CaretListener)arrayOfObject[(i + 1)]).caretUpdate(paramCaretEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void editingStopped(ChangeEvent paramChangeEvent)
/*      */     {
/* 2148 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2149 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2150 */         if (arrayOfObject[i] == CellEditorListener.class) {
/* 2151 */           ((CellEditorListener)arrayOfObject[(i + 1)]).editingStopped(paramChangeEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void editingCanceled(ChangeEvent paramChangeEvent) {
/* 2157 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2158 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2159 */         if (arrayOfObject[i] == CellEditorListener.class) {
/* 2160 */           ((CellEditorListener)arrayOfObject[(i + 1)]).editingCanceled(paramChangeEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void stateChanged(ChangeEvent paramChangeEvent)
/*      */     {
/* 2168 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2169 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2170 */         if (arrayOfObject[i] == ChangeListener.class) {
/* 2171 */           ((ChangeListener)arrayOfObject[(i + 1)]).stateChanged(paramChangeEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void columnAdded(TableColumnModelEvent paramTableColumnModelEvent)
/*      */     {
/* 2179 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2180 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2181 */         if (arrayOfObject[i] == TableColumnModelListener.class)
/* 2182 */           ((TableColumnModelListener)arrayOfObject[(i + 1)]).columnAdded(paramTableColumnModelEvent);
/*      */       }
/*      */     }
/*      */     
/*      */     public void columnMarginChanged(ChangeEvent paramChangeEvent) {
/* 2187 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2188 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2189 */         if (arrayOfObject[i] == TableColumnModelListener.class)
/* 2190 */           ((TableColumnModelListener)arrayOfObject[(i + 1)]).columnMarginChanged(paramChangeEvent);
/*      */       }
/*      */     }
/*      */     
/*      */     public void columnMoved(TableColumnModelEvent paramTableColumnModelEvent) {
/* 2195 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2196 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2197 */         if (arrayOfObject[i] == TableColumnModelListener.class)
/* 2198 */           ((TableColumnModelListener)arrayOfObject[(i + 1)]).columnMoved(paramTableColumnModelEvent);
/*      */       }
/*      */     }
/*      */     
/*      */     public void columnRemoved(TableColumnModelEvent paramTableColumnModelEvent) {
/* 2203 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2204 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2205 */         if (arrayOfObject[i] == TableColumnModelListener.class)
/* 2206 */           ((TableColumnModelListener)arrayOfObject[(i + 1)]).columnRemoved(paramTableColumnModelEvent);
/*      */       }
/*      */     }
/*      */     
/*      */     public void columnSelectionChanged(ListSelectionEvent paramListSelectionEvent) {
/* 2211 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2212 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2213 */         if (arrayOfObject[i] == TableColumnModelListener.class) {
/* 2214 */           ((TableColumnModelListener)arrayOfObject[(i + 1)]).columnSelectionChanged(paramListSelectionEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void changedUpdate(DocumentEvent paramDocumentEvent)
/*      */     {
/* 2222 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2223 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2224 */         if (arrayOfObject[i] == DocumentListener.class)
/* 2225 */           ((DocumentListener)arrayOfObject[(i + 1)]).changedUpdate(paramDocumentEvent);
/*      */       }
/*      */     }
/*      */     
/*      */     public void insertUpdate(DocumentEvent paramDocumentEvent) {
/* 2230 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2231 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2232 */         if (arrayOfObject[i] == DocumentListener.class)
/* 2233 */           ((DocumentListener)arrayOfObject[(i + 1)]).insertUpdate(paramDocumentEvent);
/*      */       }
/*      */     }
/*      */     
/*      */     public void removeUpdate(DocumentEvent paramDocumentEvent) {
/* 2238 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2239 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2240 */         if (arrayOfObject[i] == DocumentListener.class) {
/* 2241 */           ((DocumentListener)arrayOfObject[(i + 1)]).removeUpdate(paramDocumentEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void contentsChanged(ListDataEvent paramListDataEvent)
/*      */     {
/* 2249 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2250 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2251 */         if (arrayOfObject[i] == ListDataListener.class)
/* 2252 */           ((ListDataListener)arrayOfObject[(i + 1)]).contentsChanged(paramListDataEvent);
/*      */       }
/*      */     }
/*      */     
/*      */     public void intervalAdded(ListDataEvent paramListDataEvent) {
/* 2257 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2258 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2259 */         if (arrayOfObject[i] == ListDataListener.class)
/* 2260 */           ((ListDataListener)arrayOfObject[(i + 1)]).intervalAdded(paramListDataEvent);
/*      */       }
/*      */     }
/*      */     
/*      */     public void intervalRemoved(ListDataEvent paramListDataEvent) {
/* 2265 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2266 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2267 */         if (arrayOfObject[i] == ListDataListener.class) {
/* 2268 */           ((ListDataListener)arrayOfObject[(i + 1)]).intervalRemoved(paramListDataEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void valueChanged(ListSelectionEvent paramListSelectionEvent)
/*      */     {
/* 2276 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2277 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2278 */         if (arrayOfObject[i] == ListSelectionListener.class) {
/* 2279 */           ((ListSelectionListener)arrayOfObject[(i + 1)]).valueChanged(paramListSelectionEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void menuCanceled(MenuEvent paramMenuEvent)
/*      */     {
/* 2287 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2288 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2289 */         if (arrayOfObject[i] == MenuListener.class)
/* 2290 */           ((MenuListener)arrayOfObject[(i + 1)]).menuCanceled(paramMenuEvent);
/*      */       }
/*      */     }
/*      */     
/*      */     public void menuDeselected(MenuEvent paramMenuEvent) {
/* 2295 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2296 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2297 */         if (arrayOfObject[i] == MenuListener.class)
/* 2298 */           ((MenuListener)arrayOfObject[(i + 1)]).menuDeselected(paramMenuEvent);
/*      */       }
/*      */     }
/*      */     
/*      */     public void menuSelected(MenuEvent paramMenuEvent) {
/* 2303 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2304 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2305 */         if (arrayOfObject[i] == MenuListener.class) {
/* 2306 */           ((MenuListener)arrayOfObject[(i + 1)]).menuSelected(paramMenuEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void popupMenuWillBecomeVisible(PopupMenuEvent paramPopupMenuEvent)
/*      */     {
/* 2314 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2315 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2316 */         if (arrayOfObject[i] == PopupMenuListener.class) {
/* 2317 */           ((PopupMenuListener)arrayOfObject[(i + 1)]).popupMenuWillBecomeVisible(paramPopupMenuEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void popupMenuWillBecomeInvisible(PopupMenuEvent paramPopupMenuEvent) {
/* 2323 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2324 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2325 */         if (arrayOfObject[i] == PopupMenuListener.class) {
/* 2326 */           ((PopupMenuListener)arrayOfObject[(i + 1)]).popupMenuWillBecomeInvisible(paramPopupMenuEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void popupMenuCanceled(PopupMenuEvent paramPopupMenuEvent) {
/* 2332 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2333 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2334 */         if (arrayOfObject[i] == PopupMenuListener.class) {
/* 2335 */           ((PopupMenuListener)arrayOfObject[(i + 1)]).popupMenuCanceled(paramPopupMenuEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void tableChanged(TableModelEvent paramTableModelEvent)
/*      */     {
/* 2343 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2344 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2345 */         if (arrayOfObject[i] == TableModelListener.class) {
/* 2346 */           ((TableModelListener)arrayOfObject[(i + 1)]).tableChanged(paramTableModelEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void treeCollapsed(TreeExpansionEvent paramTreeExpansionEvent)
/*      */     {
/* 2354 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2355 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2356 */         if (arrayOfObject[i] == TreeExpansionListener.class)
/* 2357 */           ((TreeExpansionListener)arrayOfObject[(i + 1)]).treeCollapsed(paramTreeExpansionEvent);
/*      */       }
/*      */     }
/*      */     
/*      */     public void treeExpanded(TreeExpansionEvent paramTreeExpansionEvent) {
/* 2362 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2363 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2364 */         if (arrayOfObject[i] == TreeExpansionListener.class) {
/* 2365 */           ((TreeExpansionListener)arrayOfObject[(i + 1)]).treeExpanded(paramTreeExpansionEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void treeNodesChanged(TreeModelEvent paramTreeModelEvent)
/*      */     {
/* 2373 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2374 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2375 */         if (arrayOfObject[i] == TreeModelListener.class)
/* 2376 */           ((TreeModelListener)arrayOfObject[(i + 1)]).treeNodesChanged(paramTreeModelEvent);
/*      */       }
/*      */     }
/*      */     
/*      */     public void treeNodesInserted(TreeModelEvent paramTreeModelEvent) {
/* 2381 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2382 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2383 */         if (arrayOfObject[i] == TreeModelListener.class)
/* 2384 */           ((TreeModelListener)arrayOfObject[(i + 1)]).treeNodesInserted(paramTreeModelEvent);
/*      */       }
/*      */     }
/*      */     
/*      */     public void treeNodesRemoved(TreeModelEvent paramTreeModelEvent) {
/* 2389 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2390 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2391 */         if (arrayOfObject[i] == TreeModelListener.class)
/* 2392 */           ((TreeModelListener)arrayOfObject[(i + 1)]).treeNodesRemoved(paramTreeModelEvent);
/*      */       }
/*      */     }
/*      */     
/*      */     public void treeStructureChanged(TreeModelEvent paramTreeModelEvent) {
/* 2397 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2398 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2399 */         if (arrayOfObject[i] == TreeModelListener.class) {
/* 2400 */           ((TreeModelListener)arrayOfObject[(i + 1)]).treeStructureChanged(paramTreeModelEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void valueChanged(TreeSelectionEvent paramTreeSelectionEvent)
/*      */     {
/* 2408 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2409 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2410 */         if (arrayOfObject[i] == TreeSelectionListener.class) {
/* 2411 */           ((TreeSelectionListener)arrayOfObject[(i + 1)]).valueChanged(paramTreeSelectionEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void undoableEditHappened(UndoableEditEvent paramUndoableEditEvent)
/*      */     {
/* 2419 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2420 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2421 */         if (arrayOfObject[i] == UndoableEditListener.class) {
/* 2422 */           ((UndoableEditListener)arrayOfObject[(i + 1)]).undoableEditHappened(paramUndoableEditEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void internalFrameOpened(InternalFrameEvent paramInternalFrameEvent)
/*      */     {
/* 2430 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2431 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2432 */         if (arrayOfObject[i] == InternalFrameListener.class) {
/* 2433 */           ((InternalFrameListener)arrayOfObject[(i + 1)]).internalFrameOpened(paramInternalFrameEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void internalFrameActivated(InternalFrameEvent paramInternalFrameEvent) {
/* 2439 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2440 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2441 */         if (arrayOfObject[i] == InternalFrameListener.class) {
/* 2442 */           ((InternalFrameListener)arrayOfObject[(i + 1)]).internalFrameActivated(paramInternalFrameEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void internalFrameDeactivated(InternalFrameEvent paramInternalFrameEvent) {
/* 2448 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2449 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2450 */         if (arrayOfObject[i] == InternalFrameListener.class) {
/* 2451 */           ((InternalFrameListener)arrayOfObject[(i + 1)]).internalFrameDeactivated(paramInternalFrameEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void internalFrameIconified(InternalFrameEvent paramInternalFrameEvent) {
/* 2457 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2458 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2459 */         if (arrayOfObject[i] == InternalFrameListener.class) {
/* 2460 */           ((InternalFrameListener)arrayOfObject[(i + 1)]).internalFrameIconified(paramInternalFrameEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void internalFrameDeiconified(InternalFrameEvent paramInternalFrameEvent) {
/* 2466 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2467 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2468 */         if (arrayOfObject[i] == InternalFrameListener.class) {
/* 2469 */           ((InternalFrameListener)arrayOfObject[(i + 1)]).internalFrameDeiconified(paramInternalFrameEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void internalFrameClosing(InternalFrameEvent paramInternalFrameEvent) {
/* 2475 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2476 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2477 */         if (arrayOfObject[i] == InternalFrameListener.class) {
/* 2478 */           ((InternalFrameListener)arrayOfObject[(i + 1)]).internalFrameClosing(paramInternalFrameEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void internalFrameClosed(InternalFrameEvent paramInternalFrameEvent) {
/* 2484 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2485 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2486 */         if (arrayOfObject[i] == InternalFrameListener.class) {
/* 2487 */           ((InternalFrameListener)arrayOfObject[(i + 1)]).internalFrameClosed(paramInternalFrameEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void propertyChange(PropertyChangeEvent paramPropertyChangeEvent)
/*      */     {
/* 2495 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2496 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2497 */         if (arrayOfObject[i] == PropertyChangeListener.class) {
/* 2498 */           ((PropertyChangeListener)arrayOfObject[(i + 1)]).propertyChange(paramPropertyChangeEvent);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2503 */       if ((paramPropertyChangeEvent.getSource() instanceof JTextComponent)) {
/* 2504 */         Document localDocument = ((JTextComponent)paramPropertyChangeEvent.getSource()).getDocument();
/* 2505 */         if (localDocument == null) {
/* 2506 */           return;
/*      */         }
/*      */         try {
/* 2509 */           this.removeDocumentMethod = localDocument.getClass().getMethod("removeDocumentListener", this.documentListeners);
/*      */           
/* 2511 */           this.addDocumentMethod = localDocument.getClass().getMethod("addDocumentListener", this.documentListeners);
/*      */           try
/*      */           {
/* 2514 */             this.removeDocumentMethod.invoke(localDocument, this.documentArgs);
/* 2515 */             this.addDocumentMethod.invoke(localDocument, this.documentArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException) {
/* 2517 */             System.out.println("Exception: " + localInvocationTargetException.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException) {
/* 2519 */             System.out.println("Exception: " + localIllegalAccessException.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException) {}catch (SecurityException localSecurityException)
/*      */         {
/* 2524 */           System.out.println("Exception: " + localSecurityException.toString());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void vetoableChange(PropertyChangeEvent paramPropertyChangeEvent)
/*      */       throws PropertyVetoException
/*      */     {
/* 2534 */       Object[] arrayOfObject = SwingEventMonitor.listenerList.getListenerList();
/* 2535 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 2536 */         if (arrayOfObject[i] == VetoableChangeListener.class) {
/* 2537 */           ((VetoableChangeListener)arrayOfObject[(i + 1)]).vetoableChange(paramPropertyChangeEvent);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jaccess.jar!\com\sun\java\accessibility\util\SwingEventMonitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */