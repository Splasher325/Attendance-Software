/*      */ package com.sun.java.accessibility.util;
/*      */ 
/*      */ import java.awt.AWTEventMulticaster;
/*      */ import java.awt.Adjustable;
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.KeyboardFocusManager;
/*      */ import java.awt.Window;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.AdjustmentEvent;
/*      */ import java.awt.event.AdjustmentListener;
/*      */ import java.awt.event.ComponentEvent;
/*      */ import java.awt.event.ComponentListener;
/*      */ import java.awt.event.ContainerEvent;
/*      */ import java.awt.event.ContainerListener;
/*      */ import java.awt.event.FocusEvent;
/*      */ import java.awt.event.FocusListener;
/*      */ import java.awt.event.ItemEvent;
/*      */ import java.awt.event.ItemListener;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.event.KeyListener;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.MouseListener;
/*      */ import java.awt.event.MouseMotionListener;
/*      */ import java.awt.event.TextEvent;
/*      */ import java.awt.event.TextListener;
/*      */ import java.awt.event.WindowEvent;
/*      */ import java.awt.event.WindowListener;
/*      */ import java.io.PrintStream;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import javax.swing.JMenu;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.JRootPane;
/*      */ import javax.swing.MenuElement;
/*      */ import javax.swing.MenuSelectionManager;
/*      */ import javax.swing.event.ChangeEvent;
/*      */ import javax.swing.event.ChangeListener;
/*      */ import jdk.Exported;
/*      */ import sun.security.util.SecurityConstants.AWT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Exported
/*      */ public class AWTEventMonitor
/*      */ {
/*   51 */   private static boolean runningOnJDK1_4 = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*   62 */   protected static Component componentWithFocus = null;
/*      */   
/*   64 */   private static Component componentWithFocus_private = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*   76 */   protected static ComponentListener componentListener = null;
/*      */   
/*   78 */   private static ComponentListener componentListener_private = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*   89 */   protected static ContainerListener containerListener = null;
/*      */   
/*   91 */   private static ContainerListener containerListener_private = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  102 */   protected static FocusListener focusListener = null;
/*      */   
/*  104 */   private static FocusListener focusListener_private = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  115 */   protected static KeyListener keyListener = null;
/*      */   
/*  117 */   private static KeyListener keyListener_private = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  128 */   protected static MouseListener mouseListener = null;
/*      */   
/*  130 */   private static MouseListener mouseListener_private = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  141 */   protected static MouseMotionListener mouseMotionListener = null;
/*      */   
/*  143 */   private static MouseMotionListener mouseMotionListener_private = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  154 */   protected static WindowListener windowListener = null;
/*      */   
/*  156 */   private static WindowListener windowListener_private = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  169 */   protected static ActionListener actionListener = null;
/*      */   
/*  171 */   private static ActionListener actionListener_private = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  182 */   protected static AdjustmentListener adjustmentListener = null;
/*      */   
/*  184 */   private static AdjustmentListener adjustmentListener_private = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  195 */   protected static ItemListener itemListener = null;
/*      */   
/*  197 */   private static ItemListener itemListener_private = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  208 */   protected static TextListener textListener = null;
/*      */   
/*  210 */   private static TextListener textListener_private = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  222 */   protected static AWTEventsListener awtListener = new AWTEventsListener();
/*      */   
/*  224 */   private static final AWTEventsListener awtListener_private = new AWTEventsListener();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Component getComponentWithFocus()
/*      */   {
/*  233 */     return componentWithFocus_private;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static void checkInstallPermission()
/*      */   {
/*  240 */     SecurityManager localSecurityManager = System.getSecurityManager();
/*  241 */     if (localSecurityManager != null) {
/*  242 */       localSecurityManager.checkPermission(SecurityConstants.AWT.ALL_AWT_EVENTS_PERMISSION);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addComponentListener(ComponentListener paramComponentListener)
/*      */   {
/*  257 */     if (componentListener_private == null) {
/*  258 */       checkInstallPermission();
/*  259 */       awtListener_private.installListeners(2);
/*      */     }
/*  261 */     componentListener_private = AWTEventMulticaster.add(componentListener_private, paramComponentListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeComponentListener(ComponentListener paramComponentListener)
/*      */   {
/*  272 */     componentListener_private = AWTEventMulticaster.remove(componentListener_private, paramComponentListener);
/*  273 */     if (componentListener_private == null) {
/*  274 */       awtListener_private.removeListeners(2);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addContainerListener(ContainerListener paramContainerListener)
/*      */   {
/*  289 */     containerListener_private = AWTEventMulticaster.add(containerListener_private, paramContainerListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeContainerListener(ContainerListener paramContainerListener)
/*      */   {
/*  300 */     containerListener_private = AWTEventMulticaster.remove(containerListener_private, paramContainerListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addFocusListener(FocusListener paramFocusListener)
/*      */   {
/*  314 */     focusListener_private = AWTEventMulticaster.add(focusListener_private, paramFocusListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeFocusListener(FocusListener paramFocusListener)
/*      */   {
/*  325 */     focusListener_private = AWTEventMulticaster.remove(focusListener_private, paramFocusListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addKeyListener(KeyListener paramKeyListener)
/*      */   {
/*  339 */     if (keyListener_private == null) {
/*  340 */       checkInstallPermission();
/*  341 */       awtListener_private.installListeners(6);
/*      */     }
/*  343 */     keyListener_private = AWTEventMulticaster.add(keyListener_private, paramKeyListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeKeyListener(KeyListener paramKeyListener)
/*      */   {
/*  354 */     keyListener_private = AWTEventMulticaster.remove(keyListener_private, paramKeyListener);
/*  355 */     if (keyListener_private == null) {
/*  356 */       awtListener_private.removeListeners(6);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addMouseListener(MouseListener paramMouseListener)
/*      */   {
/*  371 */     if (mouseListener_private == null) {
/*  372 */       checkInstallPermission();
/*  373 */       awtListener_private.installListeners(7);
/*      */     }
/*  375 */     mouseListener_private = AWTEventMulticaster.add(mouseListener_private, paramMouseListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeMouseListener(MouseListener paramMouseListener)
/*      */   {
/*  386 */     mouseListener_private = AWTEventMulticaster.remove(mouseListener_private, paramMouseListener);
/*  387 */     if (mouseListener_private == null) {
/*  388 */       awtListener_private.removeListeners(7);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addMouseMotionListener(MouseMotionListener paramMouseMotionListener)
/*      */   {
/*  403 */     if (mouseMotionListener_private == null) {
/*  404 */       checkInstallPermission();
/*  405 */       awtListener_private.installListeners(8);
/*      */     }
/*  407 */     mouseMotionListener_private = AWTEventMulticaster.add(mouseMotionListener_private, paramMouseMotionListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeMouseMotionListener(MouseMotionListener paramMouseMotionListener)
/*      */   {
/*  418 */     mouseMotionListener_private = AWTEventMulticaster.remove(mouseMotionListener_private, paramMouseMotionListener);
/*  419 */     if (mouseMotionListener_private == null) {
/*  420 */       awtListener_private.removeListeners(8);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addWindowListener(WindowListener paramWindowListener)
/*      */   {
/*  435 */     if (windowListener_private == null) {
/*  436 */       checkInstallPermission();
/*  437 */       awtListener_private.installListeners(11);
/*      */     }
/*  439 */     windowListener_private = AWTEventMulticaster.add(windowListener_private, paramWindowListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeWindowListener(WindowListener paramWindowListener)
/*      */   {
/*  450 */     windowListener_private = AWTEventMulticaster.remove(windowListener_private, paramWindowListener);
/*  451 */     if (windowListener_private == null) {
/*  452 */       awtListener_private.removeListeners(11);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addActionListener(ActionListener paramActionListener)
/*      */   {
/*  467 */     if (actionListener_private == null) {
/*  468 */       checkInstallPermission();
/*  469 */       awtListener_private.installListeners(0);
/*      */     }
/*  471 */     actionListener_private = AWTEventMulticaster.add(actionListener_private, paramActionListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeActionListener(ActionListener paramActionListener)
/*      */   {
/*  482 */     actionListener_private = AWTEventMulticaster.remove(actionListener_private, paramActionListener);
/*  483 */     if (actionListener_private == null) {
/*  484 */       awtListener_private.removeListeners(0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addAdjustmentListener(AdjustmentListener paramAdjustmentListener)
/*      */   {
/*  500 */     if (adjustmentListener_private == null) {
/*  501 */       checkInstallPermission();
/*  502 */       awtListener_private.installListeners(1);
/*      */     }
/*  504 */     adjustmentListener_private = AWTEventMulticaster.add(adjustmentListener_private, paramAdjustmentListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeAdjustmentListener(AdjustmentListener paramAdjustmentListener)
/*      */   {
/*  515 */     adjustmentListener_private = AWTEventMulticaster.remove(adjustmentListener_private, paramAdjustmentListener);
/*  516 */     if (adjustmentListener_private == null) {
/*  517 */       awtListener_private.removeListeners(1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addItemListener(ItemListener paramItemListener)
/*      */   {
/*  532 */     if (itemListener_private == null) {
/*  533 */       checkInstallPermission();
/*  534 */       awtListener_private.installListeners(5);
/*      */     }
/*  536 */     itemListener_private = AWTEventMulticaster.add(itemListener_private, paramItemListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeItemListener(ItemListener paramItemListener)
/*      */   {
/*  547 */     itemListener_private = AWTEventMulticaster.remove(itemListener_private, paramItemListener);
/*  548 */     if (itemListener_private == null) {
/*  549 */       awtListener_private.removeListeners(5);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addTextListener(TextListener paramTextListener)
/*      */   {
/*  564 */     if (textListener_private == null) {
/*  565 */       checkInstallPermission();
/*  566 */       awtListener_private.installListeners(10);
/*      */     }
/*  568 */     textListener_private = AWTEventMulticaster.add(textListener_private, paramTextListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void removeTextListener(TextListener paramTextListener)
/*      */   {
/*  579 */     textListener_private = AWTEventMulticaster.remove(textListener_private, paramTextListener);
/*  580 */     if (textListener_private == null) {
/*  581 */       awtListener_private.removeListeners(10);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static class AWTEventsListener
/*      */     implements TopLevelWindowListener, ActionListener, AdjustmentListener, ComponentListener, ContainerListener, FocusListener, ItemListener, KeyListener, MouseListener, MouseMotionListener, TextListener, WindowListener, ChangeListener
/*      */   {
/*      */     private Class[] actionListeners;
/*      */     
/*      */ 
/*      */     private Method removeActionMethod;
/*      */     
/*      */ 
/*      */     private Method addActionMethod;
/*      */     
/*      */ 
/*      */     private Object[] actionArgs;
/*      */     
/*      */ 
/*      */     private Class[] itemListeners;
/*      */     
/*      */ 
/*      */     private Method removeItemMethod;
/*      */     
/*      */ 
/*      */     private Method addItemMethod;
/*      */     
/*      */ 
/*      */     private Object[] itemArgs;
/*      */     
/*      */ 
/*      */     private Class[] textListeners;
/*      */     
/*      */ 
/*      */     private Method removeTextMethod;
/*      */     
/*      */ 
/*      */     private Method addTextMethod;
/*      */     
/*      */ 
/*      */     private Object[] textArgs;
/*      */     
/*      */ 
/*      */     private Class[] windowListeners;
/*      */     
/*      */ 
/*      */     private Method removeWindowMethod;
/*      */     
/*      */ 
/*      */     private Method addWindowMethod;
/*      */     
/*      */ 
/*      */     private Object[] windowArgs;
/*      */     
/*      */ 
/*      */ 
/*      */     public AWTEventsListener()
/*      */     {
/*  641 */       String str = System.getProperty("java.version");
/*  642 */       if (str != null) {
/*  643 */         AWTEventMonitor.access$002(str.compareTo("1.4") >= 0);
/*      */       }
/*  645 */       initializeIntrospection();
/*  646 */       installListeners();
/*  647 */       if (AWTEventMonitor.runningOnJDK1_4) {
/*  648 */         MenuSelectionManager.defaultManager().addChangeListener(this);
/*      */       }
/*  650 */       EventQueueMonitor.addTopLevelWindowListener(this);
/*      */     }
/*      */     
/*      */ 
/*      */     private boolean initializeIntrospection()
/*      */     {
/*      */       try
/*      */       {
/*  658 */         this.actionListeners = new Class[1];
/*  659 */         this.actionArgs = new Object[1];
/*  660 */         this.actionListeners[0] = Class.forName("java.awt.event.ActionListener");
/*  661 */         this.actionArgs[0] = this;
/*      */         
/*  663 */         this.itemListeners = new Class[1];
/*  664 */         this.itemArgs = new Object[1];
/*  665 */         this.itemListeners[0] = Class.forName("java.awt.event.ItemListener");
/*  666 */         this.itemArgs[0] = this;
/*      */         
/*  668 */         this.textListeners = new Class[1];
/*  669 */         this.textArgs = new Object[1];
/*  670 */         this.textListeners[0] = Class.forName("java.awt.event.TextListener");
/*  671 */         this.textArgs[0] = this;
/*      */         
/*  673 */         this.windowListeners = new Class[1];
/*  674 */         this.windowArgs = new Object[1];
/*  675 */         this.windowListeners[0] = Class.forName("java.awt.event.WindowListener");
/*  676 */         this.windowArgs[0] = this;
/*      */         
/*  678 */         return true;
/*      */       } catch (ClassNotFoundException localClassNotFoundException) {
/*  680 */         System.out.println("EXCEPTION - Class 'java.awt.event.*' not in CLASSPATH"); }
/*  681 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void installListeners()
/*      */     {
/*  692 */       Window[] arrayOfWindow = EventQueueMonitor.getTopLevelWindows();
/*  693 */       if (arrayOfWindow != null) {
/*  694 */         for (int i = 0; i < arrayOfWindow.length; i++) {
/*  695 */           installListeners(arrayOfWindow[i]);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void installListeners(int paramInt)
/*      */     {
/*  707 */       Window[] arrayOfWindow = EventQueueMonitor.getTopLevelWindows();
/*  708 */       if (arrayOfWindow != null) {
/*  709 */         for (int i = 0; i < arrayOfWindow.length; i++) {
/*  710 */           installListeners(arrayOfWindow[i], paramInt);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void installListeners(Component paramComponent)
/*      */     {
/*  723 */       installListeners(paramComponent, 3);
/*  724 */       installListeners(paramComponent, 4);
/*      */       
/*      */ 
/*      */ 
/*  728 */       if (AWTEventMonitor.componentListener_private != null) {
/*  729 */         installListeners(paramComponent, 2);
/*      */       }
/*  731 */       if (AWTEventMonitor.keyListener_private != null) {
/*  732 */         installListeners(paramComponent, 6);
/*      */       }
/*  734 */       if (AWTEventMonitor.mouseListener_private != null) {
/*  735 */         installListeners(paramComponent, 7);
/*      */       }
/*  737 */       if (AWTEventMonitor.mouseMotionListener_private != null) {
/*  738 */         installListeners(paramComponent, 8);
/*      */       }
/*  740 */       if (AWTEventMonitor.windowListener_private != null) {
/*  741 */         installListeners(paramComponent, 11);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  746 */       if (AWTEventMonitor.actionListener_private != null) {
/*  747 */         installListeners(paramComponent, 0);
/*      */       }
/*  749 */       if (AWTEventMonitor.adjustmentListener_private != null) {
/*  750 */         installListeners(paramComponent, 1);
/*      */       }
/*  752 */       if (AWTEventMonitor.itemListener_private != null) {
/*  753 */         installListeners(paramComponent, 5);
/*      */       }
/*  755 */       if (AWTEventMonitor.textListener_private != null) {
/*  756 */         installListeners(paramComponent, 10);
/*      */       }
/*      */     }
/*      */     
/*      */     public void stateChanged(ChangeEvent paramChangeEvent) {
/*  761 */       processFocusGained();
/*      */     }
/*      */     
/*      */     private void processFocusGained() {
/*  765 */       Component localComponent1 = KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
/*  766 */       if (localComponent1 == null) {
/*  767 */         return;
/*      */       }
/*  769 */       MenuSelectionManager.defaultManager().removeChangeListener(this);
/*  770 */       MenuSelectionManager.defaultManager().addChangeListener(this);
/*      */       
/*      */ 
/*  773 */       if ((localComponent1 instanceof JRootPane))
/*      */       {
/*  775 */         MenuElement[] arrayOfMenuElement = MenuSelectionManager.defaultManager().getSelectedPath();
/*  776 */         if (arrayOfMenuElement.length > 1) {
/*  777 */           Component localComponent2 = arrayOfMenuElement[(arrayOfMenuElement.length - 2)].getComponent();
/*  778 */           Component localComponent3 = arrayOfMenuElement[(arrayOfMenuElement.length - 1)].getComponent();
/*      */           
/*  780 */           if (((localComponent3 instanceof JPopupMenu)) || ((localComponent3 instanceof JMenu)))
/*      */           {
/*      */ 
/*      */ 
/*  784 */             AWTEventMonitor.access$1002(localComponent3);
/*  785 */           } else if ((localComponent2 instanceof JPopupMenu))
/*      */           {
/*  787 */             AWTEventMonitor.access$1002(localComponent2);
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/*  792 */         AWTEventMonitor.access$1002(localComponent1);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void installListeners(Component paramComponent, int paramInt)
/*      */     {
/*  808 */       switch (paramInt)
/*      */       {
/*      */       case 0: 
/*      */         try {
/*  812 */           this.removeActionMethod = paramComponent.getClass().getMethod("removeActionListener", this.actionListeners);
/*      */           
/*  814 */           this.addActionMethod = paramComponent.getClass().getMethod("addActionListener", this.actionListeners);
/*      */           try
/*      */           {
/*  817 */             this.removeActionMethod.invoke(paramComponent, this.actionArgs);
/*  818 */             this.addActionMethod.invoke(paramComponent, this.actionArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException1) {
/*  820 */             System.out.println("Exception: " + localInvocationTargetException1.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException1) {
/*  822 */             System.out.println("Exception: " + localIllegalAccessException1.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException1) {}catch (SecurityException localSecurityException1)
/*      */         {
/*  827 */           System.out.println("Exception: " + localSecurityException1.toString());
/*      */         }
/*      */       
/*      */ 
/*      */       case 1: 
/*  832 */         if ((paramComponent instanceof Adjustable)) {
/*  833 */           ((Adjustable)paramComponent).removeAdjustmentListener(this);
/*  834 */           ((Adjustable)paramComponent).addAdjustmentListener(this);
/*      */         }
/*      */         
/*      */         break;
/*      */       case 2: 
/*  839 */         paramComponent.removeComponentListener(this);
/*  840 */         paramComponent.addComponentListener(this);
/*  841 */         break;
/*      */       
/*      */       case 3: 
/*  844 */         if ((paramComponent instanceof Container)) {
/*  845 */           ((Container)paramComponent).removeContainerListener(this);
/*  846 */           ((Container)paramComponent).addContainerListener(this);
/*      */         }
/*      */         
/*      */         break;
/*      */       case 4: 
/*  851 */         paramComponent.removeFocusListener(this);
/*  852 */         paramComponent.addFocusListener(this);
/*      */         
/*  854 */         if (AWTEventMonitor.runningOnJDK1_4) {
/*  855 */           processFocusGained();
/*      */ 
/*      */         }
/*  858 */         else if ((paramComponent != AWTEventMonitor.componentWithFocus_private) && (paramComponent.hasFocus())) {
/*  859 */           AWTEventMonitor.access$1002(paramComponent);
/*      */         }
/*      */         
/*      */         break;
/*      */       case 5: 
/*      */         try
/*      */         {
/*  866 */           this.removeItemMethod = paramComponent.getClass().getMethod("removeItemListener", this.itemListeners);
/*      */           
/*  868 */           this.addItemMethod = paramComponent.getClass().getMethod("addItemListener", this.itemListeners);
/*      */           try
/*      */           {
/*  871 */             this.removeItemMethod.invoke(paramComponent, this.itemArgs);
/*  872 */             this.addItemMethod.invoke(paramComponent, this.itemArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException2) {
/*  874 */             System.out.println("Exception: " + localInvocationTargetException2.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException2) {
/*  876 */             System.out.println("Exception: " + localIllegalAccessException2.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException2) {}catch (SecurityException localSecurityException2)
/*      */         {
/*  881 */           System.out.println("Exception: " + localSecurityException2.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case 6: 
/*  891 */         paramComponent.removeKeyListener(this);
/*  892 */         paramComponent.addKeyListener(this);
/*  893 */         break;
/*      */       
/*      */       case 7: 
/*  896 */         paramComponent.removeMouseListener(this);
/*  897 */         paramComponent.addMouseListener(this);
/*  898 */         break;
/*      */       
/*      */       case 8: 
/*  901 */         paramComponent.removeMouseMotionListener(this);
/*  902 */         paramComponent.addMouseMotionListener(this);
/*  903 */         break;
/*      */       case 10: 
/*      */         try
/*      */         {
/*  907 */           this.removeTextMethod = paramComponent.getClass().getMethod("removeTextListener", this.textListeners);
/*      */           
/*  909 */           this.addTextMethod = paramComponent.getClass().getMethod("addTextListener", this.textListeners);
/*      */           try
/*      */           {
/*  912 */             this.removeTextMethod.invoke(paramComponent, this.textArgs);
/*  913 */             this.addTextMethod.invoke(paramComponent, this.textArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException3) {
/*  915 */             System.out.println("Exception: " + localInvocationTargetException3.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException3) {
/*  917 */             System.out.println("Exception: " + localIllegalAccessException3.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException3) {}catch (SecurityException localSecurityException3)
/*      */         {
/*  922 */           System.out.println("Exception: " + localSecurityException3.toString());
/*      */         }
/*      */       
/*      */       case 11: 
/*      */         try
/*      */         {
/*  928 */           this.removeWindowMethod = paramComponent.getClass().getMethod("removeWindowListener", this.windowListeners);
/*      */           
/*  930 */           this.addWindowMethod = paramComponent.getClass().getMethod("addWindowListener", this.windowListeners);
/*      */           try
/*      */           {
/*  933 */             this.removeWindowMethod.invoke(paramComponent, this.windowArgs);
/*  934 */             this.addWindowMethod.invoke(paramComponent, this.windowArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException4) {
/*  936 */             System.out.println("Exception: " + localInvocationTargetException4.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException4) {
/*  938 */             System.out.println("Exception: " + localIllegalAccessException4.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException4) {}catch (SecurityException localSecurityException4)
/*      */         {
/*  943 */           System.out.println("Exception: " + localSecurityException4.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 9: 
/*      */       default: 
/*  951 */         return;
/*      */       }
/*      */       
/*      */       
/*      */ 
/*  956 */       if ((paramComponent instanceof Container)) {
/*  957 */         int i = ((Container)paramComponent).getComponentCount();
/*  958 */         for (int j = 0; j < i; j++) {
/*  959 */           installListeners(((Container)paramComponent).getComponent(j), paramInt);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void removeListeners(int paramInt)
/*      */     {
/*  971 */       Window[] arrayOfWindow = EventQueueMonitor.getTopLevelWindows();
/*  972 */       if (arrayOfWindow != null) {
/*  973 */         for (int i = 0; i < arrayOfWindow.length; i++) {
/*  974 */           removeListeners(arrayOfWindow[i], paramInt);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void removeListeners(Component paramComponent)
/*      */     {
/*  987 */       if (AWTEventMonitor.componentListener_private != null) {
/*  988 */         removeListeners(paramComponent, 2);
/*      */       }
/*  990 */       if (AWTEventMonitor.keyListener_private != null) {
/*  991 */         removeListeners(paramComponent, 6);
/*      */       }
/*  993 */       if (AWTEventMonitor.mouseListener_private != null) {
/*  994 */         removeListeners(paramComponent, 7);
/*      */       }
/*  996 */       if (AWTEventMonitor.mouseMotionListener_private != null) {
/*  997 */         removeListeners(paramComponent, 8);
/*      */       }
/*  999 */       if (AWTEventMonitor.windowListener_private != null) {
/* 1000 */         removeListeners(paramComponent, 11);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1005 */       if (AWTEventMonitor.actionListener_private != null) {
/* 1006 */         removeListeners(paramComponent, 0);
/*      */       }
/* 1008 */       if (AWTEventMonitor.adjustmentListener_private != null) {
/* 1009 */         removeListeners(paramComponent, 1);
/*      */       }
/* 1011 */       if (AWTEventMonitor.itemListener_private != null) {
/* 1012 */         removeListeners(paramComponent, 5);
/*      */       }
/* 1014 */       if (AWTEventMonitor.textListener_private != null) {
/* 1015 */         removeListeners(paramComponent, 10);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected void removeListeners(Component paramComponent, int paramInt)
/*      */     {
/* 1029 */       switch (paramInt)
/*      */       {
/*      */       case 0: 
/*      */         try {
/* 1033 */           this.removeActionMethod = paramComponent.getClass().getMethod("removeActionListener", this.actionListeners);
/*      */           
/*      */           try
/*      */           {
/* 1037 */             this.removeActionMethod.invoke(paramComponent, this.actionArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException1) {
/* 1039 */             System.out.println("Exception: " + localInvocationTargetException1.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException1) {
/* 1041 */             System.out.println("Exception: " + localIllegalAccessException1.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException1) {}catch (SecurityException localSecurityException1)
/*      */         {
/* 1046 */           System.out.println("Exception: " + localSecurityException1.toString());
/*      */         }
/*      */       
/*      */ 
/*      */       case 1: 
/* 1051 */         if ((paramComponent instanceof Adjustable)) {
/* 1052 */           ((Adjustable)paramComponent).removeAdjustmentListener(this);
/*      */         }
/*      */         
/*      */         break;
/*      */       case 2: 
/* 1057 */         paramComponent.removeComponentListener(this);
/* 1058 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case 5: 
/*      */         try
/*      */         {
/* 1074 */           this.removeItemMethod = paramComponent.getClass().getMethod("removeItemListener", this.itemListeners);
/*      */           try
/*      */           {
/* 1077 */             this.removeItemMethod.invoke(paramComponent, this.itemArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException2) {
/* 1079 */             System.out.println("Exception: " + localInvocationTargetException2.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException2) {
/* 1081 */             System.out.println("Exception: " + localIllegalAccessException2.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException2) {}catch (SecurityException localSecurityException2)
/*      */         {
/* 1086 */           System.out.println("Exception: " + localSecurityException2.toString());
/*      */         }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       case 6: 
/* 1095 */         paramComponent.removeKeyListener(this);
/* 1096 */         break;
/*      */       
/*      */       case 7: 
/* 1099 */         paramComponent.removeMouseListener(this);
/* 1100 */         break;
/*      */       
/*      */       case 8: 
/* 1103 */         paramComponent.removeMouseMotionListener(this);
/* 1104 */         break;
/*      */       case 10: 
/*      */         try
/*      */         {
/* 1108 */           this.removeTextMethod = paramComponent.getClass().getMethod("removeTextListener", this.textListeners);
/*      */           try
/*      */           {
/* 1111 */             this.removeTextMethod.invoke(paramComponent, this.textArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException3) {
/* 1113 */             System.out.println("Exception: " + localInvocationTargetException3.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException3) {
/* 1115 */             System.out.println("Exception: " + localIllegalAccessException3.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException3) {}catch (SecurityException localSecurityException3)
/*      */         {
/* 1120 */           System.out.println("Exception: " + localSecurityException3.toString());
/*      */         }
/*      */       
/*      */       case 11: 
/*      */         try
/*      */         {
/* 1126 */           this.removeWindowMethod = paramComponent.getClass().getMethod("removeWindowListener", this.windowListeners);
/*      */           try
/*      */           {
/* 1129 */             this.removeWindowMethod.invoke(paramComponent, this.windowArgs);
/*      */           } catch (InvocationTargetException localInvocationTargetException4) {
/* 1131 */             System.out.println("Exception: " + localInvocationTargetException4.toString());
/*      */           } catch (IllegalAccessException localIllegalAccessException4) {
/* 1133 */             System.out.println("Exception: " + localIllegalAccessException4.toString());
/*      */           }
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException4) {}catch (SecurityException localSecurityException4)
/*      */         {
/* 1138 */           System.out.println("Exception: " + localSecurityException4.toString());
/*      */         }
/*      */       case 3: case 4: 
/*      */       case 9: 
/*      */       default: 
/* 1143 */         return;
/*      */       }
/*      */       
/* 1146 */       if ((paramComponent instanceof Container)) {
/* 1147 */         int i = ((Container)paramComponent).getComponentCount();
/* 1148 */         for (int j = 0; j < i; j++) {
/* 1149 */           removeListeners(((Container)paramComponent).getComponent(j), paramInt);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void topLevelWindowCreated(Window paramWindow)
/*      */     {
/* 1168 */       installListeners(paramWindow);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void topLevelWindowDestroyed(Window paramWindow) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void actionPerformed(ActionEvent paramActionEvent)
/*      */     {
/* 1186 */       if (AWTEventMonitor.actionListener_private != null) {
/* 1187 */         AWTEventMonitor.actionListener_private.actionPerformed(paramActionEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void adjustmentValueChanged(AdjustmentEvent paramAdjustmentEvent)
/*      */     {
/* 1198 */       if (AWTEventMonitor.adjustmentListener_private != null) {
/* 1199 */         AWTEventMonitor.adjustmentListener_private.adjustmentValueChanged(paramAdjustmentEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void componentHidden(ComponentEvent paramComponentEvent)
/*      */     {
/* 1210 */       if (AWTEventMonitor.componentListener_private != null) {
/* 1211 */         AWTEventMonitor.componentListener_private.componentHidden(paramComponentEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void componentMoved(ComponentEvent paramComponentEvent)
/*      */     {
/* 1220 */       if (AWTEventMonitor.componentListener_private != null) {
/* 1221 */         AWTEventMonitor.componentListener_private.componentMoved(paramComponentEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void componentResized(ComponentEvent paramComponentEvent)
/*      */     {
/* 1230 */       if (AWTEventMonitor.componentListener_private != null) {
/* 1231 */         AWTEventMonitor.componentListener_private.componentResized(paramComponentEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void componentShown(ComponentEvent paramComponentEvent)
/*      */     {
/* 1240 */       if (AWTEventMonitor.componentListener_private != null) {
/* 1241 */         AWTEventMonitor.componentListener_private.componentShown(paramComponentEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void componentAdded(ContainerEvent paramContainerEvent)
/*      */     {
/* 1252 */       installListeners(paramContainerEvent.getChild());
/* 1253 */       if (AWTEventMonitor.containerListener_private != null) {
/* 1254 */         AWTEventMonitor.containerListener_private.componentAdded(paramContainerEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void componentRemoved(ContainerEvent paramContainerEvent)
/*      */     {
/* 1263 */       removeListeners(paramContainerEvent.getChild());
/* 1264 */       if (AWTEventMonitor.containerListener_private != null) {
/* 1265 */         AWTEventMonitor.containerListener_private.componentRemoved(paramContainerEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void focusGained(FocusEvent paramFocusEvent)
/*      */     {
/* 1276 */       AWTEventMonitor.access$1002((Component)paramFocusEvent.getSource());
/* 1277 */       if (AWTEventMonitor.focusListener_private != null) {
/* 1278 */         AWTEventMonitor.focusListener_private.focusGained(paramFocusEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void focusLost(FocusEvent paramFocusEvent)
/*      */     {
/* 1287 */       AWTEventMonitor.access$1002(null);
/* 1288 */       if (AWTEventMonitor.focusListener_private != null) {
/* 1289 */         AWTEventMonitor.focusListener_private.focusLost(paramFocusEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void itemStateChanged(ItemEvent paramItemEvent)
/*      */     {
/* 1300 */       if (AWTEventMonitor.itemListener_private != null) {
/* 1301 */         AWTEventMonitor.itemListener_private.itemStateChanged(paramItemEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void keyPressed(KeyEvent paramKeyEvent)
/*      */     {
/* 1312 */       if (AWTEventMonitor.keyListener_private != null) {
/* 1313 */         AWTEventMonitor.keyListener_private.keyPressed(paramKeyEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void keyReleased(KeyEvent paramKeyEvent)
/*      */     {
/* 1322 */       if (AWTEventMonitor.keyListener_private != null) {
/* 1323 */         AWTEventMonitor.keyListener_private.keyReleased(paramKeyEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void keyTyped(KeyEvent paramKeyEvent)
/*      */     {
/* 1332 */       if (AWTEventMonitor.keyListener_private != null) {
/* 1333 */         AWTEventMonitor.keyListener_private.keyTyped(paramKeyEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void mouseClicked(MouseEvent paramMouseEvent)
/*      */     {
/* 1344 */       if (AWTEventMonitor.mouseListener_private != null) {
/* 1345 */         AWTEventMonitor.mouseListener_private.mouseClicked(paramMouseEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void mouseEntered(MouseEvent paramMouseEvent)
/*      */     {
/* 1354 */       if (AWTEventMonitor.mouseListener_private != null) {
/* 1355 */         AWTEventMonitor.mouseListener_private.mouseEntered(paramMouseEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void mouseExited(MouseEvent paramMouseEvent)
/*      */     {
/* 1364 */       if (AWTEventMonitor.mouseListener_private != null) {
/* 1365 */         AWTEventMonitor.mouseListener_private.mouseExited(paramMouseEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void mousePressed(MouseEvent paramMouseEvent)
/*      */     {
/* 1374 */       if (AWTEventMonitor.mouseListener_private != null) {
/* 1375 */         AWTEventMonitor.mouseListener_private.mousePressed(paramMouseEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void mouseReleased(MouseEvent paramMouseEvent)
/*      */     {
/* 1384 */       if (AWTEventMonitor.mouseListener_private != null) {
/* 1385 */         AWTEventMonitor.mouseListener_private.mouseReleased(paramMouseEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void mouseDragged(MouseEvent paramMouseEvent)
/*      */     {
/* 1396 */       if (AWTEventMonitor.mouseMotionListener_private != null) {
/* 1397 */         AWTEventMonitor.mouseMotionListener_private.mouseDragged(paramMouseEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void mouseMoved(MouseEvent paramMouseEvent)
/*      */     {
/* 1406 */       if (AWTEventMonitor.mouseMotionListener_private != null) {
/* 1407 */         AWTEventMonitor.mouseMotionListener_private.mouseMoved(paramMouseEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void textValueChanged(TextEvent paramTextEvent)
/*      */     {
/* 1418 */       if (AWTEventMonitor.textListener_private != null) {
/* 1419 */         AWTEventMonitor.textListener_private.textValueChanged(paramTextEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void windowOpened(WindowEvent paramWindowEvent)
/*      */     {
/* 1430 */       if (AWTEventMonitor.windowListener_private != null) {
/* 1431 */         AWTEventMonitor.windowListener_private.windowOpened(paramWindowEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void windowClosing(WindowEvent paramWindowEvent)
/*      */     {
/* 1440 */       if (AWTEventMonitor.windowListener_private != null) {
/* 1441 */         AWTEventMonitor.windowListener_private.windowClosing(paramWindowEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void windowClosed(WindowEvent paramWindowEvent)
/*      */     {
/* 1450 */       if (AWTEventMonitor.windowListener_private != null) {
/* 1451 */         AWTEventMonitor.windowListener_private.windowClosed(paramWindowEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void windowIconified(WindowEvent paramWindowEvent)
/*      */     {
/* 1460 */       if (AWTEventMonitor.windowListener_private != null) {
/* 1461 */         AWTEventMonitor.windowListener_private.windowIconified(paramWindowEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void windowDeiconified(WindowEvent paramWindowEvent)
/*      */     {
/* 1470 */       if (AWTEventMonitor.windowListener_private != null) {
/* 1471 */         AWTEventMonitor.windowListener_private.windowDeiconified(paramWindowEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void windowActivated(WindowEvent paramWindowEvent)
/*      */     {
/* 1480 */       if (AWTEventMonitor.windowListener_private != null) {
/* 1481 */         AWTEventMonitor.windowListener_private.windowActivated(paramWindowEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void windowDeactivated(WindowEvent paramWindowEvent)
/*      */     {
/* 1490 */       if (AWTEventMonitor.windowListener_private != null) {
/* 1491 */         AWTEventMonitor.windowListener_private.windowDeactivated(paramWindowEvent);
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jaccess.jar!\com\sun\java\accessibility\util\AWTEventMonitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */