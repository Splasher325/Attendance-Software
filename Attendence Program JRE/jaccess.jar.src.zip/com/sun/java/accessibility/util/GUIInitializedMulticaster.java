/*    */ package com.sun.java.accessibility.util;
/*    */ 
/*    */ import java.awt.AWTEventMulticaster;
/*    */ import java.util.EventListener;
/*    */ import jdk.Exported;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Exported(false)
/*    */ public class GUIInitializedMulticaster
/*    */   extends AWTEventMulticaster
/*    */   implements GUIInitializedListener
/*    */ {
/*    */   protected GUIInitializedMulticaster(EventListener paramEventListener1, EventListener paramEventListener2)
/*    */   {
/* 49 */     super(paramEventListener1, paramEventListener2);
/*    */   }
/*    */   
/*    */   public void guiInitialized() {
/* 53 */     ((GUIInitializedListener)this.a).guiInitialized();
/* 54 */     ((GUIInitializedListener)this.b).guiInitialized();
/*    */   }
/*    */   
/*    */   public static GUIInitializedListener add(GUIInitializedListener paramGUIInitializedListener1, GUIInitializedListener paramGUIInitializedListener2) {
/* 58 */     return (GUIInitializedListener)addInternal(paramGUIInitializedListener1, paramGUIInitializedListener2);
/*    */   }
/*    */   
/*    */   public static GUIInitializedListener remove(GUIInitializedListener paramGUIInitializedListener1, GUIInitializedListener paramGUIInitializedListener2) {
/* 62 */     return (GUIInitializedListener)removeInternal(paramGUIInitializedListener1, paramGUIInitializedListener2);
/*    */   }
/*    */   
/*    */   protected static EventListener addInternal(EventListener paramEventListener1, EventListener paramEventListener2) {
/* 66 */     if (paramEventListener1 == null) return paramEventListener2;
/* 67 */     if (paramEventListener2 == null) return paramEventListener1;
/* 68 */     return new GUIInitializedMulticaster(paramEventListener1, paramEventListener2);
/*    */   }
/*    */   
/*    */   protected static EventListener removeInternal(EventListener paramEventListener1, EventListener paramEventListener2) {
/* 72 */     if ((paramEventListener1 == paramEventListener2) || (paramEventListener1 == null))
/* 73 */       return null;
/* 74 */     if ((paramEventListener1 instanceof GUIInitializedMulticaster)) {
/* 75 */       return ((GUIInitializedMulticaster)paramEventListener1).remove(paramEventListener2);
/*    */     }
/* 77 */     return paramEventListener1;
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jaccess.jar!\com\sun\java\accessibility\util\GUIInitializedMulticaster.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */