/*     */ package com.sun.java.accessibility.util;
/*     */ 
/*     */ import java.awt.AWTEvent;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dialog;
/*     */ import java.awt.Point;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.AWTEventListener;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Vector;
/*     */ import javax.accessibility.Accessible;
/*     */ import javax.accessibility.AccessibleComponent;
/*     */ import javax.accessibility.AccessibleContext;
/*     */ import jdk.Exported;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Exported
/*     */ public class EventQueueMonitor
/*     */   implements AWTEventListener
/*     */ {
/*  55 */   static Vector topLevelWindows = new Vector();
/*  56 */   static Window topLevelWindowWithFocus = null;
/*  57 */   static Point currentMousePosition = null;
/*  58 */   static Component currentMouseComponent = null;
/*     */   
/*     */ 
/*     */ 
/*  62 */   static GUIInitializedListener guiInitializedListener = null;
/*  63 */   static TopLevelWindowListener topLevelWindowListener = null;
/*  64 */   static MouseMotionListener mouseMotionListener = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */   static boolean guiInitialized = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  85 */   static EventQueueMonitorItem componentEventQueue = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  90 */   private static ComponentEvtDispatchThread cedt = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */   static Object componentEventQueueLock = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EventQueueMonitor()
/*     */   {
/* 109 */     if (cedt == null) {
/* 110 */       cedt = new ComponentEvtDispatchThread("EventQueueMonitor-ComponentEvtDispatch");
/*     */       
/* 112 */       cedt.setDaemon(true);
/* 113 */       cedt.start();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void queueComponentEvent(ComponentEvent paramComponentEvent)
/*     */   {
/* 124 */     synchronized (componentEventQueueLock) {
/* 125 */       EventQueueMonitorItem localEventQueueMonitorItem1 = new EventQueueMonitorItem(paramComponentEvent);
/* 126 */       if (componentEventQueue == null) {
/* 127 */         componentEventQueue = localEventQueueMonitorItem1;
/*     */       } else {
/* 129 */         EventQueueMonitorItem localEventQueueMonitorItem2 = componentEventQueue;
/*     */         
/* 131 */         while (localEventQueueMonitorItem2.next != null) {
/* 132 */           localEventQueueMonitorItem2 = localEventQueueMonitorItem2.next;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 137 */         localEventQueueMonitorItem2.next = localEventQueueMonitorItem1;
/*     */       }
/* 139 */       componentEventQueueLock.notifyAll();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void maybeInitialize()
/*     */   {
/* 147 */     if (cedt == null) {
/* 148 */       AccessController.doPrivileged(new PrivilegedAction()
/*     */       {
/*     */         public Object run() {
/*     */           try {
/* 152 */             long l = 100L;
/*     */             
/*     */ 
/*     */ 
/* 156 */             Toolkit.getDefaultToolkit().addAWTEventListener(new EventQueueMonitor(), l);
/*     */           }
/*     */           catch (Exception localException) {}
/* 159 */           return null;
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void eventDispatched(AWTEvent paramAWTEvent)
/*     */   {
/* 171 */     processEvent(paramAWTEvent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void maybeNotifyAssistiveTechnologies()
/*     */   {
/* 182 */     if (!guiInitialized) {
/* 183 */       guiInitialized = true;
/* 184 */       if (guiInitializedListener != null) {
/* 185 */         guiInitializedListener.guiInitialized();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void addTopLevelWindow(Component paramComponent)
/*     */   {
/* 208 */     if (paramComponent == null) {
/* 209 */       return;
/*     */     }
/*     */     
/* 212 */     if (!(paramComponent instanceof Window)) {
/* 213 */       addTopLevelWindow(paramComponent.getParent()); return;
/*     */     }
/*     */     
/*     */     Container localContainer;
/* 217 */     if (((paramComponent instanceof Dialog)) || ((paramComponent instanceof Window))) {
/* 218 */       localContainer = (Container)paramComponent;
/*     */     } else {
/* 220 */       localContainer = paramComponent.getParent();
/* 221 */       if (localContainer != null) {
/* 222 */         addTopLevelWindow(localContainer);
/* 223 */         return;
/*     */       }
/*     */     }
/*     */     
/* 227 */     if (localContainer == null) {
/* 228 */       localContainer = (Container)paramComponent;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 235 */     synchronized (topLevelWindows) {
/* 236 */       if ((localContainer != null) && (!topLevelWindows.contains(localContainer))) {
/* 237 */         topLevelWindows.addElement(localContainer);
/* 238 */         if (topLevelWindowListener != null) {
/* 239 */           topLevelWindowListener.topLevelWindowCreated((Window)localContainer);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void removeTopLevelWindow(Window paramWindow)
/*     */   {
/* 256 */     synchronized (topLevelWindows) {
/* 257 */       if (topLevelWindows.contains(paramWindow)) {
/* 258 */         topLevelWindows.removeElement(paramWindow);
/* 259 */         if (topLevelWindowListener != null) {
/* 260 */           topLevelWindowListener.topLevelWindowDestroyed(paramWindow);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void updateCurrentMousePosition(MouseEvent paramMouseEvent)
/*     */   {
/* 272 */     Point localPoint1 = currentMousePosition;
/*     */     
/*     */     try
/*     */     {
/* 276 */       Point localPoint2 = paramMouseEvent.getPoint();
/* 277 */       currentMouseComponent = (Component)paramMouseEvent.getSource();
/* 278 */       currentMousePosition = currentMouseComponent.getLocationOnScreen();
/* 279 */       currentMousePosition.translate(localPoint2.x, localPoint2.y);
/*     */     } catch (Exception localException) {
/* 281 */       currentMousePosition = localPoint1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static void processEvent(AWTEvent paramAWTEvent)
/*     */   {
/*     */     ComponentEvent localComponentEvent;
/*     */     
/*     */ 
/* 293 */     switch (paramAWTEvent.getID()) {
/*     */     case 206: 
/*     */     case 503: 
/*     */     case 506: 
/*     */     case 1004: 
/* 298 */       queueComponentEvent((ComponentEvent)paramAWTEvent);
/* 299 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 205: 
/* 306 */       if ((paramAWTEvent instanceof ComponentEvent)) {
/* 307 */         localComponentEvent = (ComponentEvent)paramAWTEvent;
/* 308 */         if ((localComponentEvent.getComponent() instanceof Window)) {
/* 309 */           addTopLevelWindow(localComponentEvent.getComponent());
/* 310 */           maybeNotifyAssistiveTechnologies();
/*     */         } else {
/* 312 */           maybeNotifyAssistiveTechnologies();
/* 313 */           addTopLevelWindow(localComponentEvent.getComponent());
/*     */         }
/*     */       }
/* 316 */       queueComponentEvent((ComponentEvent)paramAWTEvent);
/* 317 */       break;
/*     */     
/*     */ 
/*     */     case 200: 
/* 321 */       if ((paramAWTEvent instanceof ComponentEvent)) {
/* 322 */         localComponentEvent = (ComponentEvent)paramAWTEvent;
/* 323 */         if ((localComponentEvent.getComponent() instanceof Window)) {
/* 324 */           addTopLevelWindow(localComponentEvent.getComponent());
/* 325 */           maybeNotifyAssistiveTechnologies();
/*     */         } else {
/* 327 */           maybeNotifyAssistiveTechnologies();
/* 328 */           addTopLevelWindow(localComponentEvent.getComponent());
/*     */         } }
/* 330 */       break;
/*     */     
/*     */     case 202: 
/* 333 */       if ((paramAWTEvent instanceof ComponentEvent)) {
/* 334 */         localComponentEvent = (ComponentEvent)paramAWTEvent;
/* 335 */         removeTopLevelWindow((Window)localComponentEvent.getComponent()); }
/* 336 */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static synchronized Component getShowingComponentAt(Container paramContainer, int paramInt1, int paramInt2)
/*     */   {
/* 348 */     if (!paramContainer.contains(paramInt1, paramInt2)) {
/* 349 */       return null;
/*     */     }
/* 351 */     int i = paramContainer.getComponentCount();
/* 352 */     for (int j = 0; j < i; j++) {
/* 353 */       Component localComponent = paramContainer.getComponent(j);
/* 354 */       if ((localComponent != null) && (localComponent.isShowing())) {
/* 355 */         Point localPoint = localComponent.getLocation();
/* 356 */         if (localComponent.contains(paramInt1 - localPoint.x, paramInt2 - localPoint.y)) {
/* 357 */           return localComponent;
/*     */         }
/*     */       }
/*     */     }
/* 361 */     return paramContainer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static synchronized Component getComponentAt(Container paramContainer, Point paramPoint)
/*     */   {
/* 374 */     if (!paramContainer.isShowing()) {
/* 375 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 379 */     Point localPoint1 = paramContainer.getLocationOnScreen();
/* 380 */     Point localPoint2 = new Point(paramPoint.x - localPoint1.x, paramPoint.y - localPoint1.y);
/*     */     
/*     */ 
/* 383 */     Component localComponent = getShowingComponentAt(paramContainer, localPoint2.x, localPoint2.y);
/*     */     
/* 385 */     if ((localComponent != paramContainer) && ((localComponent instanceof Container))) {
/* 386 */       return getComponentAt((Container)localComponent, paramPoint);
/*     */     }
/* 388 */     return localComponent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Accessible getAccessibleAt(Point paramPoint)
/*     */   {
/* 401 */     Window localWindow = getTopLevelWindowWithFocus();
/* 402 */     Window[] arrayOfWindow = getTopLevelWindows();
/* 403 */     Component localComponent = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 409 */     if (currentMousePosition == null) {
/* 410 */       return null;
/*     */     }
/* 412 */     if ((currentMousePosition.equals(paramPoint)) && 
/* 413 */       ((currentMouseComponent instanceof Container))) {
/* 414 */       localComponent = getComponentAt((Container)currentMouseComponent, paramPoint);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 420 */     if ((localComponent == null) && (localWindow != null)) {
/* 421 */       localComponent = getComponentAt(localWindow, paramPoint);
/*     */     }
/*     */     
/*     */ 
/* 425 */     if (localComponent == null) {
/* 426 */       for (int i = 0; i < arrayOfWindow.length; i++) {
/* 427 */         localComponent = getComponentAt(arrayOfWindow[i], paramPoint);
/* 428 */         if (localComponent != null) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 434 */     if ((localComponent instanceof Accessible)) {
/* 435 */       AccessibleContext localAccessibleContext = ((Accessible)localComponent).getAccessibleContext();
/* 436 */       if (localAccessibleContext != null) {
/* 437 */         AccessibleComponent localAccessibleComponent = localAccessibleContext.getAccessibleComponent();
/* 438 */         if ((localAccessibleComponent != null) && (localAccessibleContext.getAccessibleChildrenCount() != 0)) {
/* 439 */           Point localPoint = localAccessibleComponent.getLocationOnScreen();
/* 440 */           localPoint.move(paramPoint.x - localPoint.x, paramPoint.y - localPoint.y);
/* 441 */           return localAccessibleComponent.getAccessibleAt(localPoint);
/*     */         }
/*     */       }
/* 444 */       return (Accessible)localComponent;
/*     */     }
/* 446 */     return Translator.getAccessible(localComponent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isGUIInitialized()
/*     */   {
/* 468 */     maybeInitialize();
/* 469 */     return guiInitialized;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addGUIInitializedListener(GUIInitializedListener paramGUIInitializedListener)
/*     */   {
/* 482 */     maybeInitialize();
/*     */     
/* 484 */     guiInitializedListener = GUIInitializedMulticaster.add(guiInitializedListener, paramGUIInitializedListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void removeGUIInitializedListener(GUIInitializedListener paramGUIInitializedListener)
/*     */   {
/* 496 */     guiInitializedListener = GUIInitializedMulticaster.remove(guiInitializedListener, paramGUIInitializedListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addTopLevelWindowListener(TopLevelWindowListener paramTopLevelWindowListener)
/*     */   {
/* 508 */     topLevelWindowListener = TopLevelWindowMulticaster.add(topLevelWindowListener, paramTopLevelWindowListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void removeTopLevelWindowListener(TopLevelWindowListener paramTopLevelWindowListener)
/*     */   {
/* 520 */     topLevelWindowListener = TopLevelWindowMulticaster.remove(topLevelWindowListener, paramTopLevelWindowListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Point getCurrentMousePosition()
/*     */   {
/* 529 */     return currentMousePosition;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Window[] getTopLevelWindows()
/*     */   {
/* 543 */     synchronized (topLevelWindows) {
/* 544 */       int i = topLevelWindows.size();
/* 545 */       if (i > 0) {
/* 546 */         Window[] arrayOfWindow = new Window[i];
/* 547 */         for (int j = 0; j < i; j++) {
/* 548 */           arrayOfWindow[j] = ((Window)topLevelWindows.elementAt(j));
/*     */         }
/* 550 */         return arrayOfWindow;
/*     */       }
/* 552 */       return new Window[0];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Window getTopLevelWindowWithFocus()
/*     */   {
/* 563 */     return topLevelWindowWithFocus;
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jaccess.jar!\com\sun\java\accessibility\util\EventQueueMonitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */