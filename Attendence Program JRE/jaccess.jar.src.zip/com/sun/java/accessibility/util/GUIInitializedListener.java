package com.sun.java.accessibility.util;

import java.util.EventListener;
import jdk.Exported;

@Exported
public abstract interface GUIInitializedListener
  extends EventListener
{
  public abstract void guiInitialized();
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jaccess.jar!\com\sun\java\accessibility\util\GUIInitializedListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */