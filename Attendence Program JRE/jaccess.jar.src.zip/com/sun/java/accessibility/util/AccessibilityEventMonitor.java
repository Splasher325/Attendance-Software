/*     */ package com.sun.java.accessibility.util;
/*     */ 
/*     */ import java.awt.Window;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.io.PrintStream;
/*     */ import javax.accessibility.Accessible;
/*     */ import javax.accessibility.AccessibleContext;
/*     */ import javax.accessibility.AccessibleRole;
/*     */ import javax.accessibility.AccessibleState;
/*     */ import javax.accessibility.AccessibleStateSet;
/*     */ import jdk.Exported;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Exported
/*     */ public class AccessibilityEventMonitor
/*     */ {
/*  57 */   protected static final AccessibilityListenerList listenerList = new AccessibilityListenerList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */   protected static final AccessibilityEventListener accessibilityListener = new AccessibilityEventListener();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener)
/*     */   {
/*  82 */     if (listenerList.getListenerCount(PropertyChangeListener.class) == 0) {
/*  83 */       accessibilityListener.installListeners();
/*     */     }
/*  85 */     listenerList.add(PropertyChangeListener.class, paramPropertyChangeListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener)
/*     */   {
/*  95 */     listenerList.remove(PropertyChangeListener.class, paramPropertyChangeListener);
/*  96 */     if (listenerList.getListenerCount(PropertyChangeListener.class) == 0) {
/*  97 */       accessibilityListener.removeListeners();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class AccessibilityEventListener
/*     */     implements TopLevelWindowListener, PropertyChangeListener
/*     */   {
/*     */     public AccessibilityEventListener()
/*     */     {
/* 122 */       EventQueueMonitor.addTopLevelWindowListener(this);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void installListeners()
/*     */     {
/* 132 */       Window[] arrayOfWindow = EventQueueMonitor.getTopLevelWindows();
/* 133 */       if (arrayOfWindow != null) {
/* 134 */         for (int i = 0; i < arrayOfWindow.length; i++) {
/* 135 */           if ((arrayOfWindow[i] instanceof Accessible)) {
/* 136 */             installListeners(arrayOfWindow[i]);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void installListeners(Accessible paramAccessible)
/*     */     {
/* 148 */       installListeners(paramAccessible.getAccessibleContext());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void installListeners(AccessibleContext paramAccessibleContext)
/*     */     {
/* 158 */       if (paramAccessibleContext != null) {
/* 159 */         AccessibleStateSet localAccessibleStateSet1 = paramAccessibleContext.getAccessibleStateSet();
/* 160 */         if (!localAccessibleStateSet1.contains(AccessibleState.TRANSIENT)) {
/* 161 */           paramAccessibleContext.addPropertyChangeListener(this);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 170 */           AccessibleStateSet localAccessibleStateSet2 = paramAccessibleContext.getAccessibleStateSet();
/* 171 */           if (localAccessibleStateSet2.contains(_AccessibleState.MANAGES_DESCENDANTS)) {
/* 172 */             return;
/*     */           }
/* 174 */           AccessibleRole localAccessibleRole = paramAccessibleContext.getAccessibleRole();
/* 175 */           if ((localAccessibleRole == AccessibleRole.LIST) || (localAccessibleRole == AccessibleRole.TREE))
/*     */           {
/* 177 */             return;
/*     */           }
/* 179 */           if (localAccessibleRole == AccessibleRole.TABLE)
/*     */           {
/* 181 */             Accessible localAccessible1 = paramAccessibleContext.getAccessibleChild(0);
/* 182 */             if (localAccessible1 != null) {
/* 183 */               AccessibleContext localAccessibleContext = localAccessible1.getAccessibleContext();
/* 184 */               if (localAccessibleContext != null) {
/* 185 */                 localAccessibleRole = localAccessibleContext.getAccessibleRole();
/* 186 */                 if ((localAccessibleRole != null) && (localAccessibleRole != AccessibleRole.TABLE)) {
/* 187 */                   return;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/* 192 */           int i = paramAccessibleContext.getAccessibleChildrenCount();
/* 193 */           for (int j = 0; j < i; j++) {
/* 194 */             Accessible localAccessible2 = paramAccessibleContext.getAccessibleChild(j);
/* 195 */             if (localAccessible2 != null) {
/* 196 */               installListeners(localAccessible2);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void removeListeners()
/*     */     {
/* 210 */       Window[] arrayOfWindow = EventQueueMonitor.getTopLevelWindows();
/* 211 */       if (arrayOfWindow != null) {
/* 212 */         for (int i = 0; i < arrayOfWindow.length; i++) {
/* 213 */           if ((arrayOfWindow[i] instanceof Accessible)) {
/* 214 */             removeListeners(arrayOfWindow[i]);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void removeListeners(Accessible paramAccessible)
/*     */     {
/* 226 */       removeListeners(paramAccessible.getAccessibleContext());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void removeListeners(AccessibleContext paramAccessibleContext)
/*     */     {
/* 238 */       if (paramAccessibleContext != null)
/*     */       {
/* 240 */         AccessibleStateSet localAccessibleStateSet = paramAccessibleContext.getAccessibleStateSet();
/* 241 */         if (!localAccessibleStateSet.contains(AccessibleState.TRANSIENT)) {
/* 242 */           paramAccessibleContext.removePropertyChangeListener(this);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 251 */           if (localAccessibleStateSet.contains(_AccessibleState.MANAGES_DESCENDANTS)) {
/* 252 */             return;
/*     */           }
/* 254 */           AccessibleRole localAccessibleRole = paramAccessibleContext.getAccessibleRole();
/* 255 */           if ((localAccessibleRole == AccessibleRole.LIST) || (localAccessibleRole == AccessibleRole.TABLE) || (localAccessibleRole == AccessibleRole.TREE))
/*     */           {
/*     */ 
/* 258 */             return;
/*     */           }
/* 260 */           int i = paramAccessibleContext.getAccessibleChildrenCount();
/* 261 */           for (int j = 0; j < i; j++) {
/* 262 */             Accessible localAccessible = paramAccessibleContext.getAccessibleChild(j);
/* 263 */             if (localAccessible != null) {
/* 264 */               removeListeners(localAccessible);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void topLevelWindowCreated(Window paramWindow)
/*     */     {
/* 285 */       if ((paramWindow instanceof Accessible)) {
/* 286 */         installListeners(paramWindow);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void topLevelWindowDestroyed(Window paramWindow)
/*     */     {
/* 296 */       if ((paramWindow instanceof Accessible)) {
/* 297 */         removeListeners(paramWindow);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void propertyChange(PropertyChangeEvent paramPropertyChangeEvent)
/*     */     {
/* 307 */       Object[] arrayOfObject = AccessibilityEventMonitor.listenerList.getListenerList();
/* 308 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 309 */         if (arrayOfObject[i] == PropertyChangeListener.class) {
/* 310 */           ((PropertyChangeListener)arrayOfObject[(i + 1)]).propertyChange(paramPropertyChangeEvent);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 315 */       String str = paramPropertyChangeEvent.getPropertyName();
/* 316 */       if (str.compareTo("AccessibleChild") == 0) {
/* 317 */         Object localObject1 = paramPropertyChangeEvent.getOldValue();
/* 318 */         Object localObject2 = paramPropertyChangeEvent.getNewValue();
/*     */         
/* 320 */         if (((localObject1 == null ? 1 : 0) ^ (localObject2 == null ? 1 : 0)) != 0) { Accessible localAccessible;
/* 321 */           if (localObject1 != null)
/*     */           {
/* 323 */             if ((localObject1 instanceof Accessible)) {
/* 324 */               localAccessible = (Accessible)localObject1;
/* 325 */               removeListeners(localAccessible.getAccessibleContext());
/* 326 */             } else if ((localObject1 instanceof AccessibleContext)) {
/* 327 */               removeListeners((AccessibleContext)localObject1);
/*     */             }
/* 329 */           } else if (localObject2 != null)
/*     */           {
/* 331 */             if ((localObject2 instanceof Accessible)) {
/* 332 */               localAccessible = (Accessible)localObject2;
/* 333 */               installListeners(localAccessible.getAccessibleContext());
/* 334 */             } else if ((localObject2 instanceof AccessibleContext)) {
/* 335 */               installListeners((AccessibleContext)localObject2);
/*     */             }
/*     */           }
/*     */         } else {
/* 339 */           System.out.println("ERROR in usage of PropertyChangeEvents for: " + paramPropertyChangeEvent.toString());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jaccess.jar!\com\sun\java\accessibility\util\AccessibilityEventMonitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */