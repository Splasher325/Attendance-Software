package com.sun.deploy.uitoolkit.impl.fx;

import com.sun.applet2.Applet2Context;
import com.sun.applet2.AppletParameters;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Utils
{
  static final Set<String> bannedNames = new HashSet();
  static Object unnamedKey = null;
  
  public static Map<String, String> getNamedParameters(Applet2Context paramApplet2Context)
  {
    HashMap localHashMap = new HashMap();
    Map localMap = paramApplet2Context.getParameters().rawMap();
    if (localMap != null)
    {
      Iterator localIterator = localMap.keySet().iterator();
      while (localIterator.hasNext())
      {
        Object localObject = localIterator.next();
        if (((localObject instanceof String)) && (!bannedNames.contains((String)localObject))) {
          localHashMap.put((String)localObject, (String)localMap.get(localObject));
        }
      }
    }
    return localHashMap;
  }
  
  public static String[] getUnnamed(Applet2Context paramApplet2Context)
  {
    AppletParameters localAppletParameters = paramApplet2Context.getParameters();
    return (String[])localAppletParameters.get(unnamedKey);
  }
  
  static
  {
    try
    {
      Class localClass = Class.forName("sun.plugin2.util.ParameterNames", true, null);
      for (Field localField : localClass.getDeclaredFields()) {
        if (localField.getType() == String.class)
        {
          String str = (String)localField.get(null);
          bannedNames.add(str);
        }
        else if ("ARGUMENTS".equals(localField.getName()))
        {
          unnamedKey = localField.get(null);
        }
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\Utils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */