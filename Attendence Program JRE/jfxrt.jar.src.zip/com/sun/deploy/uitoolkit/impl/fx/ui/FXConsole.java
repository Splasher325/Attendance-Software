package com.sun.deploy.uitoolkit.impl.fx.ui;

import com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager;
import com.sun.deploy.uitoolkit.ui.ConsoleController;
import com.sun.deploy.uitoolkit.ui.ConsoleHelper;
import com.sun.deploy.uitoolkit.ui.ConsoleWindow;
import com.sun.deploy.util.DeploySysAction;
import com.sun.deploy.util.DeploySysRun;
import java.io.PrintStream;
import java.text.MessageFormat;
import java.util.Iterator;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.IndexRange;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.stage.StageStyle;

public final class FXConsole
  implements ConsoleWindow
{
  private final boolean USE_TEXT_AREA = true;
  private final ConsoleController controller;
  private FXDialog dialog;
  private ScrollPane sp;
  private TextArea textArea;
  private Label textAreaLabel;
  
  public static FXConsole create(ConsoleController paramConsoleController)
    throws Exception
  {
    (FXConsole)DeploySysRun.execute(new DeploySysAction()
    {
      public Object execute()
      {
        return new FXConsole(this.val$controller);
      }
    });
  }
  
  public FXConsole(ConsoleController paramConsoleController)
  {
    this.controller = paramConsoleController;
    invokeLater(new Runnable()
    {
      public void run()
      {
        FXConsole.this.dialog = new FXDialog(ResourceManager.getMessage("console.caption"), null, false, StageStyle.DECORATED, false);
        FXConsole.this.dialog.setResizable(true);
        FXConsole.this.dialog.impl_setImportant(false);
        BorderPane localBorderPane = new BorderPane();
        FXConsole.this.dialog.setContentPane(localBorderPane);
        FXConsole.this.dialog.setWidth(470.0D);
        FXConsole.this.dialog.setHeight(430.0D);
        FXConsole.this.textArea = new TextArea();
        FXConsole.this.textArea.setEditable(false);
        FXConsole.this.textArea.setWrapText(true);
        FXConsole.this.textArea.getStyleClass().add("multiline-text");
        localBorderPane.setCenter(FXConsole.this.textArea);
        EventHandler local1 = new EventHandler()
        {
          public void handle(KeyEvent paramAnonymous2KeyEvent)
          {
            String str = paramAnonymous2KeyEvent.getCharacter();
            if ((str != null) && (str.length() == 1)) {
              switch (str.charAt(0))
              {
              case 'j': 
                FXConsole.this.dumpJCovData();
                break;
              case 'v': 
                FXConsole.this.dumpThreadStack();
                break;
              case 'p': 
                FXConsole.this.reloadProxyConfig();
                break;
              case 'r': 
                FXConsole.this.reloadPolicyConfig();
                break;
              case 'x': 
                FXConsole.this.clearClassLoaderCache();
                break;
              case 'l': 
                FXConsole.this.showClassLoaderCache();
                break;
              case 'o': 
                FXConsole.this.logging();
                break;
              case 't': 
                FXConsole.this.showThreads();
                break;
              case 's': 
                FXConsole.this.showSystemProperties();
                break;
              case 'h': 
                FXConsole.this.showHelp();
                break;
              case 'm': 
                FXConsole.this.showMemory();
                break;
              case 'c': 
                FXConsole.this.clearConsole();
                break;
              case 'g': 
                FXConsole.this.runGC();
                break;
              case 'f': 
                FXConsole.this.runFinalize();
                break;
              case 'q': 
                FXConsole.this.closeConsole();
                break;
              case '0': 
                FXConsole.this.traceLevel0();
                break;
              case '1': 
                FXConsole.this.traceLevel1();
                break;
              case '2': 
                FXConsole.this.traceLevel2();
                break;
              case '3': 
                FXConsole.this.traceLevel3();
                break;
              case '4': 
                FXConsole.this.traceLevel4();
                break;
              case '5': 
                FXConsole.this.traceLevel5();
              }
            }
          }
        };
        FXConsole.this.dialog.getScene().setOnKeyTyped(local1);
        FXConsole.this.textArea.setOnKeyTyped(local1);
        Button localButton1 = new Button(ResourceManager.getMessage("console.clear"));
        Button localButton2 = new Button(ResourceManager.getMessage("console.copy"));
        Button localButton3 = new Button(ResourceManager.getMessage("console.close"));
        FlowPane localFlowPane = new FlowPane();
        localFlowPane.getStyleClass().add("button-bar");
        localFlowPane.setId("console-dialog-button-bar");
        localFlowPane.getChildren().add(localButton1);
        localFlowPane.getChildren().add(new Label("    "));
        localFlowPane.getChildren().add(localButton2);
        localFlowPane.getChildren().add(new Label("    "));
        localFlowPane.getChildren().add(localButton3);
        localBorderPane.setBottom(localFlowPane);
        localButton1.setOnAction(new EventHandler()
        {
          public void handle(ActionEvent paramAnonymous2ActionEvent)
          {
            FXConsole.this.clearConsole();
          }
        });
        localButton2.setOnAction(new EventHandler()
        {
          public void handle(ActionEvent paramAnonymous2ActionEvent)
          {
            FXConsole.this.copyConsole();
          }
        });
        localButton3.setOnAction(new EventHandler()
        {
          public void handle(ActionEvent paramAnonymous2ActionEvent)
          {
            FXConsole.this.closeConsole();
          }
        });
      }
    });
  }
  
  private void dumpJCovData()
  {
    if (this.controller.isJCovSupported()) {
      if (this.controller.dumpJCovData()) {
        System.out.println(ResourceManager.getMessage("console.jcov.info"));
      } else {
        System.out.println(ResourceManager.getMessage("console.jcov.error"));
      }
    }
  }
  
  private void dumpThreadStack()
  {
    if (this.controller.isDumpStackSupported())
    {
      System.out.print(ResourceManager.getMessage("console.dump.stack"));
      System.out.print(ResourceManager.getMessage("console.menu.text.top"));
      ConsoleHelper.dumpAllStacks(this.controller);
      System.out.print(ResourceManager.getMessage("console.menu.text.tail"));
      System.out.print(ResourceManager.getMessage("console.done"));
    }
  }
  
  private void showThreads()
  {
    System.out.print(ResourceManager.getMessage("console.dump.thread"));
    ThreadGroup localThreadGroup = this.controller.getMainThreadGroup();
    ConsoleHelper.dumpThreadGroup(localThreadGroup);
    System.out.println(ResourceManager.getMessage("console.done"));
  }
  
  private void reloadPolicyConfig()
  {
    if (this.controller.isSecurityPolicyReloadSupported())
    {
      System.out.print(ResourceManager.getMessage("console.reload.policy"));
      this.controller.reloadSecurityPolicy();
      System.out.println(ResourceManager.getMessage("console.completed"));
    }
  }
  
  private void reloadProxyConfig()
  {
    if (this.controller.isProxyConfigReloadSupported())
    {
      System.out.println(ResourceManager.getMessage("console.reload.proxy"));
      this.controller.reloadProxyConfig();
      System.out.println(ResourceManager.getMessage("console.done"));
    }
  }
  
  private void showSystemProperties() {}
  
  private void showHelp()
  {
    ConsoleHelper.displayHelp(this.controller, this);
  }
  
  private void showClassLoaderCache()
  {
    if (this.controller.isDumpClassLoaderSupported()) {
      System.out.println(this.controller.dumpClassLoaders());
    }
  }
  
  private void clearClassLoaderCache()
  {
    if (this.controller.isClearClassLoaderSupported())
    {
      this.controller.clearClassLoaders();
      System.out.println(ResourceManager.getMessage("console.clear.classloader"));
    }
  }
  
  private void clearConsole()
  {
    clear();
  }
  
  private void copyConsole()
  {
    int i = this.textArea.getSelection().getStart();
    int j = this.textArea.getSelection().getEnd();
    if (j - i <= 0)
    {
      ClipboardContent localClipboardContent = new ClipboardContent();
      localClipboardContent.putString(this.textArea.getText());
      Clipboard.getSystemClipboard().setContent(localClipboardContent);
    }
    else
    {
      this.textArea.copy();
    }
  }
  
  private void closeConsole()
  {
    if (this.controller.isIconifiedOnClose()) {
      this.dialog.setIconified(true);
    } else {
      this.dialog.hide();
    }
    this.controller.notifyConsoleClosed();
  }
  
  private void showMemory()
  {
    long l1 = Runtime.getRuntime().freeMemory() / 1024L;
    long l2 = Runtime.getRuntime().totalMemory() / 1024L;
    long l3 = (100.0D / (l2 / l1));
    MessageFormat localMessageFormat = new MessageFormat(ResourceManager.getMessage("console.memory"));
    Object[] arrayOfObject = { new Long(l2), new Long(l1), new Long(l3) };
    System.out.print(localMessageFormat.format(arrayOfObject));
    System.out.println(ResourceManager.getMessage("console.completed"));
  }
  
  private void runFinalize()
  {
    System.out.print(ResourceManager.getMessage("console.finalize"));
    System.runFinalization();
    System.out.println(ResourceManager.getMessage("console.completed"));
    showMemory();
  }
  
  private void runGC()
  {
    System.out.print(ResourceManager.getMessage("console.gc"));
    System.gc();
    System.out.println(ResourceManager.getMessage("console.completed"));
    showMemory();
  }
  
  private void traceLevel0()
  {
    ConsoleHelper.setTraceLevel(0);
  }
  
  private void traceLevel1()
  {
    ConsoleHelper.setTraceLevel(1);
  }
  
  private void traceLevel2()
  {
    ConsoleHelper.setTraceLevel(2);
  }
  
  private void traceLevel3()
  {
    ConsoleHelper.setTraceLevel(3);
  }
  
  private void traceLevel4()
  {
    ConsoleHelper.setTraceLevel(4);
  }
  
  private void traceLevel5()
  {
    ConsoleHelper.setTraceLevel(5);
  }
  
  private void logging()
  {
    if (this.controller.isLoggingSupported()) {
      System.out.println(ResourceManager.getMessage("console.log") + this.controller.toggleLogging() + ResourceManager.getMessage("console.completed"));
    }
  }
  
  public void clear()
  {
    invokeLater(new Runnable()
    {
      public void run()
      {
        FXConsole.this.textArea.setText("");
        ConsoleHelper.displayVersion(FXConsole.this.controller, FXConsole.this);
        FXConsole.this.append("\n");
        ConsoleHelper.displayHelp(FXConsole.this.controller, FXConsole.this);
      }
    });
  }
  
  private static void invokeLater(Runnable paramRunnable)
  {
    Platform.runLater(paramRunnable);
  }
  
  public void append(final String paramString)
  {
    invokeLater(new Runnable()
    {
      public void run()
      {
        ScrollBar localScrollBar = FXConsole.this.getVerticalScrollBar();
        int i = (localScrollBar == null) || (!localScrollBar.isVisible()) || (localScrollBar.getValue() == localScrollBar.getMax()) ? 1 : 0;
        int j = FXConsole.this.textArea.getText().length();
        if (j > 1) {
          FXConsole.this.textArea.insertText(j, paramString);
        } else {
          FXConsole.this.textArea.setText(paramString);
        }
        if (i != 0) {
          FXConsole.this.setScrollPosition();
        }
      }
    });
  }
  
  private void setScrollPosition()
  {
    ScrollBar localScrollBar = getVerticalScrollBar();
    if (localScrollBar != null)
    {
      double d1 = localScrollBar.getMax();
      double d2 = localScrollBar.getValue();
      if (d2 < d1) {
        localScrollBar.setValue(d1);
      }
    }
  }
  
  private ScrollBar getVerticalScrollBar()
  {
    return findScrollBar(this.textArea, true);
  }
  
  private ScrollBar findScrollBar(Parent paramParent, boolean paramBoolean)
  {
    if ((paramParent instanceof ScrollBar))
    {
      localObject = (ScrollBar)paramParent;
      if ((((ScrollBar)localObject).getOrientation() == Orientation.VERTICAL) == paramBoolean) {
        return (ScrollBar)paramParent;
      }
      return null;
    }
    Object localObject = paramParent.getChildrenUnmodifiable().iterator();
    while (((Iterator)localObject).hasNext())
    {
      Node localNode = (Node)((Iterator)localObject).next();
      if ((localNode instanceof Parent))
      {
        ScrollBar localScrollBar = findScrollBar((Parent)localNode, paramBoolean);
        if (localScrollBar != null) {
          return localScrollBar;
        }
      }
    }
    return null;
  }
  
  public void setVisible(final boolean paramBoolean)
  {
    invokeLater(new Runnable()
    {
      public void run()
      {
        FXConsole.this.setVisibleImpl(paramBoolean);
      }
    });
  }
  
  private void setVisibleImpl(boolean paramBoolean)
  {
    if (this.controller.isIconifiedOnClose())
    {
      this.dialog.setIconified(!paramBoolean);
      this.dialog.show();
    }
    else
    {
      if (isVisible() != paramBoolean) {
        if (paramBoolean) {
          this.dialog.show();
        } else {
          this.dialog.hide();
        }
      }
      if (paramBoolean) {
        this.dialog.toFront();
      }
    }
  }
  
  public void setTitle(final String paramString)
  {
    invokeLater(new Runnable()
    {
      public void run()
      {
        FXConsole.this.setTitleImpl(paramString);
      }
    });
  }
  
  private void setTitleImpl(String paramString)
  {
    this.dialog.setTitle(paramString);
  }
  
  public String getRecentLog()
  {
    return "Not supported yet.";
  }
  
  public boolean isVisible()
  {
    if (this.controller.isIconifiedOnClose()) {
      return !this.dialog.isIconified();
    }
    return this.dialog.isShowing();
  }
  
  public void dispose() {}
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\FXConsole.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */