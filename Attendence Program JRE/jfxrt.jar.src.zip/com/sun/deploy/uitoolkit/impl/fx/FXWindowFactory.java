package com.sun.deploy.uitoolkit.impl.fx;

import com.sun.deploy.uitoolkit.PluginWindowFactory;
import com.sun.deploy.uitoolkit.Window;
import java.util.concurrent.Callable;
import sun.plugin2.main.client.ModalityInterface;
import sun.plugin2.message.Pipe;

public class FXWindowFactory
  extends PluginWindowFactory
{
  public Window createWindow()
  {
    return new FXWindow(0L, null);
  }
  
  public Window createWindow(final long paramLong, String paramString, boolean paramBoolean, ModalityInterface paramModalityInterface)
  {
    try
    {
      (Window)FXPluginToolkit.callAndWait(new Callable()
      {
        public FXWindow call()
          throws Exception
        {
          return new FXWindow(paramLong, this.val$caRenderServer);
        }
      });
    }
    catch (Exception localException)
    {
      throw new RuntimeException(localException);
    }
  }
  
  public Window createWindow(long paramLong, String paramString, boolean paramBoolean, ModalityInterface paramModalityInterface, Pipe paramPipe, int paramInt)
  {
    return createWindow(paramLong, paramString, paramBoolean, paramModalityInterface);
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\FXWindowFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */