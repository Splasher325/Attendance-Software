package com.sun.deploy.uitoolkit.impl.fx.ui;

import com.sun.deploy.security.CredentialInfo;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.ui.AppInfo;
import com.sun.deploy.uitoolkit.impl.fx.FXPluginToolkit;
import com.sun.deploy.uitoolkit.ui.ConsoleController;
import com.sun.deploy.uitoolkit.ui.ConsoleWindow;
import com.sun.deploy.uitoolkit.ui.DialogHook;
import com.sun.deploy.uitoolkit.ui.ModalityHelper;
import com.sun.deploy.uitoolkit.ui.NativeMixedCodeDialog;
import com.sun.deploy.uitoolkit.ui.PluginUIFactory;
import com.sun.deploy.util.DeploySysAction;
import com.sun.deploy.util.DeploySysRun;
import java.io.File;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.cert.Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeMap;
import java.util.Vector;
import java.util.concurrent.Callable;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MultipleSelectionModel;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import javafx.stage.Window;

public class FXUIFactory
  extends PluginUIFactory
{
  public int showMessageDialog(Object paramObject, AppInfo paramAppInfo, int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8)
  {
    switch (paramInt)
    {
    case -1: 
    case 6: 
    default: 
      return showContentDialog(paramObject, paramAppInfo, paramString1, paramString3, true, paramString5, paramString6);
    case 0: 
      if (paramString4 != null) {
        return showErrorDialog(paramObject, paramAppInfo, paramString1, paramString3, null, paramString5, paramString6, null, getDetailPanel(paramString4), null);
      }
      return showErrorDialog(paramObject, paramAppInfo, paramString1, paramString2, paramString3, paramString5, paramString6, paramString7);
    case 1: 
      showInformationDialog(paramObject, paramString1, paramString2, paramString3);
      return -1;
    case 2: 
      return showWarningDialog(paramObject, paramAppInfo, paramString1, paramString2, paramString3, paramString5, paramString6);
    case 3: 
      return showConfirmDialog(paramObject, paramAppInfo, paramString1, paramString2, paramString4, paramString5, paramString6, true);
    case 5: 
      return showIntegrationDialog(paramObject, paramAppInfo);
    case 7: 
      return showApiDialog(null, paramAppInfo, paramString1, paramString3, paramString2, paramString5, paramString6, false);
    }
    return showMixedCodeDialog(paramObject, paramAppInfo, paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, true, paramString8);
  }
  
  public void showExceptionDialog(Object paramObject, AppInfo paramAppInfo, Throwable paramThrowable, String paramString1, String paramString2, String paramString3, Certificate[] paramArrayOfCertificate)
  {
    if (paramArrayOfCertificate == null) {
      showExceptionDialog(paramObject, paramThrowable, paramString2, paramString3, paramString1);
    } else {
      showCertificateExceptionDialog(paramObject, paramAppInfo, paramThrowable, paramString3, paramString1, paramArrayOfCertificate);
    }
  }
  
  public CredentialInfo showPasswordDialog(Object paramObject, String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, CredentialInfo paramCredentialInfo, boolean paramBoolean3, String paramString3)
  {
    return showPasswordDialog0(paramObject, paramString1, paramString2, paramBoolean1, paramBoolean2, paramCredentialInfo, paramBoolean3, paramString3);
  }
  
  public int showSecurityDialog(AppInfo paramAppInfo, String paramString1, String paramString2, String paramString3, URL paramURL, boolean paramBoolean1, boolean paramBoolean2, String paramString4, String paramString5, String[] paramArrayOfString1, String[] paramArrayOfString2, boolean paramBoolean3, Certificate[] paramArrayOfCertificate, int paramInt1, int paramInt2, boolean paramBoolean4)
  {
    return showSecurityDialog0(paramAppInfo, paramString1, paramString2, paramString3, paramURL, paramBoolean1, paramBoolean2, paramString4, paramString5, paramArrayOfString1, paramArrayOfString2, paramBoolean3, paramArrayOfCertificate, paramInt1, paramInt2, paramBoolean4, false, false, false);
  }
  
  public int showSecurityDialog(AppInfo paramAppInfo, String paramString1, String paramString2, String paramString3, URL paramURL, boolean paramBoolean1, boolean paramBoolean2, String paramString4, String paramString5, String[] paramArrayOfString1, String[] paramArrayOfString2, boolean paramBoolean3, Certificate[] paramArrayOfCertificate, int paramInt1, int paramInt2, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6)
  {
    return showSecurityDialog0(paramAppInfo, paramString1, paramString2, paramString3, paramURL, paramBoolean1, paramBoolean2, paramString4, paramString5, paramArrayOfString1, paramArrayOfString2, paramBoolean3, paramArrayOfCertificate, paramInt1, paramInt2, paramBoolean4, paramBoolean5, false, paramBoolean6);
  }
  
  public int showSandboxSecurityDialog(AppInfo paramAppInfo, String paramString1, String paramString2, String paramString3, URL paramURL, boolean paramBoolean1, boolean paramBoolean2, String paramString4, String paramString5, String[] paramArrayOfString1, String[] paramArrayOfString2, boolean paramBoolean3, Certificate[] paramArrayOfCertificate, int paramInt1, int paramInt2, boolean paramBoolean4, boolean paramBoolean5)
  {
    return showSecurityDialog0(paramAppInfo, paramString1, paramString2, paramString3, paramURL, paramBoolean1, paramBoolean2, paramString4, paramString5, paramArrayOfString1, paramArrayOfString2, paramBoolean3, paramArrayOfCertificate, paramInt1, paramInt2, paramBoolean4, false, true, paramBoolean5);
  }
  
  public void showAboutJavaDialog()
  {
    Platform.runLater(new Runnable()
    {
      public void run() {}
    });
  }
  
  public int showListDialog(Object paramObject, String paramString1, String paramString2, String paramString3, boolean paramBoolean, Vector paramVector, TreeMap paramTreeMap)
  {
    ListView localListView = new ListView();
    localListView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
    localListView.setItems(FXCollections.observableList(paramVector));
    if (paramVector.size() > 0) {
      localListView.getSelectionModel().select(0);
    }
    return showListDialog0(paramObject, paramString1, paramString2, paramString3, paramBoolean, localListView, paramTreeMap);
  }
  
  public int showUpdateCheckDialog()
  {
    return showUpdateCheckDialog0();
  }
  
  public ConsoleWindow getConsole(ConsoleController paramConsoleController)
  {
    return new FXConsole(paramConsoleController);
  }
  
  public void setDialogHook(DialogHook paramDialogHook) {}
  
  public ModalityHelper getModalityHelper()
  {
    return new FXModalityHelper();
  }
  
  public static int showErrorDialog(Object paramObject1, AppInfo paramAppInfo, final String paramString1, final String paramString2, final String paramString3, final String paramString4, final String paramString5, final Throwable paramThrowable, final Object paramObject2, final Certificate[] paramArrayOfCertificate)
  {
    final Stage localStage = beforeDialog((Stage)paramObject1);
    try
    {
      Exception localException1 = ((Integer)FXPluginToolkit.callAndWait(new Callable()
      {
        public Integer call()
        {
          DialogTemplate localDialogTemplate = new DialogTemplate(this.val$ainfo, localStage, paramString1, paramString2);
          localDialogTemplate.setErrorContent(paramString3, paramString4, paramString5, paramThrowable, paramObject2, paramArrayOfCertificate, false);
          FXUIFactory.placeWindow(localDialogTemplate.getDialog());
          localDialogTemplate.setVisible(true);
          int i = localDialogTemplate.getUserAnswer();
          return new Integer(i);
        }
      })).intValue();
      System.err.println("FXUIFactory.showErrorDialog: shutting down the FX toolkit");
      try {}catch (Exception localException2)
      {
        localException2.printStackTrace();
      }
      localException2 = localException1;
      return localException2;
    }
    catch (Throwable localThrowable)
    {
      int i = -1;
      return i;
    }
    finally
    {
      afterDialog();
    }
  }
  
  public static int showErrorDialog(Object paramObject, AppInfo paramAppInfo, String paramString1, final String paramString2, final String paramString3, String paramString4, final String paramString5, final String paramString6)
  {
    final String str1 = paramString4 == null ? com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("common.ok_btn") : paramString4;
    String str2 = paramString1 == null ? com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("error.default.title") : paramString1;
    final Stage localStage = beforeDialog((Stage)paramObject);
    try
    {
      int i = ((Integer)FXPluginToolkit.callAndWait(new Callable()
      {
        public Integer call()
        {
          String str = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("error.default.title");
          DialogTemplate localDialogTemplate = new DialogTemplate(this.val$ainfo, localStage, str, paramString2);
          localDialogTemplate.setMultiButtonErrorContent(paramString3, str1, paramString5, paramString6);
          FXUIFactory.placeWindow(localDialogTemplate.getDialog());
          localDialogTemplate.setVisible(true);
          int i = localDialogTemplate.getUserAnswer();
          return new Integer(i);
        }
      })).intValue();
      return i;
    }
    catch (Throwable localThrowable)
    {
      int j = -1;
      return j;
    }
    finally
    {
      afterDialog();
    }
  }
  
  public static int showContentDialog(Object paramObject, AppInfo paramAppInfo, final String paramString1, final String paramString2, final boolean paramBoolean, final String paramString3, final String paramString4)
  {
    final Stage localStage = beforeDialog((Stage)paramObject);
    try
    {
      int i = ((Integer)FXPluginToolkit.callAndWait(new Callable()
      {
        public Integer call()
        {
          DialogTemplate localDialogTemplate = new DialogTemplate(this.val$ainfo, localStage, paramString1, null);
          localDialogTemplate.setSimpleContent(paramString2, paramBoolean, null, paramString3, paramString4, false, false);
          FXUIFactory.placeWindow(localDialogTemplate.getDialog());
          localDialogTemplate.setVisible(true);
          int i = localDialogTemplate.getUserAnswer();
          return new Integer(i);
        }
      })).intValue();
      return i;
    }
    catch (Throwable localThrowable)
    {
      int j = -1;
      return j;
    }
    finally
    {
      afterDialog();
    }
  }
  
  public static void showInformationDialog(final Object paramObject, final String paramString1, final String paramString2, final String paramString3)
  {
    final String str = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("common.ok_btn");
    AppInfo localAppInfo = new AppInfo();
    try
    {
      FXPluginToolkit.callAndWait(new Callable()
      {
        public Void call()
        {
          DialogTemplate localDialogTemplate = new DialogTemplate(this.val$ainfo, (Stage)paramObject, paramString1, paramString2);
          localDialogTemplate.setInfoContent(paramString3, str);
          FXUIFactory.placeWindow(localDialogTemplate.getDialog());
          localDialogTemplate.setVisible(true);
          return null;
        }
      });
    }
    catch (Throwable localThrowable)
    {
      Trace.ignored(localThrowable);
    }
  }
  
  public static int showWarningDialog(Object paramObject, AppInfo paramAppInfo, final String paramString1, final String paramString2, final String paramString3, String paramString4, String paramString5)
  {
    AppInfo localAppInfo = paramAppInfo == null ? new AppInfo() : paramAppInfo;
    final String str1 = paramString4 == null ? com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("common.ok_btn") : paramString4;
    final String str2 = paramString5 == null ? com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("common.cancel_btn") : paramString5;
    final Stage localStage = beforeDialog((Stage)paramObject);
    try
    {
      int i = ((Integer)FXPluginToolkit.callAndWait(new Callable()
      {
        public Integer call()
        {
          DialogTemplate localDialogTemplate = new DialogTemplate(this.val$ainfo, localStage, paramString1, paramString2);
          localDialogTemplate.setSimpleContent(paramString3, false, null, str1, str2, true, true);
          FXUIFactory.placeWindow(localDialogTemplate.getDialog());
          localDialogTemplate.setVisible(true);
          int i = localDialogTemplate.getUserAnswer();
          return new Integer(i);
        }
      })).intValue();
      return i;
    }
    catch (Throwable localThrowable)
    {
      int j = -1;
      return j;
    }
    finally
    {
      afterDialog();
    }
  }
  
  public static int showConfirmDialog(Object paramObject, AppInfo paramAppInfo, final String paramString1, final String paramString2, final String paramString3, final String paramString4, final String paramString5, final boolean paramBoolean)
  {
    AppInfo localAppInfo = paramAppInfo == null ? new AppInfo() : paramAppInfo;
    final Stage localStage = beforeDialog((Stage)paramObject);
    try
    {
      int i = ((Integer)FXPluginToolkit.callAndWait(new Callable()
      {
        public Integer call()
        {
          DialogTemplate localDialogTemplate = new DialogTemplate(this.val$ainfo, localStage, paramString1, paramString2);
          localDialogTemplate.setSimpleContent(null, false, paramString3, paramString4, paramString5, true, paramBoolean);
          FXUIFactory.placeWindow(localDialogTemplate.getDialog());
          localDialogTemplate.setVisible(true);
          int i = localDialogTemplate.getUserAnswer();
          return new Integer(i);
        }
      })).intValue();
      return i;
    }
    catch (Throwable localThrowable)
    {
      int j = -1;
      return j;
    }
    finally
    {
      afterDialog();
    }
  }
  
  public static int showMixedCodeDialog(Object paramObject, AppInfo paramAppInfo, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, boolean paramBoolean, String paramString7)
  {
    boolean bool = paramAppInfo != null;
    String str1 = "";
    String str2 = "";
    if (bool)
    {
      str1 = paramAppInfo.getVendor();
      str2 = paramAppInfo.getTitle();
    }
    String str3 = "security.dialog.nativemixcode." + (bool ? "js." : "");
    String str4 = bool ? com.sun.deploy.resources.ResourceManager.getString(str3 + "appLabelWebsite") : "";
    String str5 = bool ? com.sun.deploy.resources.ResourceManager.getString(str3 + "appLabelPublisher") : "";
    String str6 = bool ? paramAppInfo.getDisplayFrom() : "";
    try
    {
      if (NativeMixedCodeDialog.isSupported())
      {
        String str7 = com.sun.deploy.resources.ResourceManager.getString("dialog.template.more.info");
        String str8 = com.sun.deploy.resources.ResourceManager.getString("common.close_btn");
        String str9 = com.sun.deploy.resources.ResourceManager.getString("security.more.info.title");
        String str10 = com.sun.deploy.resources.ResourceManager.getString("security.dialog.mixcode.info1") + "\n\n" + com.sun.deploy.resources.ResourceManager.getString("security.dialog.mixcode.info2") + "\n\n" + com.sun.deploy.resources.ResourceManager.getString("security.dialog.mixcode.info3");
        String str11 = com.sun.deploy.resources.ResourceManager.getString("dialog.template.name");
        paramAppInfo = paramAppInfo == null ? new AppInfo() : paramAppInfo;
        return NativeMixedCodeDialog.show(paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, str7, str8, str9, str10, str11, str2, str4, str6, str5, str1, paramString7);
      }
      return MixedCodeInSwing.show(paramObject, paramAppInfo, paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramBoolean, bool, paramString7);
    }
    catch (Throwable localThrowable)
    {
      Trace.ignored(localThrowable);
    }
    return -1;
  }
  
  public static int showSecurityDialog0(final AppInfo paramAppInfo, final String paramString1, final String paramString2, final String paramString3, final URL paramURL, final boolean paramBoolean1, final boolean paramBoolean2, String paramString4, final String paramString5, final String[] paramArrayOfString1, final String[] paramArrayOfString2, final boolean paramBoolean3, final Certificate[] paramArrayOfCertificate, final int paramInt1, final int paramInt2, final boolean paramBoolean4, final boolean paramBoolean5, final boolean paramBoolean6, final boolean paramBoolean7)
  {
    final Stage localStage = beforeDialog((Stage)null);
    int i;
    try
    {
      i = ((Integer)FXPluginToolkit.callAndWait(new Callable()
      {
        public Integer call()
        {
          String str1 = this.val$okBtnStr;
          String str2 = paramString2;
          String str3 = paramString1;
          String[] arrayOfString = new String[0];
          if (paramArrayOfString2 != null) {
            arrayOfString = paramArrayOfString2;
          }
          DialogTemplate localDialogTemplate = new DialogTemplate(paramAppInfo, localStage, str3, str2);
          int i = arrayOfString.length;
          arrayOfString = FXUIFactory.addDetail(arrayOfString, paramAppInfo, true, true);
          paramAppInfo.setVendor(paramString3);
          paramAppInfo.setFrom(paramURL);
          if (paramBoolean5) {
            localDialogTemplate.setSecurityContent(paramBoolean1, paramBoolean2, this.val$okBtnStr, paramString5, paramArrayOfString1, arrayOfString, i, paramBoolean3, paramArrayOfCertificate, paramInt1, paramInt2, paramBoolean4);
          } else {
            localDialogTemplate.setNewSecurityContent(paramBoolean1, paramBoolean2, str1, paramString5, paramArrayOfString1, arrayOfString, i, paramBoolean3, paramArrayOfCertificate, paramInt1, paramInt2, paramBoolean4, paramBoolean6, paramBoolean7);
          }
          FXUIFactory.placeWindow(localDialogTemplate.getDialog());
          localDialogTemplate.setVisible(true);
          int j = localDialogTemplate.getUserAnswer();
          return new Integer(j);
        }
      })).intValue();
    }
    catch (Throwable localThrowable)
    {
      int j = -1;
      return j;
    }
    finally
    {
      afterDialog();
    }
    return i;
  }
  
  public static int showIntegrationDialog(Object paramObject, AppInfo paramAppInfo)
  {
    final Stage localStage = beforeDialog((Stage)paramObject);
    try
    {
      int i = ((Integer)FXPluginToolkit.callAndWait(new Callable()
      {
        public Integer call()
        {
          String str1 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("integration.title");
          int i = (this.val$ainfo.getDesktopHint()) || (this.val$ainfo.getMenuHint()) ? 1 : 0;
          String str2 = "integration.text.shortcut";
          if (i != 0) {
            str2 = "integration.text.both";
          } else {
            str2 = "integration.text.association";
          }
          String str3 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString(str2);
          String[] arrayOfString1 = new String[0];
          String[] arrayOfString2 = new String[0];
          arrayOfString2 = FXUIFactory.addDetail(arrayOfString2, this.val$ainfo, false, true);
          String[] arrayOfString3 = new String[0];
          arrayOfString3 = FXUIFactory.addDetail(arrayOfString3, this.val$ainfo, true, false);
          boolean bool = arrayOfString2.length + arrayOfString3.length > 1;
          String str4 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("common.ok_btn");
          String str5 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("integration.skip.button");
          DialogTemplate localDialogTemplate = new DialogTemplate(this.val$ainfo, localStage, str1, str3);
          localDialogTemplate.setSecurityContent(false, false, str4, str5, arrayOfString2, arrayOfString3, 0, bool, null, 0, 0, false);
          FXUIFactory.placeWindow(localDialogTemplate.getDialog());
          localDialogTemplate.setVisible(true);
          int j = localDialogTemplate.getUserAnswer();
          return new Integer(j);
        }
      })).intValue();
      return i;
    }
    catch (Throwable localThrowable)
    {
      int j = -1;
      return j;
    }
    finally
    {
      afterDialog();
    }
  }
  
  public static int showUpdateCheckDialog0()
  {
    final String str1 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getMessage("autoupdatecheck.caption");
    final String str2 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getMessage("autoupdatecheck.message");
    final String str3 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getMessage("autoupdatecheck.masthead");
    AppInfo localAppInfo = new AppInfo();
    final Stage localStage = beforeDialog((Stage)null);
    try
    {
      int i = ((Integer)FXPluginToolkit.callAndWait(new Callable()
      {
        public Integer call()
        {
          DialogTemplate localDialogTemplate = new DialogTemplate(this.val$ainfo, localStage, str1, str3);
          localDialogTemplate.setUpdateCheckContent(str2, "autoupdatecheck.buttonYes", "autoupdatecheck.buttonNo", "autoupdatecheck.buttonAskLater");
          FXUIFactory.placeWindow(localDialogTemplate.getDialog());
          localDialogTemplate.setVisible(true);
          int i = localDialogTemplate.getUserAnswer();
          return new Integer(i);
        }
      })).intValue();
      return i;
    }
    catch (Throwable localThrowable)
    {
      int j = 3;
      return j;
    }
    finally
    {
      afterDialog();
    }
  }
  
  public static int showListDialog0(Object paramObject, final String paramString1, final String paramString2, final String paramString3, final boolean paramBoolean, final ListView paramListView, final TreeMap paramTreeMap)
  {
    final String str1 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("common.ok_btn");
    final String str2 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("common.cancel_btn");
    Stage localStage = beforeDialog((Stage)paramObject);
    try
    {
      int i = ((Integer)FXPluginToolkit.callAndWait(new Callable()
      {
        public Integer call()
        {
          DialogTemplate localDialogTemplate = new DialogTemplate(new AppInfo(), this.val$fOwner, paramString1, paramString2);
          localDialogTemplate.setListContent(paramString3, paramListView, paramBoolean, str1, str2, paramTreeMap);
          FXUIFactory.placeWindow(localDialogTemplate.getDialog());
          localDialogTemplate.setVisible(true);
          int i = localDialogTemplate.getUserAnswer();
          return new Integer(i);
        }
      })).intValue();
      return i;
    }
    catch (Throwable localThrowable)
    {
      int j = -1;
      return j;
    }
    finally
    {
      afterDialog();
    }
  }
  
  public static int showApiDialog(Object paramObject, AppInfo paramAppInfo, final String paramString1, final String paramString2, final String paramString3, final String paramString4, final String paramString5, final boolean paramBoolean)
  {
    final String str1 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("common.ok_btn");
    final String str2 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("common.cancel_btn");
    AppInfo localAppInfo = paramAppInfo == null ? new AppInfo() : paramAppInfo;
    final Stage localStage = beforeDialog((Stage)paramObject);
    try
    {
      int i = ((Integer)FXPluginToolkit.callAndWait(new Callable()
      {
        public Integer call()
        {
          DialogTemplate localDialogTemplate = new DialogTemplate(this.val$ainfo, localStage, paramString1, paramString2);
          localDialogTemplate.setApiContent(paramString4, paramString3, paramString5, paramBoolean, str1, str2);
          FXUIFactory.placeWindow(localDialogTemplate.getDialog());
          localDialogTemplate.setVisible(true);
          int i = localDialogTemplate.getUserAnswer();
          return new Integer(i);
        }
      })).intValue();
      return i;
    }
    catch (Throwable localThrowable)
    {
      int j = -1;
      return j;
    }
    finally
    {
      afterDialog();
    }
  }
  
  public static void showExceptionDialog(Object paramObject, Throwable paramThrowable, String paramString1, String paramString2, String paramString3)
  {
    String str1 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("common.ok_btn");
    String str2 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("common.detail.button");
    if (paramString2 == null) {
      paramString2 = paramThrowable.toString();
    }
    if (paramString3 == null) {
      paramString3 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("error.default.title");
    }
    showErrorDialog(paramObject, new AppInfo(), paramString3, paramString1, paramString2, str1, str2, paramThrowable, null, null);
  }
  
  public static void showCertificateExceptionDialog(Object paramObject, AppInfo paramAppInfo, Throwable paramThrowable, String paramString1, String paramString2, Certificate[] paramArrayOfCertificate)
  {
    String str1 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("common.ok_btn");
    String str2 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("common.detail.button");
    if (paramString1 == null) {
      paramString1 = paramThrowable.toString();
    }
    if (paramString2 == null) {
      paramString2 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("error.default.title");
    }
    showErrorDialog(paramObject, paramAppInfo, paramString2, paramString1, null, str1, str2, paramThrowable, null, paramArrayOfCertificate);
  }
  
  public static CredentialInfo showPasswordDialog0(Object paramObject, final String paramString1, final String paramString2, final boolean paramBoolean1, final boolean paramBoolean2, CredentialInfo paramCredentialInfo, final boolean paramBoolean3, final String paramString3)
  {
    final Stage localStage = beforeDialog((Stage)paramObject);
    try
    {
      CredentialInfo localCredentialInfo1 = (CredentialInfo)FXPluginToolkit.callAndWait(new Callable()
      {
        public CredentialInfo call()
        {
          CredentialInfo localCredentialInfo1 = null;
          CredentialInfo localCredentialInfo2 = this.val$info;
          DialogTemplate localDialogTemplate = new DialogTemplate(new AppInfo(), localStage, paramString1, "");
          if (localCredentialInfo2 == null) {
            localCredentialInfo2 = new CredentialInfo();
          }
          localDialogTemplate.setPasswordContent(paramString2, paramBoolean1, paramBoolean2, localCredentialInfo2.getUserName(), localCredentialInfo2.getDomain(), paramBoolean3, localCredentialInfo2.getPassword(), paramString3);
          FXUIFactory.placeWindow(localDialogTemplate.getDialog());
          localDialogTemplate.setVisible(true);
          int i = localDialogTemplate.getUserAnswer();
          if ((i == 0) || (i == 2))
          {
            localCredentialInfo1 = new CredentialInfo();
            localCredentialInfo1.setUserName(localDialogTemplate.getUserName());
            localCredentialInfo1.setDomain(localDialogTemplate.getDomain());
            localCredentialInfo1.setPassword(localDialogTemplate.getPassword());
            localCredentialInfo1.setPasswordSaveApproval(localDialogTemplate.isPasswordSaved());
          }
          return localCredentialInfo1;
        }
      });
      return localCredentialInfo1;
    }
    catch (Throwable localThrowable)
    {
      CredentialInfo localCredentialInfo2 = null;
      return localCredentialInfo2;
    }
    finally
    {
      afterDialog();
    }
  }
  
  public int showSSVDialog(Object paramObject, AppInfo paramAppInfo, String paramString1, String paramString2, String paramString3, String paramString4, URL paramURL, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9)
  {
    return showSSVDialog0(paramObject, paramAppInfo, paramString1, paramString2, paramString3, paramString4, paramURL, paramString5, paramString6, paramString7, paramString8, paramString9);
  }
  
  private File[] showFileChooser_priv(final String paramString1, final String[] paramArrayOfString, final int paramInt, final boolean paramBoolean, String paramString2)
  {
    (File[])AccessController.doPrivileged(new PrivilegedAction()
    {
      public File[] run()
      {
        FileChooser localFileChooser = new FileChooser();
        File localFile = paramString1 == null ? null : new File(paramString1);
        if ((localFile != null) && (!localFile.isDirectory())) {
          localFile = localFile.getParentFile();
        }
        localFileChooser.setInitialDirectory(localFile);
        if (paramArrayOfString != null)
        {
          String[] arrayOfString = new String[paramArrayOfString.length];
          for (int i = 0; i < paramArrayOfString.length; i++) {
            if (paramArrayOfString[i] != null) {
              arrayOfString[i] = ("*." + paramArrayOfString[i]);
            }
          }
          localFileChooser.getExtensionFilters().setAll(new FileChooser.ExtensionFilter[] { new FileChooser.ExtensionFilter(Arrays.toString(paramArrayOfString), Arrays.asList(arrayOfString)) });
        }
        if (paramBoolean) {
          return (File[])localFileChooser.showOpenMultipleDialog(null).toArray(new File[0]);
        }
        if (paramInt == 8) {
          return new File[] { localFileChooser.showOpenDialog(null) };
        }
        return new File[] { localFileChooser.showSaveDialog(null) };
      }
    });
  }
  
  public File[] showFileChooser(final String paramString1, final String[] paramArrayOfString, final int paramInt, final boolean paramBoolean, final String paramString2)
  {
    try
    {
      (File[])FXPluginToolkit.callAndWait(new Callable()
      {
        public File[] call()
        {
          return FXUIFactory.this.showFileChooser_priv(paramString1, paramArrayOfString, paramInt, paramBoolean, paramString2);
        }
      });
    }
    catch (Throwable localThrowable)
    {
      Trace.ignored(localThrowable);
    }
    return null;
  }
  
  public static Pane getDetailPanel(String paramString)
  {
    BorderPane local16 = new BorderPane() {};
    TabPane localTabPane = new TabPane();
    localTabPane.setId("detail-panel-tab-pane");
    localTabPane.getStyleClass().add("floating");
    local16.setCenter(localTabPane);
    HBox localHBox = new HBox();
    localHBox.setId("detail-panel-top-pane");
    localHBox.setAlignment(Pos.BASELINE_LEFT);
    Label localLabel1 = new Label(com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("launcherrordialog.error.label"));
    localLabel1.setId("error-dialog-error-label");
    localLabel1.setMinWidth(Double.NEGATIVE_INFINITY);
    localHBox.getChildren().add(localLabel1);
    String[] arrayOfString = paramString.split("<split>");
    UITextArea localUITextArea = new UITextArea(arrayOfString[0]);
    localUITextArea.setId("detail-panel-msg0");
    localUITextArea.setPrefWidth(-1.0D);
    localHBox.getChildren().add(localUITextArea);
    local16.setTop(localHBox);
    int i = 1;
    while (i + 1 < arrayOfString.length)
    {
      Label localLabel2 = new Label();
      localLabel2.getStyleClass().add("multiline-text");
      localLabel2.setWrapText(true);
      localLabel2.setText(arrayOfString[(i + 1)]);
      Tab localTab = new Tab();
      localTab.setText(arrayOfString[i]);
      ScrollPane localScrollPane = new ScrollPane();
      localScrollPane.setContent(localLabel2);
      localScrollPane.setFitToWidth(true);
      localTab.setContent(localScrollPane);
      localTabPane.getTabs().add(localTab);
      i += 2;
    }
    return local16;
  }
  
  private static Stage beforeDialog(Stage paramStage)
  {
    return paramStage;
  }
  
  private static void afterDialog() {}
  
  public static String[] addDetail(String[] paramArrayOfString, AppInfo paramAppInfo, boolean paramBoolean1, boolean paramBoolean2)
  {
    String str1 = paramAppInfo.getTitle();
    if (str1 == null) {
      str1 = "";
    }
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < paramArrayOfString.length; i++) {
      localArrayList.add(paramArrayOfString[i]);
    }
    if (paramBoolean1)
    {
      String str2 = null;
      if ((paramAppInfo.getDesktopHint()) && (paramAppInfo.getMenuHint())) {
        str2 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("install.windows.both.message");
      } else if (paramAppInfo.getDesktopHint()) {
        str2 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("install.desktop.message");
      } else if (paramAppInfo.getMenuHint()) {
        str2 = com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager.getString("install.windows.menu.message");
      }
      if (str2 != null) {
        localArrayList.add(str2);
      }
    }
    return (String[])localArrayList.toArray(paramArrayOfString);
  }
  
  public static int showSSVDialog0(Object paramObject, AppInfo paramAppInfo, final String paramString1, final String paramString2, final String paramString3, final String paramString4, final URL paramURL, final String paramString5, final String paramString6, final String paramString7, final String paramString8, final String paramString9)
  {
    final Stage localStage = beforeDialog((Stage)paramObject);
    try
    {
      int i = ((Integer)FXPluginToolkit.callAndWait(new Callable()
      {
        public Integer call()
        {
          DialogTemplate localDialogTemplate = new DialogTemplate(this.val$ainfo, localStage, paramString1, paramString2);
          localDialogTemplate.setSSVContent(paramString3, paramString4, paramURL, paramString5, paramString6, paramString7, paramString8, paramString9);
          FXUIFactory.placeWindow(localDialogTemplate.getDialog());
          localDialogTemplate.setVisible(true);
          int i = localDialogTemplate.getUserAnswer();
          return new Integer(i);
        }
      })).intValue();
      return i;
    }
    catch (Throwable localThrowable)
    {
      int j = -1;
      return j;
    }
    finally
    {
      afterDialog();
    }
  }
  
  public static void placeWindow(Window paramWindow)
  {
    paramWindow.centerOnScreen();
  }
  
  private static Object invokeLater(Runnable paramRunnable, Integer paramInteger)
    throws Exception
  {
    if (paramRunnable != null) {
      (Integer)DeploySysRun.executePrivileged(new DeploySysAction()new Integer
      {
        public Object execute()
        {
          Platform.runLater(this.val$r);
          return null;
        }
      }, new Integer(-1));
    }
    return Integer.valueOf(-1);
  }
  
  public int showSSV3Dialog(final Object paramObject, final AppInfo paramAppInfo, final int paramInt, final String paramString1, final String paramString2, final String paramString3, final String paramString4, final String paramString5, final String paramString6, final String paramString7, final String paramString8, final String paramString9, final String paramString10, final String paramString11, final URL paramURL)
  {
    try
    {
      Class localClass = Class.forName("com.sun.deploy.config.Config", false, Thread.currentThread().getContextClassLoader());
      Method localMethod = localClass.getDeclaredMethod("getStringProperty", new Class[] { String.class });
      Object localObject1 = localMethod.invoke(localClass, new Object[] { "deployment.sqe.automation.run" });
      if (((localObject1 instanceof String)) && ("true".equals((String)localObject1))) {
        return 0;
      }
    }
    catch (Exception localException)
    {
      Trace.ignoredException(localException);
    }
    Stage localStage = beforeDialog((Stage)paramObject);
    try
    {
      int i = ((Integer)FXPluginToolkit.callAndWait(new Callable()
      {
        public Integer call()
        {
          return Integer.valueOf(FXSSV3Dialog.showSSV3Dialog(paramObject, paramAppInfo, paramInt, paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, paramString11, paramURL));
        }
      })).intValue();
      return i;
    }
    catch (Throwable localThrowable)
    {
      int j = -1;
      return j;
    }
    finally
    {
      afterDialog();
    }
  }
  
  public int showPublisherInfo(Object paramObject, final AppInfo paramAppInfo, final String paramString1, final String paramString2, final String paramString3, final String paramString4, final String paramString5, final String paramString6)
  {
    final Stage localStage = beforeDialog((Stage)paramObject);
    try
    {
      int i = ((Integer)FXPluginToolkit.callAndWait(new Callable()
      {
        public Integer call()
        {
          DialogTemplate localDialogTemplate = new DialogTemplate(paramAppInfo, localStage, paramString1, paramString2);
          Pane localPane = null;
          if (paramString6 != null) {
            localPane = FXUIFactory.getDetailPanel(paramString6);
          }
          localDialogTemplate.setPublisherInfo(paramString3, paramString4, paramString5, localPane, false);
          FXUIFactory.placeWindow(localDialogTemplate.getDialog());
          localDialogTemplate.setVisible(true);
          int i = localDialogTemplate.getUserAnswer();
          return new Integer(i);
        }
      })).intValue();
      return i;
    }
    catch (Throwable localThrowable)
    {
      int j = -1;
      return j;
    }
    finally
    {
      afterDialog();
    }
  }
  
  public int showBlockedDialog(Object paramObject, final AppInfo paramAppInfo, final String paramString1, final String paramString2, final String paramString3, final String paramString4, final String paramString5, final String paramString6)
  {
    final Stage localStage = beforeDialog((Stage)paramObject);
    try
    {
      int i = ((Integer)FXPluginToolkit.callAndWait(new Callable()
      {
        public Integer call()
        {
          DialogTemplate localDialogTemplate = new DialogTemplate(paramAppInfo, localStage, paramString1, paramString2);
          Pane localPane = null;
          if (paramString6 != null) {
            localPane = FXUIFactory.getDetailPanel(paramString6);
          }
          String str = paramAppInfo.getBlockedText();
          localDialogTemplate.setBlockedDialogInfo(paramString3, str, paramString4, paramString5, localPane, false);
          FXUIFactory.placeWindow(localDialogTemplate.getDialog());
          localDialogTemplate.setVisible(true);
          int i = localDialogTemplate.getUserAnswer();
          return new Integer(i);
        }
      })).intValue();
      return i;
    }
    catch (Throwable localThrowable)
    {
      Trace.ignored(localThrowable);
      int j = -1;
      return j;
    }
    finally
    {
      afterDialog();
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\FXUIFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */