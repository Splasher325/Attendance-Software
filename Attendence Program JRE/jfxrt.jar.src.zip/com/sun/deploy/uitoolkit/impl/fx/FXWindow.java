package com.sun.deploy.uitoolkit.impl.fx;

import com.sun.deploy.uitoolkit.SynthesizedEventListener;
import com.sun.deploy.uitoolkit.Window;
import com.sun.deploy.uitoolkit.Window.DisposeListener;
import com.sun.deploy.uitoolkit.Window.WindowSize;
import com.sun.javafx.tk.AppletWindow;
import com.sun.javafx.tk.Toolkit;
import java.util.Map;
import javafx.stage.Stage;

public class FXWindow
  extends Window
  implements AppletStageManager, SynthesizedEventListener
{
  private AppletWindow appletWindow;
  private int width = 0;
  private int height = 0;
  private Stage appletStage;
  private Stage preloaderStage;
  private Stage errorStage;
  
  FXWindow(long paramLong, String paramString)
  {
    this.appletWindow = Toolkit.getToolkit().createAppletWindow(paramLong, paramString);
    this.width = this.appletWindow.getWidth();
    this.height = this.appletWindow.getHeight();
  }
  
  public Object getWindowObject()
  {
    return this.appletWindow;
  }
  
  public void synthesizeEvent(Map paramMap)
  {
    this.appletWindow.dispatchEvent(paramMap);
  }
  
  public void requestFocus() {}
  
  public int getWindowLayerID()
  {
    return this.appletWindow.getRemoteLayerId();
  }
  
  public void setBackground(int paramInt)
  {
    this.appletWindow.setBackgroundColor(paramInt);
  }
  
  public void setForeground(int paramInt)
  {
    this.appletWindow.setForegroundColor(paramInt);
  }
  
  public void setVisible(boolean paramBoolean)
  {
    this.appletWindow.setVisible(paramBoolean);
  }
  
  public void setSize(int paramInt1, int paramInt2)
  {
    this.width = paramInt1;
    this.height = paramInt2;
    this.appletWindow.setSize(paramInt1, paramInt2);
    float f = this.appletWindow.getUIScale();
    if (this.appletStage != null)
    {
      this.appletStage.setWidth(paramInt1 / f);
      this.appletStage.setHeight(paramInt2 / f);
    }
    if (this.preloaderStage != null)
    {
      this.preloaderStage.setWidth(paramInt1 / f);
      this.preloaderStage.setHeight(paramInt2 / f);
    }
    if (this.errorStage != null)
    {
      this.errorStage.setWidth(paramInt1 / f);
      this.errorStage.setHeight(paramInt2 / f);
    }
  }
  
  public Window.WindowSize getSize()
  {
    this.width = this.appletWindow.getWidth();
    this.height = this.appletWindow.getHeight();
    return new Window.WindowSize(this, this.width, this.height);
  }
  
  public void dispose()
  {
    if (null != this.appletStage)
    {
      this.appletStage.close();
      this.appletStage = null;
    }
    if (null != this.preloaderStage)
    {
      this.preloaderStage.close();
      this.preloaderStage = null;
    }
    if (null != this.errorStage)
    {
      this.errorStage.close();
      this.errorStage = null;
    }
    this.appletWindow = null;
    Toolkit.getToolkit().closeAppletWindow();
  }
  
  public void dispose(Window.DisposeListener paramDisposeListener, long paramLong)
  {
    dispose();
  }
  
  public void setPosition(int paramInt1, int paramInt2)
  {
    this.appletWindow.setPosition(paramInt1, paramInt2);
  }
  
  public synchronized Stage getAppletStage()
  {
    if (this.appletStage == null) {
      this.appletStage = createNewStage();
    }
    return this.appletStage;
  }
  
  public Stage getPreloaderStage()
  {
    if (this.preloaderStage == null)
    {
      this.preloaderStage = createNewStage();
      if (null == this.errorStage) {
        this.appletWindow.setStageOnTop(this.preloaderStage);
      }
    }
    return this.preloaderStage;
  }
  
  public Stage getErrorStage()
  {
    if (this.errorStage == null)
    {
      this.errorStage = createNewStage();
      this.appletWindow.setStageOnTop(this.errorStage);
    }
    return this.errorStage;
  }
  
  private Stage createNewStage()
  {
    Stage localStage = new Stage();
    localStage.impl_setPrimary(true);
    float f = this.appletWindow.getUIScale();
    localStage.setWidth(this.width / f);
    localStage.setHeight(this.height / f);
    localStage.setX(this.appletWindow.getPositionX() / f);
    localStage.setY(this.appletWindow.getPositionY() / f);
    localStage.setResizable(false);
    return localStage;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\FXWindow.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */