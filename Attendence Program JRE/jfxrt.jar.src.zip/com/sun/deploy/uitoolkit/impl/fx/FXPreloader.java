package com.sun.deploy.uitoolkit.impl.fx;

import com.sun.applet2.Applet2;
import com.sun.applet2.Applet2Context;
import com.sun.applet2.preloader.CancelException;
import com.sun.applet2.preloader.event.AppletInitEvent;
import com.sun.applet2.preloader.event.ApplicationExitEvent;
import com.sun.applet2.preloader.event.DownloadEvent;
import com.sun.applet2.preloader.event.ErrorEvent;
import com.sun.applet2.preloader.event.PreloaderEvent;
import com.sun.applet2.preloader.event.UserDeclinedEvent;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.uitoolkit.Applet2Adapter;
import com.sun.deploy.uitoolkit.impl.fx.ui.FXDefaultPreloader;
import com.sun.javafx.applet.ExperimentalExtensions;
import com.sun.javafx.applet.FXApplet2;
import com.sun.javafx.applet.Splash;
import com.sun.javafx.application.ParametersImpl;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedExceptionAction;
import java.util.Map;
import java.util.concurrent.Callable;
import javafx.application.Application;
import javafx.application.Preloader.ErrorNotification;
import javafx.application.Preloader.PreloaderNotification;
import javafx.application.Preloader.ProgressNotification;
import javafx.application.Preloader.StateChangeNotification;
import javafx.application.Preloader.StateChangeNotification.Type;
import javafx.stage.Stage;

public class FXPreloader
  extends com.sun.applet2.preloader.Preloader
{
  private static final Object lock = new Object();
  private static FXPreloader defaultPreloader = null;
  private javafx.application.Preloader fxPreview = null;
  private FXWindow window = null;
  private boolean seenFatalError = false;
  
  FXPreloader()
  {
    this.fxPreview = new FXDefaultPreloader();
  }
  
  FXPreloader(Applet2Context paramApplet2Context, FXWindow paramFXWindow)
  {
    this.window = paramFXWindow;
    try
    {
      FXPluginToolkit.callAndWait(new Callable()
      {
        public Object call()
        {
          FXPreloader.this.fxPreview = new FXDefaultPreloader();
          return null;
        }
      });
    }
    catch (RuntimeException localRuntimeException)
    {
      throw localRuntimeException;
    }
    catch (Exception localException)
    {
      throw new RuntimeException(localException);
    }
    String[] arrayOfString = Utils.getUnnamed(paramApplet2Context);
    Map localMap = Utils.getNamedParameters(paramApplet2Context);
    ParametersImpl.registerParameters(this.fxPreview, new ParametersImpl(localMap, arrayOfString));
  }
  
  FXPreloader(final Class<javafx.application.Preloader> paramClass, Applet2Context paramApplet2Context, FXWindow paramFXWindow)
    throws InstantiationException, IllegalAccessException
  {
    this.window = paramFXWindow;
    if (!javafx.application.Preloader.class.isAssignableFrom(paramClass)) {
      throw new IllegalArgumentException("Unrecognized FX Preloader class");
    }
    try
    {
      FXPluginToolkit.callAndWait(new Callable()
      {
        public Object call()
          throws InstantiationException, IllegalAccessException
        {
          FXPreloader.this.fxPreview = ((javafx.application.Preloader)paramClass.newInstance());
          return null;
        }
      });
    }
    catch (InstantiationException localInstantiationException)
    {
      throw localInstantiationException;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw localIllegalAccessException;
    }
    catch (RuntimeException localRuntimeException)
    {
      throw localRuntimeException;
    }
    catch (Exception localException)
    {
      throw new RuntimeException(localException);
    }
    String[] arrayOfString = Utils.getUnnamed(paramApplet2Context);
    Map localMap = Utils.getNamedParameters(paramApplet2Context);
    ParametersImpl.registerParameters(this.fxPreview, new ParametersImpl(localMap, arrayOfString));
  }
  
  static FXPreloader getDefaultPreloader()
  {
    synchronized (lock)
    {
      if (defaultPreloader != null) {
        defaultPreloader = new FXPreloader();
      }
    }
    return defaultPreloader;
  }
  
  public static void notfiyCurrentPreloaderOnExit()
  {
    Notifier.send(new ApplicationExitEvent());
  }
  
  public static void notifyCurrentPreloaderOnError(ErrorEvent paramErrorEvent)
  {
    Notifier.send(paramErrorEvent);
  }
  
  public static void notifyCurrentPreloader(Preloader.PreloaderNotification paramPreloaderNotification)
  {
    Notifier.send(new UserEvent(paramPreloaderNotification));
  }
  
  public Object getOwner()
  {
    return null;
  }
  
  public boolean handleEvent(PreloaderEvent paramPreloaderEvent)
    throws CancelException
  {
    Boolean localBoolean = Boolean.valueOf(false);
    if ((paramPreloaderEvent instanceof ErrorEvent))
    {
      localObject = (FXApplet2Adapter)FXApplet2Adapter.get();
      ((FXApplet2Adapter)localObject).abortApplet();
    }
    Object localObject = new FXDispatcher(paramPreloaderEvent);
    try
    {
      localBoolean = (Boolean)FXPluginToolkit.callAndWait((Callable)localObject);
    }
    catch (CancelException localCancelException)
    {
      throw localCancelException;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return localBoolean.booleanValue();
  }
  
  void start()
    throws Exception
  {
    this.fxPreview.init();
    FXPluginToolkit.callAndWait(new Callable()
    {
      public Object call()
        throws Exception
      {
        Stage localStage;
        if (FXPreloader.this.window == null)
        {
          localStage = new Stage();
          localStage.impl_setPrimary(true);
        }
        else
        {
          localStage = FXPreloader.this.window.getPreloaderStage();
        }
        FXPreloader.this.fxPreview.start(localStage);
        if (!(FXPreloader.this.fxPreview instanceof FXDefaultPreloader)) {
          FXPreloader.hideSplash();
        }
        return null;
      }
    });
  }
  
  public static void hideSplash()
  {
    ExperimentalExtensions localExperimentalExtensions = ExperimentalExtensions.get();
    if (localExperimentalExtensions != null) {
      localExperimentalExtensions.getSplash().hide();
    }
  }
  
  void stop()
    throws Exception
  {
    if (this.fxPreview != null) {
      this.fxPreview.stop();
    }
  }
  
  static
  {
    Class localClass1 = Notifier.class;
    Class localClass2 = UserEvent.class;
  }
  
  class FXDispatcher
    implements Callable<Boolean>
  {
    PreloaderEvent pe;
    
    FXDispatcher(PreloaderEvent paramPreloaderEvent)
    {
      this.pe = paramPreloaderEvent;
    }
    
    private void gotFatalError()
    {
      FXPreloader.this.seenFatalError = true;
      FXApplet2Adapter localFXApplet2Adapter = (FXApplet2Adapter)FXApplet2Adapter.get();
      localFXApplet2Adapter.setExitOnIdle(true);
    }
    
    public Boolean call()
      throws Exception
    {
      if (FXPreloader.this.seenFatalError) {
        throw new CancelException("Cancel launch after fatal error");
      }
      switch (this.pe.getType())
      {
      case 5: 
        AppletInitEvent localAppletInitEvent = (AppletInitEvent)this.pe;
        Application localApplication = null;
        Applet2 localApplet2 = localAppletInitEvent.getApplet();
        if ((localApplet2 != null) && ((localApplet2 instanceof FXApplet2))) {
          localApplication = ((FXApplet2)localApplet2).getApplication();
        }
        switch (localAppletInitEvent.getSubtype())
        {
        case 2: 
          FXPreloader.this.fxPreview.handleStateChangeNotification(new Preloader.StateChangeNotification(Preloader.StateChangeNotification.Type.BEFORE_LOAD));
          break;
        case 3: 
          FXPreloader.this.fxPreview.handleStateChangeNotification(new Preloader.StateChangeNotification(Preloader.StateChangeNotification.Type.BEFORE_INIT, localApplication));
          break;
        case 4: 
          FXPreloader.this.fxPreview.handleStateChangeNotification(new Preloader.StateChangeNotification(Preloader.StateChangeNotification.Type.BEFORE_START, localApplication));
          break;
        }
        return Boolean.valueOf(true);
      case 1: 
        return Boolean.valueOf(true);
      case 1000: 
        Preloader.PreloaderNotification localPreloaderNotification = ((FXPreloader.UserEvent)this.pe).get();
        FXPreloader.this.fxPreview.handleApplicationNotification(localPreloaderNotification);
        return Boolean.valueOf(true);
      case 3: 
        DownloadEvent localDownloadEvent = (DownloadEvent)this.pe;
        double d = localDownloadEvent.getOverallPercentage() / 100.0D;
        FXPreloader.this.fxPreview.handleProgressNotification(new Preloader.ProgressNotification(d));
        return Boolean.valueOf(true);
      case 6: 
        ErrorEvent localErrorEvent = (ErrorEvent)this.pe;
        String str1 = localErrorEvent.getLocation() != null ? localErrorEvent.getLocation().toString() : null;
        Throwable localThrowable = localErrorEvent.getException();
        String str2 = localErrorEvent.getValue();
        if (str2 == null) {
          str2 = localThrowable != null ? localThrowable.getMessage() : "unknown error";
        }
        gotFatalError();
        return Boolean.valueOf(FXPreloader.this.fxPreview.handleErrorNotification(new Preloader.ErrorNotification(str1, str2, localThrowable)));
      case 7: 
        UserDeclinedEvent localUserDeclinedEvent = (UserDeclinedEvent)this.pe;
        String str3 = localUserDeclinedEvent.getLocation();
        return Boolean.valueOf(FXPreloader.this.fxPreview.handleErrorNotification(new FXPreloader.UserDeclinedNotification(FXPreloader.this, str3)));
      }
      return Boolean.valueOf(false);
    }
  }
  
  static class Notifier
    implements PrivilegedExceptionAction<Void>
  {
    PreloaderEvent pe;
    
    Notifier(PreloaderEvent paramPreloaderEvent)
    {
      this.pe = paramPreloaderEvent;
    }
    
    static void send(PreloaderEvent paramPreloaderEvent)
    {
      try
      {
        AccessController.doPrivileged(new Notifier(paramPreloaderEvent));
      }
      catch (Exception localException)
      {
        Trace.ignoredException(localException);
      }
    }
    
    public Void run()
      throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, CancelException
    {
      Applet2Adapter localApplet2Adapter = FXApplet2Adapter.get();
      if (localApplet2Adapter != null)
      {
        Class localClass = Class.forName("com.sun.javaws.progress.Progress");
        Method localMethod = localClass.getMethod("get", new Class[] { Applet2Adapter.class });
        com.sun.applet2.preloader.Preloader localPreloader = (com.sun.applet2.preloader.Preloader)localMethod.invoke(null, new Object[] { localApplet2Adapter });
        localPreloader.handleEvent(this.pe);
      }
      return null;
    }
  }
  
  class UserDeclinedNotification
    extends Preloader.ErrorNotification
  {
    public UserDeclinedNotification(String paramString)
    {
      super("User declined to grant permissions to the application.", null);
    }
  }
  
  static class UserEvent
    extends PreloaderEvent
  {
    public static final int CUSTOM_USER_EVENT = 1000;
    Preloader.PreloaderNotification pe;
    
    UserEvent(Preloader.PreloaderNotification paramPreloaderNotification)
    {
      super();
      this.pe = paramPreloaderNotification;
    }
    
    Preloader.PreloaderNotification get()
    {
      return this.pe;
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\FXPreloader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */