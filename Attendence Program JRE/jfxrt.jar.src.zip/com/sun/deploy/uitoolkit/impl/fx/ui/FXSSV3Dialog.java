package com.sun.deploy.uitoolkit.impl.fx.ui;

import com.sun.deploy.ui.AppInfo;
import com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager;
import java.net.URL;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class FXSSV3Dialog
{
  private static final int MAIN_TEXT_WIDTH = 460;
  private static final int RISK_TEXT_WIDTH = 540;
  private static final int MAX_URL_WIDTH = 360;
  private AppInfo ainfo;
  private String masthead;
  private String mainText;
  private String location;
  private String prompt;
  private String multiPrompt;
  private String multiText;
  private String runKey;
  private String updateText;
  private String cancelText;
  private URL updateURL;
  private String locationURL = "";
  private String mainJNLPURL;
  private String documentBaseURL;
  private String locationTooltip = "";
  private String mainJNLPTooltip;
  private String documentBaseTooltip;
  private int userAnswer = 1;
  private FXDialog dialog;
  private Button runButton;
  private Button updateButton;
  private Button cancelButton;
  private CheckBox multiClickCheckBox;
  
  public static int showSSV3Dialog(Object paramObject, AppInfo paramAppInfo, int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, URL paramURL)
  {
    FXSSV3Dialog localFXSSV3Dialog = new FXSSV3Dialog(paramObject, getMessage(paramString1));
    localFXSSV3Dialog.ainfo = paramAppInfo;
    localFXSSV3Dialog.masthead = getMessage(paramString2);
    localFXSSV3Dialog.mainText = getMessage(paramString3);
    localFXSSV3Dialog.location = getMessage(paramString4);
    localFXSSV3Dialog.prompt = getMessage(paramString5);
    localFXSSV3Dialog.multiPrompt = getMessage(paramString6);
    localFXSSV3Dialog.multiText = getMessage(paramString7);
    localFXSSV3Dialog.runKey = paramString8;
    localFXSSV3Dialog.updateText = getMessage(paramString9);
    localFXSSV3Dialog.cancelText = getMessage(paramString10);
    localFXSSV3Dialog.updateURL = paramURL;
    localFXSSV3Dialog.initComponents();
    localFXSSV3Dialog.setVisible(true);
    return localFXSSV3Dialog.getAnswer();
  }
  
  private FXSSV3Dialog(Object paramObject, String paramString)
  {
    Stage localStage = null;
    if ((paramObject instanceof Stage)) {
      localStage = (Stage)paramObject;
    }
    this.dialog = new FXDialog(paramString, localStage, true);
  }
  
  private void initComponents()
  {
    try
    {
      try
      {
        this.locationURL = this.ainfo.getDisplayFrom();
        this.locationTooltip = this.ainfo.getFrom().toString();
      }
      catch (Exception localException)
      {
        this.locationURL = "";
      }
      if (this.ainfo.shouldDisplayMainJNLP())
      {
        this.mainJNLPURL = this.ainfo.getDisplayMainJNLP();
        this.mainJNLPTooltip = DialogTemplate.getDisplayMainJNLPTooltip(this.ainfo);
      }
      if (this.ainfo.shouldDisplayDocumentBase())
      {
        this.documentBaseURL = this.ainfo.getDisplayDocumentBase();
        this.documentBaseTooltip = this.ainfo.getDocumentBase().toString();
      }
      this.dialog.setResizable(false);
      this.dialog.setIconifiable(false);
      Pane localPane = createContentPane();
      localPane.getChildren().add(createMastHead());
      localPane.getChildren().add(createMainContent());
      localPane.getChildren().add(createOkCancelPanel());
    }
    catch (Throwable localThrowable)
    {
      localThrowable.printStackTrace();
    }
  }
  
  private Pane createContentPane()
  {
    VBox local1 = new VBox()
    {
      protected double computePrefHeight(double paramAnonymousDouble)
      {
        double d = super.computePrefHeight(paramAnonymousDouble);
        return d;
      }
    };
    local1.setId("ssv3-content-panel");
    this.dialog.setContentPane(local1);
    return local1;
  }
  
  private Node createMastHead()
  {
    UITextArea localUITextArea = new UITextArea(this.masthead);
    localUITextArea.setId("security-masthead-label");
    return localUITextArea;
  }
  
  private Pane createMainContent()
  {
    Pane localPane = createWarningPanel();
    BorderPane localBorderPane = new BorderPane();
    localBorderPane.setTop(localPane);
    if (this.multiText == null)
    {
      UITextArea localUITextArea = new UITextArea(460.0D);
      localUITextArea.setText(this.prompt);
      localUITextArea.setId("ssv3-prompt");
      localBorderPane.setBottom(createWarningMorePrompt(localUITextArea));
    }
    return localBorderPane;
  }
  
  private Pane createWarningPanel()
  {
    BorderPane localBorderPane = new BorderPane();
    localBorderPane.setLeft(createShieldIcon());
    VBox localVBox = createLocationPanel();
    localBorderPane.setCenter(localVBox);
    return localBorderPane;
  }
  
  private VBox createLocationPanel()
  {
    VBox localVBox = new VBox();
    Text localText = new Text(this.mainText);
    localText.setId("ssv3-main-text");
    localText.setWrappingWidth(460.0D);
    localVBox.getChildren().add(localText);
    Label localLabel1 = new Label(this.location);
    localLabel1.setText(this.location);
    localLabel1.setId("ssv3-location-label");
    Label localLabel2 = new Label(this.locationURL);
    localLabel2.setTooltip(new Tooltip(this.locationTooltip));
    localLabel2.setId("ssv3-location-url");
    GridPane localGridPane = new GridPane();
    localGridPane.setId("ssv3-location-label-url");
    localGridPane.add(localLabel1, 0, 0);
    localGridPane.add(localLabel2, 1, 0);
    int i = 1;
    if (this.mainJNLPURL != null)
    {
      localLabel2 = new Label(this.mainJNLPURL);
      localLabel2.setTooltip(new Tooltip(this.mainJNLPTooltip));
      localLabel2.setMaxWidth(360.0D);
      localLabel2.setId("ssv3-location-url");
      localGridPane.add(localLabel2, 1, i++);
    }
    if (this.documentBaseURL != null)
    {
      localLabel2 = new Label(this.documentBaseURL);
      localLabel2.setTooltip(new Tooltip(this.documentBaseTooltip));
      localLabel2.setMaxWidth(360.0D);
      localLabel2.setId("ssv3-location-url");
      localGridPane.add(localLabel2, 1, i);
    }
    localVBox.getChildren().add(localGridPane);
    return localVBox;
  }
  
  private Pane createShieldIcon()
  {
    Label localLabel = new Label(null, ResourceManager.getIcon("warning48s.image"));
    localLabel.setId("ssv3-shield");
    VBox localVBox = new VBox();
    localVBox.getChildren().add(localLabel);
    return localVBox;
  }
  
  private Pane createOkCancelPanel()
  {
    HBox localHBox = new HBox();
    localHBox.getStyleClass().add("security-button-bar");
    this.runButton = new Button(getMessage(this.runKey));
    this.runButton.setMnemonicParsing(true);
    Button localButton = null;
    localHBox.getChildren().add(this.runButton);
    this.runButton.setOnAction(new EventHandler()
    {
      public void handle(ActionEvent paramAnonymousActionEvent)
      {
        FXSSV3Dialog.this.runAction();
      }
    });
    this.cancelButton = new Button(this.cancelText);
    this.cancelButton.setOnAction(new EventHandler()
    {
      public void handle(ActionEvent paramAnonymousActionEvent)
      {
        FXSSV3Dialog.this.userAnswer = 1;
        FXSSV3Dialog.this.closeDialog();
      }
    });
    this.cancelButton.setCancelButton(true);
    if (this.updateText != null)
    {
      this.updateButton = new Button(this.updateText);
      this.updateButton.setOnAction(new EventHandler()
      {
        public void handle(ActionEvent paramAnonymousActionEvent)
        {
          FXSSV3Dialog.this.updateAction();
        }
      });
      localHBox.getChildren().add(this.updateButton);
      localButton = this.updateButton;
    }
    else
    {
      localButton = this.cancelButton;
    }
    localHBox.getChildren().add(this.cancelButton);
    VBox localVBox = new VBox();
    createMultSelectionBox(localVBox);
    localVBox.getChildren().add(localHBox);
    setDefaultButton(localButton);
    return localVBox;
  }
  
  private void createMultSelectionBox(VBox paramVBox)
  {
    if ((this.multiPrompt != null) && (this.multiText != null))
    {
      this.runButton.setDisable(true);
      Label localLabel = new Label(this.multiPrompt);
      localLabel.setId("ssv3-multi-click");
      VBox localVBox1 = createWarningMorePrompt(localLabel);
      VBox localVBox2 = new VBox(8.0D);
      localVBox2.getChildren().add(localVBox1);
      localVBox2.getChildren().add(localLabel);
      HBox localHBox = new HBox();
      localHBox.getChildren().add(localVBox2);
      paramVBox.getChildren().add(localHBox);
      this.multiClickCheckBox = new CheckBox(this.multiText);
      this.multiClickCheckBox.setId("ssv3-checkbox");
      paramVBox.getChildren().add(this.multiClickCheckBox);
      this.multiClickCheckBox.setOnAction(new EventHandler()
      {
        public void handle(ActionEvent paramAnonymousActionEvent)
        {
          FXSSV3Dialog.this.runButton.setDisable(!FXSSV3Dialog.this.multiClickCheckBox.isSelected());
          if (FXSSV3Dialog.this.multiClickCheckBox.isSelected()) {
            FXSSV3Dialog.this.setDefaultButton(FXSSV3Dialog.this.runButton);
          } else if (FXSSV3Dialog.this.updateButton != null) {
            FXSSV3Dialog.this.setDefaultButton(FXSSV3Dialog.this.updateButton);
          } else if (FXSSV3Dialog.this.cancelButton != null) {
            FXSSV3Dialog.this.setDefaultButton(FXSSV3Dialog.this.cancelButton);
          }
        }
      });
    }
  }
  
  private void setDefaultButton(Button paramButton)
  {
    this.runButton.setDefaultButton(false);
    if (this.updateButton != null) {
      this.updateButton.setDefaultButton(false);
    }
    this.cancelButton.setDefaultButton(false);
    paramButton.setDefaultButton(true);
  }
  
  private void runAction()
  {
    this.userAnswer = 0;
    closeDialog();
  }
  
  private void updateAction()
  {
    DialogTemplate.showDocument(this.updateURL.toExternalForm());
  }
  
  private void closeDialog()
  {
    setVisible(false);
  }
  
  public void setVisible(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      final FXDialog localFXDialog = this.dialog;
      this.dialog.centerOnScreen();
      Runnable local6 = new Runnable()
      {
        public void run()
        {
          localFXDialog.showAndWait();
        }
      };
      local6.run();
    }
    else
    {
      this.dialog.hide();
    }
  }
  
  private int getAnswer()
  {
    return this.userAnswer;
  }
  
  private VBox createWarningMorePrompt(Node paramNode)
  {
    VBox localVBox = new VBox();
    localVBox.getChildren().add(getSecurityWarning());
    localVBox.getChildren().add(getMoreInfoButton());
    localVBox.getChildren().add(paramNode);
    return localVBox;
  }
  
  private Hyperlink getMoreInfoButton()
  {
    Hyperlink localHyperlink = null;
    localHyperlink = new Hyperlink(getMessage("dialog.template.more.info2"));
    localHyperlink.setMnemonicParsing(true);
    localHyperlink.setId("bottom-more-info-link");
    localHyperlink.setOnAction(new EventHandler()
    {
      public void handle(ActionEvent paramAnonymousActionEvent)
      {
        FXSSV3Dialog.this.showMoreInfo();
      }
    });
    return localHyperlink;
  }
  
  private static String getMessage(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    return ResourceManager.getMessage(paramString);
  }
  
  private BorderPane getSecurityWarning()
  {
    BorderPane localBorderPane = new BorderPane();
    Text localText = new Text(getMessage("dialog.unsigned.security.risk.warning"));
    localText.setFill(Color.web("0xCC0000"));
    localText.setFont(Font.font("System", FontWeight.BOLD, 15.0D));
    localText.setWrappingWidth(540.0D);
    localBorderPane.setLeft(localText);
    localBorderPane.setPadding(new Insets(8.0D, 0.0D, 0.0D, 0.0D));
    return localBorderPane;
  }
  
  private void showMoreInfo()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if (isLocalApp(this.ainfo)) {
      localStringBuilder.append(getMessage("sandbox.security.info.local.description"));
    } else {
      localStringBuilder.append(getMessage("sandbox.security.info.description"));
    }
    localStringBuilder.append("\n\n");
    if (this.updateText != null)
    {
      localStringBuilder.append(getMessage("deployment.dialog.ssv3.more.insecure"));
      localStringBuilder.append("\n\n");
    }
    if (isLocalApp(this.ainfo))
    {
      localStringBuilder.append(getMessage("deployment.dialog.ssv3.more.local"));
      localStringBuilder.append("\n\n");
    }
    if (this.multiText != null)
    {
      localStringBuilder.append(getMessage("deployment.dialog.ssv3.more.multi"));
      localStringBuilder.append("\n\n");
    }
    localStringBuilder.append(getMessage("deployment.dialog.ssv3.more.general"));
    MoreInfoDialog localMoreInfoDialog = new MoreInfoDialog(this.dialog, new String[] { localStringBuilder.toString() }, null, 0, null, 0, 0, false);
    localMoreInfoDialog.showAndWait();
  }
  
  private static boolean isLocalApp(AppInfo paramAppInfo)
  {
    URL localURL = paramAppInfo.getFrom();
    return (localURL != null) && (localURL.getProtocol().equals("file"));
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\FXSSV3Dialog.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */