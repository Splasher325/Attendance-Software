package com.sun.deploy.uitoolkit.impl.fx.ui;

import com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.security.cert.Certificate;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

class MoreInfoDialog
  extends FXDialog
{
  private Hyperlink details;
  private String[] alerts;
  private String[] infos;
  private int securityInfoCount;
  private Certificate[] certs;
  private int start;
  private int end;
  private boolean sandboxApp = false;
  private final String WARNING_ICON = "warning16.image";
  private final String INFO_ICON = "info16.image";
  private final int VERTICAL_STRUT = 18;
  private final int HORIZONTAL_STRUT = 12;
  private final int TEXT_WIDTH = 326;
  
  MoreInfoDialog(Stage paramStage, String[] paramArrayOfString1, String[] paramArrayOfString2, int paramInt1, Certificate[] paramArrayOfCertificate, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    super(ResourceManager.getMessage("security.more.info.title"), paramStage, true);
    this.alerts = paramArrayOfString1;
    this.infos = paramArrayOfString2;
    this.securityInfoCount = paramInt1;
    this.certs = paramArrayOfCertificate;
    this.start = paramInt2;
    this.end = paramInt3;
    this.sandboxApp = paramBoolean;
    initComponents(null, null);
    setResizable(false);
  }
  
  MoreInfoDialog(Stage paramStage, Pane paramPane, Throwable paramThrowable, Certificate[] paramArrayOfCertificate)
  {
    super(ResourceManager.getMessage("security.more.info.title"));
    this.certs = paramArrayOfCertificate;
    this.start = 0;
    this.end = (paramArrayOfCertificate == null ? 0 : paramArrayOfCertificate.length);
    initComponents(paramPane, paramThrowable);
  }
  
  private void initComponents(Pane paramPane, Throwable paramThrowable)
  {
    VBox localVBox = new VBox();
    localVBox.setId("more-info-dialog");
    if (paramPane != null)
    {
      VBox.setVgrow(paramPane, Priority.ALWAYS);
      localVBox.getChildren().add(paramPane);
    }
    else
    {
      Object localObject;
      if (paramThrowable != null)
      {
        localObject = new BorderPane();
        Label localLabel = new Label(ResourceManager.getString("exception.details.label"));
        ((BorderPane)localObject).setLeft(localLabel);
        localVBox.getChildren().add(localObject);
        StringWriter localStringWriter = new StringWriter();
        PrintWriter localPrintWriter = new PrintWriter(localStringWriter);
        paramThrowable.printStackTrace(localPrintWriter);
        TextArea localTextArea = new TextArea(localStringWriter.toString());
        localTextArea.setEditable(false);
        localTextArea.setWrapText(true);
        localTextArea.setPrefWidth(480.0D);
        localTextArea.setPrefHeight(240.0D);
        ScrollPane localScrollPane = new ScrollPane();
        localScrollPane.setContent(localTextArea);
        localScrollPane.setFitToWidth(true);
        VBox.setVgrow(localScrollPane, Priority.ALWAYS);
        localVBox.getChildren().add(localScrollPane);
        if (this.certs != null) {
          localVBox.getChildren().add(getLinkPanel());
        }
      }
      else
      {
        localObject = getSecurityPanel();
        if (((Pane)localObject).getChildren().size() > 0)
        {
          VBox.setVgrow((Node)localObject, Priority.ALWAYS);
          localVBox.getChildren().add(localObject);
        }
        localVBox.getChildren().add(getIntegrationPanel());
      }
    }
    localVBox.getChildren().add(getBtnPanel());
    setContentPane(localVBox);
  }
  
  private Pane getSecurityPanel()
  {
    VBox localVBox = new VBox();
    int k = this.certs == null ? 1 : 0;
    int i = (k != 0) || (this.alerts == null) ? 0 : 1;
    int j = this.alerts == null ? 0 : this.alerts.length;
    if (j > i) {
      localVBox.getChildren().add(blockPanel("warning16.image", this.alerts, i, j));
    }
    j = this.securityInfoCount;
    if (j > i) {
      localVBox.getChildren().add(blockPanel("info16.image", this.infos, i, j));
    }
    if (this.certs != null) {
      localVBox.getChildren().add(getLinkPanel());
    }
    return localVBox;
  }
  
  private Pane getLinkPanel()
  {
    HBox localHBox = new HBox();
    localHBox.setPadding(new Insets(8.0D, 0.0D, 0.0D, 0.0D));
    localHBox.setAlignment(Pos.TOP_RIGHT);
    String str = this.sandboxApp ? "sandbox.security.more.info.details" : "security.more.info.details";
    this.details = new Hyperlink(ResourceManager.getMessage(str));
    this.details.setMnemonicParsing(true);
    this.details.setOnAction(new EventHandler()
    {
      public void handle(ActionEvent paramAnonymousActionEvent)
      {
        MoreInfoDialog.this.showCertDetails();
      }
    });
    localHBox.getChildren().add(this.details);
    return localHBox;
  }
  
  private Pane getIntegrationPanel()
  {
    int i = this.securityInfoCount;
    int j = this.infos == null ? 0 : this.infos.length;
    return blockPanel("info16.image", this.infos, i, j);
  }
  
  private Pane getBtnPanel()
  {
    HBox localHBox = new HBox();
    localHBox.setId("more-info-dialog-button-panel");
    Button localButton = new Button(ResourceManager.getMessage("common.close_btn"));
    localButton.setCancelButton(true);
    localButton.setOnAction(new EventHandler()
    {
      public void handle(ActionEvent paramAnonymousActionEvent)
      {
        MoreInfoDialog.this.dismissAction();
      }
    });
    localButton.setDefaultButton(true);
    localHBox.getChildren().add(localButton);
    return localHBox;
  }
  
  private Pane blockPanel(String paramString, String[] paramArrayOfString, int paramInt1, int paramInt2)
  {
    VBox localVBox = new VBox(5.0D);
    if (paramArrayOfString != null) {
      for (int i = paramInt1; i < paramInt2; i++)
      {
        HBox localHBox = new HBox(12.0D);
        localHBox.setAlignment(Pos.TOP_LEFT);
        ImageView localImageView = ResourceManager.getIcon(paramString);
        UITextArea localUITextArea = new UITextArea(326.0D);
        localUITextArea.setWrapText(true);
        localUITextArea.setId("more-info-text-block");
        localUITextArea.setText(paramArrayOfString[i]);
        if (i > paramInt1) {
          localImageView.setVisible(false);
        }
        localHBox.getChildren().add(localImageView);
        localHBox.getChildren().add(localUITextArea);
        localVBox.getChildren().add(localHBox);
        if (i < paramInt2 - 1) {
          localVBox.getChildren().add(new Separator());
        }
      }
    }
    return localVBox;
  }
  
  private void showCertDetails()
  {
    CertificateDialog.showCertificates(this, this.certs, this.start, this.end);
  }
  
  private void dismissAction()
  {
    hide();
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\MoreInfoDialog.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */