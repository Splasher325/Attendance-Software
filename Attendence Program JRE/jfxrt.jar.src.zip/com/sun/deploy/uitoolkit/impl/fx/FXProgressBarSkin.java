package com.sun.deploy.uitoolkit.impl.fx;

import com.sun.javafx.scene.control.skin.ProgressBarSkin;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.RadialGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;

public class FXProgressBarSkin
  extends ProgressBarSkin
{
  Rectangle topGradient = new Rectangle(0.0D, 0.0D, new RadialGradient(0.05D, 0.0D, 0.5D, 0.0D, this.gradientRadius, true, CycleMethod.NO_CYCLE, new Stop[] { new Stop(0.0D, Color.rgb(255, 255, 255, 0.82D)), new Stop(0.13D, Color.rgb(255, 255, 255, 0.82D)), new Stop(0.98D, Color.rgb(255, 255, 255, 0.0D)) }));
  Rectangle bottomGradient = new Rectangle(0.0D, 0.0D, new RadialGradient(0.05D, 0.0D, 0.5D, 1.0D, this.gradientRadius, true, CycleMethod.NO_CYCLE, new Stop[] { new Stop(0.0D, Color.rgb(255, 255, 255, 0.82D)), new Stop(0.13D, Color.rgb(255, 255, 255, 0.82D)), new Stop(0.98D, Color.rgb(255, 255, 255, 0.0D)) }));
  Rectangle verticalLines;
  double gradientMargin = 4.0D;
  double gradientRadius = 0.55D;
  double gradientTweak = 1.4D;
  
  public FXProgressBarSkin(ProgressBar paramProgressBar)
  {
    super(paramProgressBar);
    this.topGradient.setManaged(false);
    this.bottomGradient.setManaged(false);
    ((StackPane)getChildren().get(1)).getChildren().addAll(new Node[] { this.topGradient, this.bottomGradient });
    this.verticalLines = new Rectangle(0.0D, 0.0D, new LinearGradient(0.0D, 0.0D, 14.0D, 0.0D, false, CycleMethod.REPEAT, new Stop[] { new Stop(0.0D, Color.TRANSPARENT), new Stop(0.93D, Color.TRANSPARENT), new Stop(0.93D, Color.rgb(184, 184, 184, 0.2D)), new Stop(1.0D, Color.rgb(184, 184, 184, 0.2D)) }));
    this.verticalLines.setManaged(false);
    getChildren().add(this.verticalLines);
  }
  
  protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    super.layoutChildren(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    if (((ProgressIndicator)getSkinnable()).isIndeterminate()) {
      return;
    }
    StackPane localStackPane1 = (StackPane)getChildren().get(0);
    StackPane localStackPane2 = (StackPane)getChildren().get(1);
    if (!localStackPane2.getChildren().contains(this.topGradient)) {
      localStackPane2.getChildren().add(this.topGradient);
    }
    if (!localStackPane2.getChildren().contains(this.bottomGradient)) {
      localStackPane2.getChildren().add(this.bottomGradient);
    }
    if (!getChildren().contains(this.verticalLines)) {
      getChildren().add(this.verticalLines);
    }
    double d1 = Math.floor(paramDouble3 / 14.0D) * 14.0D / paramDouble3;
    double d2 = localStackPane2.getWidth() * d1;
    double d3 = localStackPane2.getHeight();
    localStackPane1.resize(localStackPane1.getWidth() * d1, localStackPane1.getHeight());
    localStackPane2.resize(d2, d3);
    this.topGradient.setX(paramDouble1 + this.gradientMargin);
    this.topGradient.setY(paramDouble2 + 0.5D);
    this.topGradient.setWidth(d2 - 2.0D * this.gradientMargin);
    this.topGradient.setHeight(d3 * 0.3D / this.gradientRadius * this.gradientTweak);
    this.bottomGradient.setX(paramDouble1 + this.gradientMargin);
    this.bottomGradient.setWidth(d2 - 2.0D * this.gradientMargin);
    double d4 = d3 * 0.21D / this.gradientRadius * this.gradientTweak;
    this.bottomGradient.setY(d3 - d4 - 0.5D);
    this.bottomGradient.setHeight(d4);
    this.verticalLines.setX(paramDouble1);
    this.verticalLines.setY(paramDouble2);
    this.verticalLines.setWidth(paramDouble3 * d1);
    this.verticalLines.setHeight(paramDouble4);
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\FXProgressBarSkin.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */