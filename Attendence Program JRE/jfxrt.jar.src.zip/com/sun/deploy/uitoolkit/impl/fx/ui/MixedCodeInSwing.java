package com.sun.deploy.uitoolkit.impl.fx.ui;

import com.sun.deploy.ui.AppInfo;
import java.awt.Component;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Window;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import javax.swing.SwingUtilities;
import sun.awt.AppContext;
import sun.awt.SunToolkit;

public class MixedCodeInSwing
{
  private static boolean haveAppContext = false;
  private static Class sysUtils;
  private static Class tClass;
  private static Constructor cMethod;
  private static Method setContentMethod;
  private static Method getDialogMethod;
  private static Method setVisibleMethod;
  private static Method getAnswerMethod;
  private static Method disposeMethod;
  private static Method createSysThreadMethod;
  
  public static int show(Object paramObject, AppInfo paramAppInfo, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, boolean paramBoolean1, boolean paramBoolean2, String paramString7)
  {
    Helper localHelper = new Helper(null, paramAppInfo, paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramBoolean1, paramBoolean2, paramString7);
    try
    {
      Thread localThread = (Thread)createSysThreadMethod.invoke(null, new Object[] { localHelper });
      localThread.start();
      localThread.join();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return localHelper.getAnswer();
  }
  
  private static void placeWindow(Window paramWindow)
  {
    Rectangle localRectangle1 = getMouseScreenBounds();
    Rectangle localRectangle2 = paramWindow.getBounds();
    paramWindow.setLocation((localRectangle1.width - localRectangle2.width) / 2, (localRectangle1.height - localRectangle2.height) / 2);
  }
  
  public static Rectangle getMouseScreenBounds()
  {
    Point localPoint = MouseInfo.getPointerInfo().getLocation();
    GraphicsDevice[] arrayOfGraphicsDevice = GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices();
    for (int i = 0; i < arrayOfGraphicsDevice.length; i++)
    {
      Rectangle localRectangle = arrayOfGraphicsDevice[i].getDefaultConfiguration().getBounds();
      if ((localPoint.x >= localRectangle.x) && (localPoint.y >= localRectangle.y) && (localPoint.x <= localRectangle.x + localRectangle.width) && (localPoint.y <= localRectangle.y + localRectangle.height)) {
        return localRectangle;
      }
    }
    return new Rectangle(new Point(0, 0), Toolkit.getDefaultToolkit().getScreenSize());
  }
  
  static
  {
    try
    {
      tClass = Class.forName("com.sun.deploy.ui.DialogTemplate", true, null);
      cMethod = tClass.getDeclaredConstructor(new Class[] { AppInfo.class, Component.class, String.class, String.class, Boolean.TYPE });
      cMethod.setAccessible(true);
      setContentMethod = tClass.getDeclaredMethod("setMixedCodeContent", new Class[] { String.class, Boolean.TYPE, String.class, String.class, String.class, String.class, Boolean.TYPE, Boolean.TYPE, Boolean.TYPE, String.class });
      setContentMethod.setAccessible(true);
      getDialogMethod = tClass.getDeclaredMethod("getDialog", new Class[0]);
      getDialogMethod.setAccessible(true);
      setVisibleMethod = tClass.getDeclaredMethod("setVisible", new Class[] { Boolean.TYPE });
      setVisibleMethod.setAccessible(true);
      disposeMethod = tClass.getDeclaredMethod("disposeDialog", new Class[0]);
      disposeMethod.setAccessible(true);
      getAnswerMethod = tClass.getDeclaredMethod("getUserAnswer", new Class[0]);
      getAnswerMethod.setAccessible(true);
      sysUtils = Class.forName("sun.plugin.util.PluginSysUtil", false, null);
      createSysThreadMethod = sysUtils.getMethod("createPluginSysThread", new Class[] { Runnable.class });
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  static class Helper
    implements Runnable
  {
    private AppInfo appInfo;
    private String title;
    private String masthead;
    private String message;
    private String info;
    private String okBtnStr;
    private String cancelBtnStr;
    private boolean useWarning;
    private boolean isJsDialog;
    private int userAnswer = -1;
    private String showAlways;
    
    Helper(Component paramComponent, AppInfo paramAppInfo, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, boolean paramBoolean1, boolean paramBoolean2, String paramString7)
    {
      this.appInfo = (paramAppInfo == null ? new AppInfo() : paramAppInfo);
      this.title = paramString1;
      this.masthead = paramString2;
      this.message = paramString3;
      this.info = paramString4;
      this.okBtnStr = paramString5;
      this.cancelBtnStr = paramString6;
      this.useWarning = paramBoolean1;
      this.isJsDialog = paramBoolean2;
      this.showAlways = paramString7;
    }
    
    public void run()
    {
      synchronized (MixedCodeInSwing.class)
      {
        if (!MixedCodeInSwing.haveAppContext)
        {
          AppContext localAppContext = SunToolkit.createNewAppContext();
          MixedCodeInSwing.access$002(true);
        }
      }
      try
      {
        SwingUtilities.invokeAndWait(new Runnable()
        {
          public void run()
          {
            try
            {
              Object localObject = MixedCodeInSwing.cMethod.newInstance(new Object[] { MixedCodeInSwing.Helper.this.appInfo, null, MixedCodeInSwing.Helper.this.title, MixedCodeInSwing.Helper.this.masthead, Boolean.valueOf(false) });
              MixedCodeInSwing.setContentMethod.invoke(localObject, new Object[] { null, Boolean.valueOf(false), MixedCodeInSwing.Helper.this.message, MixedCodeInSwing.Helper.this.info, MixedCodeInSwing.Helper.this.okBtnStr, MixedCodeInSwing.Helper.this.cancelBtnStr, Boolean.valueOf(true), Boolean.valueOf(MixedCodeInSwing.Helper.this.useWarning), Boolean.valueOf(MixedCodeInSwing.Helper.this.isJsDialog), MixedCodeInSwing.Helper.this.showAlways });
              MixedCodeInSwing.setVisibleMethod.invoke(localObject, new Object[] { Boolean.valueOf(true) });
              MixedCodeInSwing.Helper.this.userAnswer = ((Integer)MixedCodeInSwing.getAnswerMethod.invoke(localObject, new Object[0])).intValue();
              MixedCodeInSwing.disposeMethod.invoke(localObject, new Object[0]);
            }
            catch (Throwable localThrowable)
            {
              localThrowable.printStackTrace();
            }
          }
        });
      }
      catch (InterruptedException localInterruptedException)
      {
        localInterruptedException.printStackTrace();
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        localInvocationTargetException.printStackTrace();
      }
      catch (Throwable localThrowable)
      {
        localThrowable.printStackTrace();
      }
    }
    
    int getAnswer()
    {
      return this.userAnswer;
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\MixedCodeInSwing.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */