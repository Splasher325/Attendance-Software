package com.sun.deploy.uitoolkit.impl.fx.ui;

import com.sun.deploy.uitoolkit.impl.fx.FXPreloader;
import com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager;
import com.sun.javafx.css.StyleManager;
import com.sun.javafx.css.Stylesheet;
import com.sun.javafx.css.converters.StringConverter;
import com.sun.javafx.css.parser.CSSParser;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import javafx.animation.FadeTransition;
import javafx.application.Application.Parameters;
import javafx.application.HostServices;
import javafx.application.Preloader;
import javafx.application.Preloader.ErrorNotification;
import javafx.application.Preloader.ProgressNotification;
import javafx.application.Preloader.StateChangeNotification;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.css.CssMetaData;
import javafx.css.StyleConverter;
import javafx.css.StyleOrigin;
import javafx.css.StyleableProperty;
import javafx.css.StyleableStringProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class FXDefaultPreloader
  extends Preloader
{
  static final double FADE_DURATION = 2000.0D;
  Stage stage;
  FXPreloaderPane pane;
  double currentWidth = 0.0D;
  double currentHeight = 0.0D;
  boolean isEmbedded;
  
  public void init()
  {
    this.pane = new FXPreloaderPane();
  }
  
  public void start(Stage paramStage)
  {
    this.stage = paramStage;
    this.stage.setTitle("JavaFX Application Preview");
    this.isEmbedded = ((paramStage.getWidth() >= 0.0D) && (paramStage.getHeight() >= 0.0D));
  }
  
  private void showIfNeeded()
  {
    if (!this.stage.isShowing())
    {
      this.stage.setScene(new FXPreloaderScene(this.pane));
      this.stage.show();
      ((FXPreloaderScene)this.stage.getScene()).loadStylesheets();
      this.stage.toFront();
      FXPreloader.hideSplash();
    }
  }
  
  public void stop() {}
  
  public void handleStateChangeNotification(Preloader.StateChangeNotification paramStateChangeNotification)
  {
    switch (paramStateChangeNotification.getType())
    {
    case BEFORE_START: 
      if (this.stage.isShowing())
      {
        if (this.isEmbedded)
        {
          FadeTransition localFadeTransition = new FadeTransition(Duration.millis(2000.0D), this.pane);
          localFadeTransition.setFromValue(1.0D);
          localFadeTransition.setToValue(0.0D);
          localFadeTransition.setOnFinished(new FadeOutFinisher(this.stage));
          localFadeTransition.play();
        }
        else
        {
          this.stage.hide();
        }
      }
      else {
        FXPreloader.hideSplash();
      }
      break;
    }
  }
  
  public boolean handleErrorNotification(Preloader.ErrorNotification paramErrorNotification)
  {
    if ((this.stage != null) && (this.stage.isShowing()) && (!this.isEmbedded)) {
      this.stage.hide();
    } else if (this.isEmbedded) {
      FXPreloader.hideSplash();
    }
    return false;
  }
  
  public void handleProgressNotification(Preloader.ProgressNotification paramProgressNotification)
  {
    if (paramProgressNotification.getProgress() != 1.0D) {
      showIfNeeded();
    }
    if (this.stage.isShowing()) {
      this.pane.setProgress(paramProgressNotification.getProgress());
    }
  }
  
  public List<CssMetaData> impl_CSS_STYLEABLES()
  {
    return CSSProperties.STYLEABLES;
  }
  
  private static class CSSProperties
  {
    private static CssMetaData<FXDefaultPreloader.FXPreloaderPane, String> PRELOADER_TEXT = new CssMetaData("-fx-preloader-text", StringConverter.getInstance())
    {
      public boolean isSettable(FXDefaultPreloader.FXPreloaderPane paramAnonymousFXPreloaderPane)
      {
        return true;
      }
      
      public StyleableProperty<String> getStyleableProperty(FXDefaultPreloader.FXPreloaderPane paramAnonymousFXPreloaderPane)
      {
        return (StyleableProperty)FXDefaultPreloader.FXPreloaderPane.access$300(paramAnonymousFXPreloaderPane);
      }
    };
    private static CssMetaData<FXDefaultPreloader.FXPreloaderPane, String> PRELOADER_GRAPHIC = new CssMetaData("-fx-preloader-graphic", StringConverter.getInstance())
    {
      public boolean isSettable(FXDefaultPreloader.FXPreloaderPane paramAnonymousFXPreloaderPane)
      {
        return true;
      }
      
      public StyleableProperty<String> getStyleableProperty(FXDefaultPreloader.FXPreloaderPane paramAnonymousFXPreloaderPane)
      {
        return (StyleableProperty)FXDefaultPreloader.FXPreloaderPane.access$400(paramAnonymousFXPreloaderPane);
      }
    };
    private static final List<CssMetaData> STYLEABLES;
    
    static
    {
      ArrayList localArrayList = new ArrayList();
      Collections.addAll(localArrayList, new CssMetaData[] { PRELOADER_TEXT, PRELOADER_GRAPHIC });
      STYLEABLES = Collections.unmodifiableList(localArrayList);
    }
  }
  
  class FXPreloaderPane
    extends Pane
  {
    ProgressBar progressBar;
    Label status;
    Label percent;
    Label graphic;
    private StringProperty preloaderText = new StyleableStringProperty()
    {
      public Object getBean()
      {
        return FXDefaultPreloader.FXPreloaderPane.this;
      }
      
      public String getName()
      {
        return "preloaderText";
      }
      
      public CssMetaData getCssMetaData()
      {
        return FXDefaultPreloader.CSSProperties.PRELOADER_TEXT;
      }
    };
    private StringProperty preloaderGraphicUrl = new StyleableStringProperty()
    {
      protected void invalidated()
      {
        if (getValue() != null)
        {
          if (FXDefaultPreloader.FXPreloaderPane.this.graphic == null)
          {
            FXDefaultPreloader.FXPreloaderPane.this.graphic = new Label();
            FXDefaultPreloader.FXPreloaderPane.this.getChildren().add(FXDefaultPreloader.FXPreloaderPane.this.graphic);
          }
          FXDefaultPreloader.FXPreloaderPane.this.graphic.setGraphic(new ImageView(new Image(getValue())));
        }
      }
      
      public Object getBean()
      {
        return FXDefaultPreloader.FXPreloaderPane.this;
      }
      
      public String getName()
      {
        return "preloaderGraphicUrl";
      }
      
      public CssMetaData getCssMetaData()
      {
        return FXDefaultPreloader.CSSProperties.PRELOADER_GRAPHIC;
      }
    };
    
    FXPreloaderPane()
    {
      getStyleClass().setAll(new String[] { "default-preloader" });
      String str = (String)FXDefaultPreloader.this.getParameters().getNamed().get("javafx.default.preloader.style");
      if (str != null) {
        setStyle(str);
      }
      this.progressBar = new ProgressBar();
      this.status = new Label(ResourceManager.getMessage("preloader.loading"));
      this.status.setId("preloader-status-label");
      this.percent = new Label("");
      this.percent.setId("preloader-percent-label");
      getChildren().addAll(new Node[] { this.progressBar, this.status, this.percent });
    }
    
    public void layoutChildren()
    {
      if ((FXDefaultPreloader.this.currentWidth == getWidth()) && (FXDefaultPreloader.this.currentHeight == getHeight())) {
        return;
      }
      FXDefaultPreloader.this.currentWidth = getWidth();
      FXDefaultPreloader.this.currentHeight = getHeight();
      setPrefHeight(FXDefaultPreloader.this.currentHeight);
      setPrefWidth(FXDefaultPreloader.this.currentWidth);
      if ((FXDefaultPreloader.this.currentWidth > 40.0D) && (FXDefaultPreloader.this.currentHeight > 21.0D))
      {
        this.percent.autosize();
        if ((FXDefaultPreloader.this.currentWidth < 100.0D) || (FXDefaultPreloader.this.currentHeight < 100.0D))
        {
          this.graphic.setVisible(false);
          this.progressBar.setVisible(false);
          this.status.setVisible(false);
          this.percent.relocate((FXDefaultPreloader.this.currentWidth - this.percent.getWidth()) / 2.0D, (FXDefaultPreloader.this.currentHeight - this.percent.getHeight()) / 2.0D);
        }
        else
        {
          if (this.graphic != null)
          {
            this.graphic.setVisible(true);
            this.graphic.autosize();
            this.graphic.relocate((FXDefaultPreloader.this.currentWidth - this.graphic.getWidth()) / 2.0D, (FXDefaultPreloader.this.currentHeight / 2.0D - this.graphic.getHeight()) / 2.0D);
          }
          this.status.setVisible(true);
          this.status.autosize();
          float f = FXDefaultPreloader.this.currentWidth < 240.0D ? 0.75F : 0.65F;
          this.progressBar.setVisible(true);
          this.progressBar.setPrefWidth(FXDefaultPreloader.this.currentWidth * f);
          this.progressBar.resize(this.progressBar.prefWidth(-1.0D), this.progressBar.prefHeight(-1.0D));
          this.progressBar.relocate((FXDefaultPreloader.this.currentWidth - this.progressBar.getWidth()) / 2.0D, FXDefaultPreloader.this.currentHeight / 2.0D - this.progressBar.getHeight());
          this.status.relocate(this.progressBar.getLayoutX(), this.progressBar.getLayoutY() + this.progressBar.getHeight() + 4.0D);
          this.percent.relocate(this.progressBar.getLayoutX() + this.progressBar.getWidth() - this.percent.getWidth(), this.progressBar.getLayoutY() - this.percent.getHeight() - 4.0D);
        }
      }
    }
    
    void setProgress(double paramDouble)
    {
      this.progressBar.setProgress(paramDouble);
      this.percent.setText(String.format("%.0f%%", new Object[] { Double.valueOf(paramDouble * 100.0D) }));
      this.percent.autosize();
      this.percent.setLayoutX(this.progressBar.getLayoutX() + this.progressBar.getPrefWidth() - this.percent.getWidth());
    }
  }
  
  private class FXPreloaderScene
    extends Scene
  {
    FXPreloaderScene(Parent paramParent)
    {
      super(600.0D, 400.0D);
      Scene localScene = new Scene(new Pane(), 0.0D, 0.0D);
      setRoot(paramParent);
      getStylesheets().addAll(new String[] { FXDefaultPreloader.class.getResource("deploydialogs.css").toExternalForm() });
    }
    
    private void loadStylesheets()
    {
      String str1 = (String)FXDefaultPreloader.this.getParameters().getNamed().get("javafx.default.preloader.stylesheet");
      if (str1 != null)
      {
        HostServices localHostServices = FXDefaultPreloader.this.getHostServices();
        String str2 = localHostServices.getDocumentBase();
        Object localObject;
        if (str1.matches(".*\\.[bc]ss$"))
        {
          if (str1.startsWith("jar:")) {
            localObject = "jar:" + localHostServices.resolveURI(str2, str1.substring(4));
          } else {
            localObject = localHostServices.resolveURI(str2, str1);
          }
          getStylesheets().add(localObject);
        }
        else
        {
          try
          {
            localObject = CSSParser.getInstance().parse(str2, str1);
            StyleManager.getInstance().addUserAgentStylesheet(this, (Stylesheet)localObject);
            ((Stylesheet)localObject).setOrigin(StyleOrigin.AUTHOR);
          }
          catch (IOException localIOException)
          {
            localIOException.printStackTrace();
          }
        }
      }
    }
  }
  
  private class FadeOutFinisher
    implements EventHandler<ActionEvent>
  {
    Stage stage;
    
    FadeOutFinisher(Stage paramStage)
    {
      this.stage = paramStage;
    }
    
    public void handle(ActionEvent paramActionEvent)
    {
      if (this.stage.isShowing()) {
        this.stage.hide();
      }
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\FXDefaultPreloader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */