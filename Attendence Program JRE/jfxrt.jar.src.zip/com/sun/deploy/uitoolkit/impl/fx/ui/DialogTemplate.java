package com.sun.deploy.uitoolkit.impl.fx.ui;

import com.sun.deploy.trace.Trace;
import com.sun.deploy.ui.AppInfo;
import com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager;
import com.sun.javafx.applet.HostServicesImpl;
import com.sun.javafx.application.HostServicesDelegate;
import java.lang.reflect.Method;
import java.net.URL;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.text.MessageFormat;
import java.util.Collection;
import java.util.Iterator;
import java.util.TreeMap;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MultipleSelectionModel;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class DialogTemplate
{
  int theAnswer = -1;
  final Object responseLock = new Object();
  private static final int RISK_LABEL_WIDTH = 52;
  private static final int RISK_TEXT_WIDTH = 490;
  private EventHandler<ActionEvent> okHandler = new EventHandler()
  {
    public void handle(ActionEvent paramAnonymousActionEvent)
    {
      DialogTemplate.this.userAnswer = 0;
      if ((DialogTemplate.this.always != null) && (DialogTemplate.this.always.isSelected())) {
        DialogTemplate.this.userAnswer = 2;
      }
      if (DialogTemplate.this.stayAliveOnOk) {
        return;
      }
      if (DialogTemplate.this.password != null) {
        DialogTemplate.this.pwd = DialogTemplate.this.password.getText().toCharArray();
      }
      if (DialogTemplate.this.pwdName != null) {
        DialogTemplate.this.userName = DialogTemplate.this.pwdName.getText();
      }
      if (DialogTemplate.this.pwdDomain != null) {
        DialogTemplate.this.domain = DialogTemplate.this.pwdDomain.getText();
      }
      if (DialogTemplate.this.scrollList != null) {
        DialogTemplate.this.userAnswer = DialogTemplate.this.scrollList.getSelectionModel().getSelectedIndex();
      }
      DialogTemplate.this.setVisible(false);
    }
  };
  private EventHandler<ActionEvent> cancelHandler = new EventHandler()
  {
    public void handle(ActionEvent paramAnonymousActionEvent)
    {
      if ((DialogTemplate.this.throwable != null) || (DialogTemplate.this.detailPanel != null))
      {
        DialogTemplate.this.showMoreInfo();
        return;
      }
      DialogTemplate.this.userAnswer = 1;
      if (DialogTemplate.this.scrollList != null) {
        DialogTemplate.this.userAnswer = -1;
      }
      DialogTemplate.this.setVisible(false);
    }
  };
  EventHandler<ActionEvent> acceptRiskHandler = new EventHandler()
  {
    public void handle(ActionEvent paramAnonymousActionEvent)
    {
      boolean bool = DialogTemplate.this.acceptRisk.isSelected();
      DialogTemplate.this.okBtn.setDisable(!bool);
      DialogTemplate.this.okBtn.setDefaultButton(bool);
      DialogTemplate.this.cancelBtn.setDefaultButton(!bool);
      if (DialogTemplate.this.always != null)
      {
        DialogTemplate.this.always.setSelected(false);
        DialogTemplate.this.always.setDisable(!bool);
      }
    }
  };
  EventHandler<ActionEvent> expandHandler = new EventHandler()
  {
    public void handle(ActionEvent paramAnonymousActionEvent)
    {
      if (paramAnonymousActionEvent.getSource() == DialogTemplate.this.expandBtn)
      {
        DialogTemplate.this.expandPanel.setTop(DialogTemplate.this.collapseBtn);
        DialogTemplate.this.expandPanel.setBottom(DialogTemplate.this.always);
        if (DialogTemplate.this.acceptRisk != null) {
          DialogTemplate.this.always.setDisable(!DialogTemplate.this.acceptRisk.isSelected());
        }
      }
      else if (paramAnonymousActionEvent.getSource() == DialogTemplate.this.collapseBtn)
      {
        DialogTemplate.this.expandPanel.setTop(DialogTemplate.this.expandBtn);
        DialogTemplate.this.expandPanel.setBottom(null);
      }
      DialogTemplate.this.dialog.sizeToScene();
    }
  };
  EventHandler moreInfoHandler = new EventHandler()
  {
    public void handle(Event paramAnonymousEvent)
    {
      DialogTemplate.this.showMoreInfo();
    }
  };
  EventHandler closeHandler = new EventHandler()
  {
    public void handle(Event paramAnonymousEvent)
    {
      DialogTemplate.this.dialog.hide();
    }
  };
  private FXDialog dialog = null;
  private VBox contentPane = null;
  private AppInfo ainfo = null;
  private String topText = null;
  private boolean useErrorIcon = false;
  private boolean useWarningIcon = false;
  private boolean useInfoIcon = false;
  private boolean useBlockedIcon = false;
  private boolean useMixcodeIcon = false;
  private Label progressStatusLabel = null;
  private BorderPane topPanel;
  private Pane centerPanel;
  private BorderPane expandPanel;
  private ImageView topIcon;
  private ImageView securityIcon;
  private Label nameInfo;
  private Label publisherInfo;
  private Label urlInfo;
  private Label mainJNLPInfo;
  private Label documentBaseInfo;
  private Button okBtn;
  private Button cancelBtn;
  private Button expandBtn;
  private Button collapseBtn;
  private CheckBox always;
  private CheckBox acceptRisk;
  private Label mixedCodeLabel;
  private UITextArea masthead1 = null;
  private UITextArea masthead2 = null;
  private static final int ICON_SIZE = 48;
  private int userAnswer = -1;
  static final int DIALOG_WIDTH = 540;
  private final int MAX_LARGE_SCROLL_WIDTH = 600;
  private final String SECURITY_ALERT_HIGH = "security.alert.high.image";
  private final String SECURITY_ALERT_LOW = "security.alert.low.image";
  private static int MAIN_TEXT_WIDTH = 400;
  private final String OK_ACTION = "OK";
  private final int MAX_BUTTONS = 2;
  private int start;
  private int end;
  private Certificate[] certs;
  private String[] alertStrs;
  private String[] infoStrs;
  private int securityInfoCount;
  private Color originalColor;
  private Cursor originalCursor = null;
  protected ProgressBar progressBar = null;
  private boolean stayAliveOnOk = false;
  private String contentString = null;
  private String reason;
  private String cacheUpgradeContentString = null;
  private String contentLabel = null;
  private String alwaysString = null;
  private String mixedCodeString = null;
  private boolean contentScroll = false;
  private boolean includeMasthead = true;
  private boolean includeAppInfo = true;
  private boolean largeScroll = false;
  private Throwable throwable = null;
  private Pane detailPanel = null;
  private char[] pwd = new char[0];
  private String userName;
  private String domain;
  private TextField pwdName;
  private TextField pwdDomain;
  private PasswordField password;
  private ListView scrollList;
  private boolean showDetails = false;
  TreeMap clientAuthCertsMap;
  private boolean majorWarning = false;
  private String okBtnStr;
  private String cancelBtnStr;
  private boolean sandboxApp = false;
  private boolean checkAlways = false;
  private boolean selfSigned = false;
  private boolean isBlockedDialog;
  
  DialogTemplate(AppInfo paramAppInfo, Stage paramStage, String paramString1, String paramString2)
  {
    Stage localStage = paramStage;
    this.dialog = new FXDialog(paramString1, localStage, false);
    this.contentPane = new VBox()
    {
      protected double computePrefHeight(double paramAnonymousDouble)
      {
        double d = super.computePrefHeight(paramAnonymousDouble);
        return d;
      }
    };
    this.dialog.setContentPane(this.contentPane);
    this.ainfo = paramAppInfo;
    this.topText = paramString2;
  }
  
  void setNewSecurityContent(boolean paramBoolean1, boolean paramBoolean2, String paramString1, String paramString2, String[] paramArrayOfString1, String[] paramArrayOfString2, int paramInt1, boolean paramBoolean3, Certificate[] paramArrayOfCertificate, int paramInt2, int paramInt3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6)
  {
    this.certs = paramArrayOfCertificate;
    this.start = paramInt2;
    this.end = paramInt3;
    this.alertStrs = paramArrayOfString1;
    this.infoStrs = paramArrayOfString2;
    this.securityInfoCount = paramInt1;
    this.majorWarning = paramBoolean4;
    this.okBtnStr = paramString1;
    this.cancelBtnStr = paramString2;
    this.sandboxApp = paramBoolean5;
    this.checkAlways = paramBoolean2;
    this.selfSigned = paramBoolean6;
    if ((paramArrayOfString1 != null) && (paramArrayOfString1.length > 0)) {
      this.useWarningIcon = true;
    }
    try
    {
      this.contentPane.setId("security-content-panel");
      this.dialog.initModality(Modality.APPLICATION_MODAL);
      this.contentPane.getChildren().add(createSecurityTopPanel());
      this.contentPane.getChildren().add(createSecurityCenterPanel());
      if (!paramBoolean6) {
        this.contentPane.getChildren().add(createSecurityBottomPanel());
      }
      this.dialog.setResizable(false);
      this.dialog.setIconifiable(false);
      if (this.alertStrs == null) {
        this.dialog.hideWindowTitle();
      }
    }
    catch (Throwable localThrowable)
    {
      Trace.ignored(localThrowable);
    }
  }
  
  private Pane createSecurityTopPanel()
  {
    BorderPane localBorderPane = new BorderPane();
    localBorderPane.setTop(createSecurityTopMastheadPanel());
    localBorderPane.setBottom(createSecurityTopIconLabelsPanel());
    return localBorderPane;
  }
  
  private Pane createSecurityTopMastheadPanel()
  {
    BorderPane localBorderPane = new BorderPane();
    this.masthead1 = new UITextArea(MAIN_TEXT_WIDTH);
    this.masthead1.setId("security-masthead-label");
    this.masthead1.setText(this.topText.trim());
    localBorderPane.setLeft(this.masthead1);
    if (this.alertStrs == null)
    {
      Button localButton = FXDialog.createCloseButton();
      localButton.setOnAction(this.closeHandler);
      localBorderPane.setRight(localButton);
    }
    return localBorderPane;
  }
  
  private Pane createSecurityTopIconLabelsPanel()
  {
    BorderPane localBorderPane = new BorderPane();
    if (this.alertStrs != null) {
      this.topIcon = ResourceManager.getIcon("warning48s.image");
    } else {
      this.topIcon = ResourceManager.getIcon("java48s.image");
    }
    Label localLabel1 = new Label(null, this.topIcon);
    localLabel1.setId("security-top-icon-label");
    localBorderPane.setLeft(localLabel1);
    GridPane localGridPane = new GridPane();
    localGridPane.setId("security-top-labels-grid");
    String str1 = ResourceManager.getMessage("dialog.template.name");
    Label localLabel2 = new Label(str1);
    localLabel2.setId("security-name-label");
    String str2 = ResourceManager.getMessage("dialog.template.publisher");
    Label localLabel3 = new Label(str2);
    localLabel3.setId("security-publisher-label");
    String str3 = ResourceManager.getMessage("deployment.ssv.location");
    Label localLabel4 = new Label(str3);
    localLabel4.setId("security-from-label");
    this.nameInfo = new Label();
    this.nameInfo.setId("security-name-value");
    this.publisherInfo = new Label();
    this.urlInfo = new Label();
    if (this.ainfo.getTitle() != null)
    {
      GridPane.setConstraints(localLabel2, 0, 0);
      GridPane.setHalignment(localLabel2, HPos.LEFT);
      localGridPane.getChildren().add(localLabel2);
      GridPane.setConstraints(this.nameInfo, 1, 0);
      localGridPane.getChildren().add(this.nameInfo);
    }
    if (this.ainfo.getVendor() != null)
    {
      GridPane.setConstraints(localLabel3, 0, 1);
      GridPane.setHalignment(localLabel3, HPos.LEFT);
      localGridPane.getChildren().add(localLabel3);
      GridPane.setConstraints(this.publisherInfo, 1, 1);
      localGridPane.getChildren().add(this.publisherInfo);
    }
    if (this.ainfo.getFrom() != null)
    {
      GridPane.setConstraints(localLabel4, 0, 2);
      GridPane.setHalignment(localLabel4, HPos.LEFT);
      localGridPane.getChildren().add(localLabel4);
      GridPane.setConstraints(this.urlInfo, 1, 2);
      localGridPane.getChildren().add(this.urlInfo);
      int i = 3;
      if (this.ainfo.shouldDisplayMainJNLP())
      {
        this.mainJNLPInfo = new Label();
        this.mainJNLPInfo.setId("dialog-from-value");
        GridPane.setConstraints(this.mainJNLPInfo, 1, i++);
        localGridPane.getChildren().add(this.mainJNLPInfo);
      }
      if (this.ainfo.shouldDisplayDocumentBase())
      {
        this.documentBaseInfo = new Label();
        this.documentBaseInfo.setId("dialog-from-value");
        GridPane.setConstraints(this.documentBaseInfo, 1, i);
        localGridPane.getChildren().add(this.documentBaseInfo);
      }
    }
    setInfo(this.ainfo);
    localBorderPane.setCenter(localGridPane);
    return localBorderPane;
  }
  
  private Pane createSecurityCenterPanel()
  {
    BorderPane localBorderPane1 = new BorderPane();
    if (this.majorWarning)
    {
      BorderPane localBorderPane2 = new BorderPane();
      String str1 = null;
      if (this.selfSigned) {
        str1 = ResourceManager.getMessage("dialog.selfsigned.security.risk.warning");
      } else {
        str1 = ResourceManager.getMessage("dialog.security.risk.warning");
      }
      String str2 = ResourceManager.getMessage("security.dialog.notverified.subject");
      Text localText = new Text(str1.replaceAll(str2, str2.toUpperCase()));
      localText.setWrappingWidth(MAIN_TEXT_WIDTH + 120);
      localText.setFill(Color.web("0xCC0000"));
      localText.setFont(Font.font("System", FontWeight.BOLD, 15.0D));
      localBorderPane2.setLeft(localText);
      localBorderPane2.setPadding(new Insets(8.0D, 0.0D, 0.0D, 0.0D));
      localBorderPane1.setTop(localBorderPane2);
      localBorderPane1.setCenter(createSecurityRiskPanel());
      localBorderPane1.setBottom(createSecurityAcceptRiskPanel());
    }
    else
    {
      localBorderPane1.setTop(createSecurityRiskPanel());
      localBorderPane1.setBottom(createSecurityAlwaysPanel());
    }
    return localBorderPane1;
  }
  
  private Pane createSecurityRiskPanel()
  {
    BorderPane localBorderPane1 = new BorderPane();
    localBorderPane1.setId("security-risk-panel");
    String str1;
    if (this.majorWarning)
    {
      str1 = this.alertStrs[0];
      int i = str1.indexOf(" ");
      String str2 = str1.substring(0, i);
      String str3 = str1.substring(i + 1);
      UITextArea localUITextArea2 = new UITextArea(52.0D);
      localUITextArea2.setText(str2);
      localUITextArea2.setId("security-risk-label");
      localBorderPane1.setLeft(localUITextArea2);
      BorderPane localBorderPane2 = new BorderPane();
      UITextArea localUITextArea3 = new UITextArea(490.0D);
      localUITextArea3.setId("security-risk-value");
      localUITextArea3.setText(str3);
      localBorderPane2.setTop(localUITextArea3);
      localBorderPane2.setBottom(createMoreInfoHyperlink());
      localBorderPane1.setRight(localBorderPane2);
    }
    else
    {
      str1 = ResourceManager.getMessage(this.sandboxApp ? "sandbox.security.dialog.valid.signed.risk" : "security.dialog.valid.signed.risk");
      UITextArea localUITextArea1 = new UITextArea(450.0D);
      localUITextArea1.setId("security-risk-value");
      localUITextArea1.setText(str1);
      localBorderPane1.setLeft(localUITextArea1);
    }
    return localBorderPane1;
  }
  
  private Hyperlink createMoreInfoHyperlink()
  {
    String str = ResourceManager.getMessage("dialog.template.more.info2");
    Hyperlink localHyperlink = new Hyperlink(str);
    localHyperlink.setMnemonicParsing(true);
    localHyperlink.setId("security-more-info-link");
    localHyperlink.setOnAction(this.moreInfoHandler);
    return localHyperlink;
  }
  
  private Pane createSecurityAcceptRiskPanel()
  {
    BorderPane localBorderPane1 = new BorderPane();
    String str1 = ResourceManager.getMessage("security.dialog.accept.title");
    String str2 = ResourceManager.getMessage("security.dialog.accept.text");
    UITextArea localUITextArea = new UITextArea(542.0D);
    localUITextArea.setId("security-risk-value");
    localUITextArea.setText(str1);
    localBorderPane1.setTop(localUITextArea);
    BorderPane localBorderPane2 = new BorderPane();
    localBorderPane2.setId("security-accept-risk-panel");
    this.acceptRisk = new CheckBox(str2);
    this.acceptRisk.setSelected(false);
    this.acceptRisk.setOnAction(this.acceptRiskHandler);
    localBorderPane2.setLeft(this.acceptRisk);
    localBorderPane2.setRight(createSecurityOkCancelButtons());
    localBorderPane1.setBottom(localBorderPane2);
    return localBorderPane1;
  }
  
  private Pane createSecurityOkCancelButtons()
  {
    HBox localHBox = new HBox();
    localHBox.getStyleClass().add("security-button-bar");
    this.okBtn = new Button(ResourceManager.getMessage(this.okBtnStr));
    this.okBtn.setMnemonicParsing(true);
    this.okBtn.setOnAction(this.okHandler);
    localHBox.getChildren().add(this.okBtn);
    this.cancelBtn = new Button(this.cancelBtnStr);
    this.cancelBtn.setOnAction(this.cancelHandler);
    this.cancelBtn.setCancelButton(true);
    localHBox.getChildren().add(this.cancelBtn);
    if (this.majorWarning)
    {
      this.okBtn.setDisable(true);
      this.cancelBtn.setDefaultButton(true);
    }
    else
    {
      this.okBtn.setDefaultButton(true);
    }
    return localHBox;
  }
  
  private Pane createSecurityAlwaysPanel()
  {
    BorderPane localBorderPane = new BorderPane();
    localBorderPane.setLeft(createSecurityAlwaysCheckbox());
    return localBorderPane;
  }
  
  private CheckBox createSecurityAlwaysCheckbox()
  {
    this.alwaysString = ResourceManager.getMessage(this.sandboxApp ? "sandbox.security.dialog.always" : "security.dialog.always");
    this.always = new CheckBox(this.alwaysString);
    if (this.majorWarning) {
      this.always.setId("security-always-trust-checkbox");
    }
    this.always.setSelected((this.sandboxApp) && (this.checkAlways));
    this.always.setVisible(true);
    return this.always;
  }
  
  private Pane createSecurityBottomPanel()
  {
    if (this.majorWarning) {
      return createSecurityBottomExpandPanel();
    }
    return createSecurityBottomMoreInfoPanel();
  }
  
  private Pane createSecurityBottomExpandPanel()
  {
    this.expandPanel = new BorderPane();
    this.expandPanel.setId("security-bottom-panel");
    this.always = createSecurityAlwaysCheckbox();
    ImageView localImageView1 = ResourceManager.getIcon("toggle_down2.image");
    String str1 = ResourceManager.getMessage("security.dialog.show.options");
    this.expandBtn = new Button(str1, localImageView1);
    this.expandBtn.setId("security-expand-button");
    this.expandBtn.setOnAction(this.expandHandler);
    ImageView localImageView2 = ResourceManager.getIcon("toggle_up2.image");
    String str2 = ResourceManager.getMessage("security.dialog.hide.options");
    this.collapseBtn = new Button(str2, localImageView2);
    this.collapseBtn.setId("security-expand-button");
    this.collapseBtn.setOnAction(this.expandHandler);
    this.expandPanel.setTop(this.expandBtn);
    return this.expandPanel;
  }
  
  private Pane createSecurityBottomMoreInfoPanel()
  {
    BorderPane localBorderPane1 = new BorderPane();
    localBorderPane1.setId("security-bottom-panel");
    HBox localHBox = new HBox();
    if (this.alertStrs != null) {
      this.securityIcon = ResourceManager.getIcon("yellowShield.image");
    } else {
      this.securityIcon = ResourceManager.getIcon("blueShield.image");
    }
    localHBox.getChildren().add(this.securityIcon);
    BorderPane localBorderPane2 = new BorderPane();
    localBorderPane2.setId("security-more-info-panel");
    localBorderPane2.setCenter(createMoreInfoHyperlink());
    localHBox.getChildren().add(localBorderPane2);
    localBorderPane1.setRight(createSecurityOkCancelButtons());
    localBorderPane1.setLeft(localHBox);
    return localBorderPane1;
  }
  
  void setSecurityContent(boolean paramBoolean1, boolean paramBoolean2, String paramString1, String paramString2, String[] paramArrayOfString1, String[] paramArrayOfString2, int paramInt1, boolean paramBoolean3, Certificate[] paramArrayOfCertificate, int paramInt2, int paramInt3, boolean paramBoolean4)
  {
    this.certs = paramArrayOfCertificate;
    this.start = paramInt2;
    this.end = paramInt3;
    this.alertStrs = paramArrayOfString1;
    this.infoStrs = paramArrayOfString2;
    this.securityInfoCount = paramInt1;
    this.majorWarning = paramBoolean4;
    if ((paramArrayOfString1 != null) && (paramArrayOfString1.length > 0)) {
      this.useWarningIcon = true;
    }
    try
    {
      this.contentPane.getChildren().add(createTopPanel(false));
      this.dialog.initModality(Modality.APPLICATION_MODAL);
      if (paramBoolean1) {
        this.alwaysString = ResourceManager.getMessage("security.dialog.always");
      }
      this.contentPane.getChildren().add(createCenterPanel(paramBoolean2, paramString1, paramString2, -1));
      this.contentPane.getChildren().add(createBottomPanel(paramBoolean3));
      this.dialog.setResizable(false);
      this.dialog.setIconifiable(false);
    }
    catch (Throwable localThrowable)
    {
      localThrowable.printStackTrace();
    }
  }
  
  void setSSVContent(String paramString1, String paramString2, URL paramURL, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7)
  {
    try
    {
      BorderPane localBorderPane1 = new BorderPane();
      localBorderPane1.setId("ssv-content-panel");
      this.dialog.initModality(Modality.APPLICATION_MODAL);
      this.contentPane.getChildren().add(localBorderPane1);
      localBorderPane1.setTop(createSSVTopPanel(this.topText, this.ainfo.getTitle(), this.ainfo.getDisplayFrom()));
      BorderPane localBorderPane2 = createSSVRiskPanel(paramString1, paramString2, paramURL);
      final SSVChoicePanel localSSVChoicePanel = new SSVChoicePanel(paramString3, paramString4, paramString5);
      BorderPane localBorderPane3 = new BorderPane();
      localBorderPane3.setTop(localBorderPane2);
      localBorderPane3.setBottom(localSSVChoicePanel);
      localBorderPane1.setCenter(localBorderPane3);
      FlowPane localFlowPane = new FlowPane(6.0D, 0.0D);
      localFlowPane.getStyleClass().add("button-bar");
      this.okBtn = new Button(paramString6);
      this.okBtn.setOnAction(new EventHandler()
      {
        public void handle(ActionEvent paramAnonymousActionEvent)
        {
          if (localSSVChoicePanel.getSelection() == 0) {
            DialogTemplate.this.setUserAnswer(2);
          } else {
            DialogTemplate.this.setUserAnswer(0);
          }
          DialogTemplate.this.setVisible(false);
        }
      });
      localFlowPane.getChildren().add(this.okBtn);
      this.cancelBtn = new Button(paramString7);
      this.cancelBtn.setOnAction(new EventHandler()
      {
        public void handle(ActionEvent paramAnonymousActionEvent)
        {
          DialogTemplate.this.cancelAction();
        }
      });
      this.cancelBtn.setCancelButton(true);
      localFlowPane.getChildren().add(this.cancelBtn);
      this.okBtn.setDefaultButton(true);
      localBorderPane1.setBottom(localFlowPane);
      this.dialog.setResizable(false);
      this.dialog.setIconifiable(false);
    }
    catch (Throwable localThrowable) {}
  }
  
  void setSimpleContent(String paramString1, boolean paramBoolean1, String paramString2, String paramString3, String paramString4, boolean paramBoolean2, boolean paramBoolean3)
  {
    this.contentString = paramString1;
    this.contentScroll = paramBoolean1;
    this.includeMasthead = paramBoolean2;
    this.includeAppInfo = paramBoolean2;
    this.largeScroll = (!paramBoolean2);
    this.useWarningIcon = paramBoolean3;
    if (paramString2 != null)
    {
      String[] arrayOfString = { paramString2 };
      if (paramBoolean3) {
        this.alertStrs = arrayOfString;
      } else {
        this.infoStrs = arrayOfString;
      }
    }
    try
    {
      this.contentPane.getChildren().add(createTopPanel(false));
      this.contentPane.getChildren().add(createCenterPanel(false, paramString3, paramString4, -1));
      this.contentPane.getChildren().add(createBottomPanel(false));
      this.dialog.setResizable(paramBoolean1);
    }
    catch (Throwable localThrowable) {}
  }
  
  void setMixedCodeContent(String paramString1, boolean paramBoolean1, String paramString2, String paramString3, String paramString4, String paramString5, boolean paramBoolean2, boolean paramBoolean3)
  {
    this.contentString = paramString1;
    this.contentScroll = paramBoolean1;
    this.includeMasthead = paramBoolean2;
    this.includeAppInfo = paramBoolean2;
    this.largeScroll = (!paramBoolean2);
    this.useMixcodeIcon = true;
    this.alertStrs = new String[1];
    String[] arrayOfString1 = { paramString3 };
    this.alertStrs = arrayOfString1;
    this.infoStrs = new String[3];
    String str1 = ResourceManager.getString("security.dialog.mixcode.info1");
    String str2 = ResourceManager.getString("security.dialog.mixcode.info2");
    String str3 = ResourceManager.getString("security.dialog.mixcode.info3");
    String[] arrayOfString2 = { str1, str2, str3 };
    this.infoStrs = arrayOfString2;
    try
    {
      this.contentPane.getChildren().add(createTopPanel(false));
      this.mixedCodeString = paramString2;
      this.contentPane.getChildren().add(createCenterPanel(false, paramString4, paramString5, -1));
      this.contentPane.getChildren().add(createBottomPanel(false));
      this.okBtn.requestFocus();
      boolean bool = paramBoolean1;
      this.dialog.setResizable(bool);
    }
    catch (Throwable localThrowable) {}
  }
  
  void setListContent(String paramString1, ListView paramListView, boolean paramBoolean, String paramString2, String paramString3, TreeMap paramTreeMap)
  {
    this.useWarningIcon = true;
    this.includeAppInfo = false;
    this.clientAuthCertsMap = paramTreeMap;
    this.contentLabel = paramString1;
    this.contentScroll = true;
    this.scrollList = paramListView;
    this.showDetails = paramBoolean;
    try
    {
      this.contentPane.getChildren().add(createTopPanel(false));
      this.contentPane.getChildren().add(createCenterPanel(false, paramString2, paramString3, -1));
      this.contentPane.getChildren().add(createBottomPanel(false));
    }
    catch (Throwable localThrowable) {}
  }
  
  void setApiContent(String paramString1, String paramString2, String paramString3, boolean paramBoolean, String paramString4, String paramString5)
  {
    this.contentString = paramString1;
    this.contentLabel = paramString2;
    this.contentScroll = (paramString1 != null);
    this.alwaysString = paramString3;
    if ((paramString2 == null) && (paramString1 != null))
    {
      this.infoStrs = new String[1];
      this.infoStrs[0] = paramString1;
      this.contentString = null;
    }
    this.includeMasthead = true;
    this.includeAppInfo = (this.contentString == null);
    this.largeScroll = false;
    try
    {
      this.contentPane.getChildren().add(createTopPanel(false));
      this.contentPane.getChildren().add(createCenterPanel(false, paramString4, paramString5, -1));
      this.contentPane.getChildren().add(createBottomPanel(false));
      this.dialog.setResizable(this.contentScroll);
    }
    catch (Throwable localThrowable) {}
  }
  
  void setErrorContent(String paramString1, String paramString2, String paramString3, Throwable paramThrowable, Object paramObject, Certificate[] paramArrayOfCertificate, boolean paramBoolean)
  {
    Pane localPane1 = (Pane)paramObject;
    this.contentString = paramString1;
    this.throwable = paramThrowable;
    this.detailPanel = localPane1;
    this.certs = paramArrayOfCertificate;
    if (paramBoolean) {
      this.includeAppInfo = false;
    }
    this.useErrorIcon = true;
    try
    {
      this.contentPane.getChildren().add(createTopPanel(false));
      this.contentPane.getChildren().add(createCenterPanel(false, paramString2, paramString3, -1));
      Pane localPane2 = createBottomPanel(false);
      if (localPane2.getChildren().size() > 0) {
        this.contentPane.getChildren().add(localPane2);
      }
      this.dialog.setResizable(false);
    }
    catch (Throwable localThrowable) {}
  }
  
  void setMultiButtonErrorContent(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    this.useErrorIcon = true;
    try
    {
      this.contentPane.getChildren().add(createTopPanel(false));
      BorderPane localBorderPane = new BorderPane();
      localBorderPane.setId("error-panel");
      localBorderPane.setTop(createInfoPanel(paramString1));
      localBorderPane.setBottom(createThreeButtonsPanel(paramString2, paramString3, paramString4, false));
      this.contentPane.getChildren().add(localBorderPane);
      this.dialog.setResizable(false);
    }
    catch (Throwable localThrowable) {}
  }
  
  void setInfoContent(String paramString1, String paramString2)
  {
    this.useInfoIcon = true;
    this.contentString = paramString1;
    try
    {
      this.contentPane.getChildren().add(createTopPanel(false));
      this.contentPane.getChildren().add(createCenterPanel(false, paramString2, null, -1));
      this.dialog.setResizable(false);
    }
    catch (Throwable localThrowable) {}
  }
  
  void setPasswordContent(String paramString1, boolean paramBoolean1, boolean paramBoolean2, String paramString2, String paramString3, boolean paramBoolean3, char[] paramArrayOfChar, String paramString4)
  {
    try
    {
      this.contentPane.getChildren().add(createPasswordPanel(paramString1, paramBoolean1, paramBoolean2, paramString2, paramString3, paramBoolean3, paramArrayOfChar, paramString4));
      this.dialog.initModality(Modality.APPLICATION_MODAL);
      this.dialog.setResizable(false);
      this.dialog.setIconifiable(false);
    }
    catch (Throwable localThrowable) {}
  }
  
  void setUpdateCheckContent(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    try
    {
      this.contentPane.getChildren().add(createTopPanel(false));
      this.contentPane.getChildren().add(createInfoPanel(paramString1));
      this.contentPane.getChildren().add(createThreeButtonsPanel(paramString2, paramString3, paramString4, true));
      this.dialog.setResizable(false);
    }
    catch (Throwable localThrowable) {}
  }
  
  void setProgressContent(String paramString1, String paramString2, String paramString3, boolean paramBoolean, int paramInt)
  {
    try
    {
      this.cacheUpgradeContentString = paramString3;
      this.contentPane.getChildren().add(createTopPanel(false));
      this.contentPane.getChildren().add(createCenterPanel(false, paramString1, paramString2, paramInt));
      if (this.cacheUpgradeContentString == null) {
        this.contentPane.getChildren().add(createBottomPanel(false));
      }
      this.dialog.setResizable(false);
    }
    catch (Throwable localThrowable) {}
  }
  
  private Pane createInfoPanel(String paramString)
  {
    StackPane localStackPane = new StackPane();
    localStackPane.setId("info-panel");
    UITextArea localUITextArea = new UITextArea(508.0D);
    localUITextArea.setId("info-panel-text");
    localUITextArea.setText(paramString);
    localStackPane.getChildren().add(localUITextArea);
    return localStackPane;
  }
  
  private Pane createThreeButtonsPanel(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
  {
    FlowPane localFlowPane = new FlowPane(6.0D, 0.0D);
    localFlowPane.getStyleClass().add("button-bar");
    Button localButton1 = new Button(ResourceManager.getMessage(paramString1));
    localButton1.setOnAction(new EventHandler()
    {
      public void handle(ActionEvent paramAnonymousActionEvent)
      {
        DialogTemplate.this.setUserAnswer(0);
        DialogTemplate.this.setVisible(false);
      }
    });
    localFlowPane.getChildren().add(localButton1);
    Button localButton2 = new Button(ResourceManager.getMessage(paramString2));
    localButton2.setOnAction(new EventHandler()
    {
      public void handle(ActionEvent paramAnonymousActionEvent)
      {
        DialogTemplate.this.setVisible(false);
        DialogTemplate.this.setUserAnswer(1);
      }
    });
    localFlowPane.getChildren().add(localButton2);
    Button localButton3 = null;
    if (paramString3 != null)
    {
      localButton3 = new Button(ResourceManager.getMessage(paramString3));
      localButton3.setOnAction(new EventHandler()
      {
        public void handle(ActionEvent paramAnonymousActionEvent)
        {
          DialogTemplate.this.setVisible(false);
          DialogTemplate.this.setUserAnswer(3);
        }
      });
      localFlowPane.getChildren().add(localButton3);
    }
    if (paramBoolean) {
      localButton3.setTooltip(new Tooltip(ResourceManager.getMessage("autoupdatecheck.masthead")));
    }
    if (localButton3 != null) {
      resizeButtons(new Button[] { localButton1, localButton2, localButton3 });
    } else {
      resizeButtons(new Button[] { localButton1, localButton2 });
    }
    return localFlowPane;
  }
  
  private Pane createTopPanel(boolean paramBoolean)
  {
    this.topPanel = new BorderPane();
    this.topPanel.setId("top-panel");
    if (this.includeMasthead)
    {
      this.masthead1 = new UITextArea(MAIN_TEXT_WIDTH);
      this.masthead1.setId("masthead-label-1");
      Object localObject1 = this.topText;
      String str1 = null;
      for (String str2 : new String[] { "security.dialog.caption.run.question", "security.dialog.caption.continue.question" })
      {
        String str3 = ResourceManager.getMessage(str2);
        if ((str3 != null) && (((String)localObject1).endsWith(str3)))
        {
          str1 = ((String)localObject1).substring(0, ((String)localObject1).indexOf(str3)).trim();
          localObject1 = str3;
          break;
        }
      }
      ??? = new VBox();
      ((VBox)???).setAlignment(Pos.CENTER_LEFT);
      this.masthead1.setText((String)localObject1);
      this.masthead1.setAlignment(Pos.CENTER_LEFT);
      ((VBox)???).getChildren().add(this.masthead1);
      if (str1 != null)
      {
        this.masthead2 = new UITextArea(MAIN_TEXT_WIDTH);
        this.masthead2.setId("masthead-label-2");
        this.masthead2.setText(str1);
        this.masthead2.setAlignment(Pos.CENTER_LEFT);
        ((VBox)???).getChildren().add(this.masthead2);
      }
      this.topPanel.setLeft((Node)???);
      BorderPane.setAlignment((Node)???, Pos.CENTER_LEFT);
      if (paramBoolean)
      {
        ImageView localImageView = ResourceManager.getIcon("progress.background.image");
      }
      else
      {
        this.topIcon = ResourceManager.getIcon("java48.image");
        if (this.useErrorIcon) {
          this.topIcon = ResourceManager.getIcon("error48.image");
        }
        if (this.useInfoIcon) {
          this.topIcon = ResourceManager.getIcon("info48.image");
        }
        if (this.useMixcodeIcon) {
          this.topIcon = ResourceManager.getIcon("mixcode.image");
        }
        if (this.useBlockedIcon) {
          this.topIcon = ResourceManager.getIcon("cert_error48.image");
        }
        if (this.useWarningIcon)
        {
          if (this.majorWarning) {
            this.topIcon = ResourceManager.getIcon("major-warning48.image");
          } else {
            this.topIcon = ResourceManager.getIcon("warning48.image");
          }
        }
        else if (this.ainfo.getIconRef() != null) {
          this.topIcon = ResourceManager.getIcon(this.ainfo.getIconRef());
        }
        this.topPanel.setRight(this.topIcon);
      }
    }
    return this.topPanel;
  }
  
  private Pane createCenterPanel(boolean paramBoolean, String paramString1, String paramString2, int paramInt)
  {
    this.centerPanel = new VBox();
    this.centerPanel.setId("center-panel");
    GridPane localGridPane = new GridPane();
    localGridPane.setId("center-panel-grid");
    Label localLabel1 = new Label(ResourceManager.getMessage("dialog.template.name"));
    localLabel1.setId("dialog-name-label");
    Label localLabel2 = new Label(ResourceManager.getMessage("dialog.template.publisher"));
    localLabel2.setId("dialog-publisher-label");
    Label localLabel3 = new Label(ResourceManager.getMessage("deployment.ssv.location"));
    localLabel3.setId("dialog-from-label");
    Label localLabel4 = new Label(ResourceManager.getMessage("deployment.ssv.reason"));
    localLabel4.setId("dialog-reason-label");
    this.nameInfo = new Label();
    this.nameInfo.setId("dialog-name-value");
    this.publisherInfo = new Label();
    this.publisherInfo.setId("dialog-publisher-value");
    this.urlInfo = new Label();
    this.urlInfo.setId("dialog-from-value");
    Label localLabel5 = new Label();
    localLabel5.setWrapText(true);
    localLabel5.setId("dialog-reason-value");
    int i = 0;
    if (this.ainfo.getTitle() != null)
    {
      GridPane.setConstraints(localLabel1, 0, i);
      GridPane.setHalignment(localLabel1, HPos.RIGHT);
      localGridPane.getChildren().add(localLabel1);
      GridPane.setConstraints(this.nameInfo, 1, i++);
      localGridPane.getChildren().add(this.nameInfo);
    }
    if (this.ainfo.getVendor() != null)
    {
      GridPane.setConstraints(localLabel2, 0, i);
      GridPane.setHalignment(localLabel2, HPos.RIGHT);
      localGridPane.getChildren().add(localLabel2);
      GridPane.setConstraints(this.publisherInfo, 1, i++);
      localGridPane.getChildren().add(this.publisherInfo);
    }
    if (this.ainfo.getFrom() != null)
    {
      GridPane.setConstraints(localLabel3, 0, i);
      GridPane.setHalignment(localLabel3, HPos.RIGHT);
      localGridPane.getChildren().add(localLabel3);
      GridPane.setConstraints(this.urlInfo, 1, i++);
      localGridPane.getChildren().add(this.urlInfo);
      if (this.ainfo.shouldDisplayMainJNLP())
      {
        this.mainJNLPInfo = new Label();
        this.mainJNLPInfo.setId("dialog-from-value");
        GridPane.setConstraints(this.mainJNLPInfo, 1, i++);
        localGridPane.getChildren().add(this.mainJNLPInfo);
      }
      if (this.ainfo.shouldDisplayDocumentBase())
      {
        this.documentBaseInfo = new Label();
        this.documentBaseInfo.setId("dialog-from-value");
        GridPane.setConstraints(this.documentBaseInfo, 1, i++);
        localGridPane.getChildren().add(this.documentBaseInfo);
      }
    }
    if (this.reason != null)
    {
      GridPane.setConstraints(localLabel4, 0, i);
      GridPane.setHalignment(localLabel4, HPos.RIGHT);
      localGridPane.getChildren().add(localLabel4);
      localLabel5.setText(this.reason);
      GridPane.setConstraints(localLabel5, 1, i++);
      localGridPane.getChildren().add(localLabel5);
    }
    setInfo(this.ainfo);
    FlowPane localFlowPane = new FlowPane();
    localFlowPane.setId("center-checkbox-panel");
    BorderPane localBorderPane1 = new BorderPane();
    localBorderPane1.setId("mixed-code-panel");
    BorderPane localBorderPane2 = new BorderPane();
    localBorderPane2.setId("center-content-panel");
    VBox.setVgrow(localBorderPane2, Priority.ALWAYS);
    Object localObject1;
    if (this.alwaysString != null)
    {
      localObject1 = "security.dialog.always";
      this.always = new CheckBox(this.alwaysString);
      this.always.setSelected(paramBoolean);
      localFlowPane.getChildren().add(this.always);
    }
    if (this.mixedCodeString != null)
    {
      this.mixedCodeLabel = new Label(this.mixedCodeString);
      localObject1 = new BorderPane();
      ((BorderPane)localObject1).setId("center-more-info-panel");
      localObject2 = new Hyperlink(ResourceManager.getMessage("dialog.template.more.info"));
      ((Hyperlink)localObject2).setMnemonicParsing(true);
      ((Hyperlink)localObject2).setOnAction(new EventHandler()
      {
        public void handle(ActionEvent paramAnonymousActionEvent)
        {
          DialogTemplate.this.showMixedcodeMoreInfo();
        }
      });
      ((BorderPane)localObject1).setLeft((Node)localObject2);
      localBorderPane1.setTop(this.mixedCodeLabel);
      localBorderPane1.setBottom((Node)localObject1);
    }
    int j = paramInt >= 0 ? 1 : 0;
    if (j != 0)
    {
      this.progressBar = new ProgressBar();
      this.progressBar.setVisible(paramInt <= 100);
    }
    Object localObject4;
    if (this.contentString != null)
    {
      if (this.contentLabel != null)
      {
        localObject2 = new BorderPane();
        ((BorderPane)localObject2).setLeft(new Label(this.contentLabel));
        localBorderPane2.setTop((Node)localObject2);
      }
      if (this.contentScroll)
      {
        boolean bool = this.largeScroll;
        if (this.largeScroll)
        {
          localObject2 = new Label(this.contentString);
          ((Label)localObject2).setPrefWidth(640.0D);
          ((Label)localObject2).setPrefHeight(240.0D);
        }
        else
        {
          localObject2 = new Label(this.contentString);
          ((Label)localObject2).setPrefWidth(320.0D);
          ((Label)localObject2).setPrefHeight(48.0D);
        }
        localObject4 = new ScrollPane();
        ((ScrollPane)localObject4).setContent((Node)localObject2);
        ((ScrollPane)localObject4).setFitToWidth(true);
        VBox.setVgrow((Node)localObject4, Priority.ALWAYS);
        if (bool) {
          ((ScrollPane)localObject4).setMaxWidth(600.0D);
        }
        localBorderPane2.setCenter((Node)localObject4);
      }
      else if (this.isBlockedDialog)
      {
        localObject2 = new VBox();
        localObject3 = new UITextArea(this.contentString);
        ((UITextArea)localObject3).setId("center-content-area");
        ((UITextArea)localObject3).setAlignment(Pos.TOP_CENTER);
        ((UITextArea)localObject3).setPrefWidth(540.0D);
        localObject4 = new Hyperlink(ResourceManager.getMessage("deployment.blocked.moreinfo.hyperlink.text"));
        final String str = ResourceManager.getMessage("deployment.blocked.moreinfo.hyperlink.url");
        ((Hyperlink)localObject4).setMnemonicParsing(true);
        ((Hyperlink)localObject4).setOnAction(new EventHandler()
        {
          public void handle(ActionEvent paramAnonymousActionEvent)
          {
            HostServicesDelegate localHostServicesDelegate = HostServicesImpl.getInstance(null);
            if ((localHostServicesDelegate != null) && (str != null)) {
              localHostServicesDelegate.showDocument(str);
            }
          }
        });
        ((VBox)localObject2).getChildren().add(localObject3);
        ((VBox)localObject2).getChildren().add(localObject4);
        localBorderPane2.setCenter((Node)localObject2);
      }
      else
      {
        localObject2 = new UITextArea(this.contentString);
        ((UITextArea)localObject2).setId("center-content-area");
        ((UITextArea)localObject2).setAlignment(Pos.TOP_LEFT);
        localBorderPane2.setCenter((Node)localObject2);
      }
      localBorderPane2.setPadding(new Insets(0.0D, 0.0D, 12.0D, 0.0D));
    }
    if (this.scrollList != null)
    {
      if (this.contentLabel != null)
      {
        localObject2 = new BorderPane();
        ((BorderPane)localObject2).setLeft(new Label(this.contentLabel));
        localBorderPane2.setTop((Node)localObject2);
      }
      if (this.contentScroll)
      {
        localObject2 = new ScrollPane();
        ((ScrollPane)localObject2).setContent(this.scrollList);
        VBox.setVgrow((Node)localObject2, Priority.ALWAYS);
        localBorderPane2.setCenter((Node)localObject2);
      }
      if (this.showDetails)
      {
        localObject2 = new Hyperlink(ResourceManager.getMessage("security.more.info.details"));
        ((Hyperlink)localObject2).setMnemonicParsing(true);
        ((Hyperlink)localObject2).setOnAction(new EventHandler()
        {
          public void handle(ActionEvent paramAnonymousActionEvent)
          {
            DialogTemplate.this.showCertificateDetails();
          }
        });
        localObject3 = new FlowPane();
        ((FlowPane)localObject3).setPadding(new Insets(12.0D, 0.0D, 12.0D, 0.0D));
        ((FlowPane)localObject3).setAlignment(Pos.TOP_LEFT);
        ((FlowPane)localObject3).getChildren().add(localObject2);
        localBorderPane2.setBottom((Node)localObject3);
      }
    }
    Object localObject2 = new FlowPane(6.0D, 0.0D);
    ((FlowPane)localObject2).getStyleClass().add("button-bar");
    ((FlowPane)localObject2).setId("center-bottom-button-bar");
    this.okBtn = new Button(paramString1 == null ? "" : ResourceManager.getMessage(paramString1));
    this.okBtn.setOnAction(this.okHandler);
    ((FlowPane)localObject2).getChildren().add(this.okBtn);
    this.okBtn.setVisible(paramString1 != null);
    this.cancelBtn = new Button(paramString2 == null ? "" : ResourceManager.getMessage(paramString2));
    this.cancelBtn.setOnAction(this.cancelHandler);
    ((FlowPane)localObject2).getChildren().add(this.cancelBtn);
    this.cancelBtn.setVisible(paramString2 != null);
    if (this.okBtn.isVisible()) {
      this.okBtn.setDefaultButton(true);
    } else {
      this.cancelBtn.setCancelButton(true);
    }
    resizeButtons(new Button[] { this.okBtn, this.cancelBtn });
    if ((this.isBlockedDialog) && (localBorderPane2.getChildren().size() > 0)) {
      this.centerPanel.getChildren().add(localBorderPane2);
    }
    if (this.cacheUpgradeContentString != null)
    {
      localObject3 = new UITextArea(this.cacheUpgradeContentString);
      ((UITextArea)localObject3).setId("cache-upgrade-content");
      localBorderPane2.setTop((Node)localObject3);
    }
    else
    {
      if (this.includeAppInfo) {
        this.centerPanel.getChildren().add(localGridPane);
      }
      if (this.alwaysString != null) {
        this.centerPanel.getChildren().add(localFlowPane);
      }
      if (this.mixedCodeString != null) {
        this.centerPanel.getChildren().add(localBorderPane1);
      }
    }
    if ((!this.isBlockedDialog) && (localBorderPane2.getChildren().size() > 0)) {
      this.centerPanel.getChildren().add(localBorderPane2);
    }
    Object localObject3 = new BorderPane();
    ((BorderPane)localObject3).setId("center-bottom-panel");
    if (j != 0)
    {
      this.progressStatusLabel = new Label(" ");
      this.progressStatusLabel.getStyleClass().add("progress-label");
      localObject4 = new BorderPane();
      ((BorderPane)localObject4).setId("center-progress-status-panel");
      this.centerPanel.getChildren().add(localObject4);
      ((BorderPane)localObject4).setLeft(this.progressStatusLabel);
      ((BorderPane)localObject4).setPadding(new Insets(2.0D, 0.0D, 2.0D, 0.0D));
      ((BorderPane)localObject3).setCenter(this.progressBar);
    }
    ((BorderPane)localObject3).setRight((Node)localObject2);
    this.centerPanel.getChildren().add(localObject3);
    return this.centerPanel;
  }
  
  private Pane createBottomPanel(boolean paramBoolean)
  {
    HBox localHBox = new HBox();
    localHBox.setId("bottom-panel");
    if ((this.alertStrs != null) || (this.infoStrs != null))
    {
      String str = "security.alert.high.image";
      if ((this.alertStrs == null) || (this.alertStrs.length == 0))
      {
        str = "security.alert.low.image";
        if (this.always != null) {
          this.always.setSelected(true);
        }
      }
      else if (this.mixedCodeString == null)
      {
        this.okBtn.setDefaultButton(false);
        this.cancelBtn.setCancelButton(true);
      }
      this.securityIcon = ResourceManager.getIcon(str);
      localHBox.getChildren().add(this.securityIcon);
      int i = 0;
      Hyperlink localHyperlink = null;
      if (paramBoolean)
      {
        localHyperlink = new Hyperlink(ResourceManager.getMessage("dialog.template.more.info"));
        localHyperlink.setMnemonicParsing(true);
        localHyperlink.setId("bottom-more-info-link");
        localHyperlink.setOnAction(new EventHandler()
        {
          public void handle(ActionEvent paramAnonymousActionEvent)
          {
            DialogTemplate.this.showMoreInfo();
          }
        });
      }
      int j = 333;
      UITextArea localUITextArea = new UITextArea(j);
      localUITextArea.setId("bottom-text");
      if (((this.alertStrs == null) || (this.alertStrs.length == 0)) && (this.infoStrs != null) && (this.infoStrs.length != 0)) {
        localUITextArea.setText(this.infoStrs[0] != null ? this.infoStrs[0] : " ");
      } else if ((this.alertStrs != null) && (this.alertStrs.length != 0)) {
        localUITextArea.setText(this.alertStrs[0] != null ? this.alertStrs[0] : " ");
      }
      localHBox.getChildren().add(localUITextArea);
      if (localHyperlink != null) {
        localHBox.getChildren().add(localHyperlink);
      }
    }
    return localHBox;
  }
  
  private BorderPane createSSVTopPanel(String paramString1, String paramString2, String paramString3)
  {
    BorderPane localBorderPane = new BorderPane();
    localBorderPane.setPadding(new Insets(16.0D, 0.0D, 16.0D, 16.0D));
    Label localLabel1 = new Label(paramString1);
    localLabel1.getStyleClass().add("ssv-big-bold-label");
    localBorderPane.setTop(localLabel1);
    Label localLabel2 = new Label(ResourceManager.getMessage("dialog.template.name"));
    localLabel2.getStyleClass().add("ssv-small-bold-label");
    localLabel2.setId("ssv-top-panel-name-label");
    Label localLabel3 = new Label(ResourceManager.getMessage("deployment.ssv.location"));
    localLabel3.getStyleClass().add("ssv-small-bold-label");
    localLabel3.setId("ssv-top-panel-from-label");
    this.nameInfo = new Label(paramString2);
    this.nameInfo.getStyleClass().add("ssv-big-bold-label");
    Label localLabel4 = new Label(paramString3);
    localLabel4.getStyleClass().add("ssv-small-label");
    BorderPane[] arrayOfBorderPane = new BorderPane[4];
    for (int i = 0; i < 4; i++) {
      arrayOfBorderPane[i] = new BorderPane();
    }
    ImageView localImageView = ResourceManager.getIcon("warning48.image");
    arrayOfBorderPane[2].setTop(localLabel2);
    arrayOfBorderPane[2].setBottom(localLabel3);
    arrayOfBorderPane[2].setPadding(new Insets(2.0D, 0.0D, 0.0D, 0.0D));
    arrayOfBorderPane[3].setTop(this.nameInfo);
    arrayOfBorderPane[3].setBottom(localLabel4);
    arrayOfBorderPane[1].setLeft(arrayOfBorderPane[2]);
    arrayOfBorderPane[1].setCenter(arrayOfBorderPane[3]);
    arrayOfBorderPane[1].setPadding(new Insets(12.0D, 0.0D, 12.0D, 0.0D));
    arrayOfBorderPane[0].setLeft(localImageView);
    arrayOfBorderPane[0].setRight(arrayOfBorderPane[1]);
    arrayOfBorderPane[0].setPadding(new Insets(8.0D, 0.0D, 0.0D, 32.0D));
    localBorderPane.setBottom(arrayOfBorderPane[0]);
    return localBorderPane;
  }
  
  private BorderPane createSSVRiskPanel(String paramString1, String paramString2, final URL paramURL)
  {
    BorderPane localBorderPane1 = new BorderPane();
    localBorderPane1.setPadding(new Insets(8.0D, 8.0D, 0.0D, 8.0D));
    int i = paramString1.indexOf(" ");
    if (i < paramString1.length() - 2)
    {
      String str1 = paramString1.substring(0, i);
      String str2 = paramString1.substring(i + 1);
      BorderPane localBorderPane2 = new BorderPane();
      Label localLabel1 = new Label(str1);
      localLabel1.getStyleClass().add("ssv-small-bold-label");
      localBorderPane2.setTop(localLabel1);
      localBorderPane2.setPadding(new Insets(0.0D, 8.0D, 0.0D, 8.0D));
      BorderPane localBorderPane3 = new BorderPane();
      Label localLabel2 = new Label(str2);
      localBorderPane3.setLeft(localLabel2);
      localLabel2.getStyleClass().add("ssv-small-label");
      Hyperlink localHyperlink = new Hyperlink(paramString2);
      localHyperlink.setOnAction(new EventHandler()
      {
        public void handle(ActionEvent paramAnonymousActionEvent)
        {
          HostServicesDelegate localHostServicesDelegate = HostServicesImpl.getInstance(null);
          if ((localHostServicesDelegate != null) && (paramURL != null)) {
            localHostServicesDelegate.showDocument(paramURL.toExternalForm());
          }
        }
      });
      localBorderPane3.setRight(localHyperlink);
      localBorderPane1.setLeft(localBorderPane2);
      localBorderPane1.setCenter(localBorderPane3);
    }
    return localBorderPane1;
  }
  
  private Pane createPasswordPanel(String paramString1, boolean paramBoolean1, boolean paramBoolean2, String paramString2, String paramString3, boolean paramBoolean3, char[] paramArrayOfChar, String paramString4)
  {
    Label localLabel1 = new Label();
    Label localLabel2 = new Label();
    ImageView localImageView = ResourceManager.getIcon("pwd-masthead.png");
    if (paramBoolean1)
    {
      str = "password.dialog.username";
      localLabel1.setText(ResourceManager.getMessage(str));
      localLabel1.setMnemonicParsing(true);
      this.pwdName = new TextField();
      this.pwdName.setId("user-name-field");
      this.pwdName.setText(paramString2);
      localLabel1.setLabelFor(this.pwdName);
      localLabel1.setId("user-name-label");
    }
    String str = "password.dialog.password";
    Label localLabel3 = new Label(ResourceManager.getMessage(str));
    this.password = new PasswordField();
    this.password.setText(String.valueOf(paramArrayOfChar));
    localLabel3.setLabelFor(this.password);
    localLabel3.setMnemonicParsing(true);
    localLabel3.setId("password-label");
    if (paramBoolean2)
    {
      localObject = "password.dialog.domain";
      localLabel2.setText(ResourceManager.getMessage((String)localObject));
      this.pwdDomain = new TextField();
      this.pwdDomain.setText(paramString3);
      localLabel2.setLabelFor(this.pwdDomain);
      localLabel2.setMnemonicParsing(true);
      localLabel2.setId("password-domain-label");
    }
    Object localObject = new VBox();
    ((VBox)localObject).setMaxWidth(localImageView.getImage().getWidth());
    ((VBox)localObject).getChildren().add(localImageView);
    VBox localVBox = new VBox(10.0D);
    localVBox.setId("password-panel");
    Label localLabel4 = new Label();
    localLabel4.setId("password-details");
    localLabel4.setWrapText(true);
    localLabel4.setText(paramString1);
    localVBox.getChildren().add(localLabel4);
    GridPane localGridPane = new GridPane();
    localGridPane.setId("password-panel-grid");
    int i = 0;
    if (paramBoolean1)
    {
      GridPane.setConstraints(localLabel1, 0, i);
      GridPane.setHalignment(localLabel1, HPos.RIGHT);
      localGridPane.getChildren().add(localLabel1);
      GridPane.setConstraints(this.pwdName, 1, i++);
      localGridPane.getChildren().add(this.pwdName);
    }
    GridPane.setConstraints(localLabel3, 0, i);
    GridPane.setHalignment(localLabel3, HPos.RIGHT);
    localGridPane.getChildren().add(localLabel3);
    GridPane.setConstraints(this.password, 1, i++);
    localGridPane.getChildren().add(this.password);
    if (paramBoolean2)
    {
      GridPane.setConstraints(localLabel2, 0, i);
      GridPane.setHalignment(localLabel2, HPos.RIGHT);
      localGridPane.getChildren().add(localLabel2);
      GridPane.setConstraints(this.pwdDomain, 1, i++);
      localGridPane.getChildren().add(this.pwdDomain);
    }
    if (paramBoolean3)
    {
      this.always = new CheckBox(ResourceManager.getMessage("password.dialog.save"));
      this.always.setId("password-always-checkbox");
      this.always.setSelected(paramArrayOfChar.length > 0);
      GridPane.setConstraints(this.always, 1, i++);
      localGridPane.getChildren().add(this.always);
    }
    localVBox.getChildren().add(localGridPane);
    FlowPane localFlowPane = new FlowPane(6.0D, 0.0D);
    localFlowPane.setPrefWrapLength(300.0D);
    localFlowPane.getStyleClass().add("button-bar");
    localFlowPane.setId("password-button-bar");
    this.okBtn = new Button(ResourceManager.getMessage("common.ok_btn"));
    this.okBtn.setOnAction(this.okHandler);
    this.okBtn.setDefaultButton(true);
    this.cancelBtn = new Button(ResourceManager.getMessage("common.cancel_btn"));
    this.cancelBtn.setOnAction(this.cancelHandler);
    resizeButtons(new Button[] { this.okBtn, this.cancelBtn });
    localFlowPane.getChildren().addAll(new Node[] { this.okBtn, this.cancelBtn });
    localVBox.getChildren().add(localFlowPane);
    if (paramString4 != null)
    {
      MessageFormat localMessageFormat = new MessageFormat(ResourceManager.getMessage("password.dialog.scheme"));
      Object[] arrayOfObject = { paramString4 };
      Label localLabel5 = new Label(localMessageFormat.format(arrayOfObject));
      localVBox.getChildren().add(localLabel5);
    }
    ((VBox)localObject).getChildren().add(localVBox);
    return (Pane)localObject;
  }
  
  void showMoreInfo()
  {
    MoreInfoDialog localMoreInfoDialog;
    if ((this.throwable == null) && (this.detailPanel == null)) {
      localMoreInfoDialog = new MoreInfoDialog(this.dialog, this.alertStrs, this.infoStrs, this.securityInfoCount, this.certs, this.start, this.end, this.sandboxApp);
    } else {
      localMoreInfoDialog = new MoreInfoDialog(this.dialog, this.detailPanel, this.throwable, this.certs);
    }
    localMoreInfoDialog.show();
  }
  
  void showMixedcodeMoreInfo()
  {
    MoreInfoDialog localMoreInfoDialog = new MoreInfoDialog(this.dialog, null, this.infoStrs, 0, null, 0, 0, this.sandboxApp);
    localMoreInfoDialog.show();
  }
  
  void showCertificateDetails()
  {
    long l = this.scrollList.getSelectionModel().getSelectedIndex();
    X509Certificate[] arrayOfX509Certificate = null;
    Iterator localIterator = this.clientAuthCertsMap.values().iterator();
    while ((l >= 0L) && (localIterator.hasNext()))
    {
      arrayOfX509Certificate = (X509Certificate[])localIterator.next();
      l -= 1L;
    }
    if (arrayOfX509Certificate != null) {
      CertificateDialog.showCertificates(this.dialog, arrayOfX509Certificate, 0, arrayOfX509Certificate.length);
    }
  }
  
  public void setVisible(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      final FXDialog localFXDialog = this.dialog;
      Runnable local12 = new Runnable()
      {
        public void run()
        {
          localFXDialog.showAndWait();
        }
      };
      local12.run();
    }
    else
    {
      this.dialog.hide();
    }
  }
  
  public static void resizeButtons(Button... paramVarArgs)
  {
    int i = paramVarArgs.length;
    double d = 50.0D;
    for (int j = 0; j < i; j++) {
      if (paramVarArgs[j].prefWidth(-1.0D) > d) {
        d = paramVarArgs[j].prefWidth(-1.0D);
      }
    }
  }
  
  public void cancelAction()
  {
    this.userAnswer = 1;
    setVisible(false);
  }
  
  int getUserAnswer()
  {
    return this.userAnswer;
  }
  
  void setUserAnswer(int paramInt)
  {
    this.userAnswer = paramInt;
  }
  
  char[] getPassword()
  {
    return this.pwd;
  }
  
  String getUserName()
  {
    return this.userName;
  }
  
  String getDomain()
  {
    return this.domain;
  }
  
  public boolean isPasswordSaved()
  {
    return (this.always != null) && (this.always.isSelected());
  }
  
  public void progress(int paramInt)
  {
    if (this.progressBar != null) {
      if (paramInt <= 100)
      {
        this.progressBar.setProgress(paramInt / 100.0D);
        this.progressBar.setVisible(true);
      }
      else
      {
        this.progressBar.setVisible(false);
      }
    }
  }
  
  public FXDialog getDialog()
  {
    return this.dialog;
  }
  
  static String getDisplayMainJNLPTooltip(AppInfo paramAppInfo)
  {
    try
    {
      Class localClass = AppInfo.class;
      Method localMethod = localClass.getMethod("getDisplayMainJNLPTooltip", (Class[])null);
      return (String)localMethod.invoke(paramAppInfo, new Object[0]);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return "";
  }
  
  public void setInfo(AppInfo paramAppInfo)
  {
    this.ainfo = paramAppInfo;
    if (this.nameInfo != null) {
      this.nameInfo.setText(paramAppInfo.getTitle());
    }
    if (this.publisherInfo != null) {
      this.publisherInfo.setText(paramAppInfo.getVendor());
    }
    URL localURL;
    if (this.urlInfo != null)
    {
      this.urlInfo.setText(paramAppInfo.getDisplayFrom());
      localURL = paramAppInfo.getFrom();
      this.urlInfo.setTooltip(new Tooltip(localURL == null ? "" : localURL.toString()));
    }
    if (this.mainJNLPInfo != null)
    {
      this.mainJNLPInfo.setText(paramAppInfo.getDisplayMainJNLP());
      this.mainJNLPInfo.setTooltip(new Tooltip(getDisplayMainJNLPTooltip(paramAppInfo)));
    }
    if (this.documentBaseInfo != null)
    {
      this.documentBaseInfo.setText(paramAppInfo.getDisplayDocumentBase());
      localURL = paramAppInfo.getDocumentBase();
      this.documentBaseInfo.setTooltip(new Tooltip(localURL == null ? "" : localURL.toString()));
    }
  }
  
  void showOk(boolean paramBoolean)
  {
    resizeButtons(new Button[] { this.okBtn, this.cancelBtn });
    this.okBtn.setVisible(paramBoolean);
  }
  
  void stayAlive()
  {
    this.stayAliveOnOk = true;
  }
  
  public void setProgressStatusText(String paramString)
  {
    if (this.progressStatusLabel != null)
    {
      if ((paramString == null) || (paramString.length() == 0)) {
        paramString = " ";
      }
      this.progressStatusLabel.setText(paramString);
    }
  }
  
  void setPublisherInfo(String paramString1, String paramString2, String paramString3, Object paramObject, boolean paramBoolean)
  {
    this.detailPanel = ((Pane)paramObject);
    this.contentString = paramString1;
    this.useInfoIcon = true;
    if (paramObject == null) {
      paramString3 = null;
    }
    if (paramBoolean) {
      this.includeAppInfo = false;
    }
    this.okBtnStr = paramString2;
    this.cancelBtnStr = paramString3;
    try
    {
      this.contentPane.getChildren().add(createTopPanel(true));
      this.contentPane.getChildren().add(createCenterPanel(false, paramString2, paramString3, -1));
      this.dialog.setResizable(false);
      this.dialog.setIconifiable(false);
    }
    catch (Throwable localThrowable)
    {
      Trace.ignored(localThrowable);
    }
  }
  
  void setBlockedDialogInfo(String paramString1, String paramString2, String paramString3, String paramString4, Object paramObject, boolean paramBoolean)
  {
    this.detailPanel = ((Pane)paramObject);
    this.contentString = paramString2;
    this.reason = paramString1;
    this.useBlockedIcon = true;
    this.isBlockedDialog = true;
    if (paramObject == null) {
      paramString4 = null;
    }
    if (paramBoolean) {
      this.includeAppInfo = false;
    }
    this.okBtnStr = paramString3;
    this.cancelBtnStr = paramString4;
    try
    {
      this.contentPane.getChildren().add(createTopPanel(true));
      this.contentPane.getChildren().add(createCenterPanel(false, paramString3, paramString4, -1));
      this.dialog.setResizable(false);
      this.dialog.setIconifiable(false);
    }
    catch (Throwable localThrowable)
    {
      Trace.ignored(localThrowable);
    }
  }
  
  static void showDocument(String paramString)
  {
    try
    {
      Class localClass = Class.forName("com.sun.deploy.config.Platform");
      Method localMethod1 = localClass.getMethod("get", new Class[0]);
      Object localObject = localMethod1.invoke(null, new Object[0]);
      Method localMethod2 = localObject.getClass().getMethod("showDocument", new Class[] { String.class });
      localMethod2.invoke(localObject, new Object[] { paramString });
    }
    catch (Exception localException)
    {
      Trace.ignored(localException);
    }
  }
  
  private class SSVChoicePanel
    extends BorderPane
  {
    ToggleGroup group;
    RadioButton button1;
    RadioButton button2;
    
    public SSVChoicePanel(String paramString1, String paramString2, String paramString3)
    {
      setPadding(new Insets(8.0D, 16.0D, 0.0D, 16.0D));
      BorderPane localBorderPane = new BorderPane();
      VBox localVBox = new VBox();
      localVBox.setSpacing(4.0D);
      Label localLabel = new Label(paramString1);
      localLabel.getStyleClass().add("ssv-small-bold-label");
      localBorderPane.setCenter(localLabel);
      this.button1 = new RadioButton(paramString2);
      this.button1.getStyleClass().add("ssv-small-label");
      this.button2 = new RadioButton(paramString3);
      this.button2.getStyleClass().add("ssv-small-label");
      this.group = new ToggleGroup();
      this.button1.setToggleGroup(this.group);
      this.button2.setToggleGroup(this.group);
      this.button1.setSelected(true);
      localVBox.getChildren().addAll(new Node[] { this.button1, this.button2 });
      localVBox.setPadding(new Insets(0.0D, 16.0D, 0.0D, 32.0D));
      setTop(localBorderPane);
      setBottom(localVBox);
      this.button1.requestFocus();
    }
    
    public int getSelection()
    {
      if (this.button2.isSelected()) {
        return 1;
      }
      return 0;
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\DialogTemplate.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */