package com.sun.deploy.uitoolkit.impl.fx;

import com.sun.javafx.applet.HostServicesImpl;
import com.sun.javafx.application.HostServicesDelegate;
import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URL;
import javafx.application.Application;
import netscape.javascript.JSObject;

public class HostServicesFactory
{
  public static HostServicesDelegate getInstance(Application paramApplication)
  {
    HostServicesDelegate localHostServicesDelegate = HostServicesImpl.getInstance(paramApplication);
    if (localHostServicesDelegate == null) {
      localHostServicesDelegate = StandaloneHostService.getInstance(paramApplication);
    }
    return localHostServicesDelegate;
  }
  
  private HostServicesFactory()
  {
    throw new InternalError();
  }
  
  private static class StandaloneHostService
    extends HostServicesDelegate
  {
    private static HostServicesDelegate instance = null;
    private Class appClass = null;
    static final String[] browsers = { "google-chrome", "firefox", "opera", "konqueror", "mozilla" };
    
    public static HostServicesDelegate getInstance(Application paramApplication)
    {
      synchronized (StandaloneHostService.class)
      {
        if (instance == null) {
          instance = new StandaloneHostService(paramApplication);
        }
        return instance;
      }
    }
    
    private StandaloneHostService(Application paramApplication)
    {
      this.appClass = paramApplication.getClass();
    }
    
    public String getCodeBase()
    {
      String str1 = this.appClass.getName();
      int i = str1.lastIndexOf(".");
      if (i >= 0) {
        str1 = str1.substring(i + 1);
      }
      str1 = str1 + ".class";
      String str2 = this.appClass.getResource(str1).toString();
      if ((!str2.startsWith("jar:file:")) || (str2.indexOf("!") == -1)) {
        return "";
      }
      String str3 = str2.substring(4, str2.lastIndexOf("!"));
      File localFile = null;
      try
      {
        localFile = new File(new URI(str3).getPath());
      }
      catch (Exception localException) {}
      if (localFile != null)
      {
        String str4 = localFile.getParent();
        if (str4 != null) {
          return toURIString(str4);
        }
      }
      return "";
    }
    
    private String toURIString(String paramString)
    {
      try
      {
        return new File(paramString).toURI().toString();
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
      return "";
    }
    
    public String getDocumentBase()
    {
      return toURIString(System.getProperty("user.dir"));
    }
    
    public void showDocument(String paramString)
    {
      String str1 = System.getProperty("os.name");
      try
      {
        if (str1.startsWith("Mac OS"))
        {
          Class.forName("com.apple.eio.FileManager").getDeclaredMethod("openURL", new Class[] { String.class }).invoke(null, new Object[] { paramString });
        }
        else if (str1.startsWith("Windows"))
        {
          Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + paramString);
        }
        else
        {
          Object localObject = null;
          for (String str2 : browsers) {
            if (localObject == null) {
              if (Runtime.getRuntime().exec(new String[] { "which", str2 }).getInputStream().read() != -1) {
                Runtime.getRuntime().exec(new String[] { localObject = str2, paramString });
              }
            }
          }
          if (localObject == null) {
            throw new Exception("No web browser found");
          }
        }
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
    }
    
    public JSObject getWebContext()
    {
      return null;
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\HostServicesFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */