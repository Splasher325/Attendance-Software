package com.sun.deploy.uitoolkit.impl.fx;

import javafx.stage.Stage;

public abstract interface AppletStageManager
{
  public abstract Stage getAppletStage();
  
  public abstract Stage getPreloaderStage();
  
  public abstract Stage getErrorStage();
  
  public abstract void setSize(int paramInt1, int paramInt2);
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\AppletStageManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */