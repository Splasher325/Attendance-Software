package com.sun.deploy.uitoolkit.impl.fx.ui;

import javafx.scene.control.Label;

public class UITextArea
  extends Label
{
  double preferred_width = 360.0D;
  
  public UITextArea(String paramString)
  {
    setText(paramString);
    setPrefWidth(this.preferred_width);
  }
  
  public UITextArea(double paramDouble)
  {
    this.preferred_width = paramDouble;
    setPrefWidth(this.preferred_width);
    setMinSize(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\UITextArea.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */