package com.sun.deploy.uitoolkit.impl.fx.ui;

import com.sun.deploy.appcontext.AppContext;
import java.util.HashMap;

public class FXAppContext
  implements AppContext
{
  private HashMap storage = new HashMap();
  private static FXAppContext theInstance = new FXAppContext();
  
  public static synchronized FXAppContext getInstance()
  {
    return theInstance;
  }
  
  public Object get(Object paramObject)
  {
    return this.storage.get(paramObject);
  }
  
  public Object put(Object paramObject1, Object paramObject2)
  {
    return this.storage.put(paramObject1, paramObject2);
  }
  
  public Object remove(Object paramObject)
  {
    return this.storage.remove(paramObject);
  }
  
  public void invokeLater(Runnable paramRunnable)
  {
    paramRunnable.run();
  }
  
  public void invokeAndWait(Runnable paramRunnable)
  {
    paramRunnable.run();
  }
  
  public ThreadGroup getThreadGroup()
  {
    return Thread.currentThread().getThreadGroup();
  }
  
  public void dispose()
  {
    this.storage.clear();
  }
  
  public boolean destroy(long paramLong)
  {
    return true;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\FXAppContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */