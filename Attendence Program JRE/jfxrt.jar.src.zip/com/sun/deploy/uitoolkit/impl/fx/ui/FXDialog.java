package com.sun.deploy.uitoolkit.impl.fx.ui;

import com.sun.javafx.stage.StageHelper;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.css.PseudoClass;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.geometry.Point2D;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToolBar;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;

class FXDialog
  extends Stage
{
  private BorderPane root;
  private StackPane decoratedRoot;
  private ToolBar toolBar;
  private HBox windowBtns;
  private Button minButton;
  private Button maxButton;
  private Rectangle resizeCorner;
  private double mouseDragOffsetX = 0.0D;
  private double mouseDragOffsetY = 0.0D;
  protected Label titleLabel;
  private static final int HEADER_HEIGHT = 28;
  private static final PseudoClass PSEUDO_CLASS_ACTIVE = PseudoClass.getPseudoClass("active");
  
  FXDialog(String paramString)
  {
    this(paramString, null, false);
  }
  
  FXDialog(String paramString, Window paramWindow, boolean paramBoolean)
  {
    this(paramString, paramWindow, paramBoolean, StageStyle.TRANSPARENT, true);
  }
  
  FXDialog(String paramString, Window paramWindow, boolean paramBoolean1, StageStyle paramStageStyle, boolean paramBoolean2)
  {
    super(paramStageStyle);
    StageHelper.initSecurityDialog(this, paramBoolean2);
    setTitle(paramString);
    if (paramWindow != null) {
      initOwner(paramWindow);
    }
    if (paramBoolean1) {
      initModality(Modality.WINDOW_MODAL);
    }
    resizableProperty().addListener(new InvalidationListener()
    {
      public void invalidated(Observable paramAnonymousObservable)
      {
        FXDialog.this.resizeCorner.setVisible(FXDialog.this.isResizable());
        FXDialog.this.maxButton.setVisible(FXDialog.this.isResizable());
      }
    });
    this.root = new BorderPane();
    if (paramStageStyle == StageStyle.DECORATED)
    {
      localScene = new Scene(this.root);
      localScene.getStylesheets().addAll(new String[] { FXDialog.class.getResource("deploydialogs.css").toExternalForm() });
      setScene(localScene);
      return;
    }
    this.decoratedRoot = new StackPane()
    {
      protected void layoutChildren()
      {
        super.layoutChildren();
        if (FXDialog.this.resizeCorner != null) {
          FXDialog.this.resizeCorner.relocate(getWidth() - 20.0D, getHeight() - 20.0D);
        }
      }
    };
    this.decoratedRoot.getChildren().add(this.root);
    Scene localScene = new Scene(this.decoratedRoot);
    String str = (String)AccessController.doPrivileged(new PrivilegedAction()
    {
      public Object run()
      {
        URL localURL = FXDialog.class.getResource("deploydialogs.css");
        return localURL.toExternalForm();
      }
    });
    localScene.getStylesheets().addAll(new String[] { str });
    localScene.setFill(Color.TRANSPARENT);
    setScene(localScene);
    this.decoratedRoot.getStyleClass().add("decorated-root");
    focusedProperty().addListener(new InvalidationListener()
    {
      public void invalidated(Observable paramAnonymousObservable)
      {
        boolean bool = ((ReadOnlyBooleanProperty)paramAnonymousObservable).get();
        FXDialog.this.decoratedRoot.pseudoClassStateChanged(FXDialog.PSEUDO_CLASS_ACTIVE, bool);
      }
    });
    this.toolBar = new ToolBar();
    this.toolBar.setId("window-header");
    this.toolBar.setPrefHeight(28.0D);
    this.toolBar.setMinHeight(28.0D);
    this.toolBar.setMaxHeight(28.0D);
    addDragHandlers(this.toolBar);
    this.titleLabel = new Label();
    this.titleLabel.setId("window-title");
    this.titleLabel.setText(getTitle());
    titleProperty().addListener(new InvalidationListener()
    {
      public void invalidated(Observable paramAnonymousObservable)
      {
        FXDialog.this.titleLabel.setText(FXDialog.this.getTitle());
      }
    });
    Region localRegion = new Region();
    HBox.setHgrow(localRegion, Priority.ALWAYS);
    WindowButton localWindowButton = new WindowButton("close");
    localWindowButton.setOnAction(new EventHandler()
    {
      public void handle(Event paramAnonymousEvent)
      {
        FXDialog.this.hide();
      }
    });
    this.minButton = new WindowButton("minimize");
    this.minButton.setOnAction(new EventHandler()
    {
      public void handle(Event paramAnonymousEvent)
      {
        FXDialog.this.setIconified(!FXDialog.this.isIconified());
      }
    });
    this.maxButton = new WindowButton("maximize");
    this.maxButton.setOnAction(new EventHandler()
    {
      private double restoreX;
      private double restoreY;
      private double restoreW;
      private double restoreH;
      
      public void handle(Event paramAnonymousEvent)
      {
        Screen localScreen = Screen.getPrimary();
        double d1 = localScreen.getVisualBounds().getMinX();
        double d2 = localScreen.getVisualBounds().getMinY();
        double d3 = localScreen.getVisualBounds().getWidth();
        double d4 = localScreen.getVisualBounds().getHeight();
        if ((this.restoreW == 0.0D) || (FXDialog.this.getX() != d1) || (FXDialog.this.getY() != d2) || (FXDialog.this.getWidth() != d3) || (FXDialog.this.getHeight() != d4))
        {
          this.restoreX = FXDialog.this.getX();
          this.restoreY = FXDialog.this.getY();
          this.restoreW = FXDialog.this.getWidth();
          this.restoreH = FXDialog.this.getHeight();
          FXDialog.this.setX(d1);
          FXDialog.this.setY(d2);
          FXDialog.this.setWidth(d3);
          FXDialog.this.setHeight(d4);
        }
        else
        {
          FXDialog.this.setX(this.restoreX);
          FXDialog.this.setY(this.restoreY);
          FXDialog.this.setWidth(this.restoreW);
          FXDialog.this.setHeight(this.restoreH);
        }
      }
    });
    this.windowBtns = new HBox(3.0D);
    this.windowBtns.getChildren().addAll(new Node[] { this.minButton, this.maxButton, localWindowButton });
    this.toolBar.getItems().addAll(new Node[] { this.titleLabel, localRegion, this.windowBtns });
    this.root.setTop(this.toolBar);
    this.resizeCorner = new Rectangle(10.0D, 10.0D);
    this.resizeCorner.setId("window-resize-corner");
    EventHandler local9 = new EventHandler()
    {
      private double width;
      private double height;
      private Point2D dragAnchor;
      
      public void handle(MouseEvent paramAnonymousMouseEvent)
      {
        EventType localEventType = paramAnonymousMouseEvent.getEventType();
        if (localEventType == MouseEvent.MOUSE_PRESSED)
        {
          this.width = FXDialog.this.getWidth();
          this.height = FXDialog.this.getHeight();
          this.dragAnchor = new Point2D(paramAnonymousMouseEvent.getSceneX(), paramAnonymousMouseEvent.getSceneY());
        }
        else if (localEventType == MouseEvent.MOUSE_DRAGGED)
        {
          FXDialog.this.setWidth(Math.max(FXDialog.this.decoratedRoot.minWidth(-1.0D), this.width + (paramAnonymousMouseEvent.getSceneX() - this.dragAnchor.getX())));
          FXDialog.this.setHeight(Math.max(FXDialog.this.decoratedRoot.minHeight(-1.0D), this.height + (paramAnonymousMouseEvent.getSceneY() - this.dragAnchor.getY())));
        }
      }
    };
    this.resizeCorner.setOnMousePressed(local9);
    this.resizeCorner.setOnMouseDragged(local9);
    this.resizeCorner.setManaged(false);
    this.decoratedRoot.getChildren().add(this.resizeCorner);
  }
  
  void setContentPane(Pane paramPane)
  {
    if (paramPane.getId() == null) {
      paramPane.setId("content-pane");
    }
    this.root.setCenter(paramPane);
  }
  
  public void setIconifiable(boolean paramBoolean)
  {
    this.minButton.setVisible(paramBoolean);
  }
  
  public void hideWindowTitle()
  {
    if (this.toolBar != null)
    {
      this.root.setTop(null);
      sizeToScene();
      addDragHandlers(this.root);
    }
  }
  
  private void addDragHandlers(Node paramNode)
  {
    paramNode.setOnMousePressed(new EventHandler()
    {
      public void handle(MouseEvent paramAnonymousMouseEvent)
      {
        FXDialog.this.mouseDragOffsetX = paramAnonymousMouseEvent.getSceneX();
        FXDialog.this.mouseDragOffsetY = paramAnonymousMouseEvent.getSceneY();
      }
    });
    paramNode.setOnMouseDragged(new EventHandler()
    {
      public void handle(MouseEvent paramAnonymousMouseEvent)
      {
        FXDialog.this.setX(paramAnonymousMouseEvent.getScreenX() - FXDialog.this.mouseDragOffsetX);
        FXDialog.this.setY(paramAnonymousMouseEvent.getScreenY() - FXDialog.this.mouseDragOffsetY);
      }
    });
  }
  
  public static Button createCloseButton()
  {
    return new WindowButton("black-close");
  }
  
  private static class WindowButton
    extends Button
  {
    WindowButton(String paramString)
    {
      getStyleClass().setAll(new String[] { "window-button" });
      setId("window-" + paramString + "-button");
      StackPane localStackPane = new StackPane();
      localStackPane.getStyleClass().setAll(new String[] { "graphic" });
      setGraphic(localStackPane);
      setMinSize(17.0D, 17.0D);
      setPrefSize(17.0D, 17.0D);
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\FXDialog.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */