package com.sun.deploy.uitoolkit.impl.fx.ui;

import com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager;
import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.MessageFormat;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public class FXAboutDialog
{
  static void showAboutJavaDialog()
  {
    FXDialog localFXDialog = new FXDialog(ResourceManager.getMessage("dialogfactory.aboutDialogTitle"));
    localFXDialog.setResizable(false);
    VBox localVBox1 = new VBox();
    VBox localVBox2 = new VBox();
    localVBox2.setId("about-dialog-top-panel");
    localVBox1.getChildren().add(localVBox2);
    String str1 = System.getProperty("java.version");
    int i = str1.indexOf(".");
    String str2 = str1.substring(i + 1, str1.indexOf(".", i + 1));
    ImageView localImageView1 = ResourceManager.getIcon("about.java" + ("6".equals(str2) ? "6" : "") + ".image");
    localVBox2.getChildren().add(localImageView1);
    VBox localVBox3 = new VBox();
    localVBox3.setId("about-dialog-center-panel");
    localVBox2.getChildren().add(localVBox3);
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(getVersionStr());
    localStringBuilder.append("\n");
    localStringBuilder.append(ResourceManager.getMessage("about.copyright"));
    localStringBuilder.append("\n \n");
    localStringBuilder.append(ResourceManager.getMessage("about.prompt.info"));
    Label localLabel = new Label();
    localLabel.setWrapText(true);
    localLabel.setText(localStringBuilder.toString());
    localLabel.setPrefWidth(localImageView1.prefWidth(-1.0D) - 16.0D);
    localLabel.setMinWidth(Double.NEGATIVE_INFINITY);
    localVBox3.getChildren().add(localLabel);
    String str3 = ResourceManager.getMessage("about.home.link");
    Hyperlink localHyperlink = new Hyperlink(str3);
    localHyperlink.setOnAction(new EventHandler()
    {
      public void handle(Event paramAnonymousEvent)
      {
        FXAboutDialog.browserToUrl(this.val$linkURL);
      }
    });
    localVBox3.getChildren().add(localHyperlink);
    ImageView localImageView2 = ResourceManager.getIcon("sun.logo.image");
    localVBox3.getChildren().add(localImageView2);
    StackPane localStackPane = new StackPane();
    localStackPane.getStyleClass().add("button-bar");
    localStackPane.setId("about-dialog-button-bar");
    localVBox1.getChildren().add(localStackPane);
    Button localButton = new Button(ResourceManager.getMessage("about.option.close"));
    localButton.setDefaultButton(true);
    localButton.setOnAction(new EventHandler()
    {
      public void handle(Event paramAnonymousEvent)
      {
        this.val$dialog.close();
      }
    });
    localButton.setAlignment(Pos.TOP_LEFT);
    localStackPane.getChildren().add(localButton);
    localFXDialog.setContentPane(localVBox1);
    localFXDialog.show();
    localButton.requestFocus();
  }
  
  private static void browserToUrl(String paramString)
  {
    try
    {
      Desktop.getDesktop().browse(new URI(paramString));
    }
    catch (URISyntaxException localURISyntaxException)
    {
      localURISyntaxException.printStackTrace();
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }
  
  private static String getVersionStr()
  {
    String str1 = System.getProperty("java.version");
    int i = str1.indexOf(".");
    String str2 = str1.substring(i + 1, str1.indexOf(".", i + 1));
    int j = str1.lastIndexOf("_");
    String str3 = null;
    if (j != -1)
    {
      int k = str1.indexOf("-");
      if (k != -1) {
        str3 = str1.substring(j + 1, k);
      } else {
        str3 = str1.substring(j + 1, str1.length());
      }
      if (str3.startsWith("0")) {
        str3 = str3.substring(1);
      }
    }
    String str4 = null;
    if (str3 != null) {
      str4 = MessageFormat.format(ResourceManager.getMessage("about.java.version.update"), new Object[] { str2, str3 });
    } else {
      str4 = MessageFormat.format(ResourceManager.getMessage("about.java.version"), new Object[] { str2 });
    }
    String str5 = MessageFormat.format(ResourceManager.getMessage("about.java.build"), new Object[] { System.getProperty("java.runtime.version") });
    return str4 + " " + str5;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\FXAboutDialog.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */