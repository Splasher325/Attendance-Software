package com.sun.deploy.uitoolkit.impl.fx.ui;

import com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager;
import java.security.MessageDigest;
import java.security.Principal;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.text.MessageFormat;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ListChangeListener.Change;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MultipleSelectionModel;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TableView.TableViewSelectionModel;
import javafx.scene.control.TextArea;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;
import javafx.util.Callback;
import sun.misc.HexDumpEncoder;
import sun.security.x509.SerialNumber;

public class CertificateDialog
{
  public static void showCertificates(Stage paramStage, Certificate[] paramArrayOfCertificate, int paramInt1, int paramInt2)
  {
    FXDialog localFXDialog = new FXDialog(ResourceManager.getMessage("cert.dialog.caption"), paramStage, true);
    localFXDialog.setWidth(800.0D);
    localFXDialog.setHeight(600.0D);
    BorderPane localBorderPane = new BorderPane();
    localFXDialog.setContentPane(localBorderPane);
    localBorderPane.setCenter(getComponents(paramStage, paramArrayOfCertificate, paramInt1, paramInt2));
    FlowPane localFlowPane = new FlowPane();
    localFlowPane.getStyleClass().add("button-bar");
    Button localButton = new Button(ResourceManager.getMessage("cert.dialog.close"));
    localButton.setDefaultButton(true);
    localButton.setOnAction(new EventHandler()
    {
      public void handle(ActionEvent paramAnonymousActionEvent)
      {
        this.val$details.hide();
      }
    });
    localFlowPane.getChildren().add(localButton);
    localBorderPane.setBottom(localFlowPane);
    localFXDialog.show();
  }
  
  private static Node getComponents(Stage paramStage, Certificate[] paramArrayOfCertificate, int paramInt1, int paramInt2)
  {
    SplitPane localSplitPane1 = new SplitPane();
    if ((paramArrayOfCertificate.length > paramInt1) && ((paramArrayOfCertificate[paramInt1] instanceof X509Certificate)))
    {
      TreeView localTreeView = buildCertChainTree(paramArrayOfCertificate, paramInt1, paramInt2);
      final TableView localTableView = new TableView();
      final TextArea localTextArea = new TextArea();
      localTextArea.setEditable(false);
      MultipleSelectionModel localMultipleSelectionModel = localTreeView.getSelectionModel();
      localMultipleSelectionModel.getSelectedItems().addListener(new ListChangeListener()
      {
        public void onChanged(ListChangeListener.Change<? extends TreeItem<CertificateDialog.CertificateInfo>> paramAnonymousChange)
        {
          ObservableList localObservableList = this.val$treeSM.getSelectedItems();
          if ((localObservableList != null) && (localObservableList.size() == 1))
          {
            TreeItem localTreeItem = (TreeItem)localObservableList.get(0);
            CertificateDialog.CertificateInfo localCertificateInfo = (CertificateDialog.CertificateInfo)localTreeItem.getValue();
            CertificateDialog.showCertificateInfo(localCertificateInfo.getCertificate(), localTableView, localTextArea);
          }
        }
      });
      TableColumn localTableColumn1 = new TableColumn();
      localTableColumn1.setText(ResourceManager.getMessage("cert.dialog.field"));
      localTableColumn1.setCellValueFactory(new Callback()
      {
        public ObservableValue<Object> call(TableColumn.CellDataFeatures<CertificateDialog.Row, Object> paramAnonymousCellDataFeatures)
        {
          return new ReadOnlyObjectWrapper(((CertificateDialog.Row)paramAnonymousCellDataFeatures.getValue()).field);
        }
      });
      TableColumn localTableColumn2 = new TableColumn();
      localTableColumn2.setText(ResourceManager.getMessage("cert.dialog.value"));
      localTableColumn2.setCellValueFactory(new Callback()
      {
        public ObservableValue<Object> call(TableColumn.CellDataFeatures<CertificateDialog.Row, Object> paramAnonymousCellDataFeatures)
        {
          return new ReadOnlyObjectWrapper(((CertificateDialog.Row)paramAnonymousCellDataFeatures.getValue()).value);
        }
      });
      localTableView.getColumns().addAll(new TableColumn[] { localTableColumn1, localTableColumn2 });
      TableView.TableViewSelectionModel localTableViewSelectionModel = localTableView.getSelectionModel();
      localTableViewSelectionModel.setSelectionMode(SelectionMode.SINGLE);
      localTableViewSelectionModel.getSelectedItems().addListener(new ListChangeListener()
      {
        public void onChanged(ListChangeListener.Change<? extends String> paramAnonymousChange)
        {
          ObservableList localObservableList = this.val$tableSM.getSelectedItems();
          if ((localObservableList != null) && (localObservableList.size() == 1))
          {
            String str = ((CertificateDialog.Row)localObservableList.get(0)).value;
            localTextArea.setText(str);
          }
        }
      });
      localTreeView.setMinWidth(Double.NEGATIVE_INFINITY);
      localTreeView.setMinHeight(Double.NEGATIVE_INFINITY);
      ScrollPane localScrollPane = makeScrollPane(localTreeView);
      localScrollPane.setFitToWidth(true);
      localScrollPane.setFitToHeight(true);
      localSplitPane1.getItems().add(localScrollPane);
      SplitPane localSplitPane2 = new SplitPane();
      localSplitPane2.setOrientation(Orientation.VERTICAL);
      localSplitPane2.getItems().add(localTableView);
      localTextArea.setPrefWidth(320.0D);
      localTextArea.setPrefHeight(120.0D);
      localSplitPane2.getItems().add(localTextArea);
      localSplitPane2.setDividerPosition(0, 0.8D);
      localSplitPane1.getItems().add(localSplitPane2);
      localSplitPane1.setDividerPosition(0, 0.4D);
      localMultipleSelectionModel.select(0);
    }
    return localSplitPane1;
  }
  
  private static ScrollPane makeScrollPane(Node paramNode)
  {
    ScrollPane localScrollPane = new ScrollPane();
    localScrollPane.setContent(paramNode);
    if ((paramNode instanceof Label)) {
      localScrollPane.setFitToWidth(true);
    }
    return localScrollPane;
  }
  
  private static TreeView buildCertChainTree(Certificate[] paramArrayOfCertificate, int paramInt1, int paramInt2)
  {
    Object localObject1 = null;
    Object localObject2 = null;
    for (int i = paramInt1; (i < paramArrayOfCertificate.length) && (i < paramInt2); i++)
    {
      TreeItem localTreeItem = new TreeItem(new CertificateInfo((X509Certificate)paramArrayOfCertificate[i]));
      if (localObject1 == null) {
        localObject1 = localTreeItem;
      } else {
        ((TreeItem)localObject2).getChildren().add(localTreeItem);
      }
      localObject2 = localTreeItem;
    }
    TreeView localTreeView = new TreeView();
    localTreeView.setShowRoot(true);
    localTreeView.setRoot((TreeItem)localObject1);
    localTreeView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
    return localTreeView;
  }
  
  private static void showCertificateInfo(X509Certificate paramX509Certificate, TableView paramTableView, TextArea paramTextArea)
  {
    String str1 = "V" + paramX509Certificate.getVersion();
    String str2 = "[xxxxx-xxxxx]";
    String str3 = null;
    String str4 = null;
    try
    {
      SerialNumber localSerialNumber = new SerialNumber(paramX509Certificate.getSerialNumber());
      str2 = "[" + localSerialNumber.getNumber() + "]";
      str3 = getCertFingerPrint("MD5", paramX509Certificate);
      str4 = getCertFingerPrint("SHA1", paramX509Certificate);
    }
    catch (Throwable localThrowable) {}
    String str5 = "[" + paramX509Certificate.getSigAlgName() + "]";
    String str6 = formatDNString(paramX509Certificate.getIssuerDN().toString());
    String str7 = "[From: " + paramX509Certificate.getNotBefore() + ",\n To: " + paramX509Certificate.getNotAfter() + "]";
    String str8 = formatDNString(paramX509Certificate.getSubjectDN().toString());
    HexDumpEncoder localHexDumpEncoder = new HexDumpEncoder();
    String str9 = localHexDumpEncoder.encodeBuffer(paramX509Certificate.getSignature());
    ObservableList localObservableList = FXCollections.observableArrayList(new Row[] { new Row(ResourceManager.getMessage("cert.dialog.field.Version"), str1), new Row(ResourceManager.getMessage("cert.dialog.field.SerialNumber"), str2), new Row(ResourceManager.getMessage("cert.dialog.field.SignatureAlg"), str5), new Row(ResourceManager.getMessage("cert.dialog.field.Issuer"), str6), new Row(ResourceManager.getMessage("cert.dialog.field.Validity"), str7), new Row(ResourceManager.getMessage("cert.dialog.field.Subject"), str8), new Row(ResourceManager.getMessage("cert.dialog.field.Signature"), str9), new Row(ResourceManager.getMessage("cert.dialog.field.md5Fingerprint"), str3), new Row(ResourceManager.getMessage("cert.dialog.field.sha1Fingerprint"), str4) });
    paramTableView.setItems(localObservableList);
    paramTableView.getSelectionModel().select(8, null);
  }
  
  public static String formatDNString(String paramString)
  {
    int i = paramString.length();
    int j = 0;
    int k = 0;
    StringBuffer localStringBuffer = new StringBuffer();
    for (int m = 0; m < i; m++)
    {
      char c = paramString.charAt(m);
      if ((c == '"') || (c == '\'')) {
        k = k == 0 ? 1 : 0;
      }
      if ((c == ',') && (k == 0)) {
        localStringBuffer.append(",\n");
      } else {
        localStringBuffer.append(c);
      }
    }
    return localStringBuffer.toString();
  }
  
  public static String getCertFingerPrint(String paramString, X509Certificate paramX509Certificate)
    throws Exception
  {
    byte[] arrayOfByte1 = paramX509Certificate.getEncoded();
    MessageDigest localMessageDigest = MessageDigest.getInstance(paramString);
    byte[] arrayOfByte2 = localMessageDigest.digest(arrayOfByte1);
    return toHexString(arrayOfByte2);
  }
  
  private static void byte2hex(byte paramByte, StringBuffer paramStringBuffer)
  {
    char[] arrayOfChar = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
    int i = (paramByte & 0xF0) >> 4;
    int j = paramByte & 0xF;
    paramStringBuffer.append(arrayOfChar[i]);
    paramStringBuffer.append(arrayOfChar[j]);
  }
  
  private static String toHexString(byte[] paramArrayOfByte)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int i = paramArrayOfByte.length;
    for (int j = 0; j < i; j++)
    {
      byte2hex(paramArrayOfByte[j], localStringBuffer);
      if (j < i - 1) {
        localStringBuffer.append(":");
      }
    }
    return localStringBuffer.toString();
  }
  
  public static class CertificateInfo
  {
    X509Certificate cert;
    
    public CertificateInfo(X509Certificate paramX509Certificate)
    {
      this.cert = paramX509Certificate;
    }
    
    public X509Certificate getCertificate()
    {
      return this.cert;
    }
    
    private String extractAliasName(X509Certificate paramX509Certificate)
    {
      String str1 = ResourceManager.getMessage("security.dialog.unknown.subject");
      String str2 = ResourceManager.getMessage("security.dialog.unknown.issuer");
      try
      {
        Principal localPrincipal = paramX509Certificate.getSubjectDN();
        localObject = paramX509Certificate.getIssuerDN();
        String str3 = localPrincipal.getName();
        String str4 = ((Principal)localObject).getName();
        str1 = extractFromQuote(str3, "CN=");
        if (str1 == null) {
          str1 = extractFromQuote(str3, "O=");
        }
        if (str1 == null) {
          str1 = ResourceManager.getMessage("security.dialog.unknown.subject");
        }
        str2 = extractFromQuote(str4, "CN=");
        if (str2 == null) {
          str2 = extractFromQuote(str4, "O=");
        }
        if (str2 == null) {
          str2 = ResourceManager.getMessage("security.dialog.unknown.issuer");
        }
      }
      catch (Exception localException) {}
      MessageFormat localMessageFormat = new MessageFormat(ResourceManager.getMessage("security.dialog.certShowName"));
      Object localObject = { str1, str2 };
      return localMessageFormat.format(localObject);
    }
    
    private String extractFromQuote(String paramString1, String paramString2)
    {
      if (paramString1 == null) {
        return null;
      }
      int i = paramString1.indexOf(paramString2);
      int j = 0;
      if (i >= 0)
      {
        i += paramString2.length();
        if (paramString1.charAt(i) == '"')
        {
          i += 1;
          j = paramString1.indexOf('"', i);
        }
        else
        {
          j = paramString1.indexOf(',', i);
        }
        if (j < 0) {
          return paramString1.substring(i);
        }
        return paramString1.substring(i, j);
      }
      return null;
    }
    
    public String toString()
    {
      return extractAliasName(this.cert);
    }
  }
  
  private static class Row
  {
    public String field;
    public String value;
    
    Row(String paramString1, String paramString2)
    {
      this.field = paramString1;
      this.value = paramString2;
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\CertificateDialog.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */