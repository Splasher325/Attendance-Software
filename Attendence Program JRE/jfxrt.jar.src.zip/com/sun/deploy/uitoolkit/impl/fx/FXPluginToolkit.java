package com.sun.deploy.uitoolkit.impl.fx;

import com.sun.applet2.Applet2Context;
import com.sun.applet2.preloader.Preloader;
import com.sun.deploy.appcontext.AppContext;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.uitoolkit.Applet2Adapter;
import com.sun.deploy.uitoolkit.DragContext;
import com.sun.deploy.uitoolkit.DragHelper;
import com.sun.deploy.uitoolkit.DragListener;
import com.sun.deploy.uitoolkit.PluginUIToolkit;
import com.sun.deploy.uitoolkit.PluginWindowFactory;
import com.sun.deploy.uitoolkit.UIToolkit;
import com.sun.deploy.uitoolkit.Window;
import com.sun.deploy.uitoolkit.impl.fx.ui.FXAppContext;
import com.sun.deploy.uitoolkit.impl.fx.ui.FXUIFactory;
import com.sun.deploy.uitoolkit.ui.UIFactory;
import com.sun.deploy.util.Waiter;
import com.sun.deploy.util.Waiter.WaiterTask;
import com.sun.javafx.application.PlatformImpl;
import com.sun.javafx.application.PlatformImpl.FinishListener;
import com.sun.javafx.tk.Toolkit;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.concurrent.Callable;
import javafx.application.Platform;
import sun.plugin2.applet.Plugin2Manager;
import sun.plugin2.message.Pipe;

public class FXPluginToolkit
  extends PluginUIToolkit
{
  static PluginWindowFactory windowFactory = null;
  private final Object initializedLock = new Object();
  private boolean initialized = false;
  private PlatformImpl.FinishListener finishListener = null;
  public static final DragHelper noOpDragHelper = new DragHelper()
  {
    public void register(DragContext paramAnonymousDragContext, DragListener paramAnonymousDragListener) {}
    
    public void makeDisconnected(DragContext paramAnonymousDragContext, Window paramAnonymousWindow) {}
    
    public void restore(DragContext paramAnonymousDragContext) {}
    
    public void unregister(DragContext paramAnonymousDragContext) {}
  };
  static FXUIFactory fxUIFactory = new FXUIFactory();
  
  public PluginWindowFactory getWindowFactory()
  {
    if (windowFactory == null)
    {
      doInitIfNeeded();
      windowFactory = new FXWindowFactory();
    }
    return windowFactory;
  }
  
  public Preloader getDefaultPreloader()
  {
    doInitIfNeeded();
    return FXPreloader.getDefaultPreloader();
  }
  
  public Applet2Adapter getApplet2Adapter(Applet2Context paramApplet2Context)
  {
    doInitIfNeeded();
    FXApplet2Adapter localFXApplet2Adapter = FXApplet2Adapter.getFXApplet2Adapter(paramApplet2Context);
    uninstallFinishListener();
    return localFXApplet2Adapter;
  }
  
  public void init()
  {
    Waiter.set(new FxWaiter());
  }
  
  private void doInitIfNeeded()
  {
    synchronized (this.initializedLock)
    {
      if (!this.initialized)
      {
        Boolean localBoolean = (Boolean)AccessController.doPrivileged(new PrivilegedAction()
        {
          public Object run()
          {
            try
            {
              ClassLoader localClassLoader = Thread.currentThread().getContextClassLoader();
              Class localClass = Class.forName("com.sun.deploy.uitoolkit.ToolkitStore", false, localClassLoader);
              Field localField = localClass.getDeclaredField("isPlugin");
              localField.setAccessible(true);
              return Boolean.valueOf(localField.getBoolean(localClass));
            }
            catch (Throwable localThrowable)
            {
              Trace.ignored(localThrowable, true);
            }
            return Boolean.FALSE;
          }
        });
        boolean bool = localBoolean.booleanValue();
        PlatformImpl.setTaskbarApplication(!bool);
        installFinishListener();
        PlatformImpl.startup(new Runnable()
        {
          public void run() {}
        });
        this.initialized = true;
      }
    }
  }
  
  private void installFinishListener()
  {
    this.finishListener = new PlatformImpl.FinishListener()
    {
      public void idle(boolean paramAnonymousBoolean) {}
      
      public void exitCalled()
      {
        FXPluginToolkit.this.uninstallFinishListener();
        PlatformImpl.tkExit();
      }
    };
    PlatformImpl.addListener(this.finishListener);
  }
  
  private void uninstallFinishListener()
  {
    synchronized (this.initializedLock)
    {
      if (this.finishListener != null)
      {
        PlatformImpl.removeListener(this.finishListener);
        this.finishListener = null;
      }
    }
  }
  
  public boolean printApplet(Plugin2Manager paramPlugin2Manager, int paramInt1, Pipe paramPipe, long paramLong, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    doInitIfNeeded();
    return false;
  }
  
  public DragHelper getDragHelper()
  {
    doInitIfNeeded();
    return noOpDragHelper;
  }
  
  public void dispose()
    throws Exception
  {}
  
  public boolean isHeadless()
  {
    return false;
  }
  
  public void setContextClassLoader(final ClassLoader paramClassLoader)
  {
    if (paramClassLoader == null) {
      return;
    }
    Platform.runLater(new Runnable()
    {
      public void run()
      {
        Thread.currentThread().setContextClassLoader(paramClassLoader);
      }
    });
  }
  
  public void warmup()
  {
    doInitIfNeeded();
  }
  
  public AppContext getAppContext()
  {
    return FXAppContext.getInstance();
  }
  
  public AppContext createAppContext()
  {
    return FXAppContext.getInstance();
  }
  
  public SecurityManager getSecurityManager()
  {
    SecurityManager localSecurityManager = null;
    try
    {
      Class localClass = Class.forName("sun.plugin2.applet.FXAppletSecurityManager", false, Thread.currentThread().getContextClassLoader());
      Constructor localConstructor = localClass.getDeclaredConstructor(new Class[0]);
      localSecurityManager = (SecurityManager)localConstructor.newInstance(new Object[0]);
    }
    catch (Exception localException)
    {
      Trace.ignoredException(localException);
    }
    return localSecurityManager;
  }
  
  public UIToolkit changeMode(int paramInt)
  {
    return this;
  }
  
  public UIFactory getUIFactory()
  {
    doInitIfNeeded();
    return fxUIFactory;
  }
  
  public static <T> T callAndWait(Callable<T> paramCallable)
    throws Exception
  {
    Caller localCaller = new Caller(paramCallable);
    if (Platform.isFxApplicationThread())
    {
      localCaller.run();
    }
    else
    {
      Platform.runLater(localCaller);
      if (FXApplet2Adapter.isPlatformDestroyed()) {
        return null;
      }
    }
    return (T)localCaller.waitForReturn();
  }
  
  private static class Caller<T>
    implements Runnable
  {
    private T returnValue = null;
    Exception exception = null;
    private Callable<T> returnable;
    private Boolean returned = Boolean.FALSE;
    private final Object lock = new Object();
    
    Caller(Callable<T> paramCallable)
    {
      this.returnable = paramCallable;
    }
    
    public void run()
    {
      try
      {
        this.returnValue = this.returnable.call();
      }
      catch (Throwable ???)
      {
        if ((??? instanceof Exception)) {
          this.exception = ((Exception)???);
        } else {
          this.exception = new RuntimeException("Problem in callAndWait()", (Throwable)???);
        }
      }
      finally
      {
        synchronized (this.lock)
        {
          this.returned = Boolean.valueOf(true);
          this.lock.notifyAll();
        }
      }
    }
    
    T waitForReturn()
      throws Exception
    {
      synchronized (this.lock)
      {
        while ((!this.returned.booleanValue()) && (!FXApplet2Adapter.isPlatformDestroyed())) {
          try
          {
            this.lock.wait(500L);
          }
          catch (InterruptedException localInterruptedException)
          {
            System.out.println("Interrupted wait" + localInterruptedException.getStackTrace());
          }
        }
      }
      if (this.exception != null) {
        throw this.exception;
      }
      return (T)this.returnValue;
    }
  }
  
  private static final class FxWaiter
    extends Waiter
  {
    private final Toolkit tk = Toolkit.getToolkit();
    
    FxWaiter()
    {
      Class localClass = FXPluginToolkit.TaskThread.class;
    }
    
    public Object wait(Waiter.WaiterTask paramWaiterTask)
      throws Exception
    {
      if (!this.tk.isFxUserThread()) {
        return paramWaiterTask.run();
      }
      final Object localObject = new Object();
      Runnable local1 = new Runnable()
      {
        public void run()
        {
          FXPluginToolkit.FxWaiter.this.tk.exitNestedEventLoop(localObject, null);
        }
      };
      FXPluginToolkit.TaskThread localTaskThread = new FXPluginToolkit.TaskThread(paramWaiterTask, local1);
      localTaskThread.start();
      this.tk.enterNestedEventLoop(localObject);
      return localTaskThread.getResult();
    }
  }
  
  private static class TaskThread
    extends Thread
  {
    final Waiter.WaiterTask task;
    final Runnable cleanup;
    Object rv;
    
    TaskThread(Waiter.WaiterTask paramWaiterTask, Runnable paramRunnable)
    {
      this.task = paramWaiterTask;
      this.cleanup = paramRunnable;
    }
    
    public Object getResult()
      throws Exception
    {
      if ((this.rv instanceof Exception)) {
        throw ((Exception)this.rv);
      }
      return this.rv;
    }
    
    public void run()
    {
      try
      {
        this.rv = this.task.run();
      }
      catch (Exception localException)
      {
        this.rv = localException;
      }
      finally
      {
        Platform.runLater(this.cleanup);
      }
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\FXPluginToolkit.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */