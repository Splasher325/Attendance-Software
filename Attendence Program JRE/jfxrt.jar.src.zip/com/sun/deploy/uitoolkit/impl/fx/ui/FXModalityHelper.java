package com.sun.deploy.uitoolkit.impl.fx.ui;

import com.sun.deploy.uitoolkit.ui.AbstractDialog;
import com.sun.deploy.uitoolkit.ui.ModalityHelper;
import java.io.PrintStream;
import sun.plugin2.applet.Plugin2Manager;
import sun.plugin2.main.client.ModalityInterface;

public class FXModalityHelper
  implements ModalityHelper
{
  public void reactivateDialog(AbstractDialog paramAbstractDialog)
  {
    System.out.println("FXModalityHelper.reactivateDialog");
  }
  
  public boolean installModalityListener(ModalityInterface paramModalityInterface)
  {
    System.out.println("FXModalityHelper.installModalityListener" + paramModalityInterface);
    return false;
  }
  
  public void pushManagerShowingSystemDialog()
  {
    System.out.println("FXModalityHelper.pushManagerShowingSystemDialog");
  }
  
  public Plugin2Manager getManagerShowingSystemDialog()
  {
    System.out.println("FXModalityHelper.getManagerShowingSystemDialog");
    return null;
  }
  
  public void popManagerShowingSystemDialog()
  {
    System.out.println("FXModalityHelper.popManagerShowingSystemDialog");
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\FXModalityHelper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */