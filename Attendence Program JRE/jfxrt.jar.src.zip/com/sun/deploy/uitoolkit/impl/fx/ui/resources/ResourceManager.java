package com.sun.deploy.uitoolkit.impl.fx.ui.resources;

import com.sun.deploy.trace.Trace;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedExceptionAction;
import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ResourceManager
{
  private static ResourceBundle rbFX;
  private static ResourceBundle rbJRE;
  private static final String UNDERSCORE = "_";
  private static final String ESC_UNDERSCORE = "__";
  private static final String AMPERSAND = "&";
  private static final String ESC_AMPERSAND = "&&";
  private static Pattern p_start = Pattern.compile("^&[^&]");
  private static Pattern p_other = Pattern.compile("[^&]&[^&]");
  private static Pattern p_underscore = Pattern.compile("_");
  private static Pattern p_escampersand = Pattern.compile("&&");
  
  static void reset()
  {
    rbFX = ResourceBundle.getBundle("com.sun.deploy.uitoolkit.impl.fx.ui.resources.Deployment");
    try
    {
      rbJRE = ResourceBundle.getBundle("com.sun.deploy.resources.Deployment");
    }
    catch (MissingResourceException localMissingResourceException)
    {
      Trace.ignoredException(localMissingResourceException);
      rbJRE = rbFX;
    }
  }
  
  public static String getMessage(String paramString)
  {
    return convertMnemonics(getString(paramString));
  }
  
  private static String escapeUnderscore(String paramString)
  {
    return p_underscore.matcher(paramString).replaceAll("__");
  }
  
  private static String unescapeAmpersand(String paramString)
  {
    return p_escampersand.matcher(paramString).replaceAll("&");
  }
  
  private static String convertMnemonics(String paramString)
  {
    String str;
    if (p_start.matcher(paramString).find())
    {
      str = "_" + paramString.substring(1);
    }
    else
    {
      Matcher localMatcher;
      if ((localMatcher = p_other.matcher(paramString)).find()) {
        str = escapeUnderscore(paramString.substring(0, localMatcher.start() + 1)) + "_" + paramString.substring(localMatcher.end() - 1);
      } else {
        str = escapeUnderscore(paramString);
      }
    }
    return unescapeAmpersand(str);
  }
  
  public static String getFormattedMessage(String paramString, Object[] paramArrayOfObject)
  {
    try
    {
      return new MessageFormat(getMessage(paramString)).format(paramArrayOfObject);
    }
    catch (MissingResourceException localMissingResourceException)
    {
      Trace.ignoredException(localMissingResourceException);
    }
    return paramString;
  }
  
  public static String getString(String paramString)
  {
    try
    {
      return rbFX.containsKey(paramString) ? rbFX.getString(paramString) : rbJRE.getString(paramString);
    }
    catch (MissingResourceException localMissingResourceException) {}
    return paramString;
  }
  
  public static String getString(String paramString, Object... paramVarArgs)
  {
    return MessageFormat.format(getString(paramString), paramVarArgs);
  }
  
  public static ImageView getIcon(String paramString)
  {
    try
    {
      (ImageView)AccessController.doPrivileged(new PrivilegedExceptionAction()
      {
        public ImageView run()
        {
          return ResourceManager.getIcon_(this.val$key);
        }
      });
    }
    catch (Exception localException)
    {
      Trace.ignoredException(localException);
    }
    return null;
  }
  
  public static ImageView getIcon_(String paramString)
  {
    String str1 = getString(paramString);
    URL localURL = rbFX.getClass().getResource(str1);
    String str2 = rbFX.getClass().getName();
    if ((localURL == null) || (paramString.equals("about.java.image")))
    {
      localURL = rbJRE.getClass().getResource(str1);
      str2 = rbJRE.getClass().getName();
    }
    return getIcon(localURL);
  }
  
  public static ImageView getIcon(URL paramURL)
  {
    Image localImage = new Image(paramURL.toString());
    return new ImageView(localImage);
  }
  
  static
  {
    reset();
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\resources\ResourceManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */