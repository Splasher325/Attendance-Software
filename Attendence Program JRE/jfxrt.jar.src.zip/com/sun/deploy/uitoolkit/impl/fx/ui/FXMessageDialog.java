package com.sun.deploy.uitoolkit.impl.fx.ui;

import java.io.PrintStream;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class FXMessageDialog
{
  Stage stage = new Stage();
  Scene scene;
  Group group = new Group();
  Button button1;
  private final Object responseLock = new Object();
  private int response = -1;
  
  public FXMessageDialog()
  {
    this.group.getChildren().add(new Text("MessageDialog"));
    this.group.getChildren().add(this.button1 = new Button("Button"));
    this.button1.setOnAction(new DialogEventHandler(1));
    this.scene = new Scene(this.group);
    Platform.runLater(new Runnable()
    {
      public void run()
      {
        FXMessageDialog.this.stage.show();
      }
    });
  }
  
  public int getResponse()
  {
    synchronized (this.responseLock)
    {
      if (this.response == -1) {
        try
        {
          this.responseLock.wait();
        }
        catch (InterruptedException localInterruptedException)
        {
          System.out.println("interupted " + localInterruptedException);
        }
      }
      return this.response;
    }
  }
  
  class DialogEventHandler
    implements EventHandler<ActionEvent>
  {
    int id;
    
    DialogEventHandler(int paramInt)
    {
      this.id = paramInt;
    }
    
    public void handle(ActionEvent paramActionEvent)
    {
      synchronized (FXMessageDialog.this.responseLock)
      {
        FXMessageDialog.this.response = this.id;
        FXMessageDialog.this.responseLock.notifyAll();
      }
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\FXMessageDialog.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */