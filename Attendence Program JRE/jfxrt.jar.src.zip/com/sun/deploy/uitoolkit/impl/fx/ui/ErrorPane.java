package com.sun.deploy.uitoolkit.impl.fx.ui;

import com.sun.applet2.Applet2Context;
import com.sun.applet2.Applet2Host;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.ui.AppInfo;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.deploy.uitoolkit.impl.fx.ui.resources.ResourceManager;
import com.sun.deploy.uitoolkit.ui.UIFactory;
import java.lang.reflect.Method;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;

public class ErrorPane
  extends Pane
{
  Applet2Context a2c;
  Label label;
  
  public ErrorPane(Applet2Context paramApplet2Context, Throwable paramThrowable, final boolean paramBoolean)
  {
    this.a2c = paramApplet2Context;
    setStyle("-fx-background-color: white; -fx-padding: 4; -fx-border-color: lightgray;");
    ImageView localImageView = ResourceManager.getIcon("error.pane.icon");
    this.label = new Label(ResourceManager.getMessage("error.pane.message"), localImageView);
    setOnMouseClicked(new EventHandler()
    {
      public void handle(MouseEvent paramAnonymousMouseEvent)
      {
        int i = -1;
        if (paramBoolean)
        {
          ToolkitStore.getUI();
          i = ToolkitStore.getUI().showMessageDialog(null, new AppInfo(), 0, null, ResourceManager.getMessage("applet.error.generic.masthead"), ResourceManager.getMessage("applet.error.generic.body"), null, "applet.error.details.btn", "applet.error.ignore.btn", "applet.error.reload.btn");
        }
        else
        {
          ToolkitStore.getUI();
          i = ToolkitStore.getUI().showMessageDialog(null, new AppInfo(), 0, null, ResourceManager.getMessage("applet.error.generic.masthead"), ResourceManager.getMessage("applet.error.generic.body"), null, "applet.error.details.btn", "applet.error.ignore.btn", null);
        }
        ToolkitStore.getUI();
        if (i == 0)
        {
          try
          {
            Class localClass = Class.forName("sun.plugin.JavaRunTime");
            Method localMethod = localClass.getDeclaredMethod("showJavaConsole", new Class[] { Boolean.TYPE });
            localMethod.invoke(null, new Object[] { Boolean.valueOf(true) });
          }
          catch (Exception localException)
          {
            Trace.ignoredException(localException);
          }
        }
        else
        {
          ToolkitStore.getUI();
          if (i != 1)
          {
            ToolkitStore.getUI();
            if (i == 3) {
              ErrorPane.this.reloadApplet();
            }
          }
        }
      }
    });
    getChildren().add(this.label);
  }
  
  public void layoutChildren()
  {
    super.layoutChildren();
    Insets localInsets = getInsets();
    this.label.relocate(localInsets.getLeft(), localInsets.getTop());
  }
  
  private void reloadApplet()
  {
    if ((this.a2c != null) && (this.a2c.getHost() != null)) {
      this.a2c.getHost().reloadAppletPage();
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\ErrorPane.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */