package com.sun.deploy.uitoolkit.impl.fx.ui;

import com.sun.deploy.ui.AppInfo;
import com.sun.javafx.stage.StageHelper;
import java.io.PrintStream;
import java.net.URL;
import java.security.cert.Certificate;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

class FXSecurityDialog
{
  private Stage stage;
  private Scene scene;
  private Button okButton;
  private Button cancelButton;
  private final Object responseLock = new Object();
  private int response = -1;
  
  FXSecurityDialog(AppInfo paramAppInfo, final String paramString1, final String paramString2, String paramString3, URL paramURL, boolean paramBoolean1, boolean paramBoolean2, final String paramString4, final String paramString5, String[] paramArrayOfString1, String[] paramArrayOfString2, boolean paramBoolean3, Certificate[] paramArrayOfCertificate, int paramInt1, int paramInt2, boolean paramBoolean4)
  {
    Platform.runLater(new Runnable()
    {
      public void run()
      {
        FXSecurityDialog.this.stage = new Stage();
        FXSecurityDialog.this.stage.setTitle(paramString1);
        StageHelper.initSecurityDialog(FXSecurityDialog.this.stage, true);
        VBox localVBox = new VBox();
        Text localText = new Text(paramString2);
        localVBox.getChildren().add(localText);
        HBox localHBox = new HBox();
        FXSecurityDialog.this.okButton = new Button(paramString4);
        FXSecurityDialog.this.cancelButton = new Button(paramString5);
        localHBox.getChildren().add(FXSecurityDialog.this.okButton);
        localHBox.getChildren().add(FXSecurityDialog.this.cancelButton);
        localVBox.getChildren().add(localHBox);
        FXSecurityDialog.DialogEventHandler localDialogEventHandler = new FXSecurityDialog.DialogEventHandler(FXSecurityDialog.this, null);
        FXSecurityDialog.this.okButton.setOnAction(localDialogEventHandler);
        FXSecurityDialog.this.cancelButton.setOnAction(localDialogEventHandler);
        FXSecurityDialog.this.scene = new Scene(localVBox, 640.0D, 480.0D);
        FXSecurityDialog.this.stage.setScene(FXSecurityDialog.this.scene);
      }
    });
  }
  
  void setVisible(boolean paramBoolean)
  {
    Platform.runLater(new Runnable()
    {
      public void run()
      {
        FXSecurityDialog.this.stage.show();
      }
    });
  }
  
  int getResponse()
  {
    synchronized (this.responseLock)
    {
      if (this.response == -1) {
        try
        {
          this.responseLock.wait();
        }
        catch (InterruptedException localInterruptedException)
        {
          System.out.println("interupted " + localInterruptedException);
        }
      }
      return this.response;
    }
  }
  
  private class DialogEventHandler
    implements EventHandler<ActionEvent>
  {
    private DialogEventHandler() {}
    
    public void handle(ActionEvent paramActionEvent)
    {
      synchronized (FXSecurityDialog.this.responseLock)
      {
        if (paramActionEvent.getSource() == FXSecurityDialog.this.okButton) {
          FXSecurityDialog.this.response = 0;
        } else {
          FXSecurityDialog.this.response = 1;
        }
        FXSecurityDialog.this.responseLock.notifyAll();
        FXSecurityDialog.this.stage.close();
      }
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\deploy\uitoolkit\impl\fx\ui\FXSecurityDialog.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */