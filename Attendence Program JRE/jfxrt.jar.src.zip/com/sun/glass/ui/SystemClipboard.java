package com.sun.glass.ui;

import java.util.HashMap;

public abstract class SystemClipboard
  extends Clipboard
{
  protected SystemClipboard(String paramString)
  {
    super(paramString);
    Application.checkEventThread();
  }
  
  protected abstract boolean isOwner();
  
  protected abstract void pushToSystem(HashMap<String, Object> paramHashMap, int paramInt);
  
  protected abstract void pushTargetActionToSystem(int paramInt);
  
  protected abstract Object popFromSystem(String paramString);
  
  protected abstract int supportedSourceActionsFromSystem();
  
  protected abstract String[] mimesFromSystem();
  
  public void flush(ClipboardAssistance paramClipboardAssistance, HashMap<String, Object> paramHashMap, int paramInt)
  {
    Application.checkEventThread();
    setSharedData(paramClipboardAssistance, paramHashMap, paramInt);
    pushToSystem(paramHashMap, paramInt);
  }
  
  public int getSupportedSourceActions()
  {
    
    if (isOwner()) {
      return super.getSupportedSourceActions();
    }
    return supportedSourceActionsFromSystem();
  }
  
  public void setTargetAction(int paramInt)
  {
    Application.checkEventThread();
    pushTargetActionToSystem(paramInt);
  }
  
  public Object getLocalData(String paramString)
  {
    return super.getData(paramString);
  }
  
  public Object getData(String paramString)
  {
    
    if (isOwner()) {
      return getLocalData(paramString);
    }
    return popFromSystem(paramString);
  }
  
  public String[] getMimeTypes()
  {
    
    if (isOwner()) {
      return super.getMimeTypes();
    }
    return mimesFromSystem();
  }
  
  public String toString()
  {
    Application.checkEventThread();
    return "System Clipboard";
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\SystemClipboard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */