package com.sun.glass.ui;

import com.sun.glass.ui.delegate.ClipboardDelegate;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Clipboard
{
  public static final String TEXT_TYPE = "text/plain";
  public static final String HTML_TYPE = "text/html";
  public static final String RTF_TYPE = "text/rtf";
  public static final String URI_TYPE = "text/uri-list";
  public static final String FILE_LIST_TYPE = "application/x-java-file-list";
  public static final String RAW_IMAGE_TYPE = "application/x-java-rawimage";
  public static final String DRAG_IMAGE = "application/x-java-drag-image";
  public static final String DRAG_IMAGE_OFFSET = "application/x-java-drag-image-offset";
  public static final String IE_URL_SHORTCUT_FILENAME = "text/ie-shortcut-filename";
  public static final int ACTION_NONE = 0;
  public static final int ACTION_COPY = 1;
  public static final int ACTION_MOVE = 2;
  public static final int ACTION_REFERENCE = 1073741824;
  public static final int ACTION_COPY_OR_MOVE = 3;
  public static final int ACTION_ANY = 1342177279;
  public static final String DND = "DND";
  public static final String SYSTEM = "SYSTEM";
  public static final String SELECTION = "SELECTION";
  private static final Map<String, Clipboard> clipboards = new HashMap();
  private static final ClipboardDelegate delegate = PlatformFactory.getPlatformFactory().createClipboardDelegate();
  private final HashSet<ClipboardAssistance> assistants = new HashSet();
  private final String name;
  private final Object localDataProtector = new Object();
  private HashMap<String, Object> localSharedData;
  private ClipboardAssistance dataSource;
  protected int supportedActions = 1;
  
  protected Clipboard(String paramString)
  {
    Application.checkEventThread();
    this.name = paramString;
  }
  
  public void add(ClipboardAssistance paramClipboardAssistance)
  {
    
    synchronized (this.assistants)
    {
      this.assistants.add(paramClipboardAssistance);
    }
  }
  
  public void remove(ClipboardAssistance paramClipboardAssistance)
  {
    
    synchronized (this.localDataProtector)
    {
      if (paramClipboardAssistance == this.dataSource) {
        this.dataSource = null;
      }
    }
    boolean bool;
    synchronized (this.assistants)
    {
      this.assistants.remove(paramClipboardAssistance);
      bool = this.assistants.isEmpty();
    }
    if (bool)
    {
      synchronized (clipboards)
      {
        clipboards.remove(this.name);
      }
      close();
    }
  }
  
  protected void setSharedData(ClipboardAssistance paramClipboardAssistance, HashMap<String, Object> paramHashMap, int paramInt)
  {
    
    synchronized (this.localDataProtector)
    {
      this.localSharedData = ((HashMap)paramHashMap.clone());
      this.supportedActions = paramInt;
      this.dataSource = paramClipboardAssistance;
    }
  }
  
  public void flush(ClipboardAssistance paramClipboardAssistance, HashMap<String, Object> paramHashMap, int paramInt)
  {
    Application.checkEventThread();
    setSharedData(paramClipboardAssistance, paramHashMap, paramInt);
    contentChanged();
  }
  
  public int getSupportedSourceActions()
  {
    Application.checkEventThread();
    return this.supportedActions;
  }
  
  public void setTargetAction(int paramInt)
  {
    Application.checkEventThread();
    actionPerformed(paramInt);
  }
  
  public void contentChanged()
  {
    
    HashSet localHashSet;
    synchronized (this.assistants)
    {
      localHashSet = (HashSet)this.assistants.clone();
    }
    ??? = localHashSet.iterator();
    while (((Iterator)???).hasNext())
    {
      ClipboardAssistance localClipboardAssistance = (ClipboardAssistance)((Iterator)???).next();
      localClipboardAssistance.contentChanged();
    }
  }
  
  public void actionPerformed(int paramInt)
  {
    
    synchronized (this.localDataProtector)
    {
      if (null != this.dataSource) {
        this.dataSource.actionPerformed(paramInt);
      }
    }
  }
  
  public Object getData(String paramString)
  {
    
    synchronized (this.localDataProtector)
    {
      if (this.localSharedData == null) {
        return null;
      }
      Object localObject1 = this.localSharedData.get(paramString);
      return (localObject1 instanceof DelayedCallback) ? ((DelayedCallback)localObject1).providedData() : localObject1;
    }
  }
  
  public String[] getMimeTypes()
  {
    
    synchronized (this.localDataProtector)
    {
      if (this.localSharedData == null) {
        return null;
      }
      Set localSet = this.localSharedData.keySet();
      String[] arrayOfString = new String[localSet.size()];
      int i = 0;
      Iterator localIterator = localSet.iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        arrayOfString[(i++)] = str;
      }
      return arrayOfString;
    }
  }
  
  protected static Clipboard get(String paramString)
  {
    
    synchronized (clipboards)
    {
      if (!clipboards.keySet().contains(paramString))
      {
        Clipboard localClipboard = delegate.createClipboard(paramString);
        if (localClipboard == null) {
          localClipboard = new Clipboard(paramString);
        }
        clipboards.put(paramString, localClipboard);
      }
      return (Clipboard)clipboards.get(paramString);
    }
  }
  
  public Pixels getPixelsForRawImage(byte[] paramArrayOfByte)
  {
    Application.checkEventThread();
    ByteBuffer localByteBuffer1 = ByteBuffer.wrap(paramArrayOfByte, 0, 8);
    int i = localByteBuffer1.getInt();
    int j = localByteBuffer1.getInt();
    ByteBuffer localByteBuffer2 = ByteBuffer.wrap(paramArrayOfByte, 8, paramArrayOfByte.length - 8);
    return Application.GetApplication().createPixels(i, j, localByteBuffer2.slice());
  }
  
  public String toString()
  {
    return "Clipboard: " + this.name + "@" + hashCode();
  }
  
  protected void close()
  {
    
    synchronized (this.localDataProtector)
    {
      this.dataSource = null;
    }
  }
  
  public String getName()
  {
    Application.checkEventThread();
    return this.name;
  }
  
  public static String getActionString(int paramInt)
  {
    Application.checkEventThread();
    StringBuilder localStringBuilder = new StringBuilder("");
    int[] arrayOfInt = { 1, 2, 1073741824 };
    String[] arrayOfString = { "copy", "move", "link" };
    for (int i = 0; i < 3; i++) {
      if ((arrayOfInt[i] & paramInt) > 0)
      {
        if (localStringBuilder.length() > 0) {
          localStringBuilder.append(",");
        }
        localStringBuilder.append(arrayOfString[i]);
      }
    }
    return localStringBuilder.toString();
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\Clipboard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */