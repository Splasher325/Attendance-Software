package com.sun.glass.ui;

import com.sun.glass.ui.delegate.MenuDelegate;
import com.sun.glass.ui.delegate.MenuItemDelegate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class Menu
{
  private final MenuDelegate delegate;
  private String title;
  private boolean enabled;
  private final List<Object> items = new ArrayList();
  private EventHandler eventHandler;
  
  public EventHandler getEventHandler()
  {
    Application.checkEventThread();
    return this.eventHandler;
  }
  
  public void setEventHandler(EventHandler paramEventHandler)
  {
    Application.checkEventThread();
    this.eventHandler = paramEventHandler;
  }
  
  protected Menu(String paramString)
  {
    this(paramString, true);
  }
  
  protected Menu(String paramString, boolean paramBoolean)
  {
    Application.checkEventThread();
    this.title = paramString;
    this.enabled = paramBoolean;
    this.delegate = PlatformFactory.getPlatformFactory().createMenuDelegate(this);
    if (!this.delegate.createMenu(paramString, paramBoolean)) {
      throw new RuntimeException("Menu creation error.");
    }
  }
  
  public String getTitle()
  {
    Application.checkEventThread();
    return this.title;
  }
  
  public void setTitle(String paramString)
  {
    
    if (this.delegate.setTitle(paramString)) {
      this.title = paramString;
    }
  }
  
  public boolean isEnabled()
  {
    Application.checkEventThread();
    return this.enabled;
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    
    if (this.delegate.setEnabled(paramBoolean)) {
      this.enabled = paramBoolean;
    }
  }
  
  public boolean setPixels(Pixels paramPixels)
  {
    Application.checkEventThread();
    return this.delegate.setPixels(paramPixels);
  }
  
  public List<Object> getItems()
  {
    Application.checkEventThread();
    return Collections.unmodifiableList(this.items);
  }
  
  public void add(Menu paramMenu)
  {
    Application.checkEventThread();
    insert(paramMenu, this.items.size());
  }
  
  public void add(MenuItem paramMenuItem)
  {
    Application.checkEventThread();
    insert(paramMenuItem, this.items.size());
  }
  
  public void insert(Menu paramMenu, int paramInt)
    throws IndexOutOfBoundsException
  {
    
    if (paramMenu == null) {
      throw new IllegalArgumentException();
    }
    synchronized (this.items)
    {
      if ((paramInt < 0) || (paramInt > this.items.size())) {
        throw new IndexOutOfBoundsException();
      }
      MenuDelegate localMenuDelegate = paramMenu.getDelegate();
      if (this.delegate.insert(localMenuDelegate, paramInt)) {
        this.items.add(paramInt, paramMenu);
      }
    }
  }
  
  public void insert(MenuItem paramMenuItem, int paramInt)
    throws IndexOutOfBoundsException
  {
    
    synchronized (this.items)
    {
      if ((paramInt < 0) || (paramInt > this.items.size())) {
        throw new IndexOutOfBoundsException();
      }
      MenuItemDelegate localMenuItemDelegate = paramMenuItem != null ? paramMenuItem.getDelegate() : null;
      if (this.delegate.insert(localMenuItemDelegate, paramInt)) {
        this.items.add(paramInt, paramMenuItem);
      }
    }
  }
  
  public void remove(int paramInt)
    throws IndexOutOfBoundsException
  {
    
    synchronized (this.items)
    {
      Object localObject1 = this.items.get(paramInt);
      boolean bool = false;
      if (localObject1 == MenuItem.Separator) {
        bool = this.delegate.remove((MenuItemDelegate)null, paramInt);
      } else if ((localObject1 instanceof MenuItem)) {
        bool = this.delegate.remove(((MenuItem)localObject1).getDelegate(), paramInt);
      } else {
        bool = this.delegate.remove(((Menu)localObject1).getDelegate(), paramInt);
      }
      if (bool) {
        this.items.remove(paramInt);
      }
    }
  }
  
  MenuDelegate getDelegate()
  {
    return this.delegate;
  }
  
  protected void notifyMenuOpening()
  {
    if (this.eventHandler != null) {
      this.eventHandler.handleMenuOpening(this, System.nanoTime());
    }
  }
  
  protected void notifyMenuClosed()
  {
    if (this.eventHandler != null) {
      this.eventHandler.handleMenuClosed(this, System.nanoTime());
    }
  }
  
  public static class EventHandler
  {
    public void handleMenuOpening(Menu paramMenu, long paramLong) {}
    
    public void handleMenuClosed(Menu paramMenu, long paramLong) {}
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\Menu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */