package com.sun.glass.ui;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CommonDialogs
{
  public static FileChooserResult showFileChooser(Window paramWindow, File paramFile, String paramString1, String paramString2, int paramInt1, boolean paramBoolean, List<ExtensionFilter> paramList, int paramInt2)
  {
    Application.checkEventThread();
    String str = convertFolder(paramFile);
    if (paramString1 == null) {
      paramString1 = "";
    }
    if ((paramInt1 != 0) && (paramInt1 != 1)) {
      throw new IllegalArgumentException("Type parameter must be equal to one of the constants from Type");
    }
    ExtensionFilter[] arrayOfExtensionFilter = null;
    if (paramList != null) {
      arrayOfExtensionFilter = (ExtensionFilter[])paramList.toArray(new ExtensionFilter[paramList.size()]);
    }
    if ((paramList == null) || (paramList.isEmpty()) || (paramInt2 < 0) || (paramInt2 >= paramList.size())) {
      paramInt2 = 0;
    }
    return Application.GetApplication().staticCommonDialogs_showFileChooser(paramWindow, str, paramString1, convertTitle(paramString2), paramInt1, paramBoolean, arrayOfExtensionFilter, paramInt2);
  }
  
  public static File showFolderChooser(Window paramWindow, File paramFile, String paramString)
  {
    Application.checkEventThread();
    return Application.GetApplication().staticCommonDialogs_showFolderChooser(paramWindow, convertFolder(paramFile), convertTitle(paramString));
  }
  
  private static String convertFolder(File paramFile)
  {
    if (paramFile != null)
    {
      if (paramFile.isDirectory()) {
        try
        {
          return paramFile.getCanonicalPath();
        }
        catch (IOException localIOException)
        {
          throw new IllegalArgumentException("Unable to get a canonical path for folder", localIOException);
        }
      }
      throw new IllegalArgumentException("Folder parameter must be a valid folder");
    }
    return "";
  }
  
  private static String convertTitle(String paramString)
  {
    return paramString != null ? paramString : "";
  }
  
  protected static FileChooserResult createFileChooserResult(String[] paramArrayOfString, ExtensionFilter[] paramArrayOfExtensionFilter, int paramInt)
  {
    ArrayList localArrayList = new ArrayList();
    for (String str : paramArrayOfString) {
      localArrayList.add(new File(str));
    }
    return new FileChooserResult(localArrayList, (paramArrayOfExtensionFilter == null) || (paramInt < 0) || (paramInt >= paramArrayOfExtensionFilter.length) ? null : paramArrayOfExtensionFilter[paramInt]);
  }
  
  public static final class ExtensionFilter
  {
    private final String description;
    private final List<String> extensions;
    
    public ExtensionFilter(String paramString, List<String> paramList)
    {
      Application.checkEventThread();
      if ((paramString == null) || (paramString.trim().isEmpty())) {
        throw new IllegalArgumentException("Description parameter must be non-null and not empty");
      }
      if ((paramList == null) || (paramList.isEmpty())) {
        throw new IllegalArgumentException("Extensions parameter must be non-null and not empty");
      }
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        if ((str == null) || (str.length() == 0)) {
          throw new IllegalArgumentException("Each extension must be non-null and not empty");
        }
      }
      this.description = paramString;
      this.extensions = paramList;
    }
    
    public String getDescription()
    {
      Application.checkEventThread();
      return this.description;
    }
    
    public List<String> getExtensions()
    {
      Application.checkEventThread();
      return this.extensions;
    }
    
    private String[] extensionsToArray()
    {
      Application.checkEventThread();
      return (String[])this.extensions.toArray(new String[this.extensions.size()]);
    }
  }
  
  public static final class FileChooserResult
  {
    private final List<File> files;
    private final CommonDialogs.ExtensionFilter filter;
    
    public FileChooserResult(List<File> paramList, CommonDialogs.ExtensionFilter paramExtensionFilter)
    {
      if (paramList == null) {
        throw new NullPointerException("files should not be null");
      }
      this.files = paramList;
      this.filter = paramExtensionFilter;
    }
    
    public FileChooserResult()
    {
      this(new ArrayList(), null);
    }
    
    public List<File> getFiles()
    {
      return this.files;
    }
    
    public CommonDialogs.ExtensionFilter getExtensionFilter()
    {
      return this.filter;
    }
  }
  
  public static final class Type
  {
    public static final int OPEN = 0;
    public static final int SAVE = 1;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\CommonDialogs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */