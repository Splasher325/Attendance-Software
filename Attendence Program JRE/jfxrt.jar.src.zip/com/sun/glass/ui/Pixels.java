package com.sun.glass.ui;

import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;

public abstract class Pixels
{
  protected final int width;
  protected final int height;
  protected final int bytesPerComponent;
  protected final ByteBuffer bytes;
  protected final IntBuffer ints;
  private final float scale;
  
  public static int getNativeFormat()
  {
    Application.checkEventThread();
    return Application.GetApplication().staticPixels_getNativeFormat();
  }
  
  protected Pixels(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer)
  {
    this.width = paramInt1;
    this.height = paramInt2;
    this.bytesPerComponent = 1;
    this.bytes = paramByteBuffer.slice();
    if ((this.width <= 0) || (this.height <= 0) || (this.width * this.height * 4 > this.bytes.capacity())) {
      throw new IllegalArgumentException("Too small byte buffer size " + this.width + "x" + this.height + " [" + this.width * this.height * 4 + "] > " + this.bytes.capacity());
    }
    this.ints = null;
    this.scale = 1.0F;
  }
  
  protected Pixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer)
  {
    this.width = paramInt1;
    this.height = paramInt2;
    this.bytesPerComponent = 4;
    this.ints = paramIntBuffer.slice();
    if ((this.width <= 0) || (this.height <= 0) || (this.width * this.height > this.ints.capacity())) {
      throw new IllegalArgumentException("Too small int buffer size " + this.width + "x" + this.height + " [" + this.width * this.height + "] > " + this.ints.capacity());
    }
    this.bytes = null;
    this.scale = 1.0F;
  }
  
  protected Pixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer, float paramFloat)
  {
    this.width = paramInt1;
    this.height = paramInt2;
    this.bytesPerComponent = 4;
    this.ints = paramIntBuffer.slice();
    if ((this.width <= 0) || (this.height <= 0) || (this.width * this.height > this.ints.capacity())) {
      throw new IllegalArgumentException("Too small int buffer size " + this.width + "x" + this.height + " [" + this.width * this.height + "] > " + this.ints.capacity());
    }
    this.bytes = null;
    this.scale = paramFloat;
  }
  
  public final float getScale()
  {
    Application.checkEventThread();
    return this.scale;
  }
  
  public final float getScaleUnsafe()
  {
    return this.scale;
  }
  
  public final int getWidth()
  {
    Application.checkEventThread();
    return this.width;
  }
  
  public final int getWidthUnsafe()
  {
    return this.width;
  }
  
  public final int getHeight()
  {
    Application.checkEventThread();
    return this.height;
  }
  
  public final int getHeightUnsafe()
  {
    return this.height;
  }
  
  public final int getBytesPerComponent()
  {
    Application.checkEventThread();
    return this.bytesPerComponent;
  }
  
  public final Buffer getPixels()
  {
    if (this.bytes != null)
    {
      this.bytes.rewind();
      return this.bytes;
    }
    if (this.ints != null)
    {
      this.ints.rewind();
      return this.ints;
    }
    throw new RuntimeException("Unexpected Pixels state.");
  }
  
  public final ByteBuffer asByteBuffer()
  {
    Application.checkEventThread();
    ByteBuffer localByteBuffer = ByteBuffer.allocateDirect(getWidth() * getHeight() * 4);
    localByteBuffer.order(ByteOrder.nativeOrder());
    localByteBuffer.rewind();
    asByteBuffer(localByteBuffer);
    return localByteBuffer;
  }
  
  public final void asByteBuffer(ByteBuffer paramByteBuffer)
  {
    
    if (!paramByteBuffer.isDirect()) {
      throw new RuntimeException("Expected direct buffer.");
    }
    if (paramByteBuffer.remaining() < getWidth() * getHeight() * 4) {
      throw new RuntimeException("Too small buffer.");
    }
    _fillDirectByteBuffer(paramByteBuffer);
  }
  
  private void attachData(long paramLong)
  {
    int[] arrayOfInt;
    if (this.ints != null)
    {
      arrayOfInt = !this.ints.isDirect() ? this.ints.array() : null;
      _attachInt(paramLong, this.width, this.height, this.ints, arrayOfInt, arrayOfInt != null ? this.ints.arrayOffset() : 0);
    }
    if (this.bytes != null)
    {
      arrayOfInt = !this.bytes.isDirect() ? this.bytes.array() : null;
      _attachByte(paramLong, this.width, this.height, this.bytes, arrayOfInt, arrayOfInt != null ? this.bytes.arrayOffset() : 0);
    }
  }
  
  protected abstract void _fillDirectByteBuffer(ByteBuffer paramByteBuffer);
  
  protected abstract void _attachInt(long paramLong, int paramInt1, int paramInt2, IntBuffer paramIntBuffer, int[] paramArrayOfInt, int paramInt3);
  
  protected abstract void _attachByte(long paramLong, int paramInt1, int paramInt2, ByteBuffer paramByteBuffer, byte[] paramArrayOfByte, int paramInt3);
  
  public final boolean equals(Object paramObject)
  {
    Application.checkEventThread();
    boolean bool = (paramObject != null) && (getClass().equals(paramObject.getClass()));
    if (bool)
    {
      Pixels localPixels = (Pixels)paramObject;
      bool = (getWidth() == localPixels.getWidth()) && (getHeight() == localPixels.getHeight());
      if (bool)
      {
        ByteBuffer localByteBuffer1 = asByteBuffer();
        ByteBuffer localByteBuffer2 = localPixels.asByteBuffer();
        bool = localByteBuffer1.compareTo(localByteBuffer2) == 0;
      }
    }
    return bool;
  }
  
  public final int hashCode()
  {
    Application.checkEventThread();
    int i = getWidth();
    i = 31 * i + getHeight();
    i = 17 * i + asByteBuffer().hashCode();
    return i;
  }
  
  public static class Format
  {
    public static final int BYTE_BGRA_PRE = 1;
    public static final int BYTE_ARGB = 2;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\Pixels.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */