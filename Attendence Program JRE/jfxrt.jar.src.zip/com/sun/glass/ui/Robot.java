package com.sun.glass.ui;

import java.security.AccessController;
import java.security.AllPermission;
import java.security.Permission;

public abstract class Robot
{
  private static final Permission allPermission = new AllPermission();
  public static final int MOUSE_LEFT_BTN = 1;
  public static final int MOUSE_RIGHT_BTN = 2;
  public static final int MOUSE_MIDDLE_BTN = 4;
  
  protected abstract void _create();
  
  protected Robot()
  {
    if (System.getSecurityManager() != null) {
      AccessController.checkPermission(allPermission);
    }
    Application.checkEventThread();
    _create();
  }
  
  protected abstract void _destroy();
  
  public void destroy()
  {
    Application.checkEventThread();
    _destroy();
  }
  
  protected abstract void _keyPress(int paramInt);
  
  public void keyPress(int paramInt)
  {
    Application.checkEventThread();
    _keyPress(paramInt);
  }
  
  protected abstract void _keyRelease(int paramInt);
  
  public void keyRelease(int paramInt)
  {
    Application.checkEventThread();
    _keyRelease(paramInt);
  }
  
  protected abstract void _mouseMove(int paramInt1, int paramInt2);
  
  public void mouseMove(int paramInt1, int paramInt2)
  {
    Application.checkEventThread();
    _mouseMove(paramInt1, paramInt2);
  }
  
  protected abstract void _mousePress(int paramInt);
  
  public void mousePress(int paramInt)
  {
    Application.checkEventThread();
    _mousePress(paramInt);
  }
  
  protected abstract void _mouseRelease(int paramInt);
  
  public void mouseRelease(int paramInt)
  {
    Application.checkEventThread();
    _mouseRelease(paramInt);
  }
  
  protected abstract void _mouseWheel(int paramInt);
  
  public void mouseWheel(int paramInt)
  {
    Application.checkEventThread();
    _mouseWheel(paramInt);
  }
  
  protected abstract int _getMouseX();
  
  public int getMouseX()
  {
    Application.checkEventThread();
    return _getMouseX();
  }
  
  protected abstract int _getMouseY();
  
  public int getMouseY()
  {
    Application.checkEventThread();
    return _getMouseY();
  }
  
  protected abstract int _getPixelColor(int paramInt1, int paramInt2);
  
  public int getPixelColor(int paramInt1, int paramInt2)
  {
    Application.checkEventThread();
    return _getPixelColor(paramInt1, paramInt2);
  }
  
  protected abstract Pixels _getScreenCapture(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean);
  
  public Pixels getScreenCapture(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    Application.checkEventThread();
    return _getScreenCapture(paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean);
  }
  
  public Pixels getScreenCapture(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return getScreenCapture(paramInt1, paramInt2, paramInt3, paramInt4, false);
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\Robot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */