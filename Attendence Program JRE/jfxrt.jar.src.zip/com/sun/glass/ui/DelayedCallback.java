package com.sun.glass.ui;

public abstract interface DelayedCallback
{
  public abstract Object providedData();
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\DelayedCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */