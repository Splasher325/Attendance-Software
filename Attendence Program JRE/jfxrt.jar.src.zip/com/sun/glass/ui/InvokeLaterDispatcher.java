package com.sun.glass.ui;

import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;

public final class InvokeLaterDispatcher
  extends Thread
{
  private final BlockingDeque<Runnable> deque = new LinkedBlockingDeque();
  private final Object LOCK = new StringBuilder("InvokeLaterLock");
  private boolean nestedEventLoopEntered = false;
  private volatile boolean leavingNestedEventLoop = false;
  private final InvokeLaterSubmitter invokeLaterSubmitter;
  
  public InvokeLaterDispatcher(InvokeLaterSubmitter paramInvokeLaterSubmitter)
  {
    setDaemon(true);
    this.invokeLaterSubmitter = paramInvokeLaterSubmitter;
  }
  
  public void run()
  {
    try
    {
      for (;;)
      {
        Runnable localRunnable = (Runnable)this.deque.takeFirst();
        if (this.leavingNestedEventLoop)
        {
          this.deque.addFirst(localRunnable);
          synchronized (this.LOCK)
          {
            while (this.leavingNestedEventLoop) {
              this.LOCK.wait();
            }
          }
        }
        else
        {
          ??? = new Future(localRunnable);
          this.invokeLaterSubmitter.submitForLaterInvocation((Runnable)???);
          synchronized (this.LOCK)
          {
            try
            {
              while ((!((Future)???).isDone()) && (!this.nestedEventLoopEntered)) {
                this.LOCK.wait();
              }
            }
            finally
            {
              this.nestedEventLoopEntered = false;
            }
          }
        }
      }
    }
    catch (InterruptedException localInterruptedException) {}
  }
  
  public void invokeAndWait(Runnable paramRunnable)
  {
    Future localFuture = new Future(paramRunnable);
    this.invokeLaterSubmitter.submitForLaterInvocation(localFuture);
    synchronized (this.LOCK)
    {
      try
      {
        while (!localFuture.isDone()) {
          this.LOCK.wait();
        }
      }
      catch (InterruptedException localInterruptedException) {}
    }
  }
  
  public void invokeLater(Runnable paramRunnable)
  {
    this.deque.addLast(paramRunnable);
  }
  
  public void notifyEnteringNestedEventLoop()
  {
    synchronized (this.LOCK)
    {
      this.nestedEventLoopEntered = true;
      this.LOCK.notifyAll();
    }
  }
  
  public void notifyLeavingNestedEventLoop()
  {
    synchronized (this.LOCK)
    {
      this.leavingNestedEventLoop = true;
      this.LOCK.notifyAll();
    }
  }
  
  public void notifyLeftNestedEventLoop()
  {
    synchronized (this.LOCK)
    {
      this.leavingNestedEventLoop = false;
      this.LOCK.notifyAll();
    }
  }
  
  private class Future
    implements Runnable
  {
    private boolean done = false;
    private final Runnable runnable;
    
    public Future(Runnable paramRunnable)
    {
      this.runnable = paramRunnable;
    }
    
    public boolean isDone()
    {
      return this.done;
    }
    
    /* Error */
    public void run()
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 35	com/sun/glass/ui/InvokeLaterDispatcher$Future:runnable	Ljava/lang/Runnable;
      //   4: invokeinterface 39 1 0
      //   9: aload_0
      //   10: getfield 34	com/sun/glass/ui/InvokeLaterDispatcher$Future:this$0	Lcom/sun/glass/ui/InvokeLaterDispatcher;
      //   13: invokestatic 36	com/sun/glass/ui/InvokeLaterDispatcher:access$000	(Lcom/sun/glass/ui/InvokeLaterDispatcher;)Ljava/lang/Object;
      //   16: dup
      //   17: astore_1
      //   18: monitorenter
      //   19: aload_0
      //   20: iconst_1
      //   21: putfield 33	com/sun/glass/ui/InvokeLaterDispatcher$Future:done	Z
      //   24: aload_0
      //   25: getfield 34	com/sun/glass/ui/InvokeLaterDispatcher$Future:this$0	Lcom/sun/glass/ui/InvokeLaterDispatcher;
      //   28: invokestatic 36	com/sun/glass/ui/InvokeLaterDispatcher:access$000	(Lcom/sun/glass/ui/InvokeLaterDispatcher;)Ljava/lang/Object;
      //   31: invokevirtual 38	java/lang/Object:notifyAll	()V
      //   34: aload_1
      //   35: monitorexit
      //   36: goto +8 -> 44
      //   39: astore_2
      //   40: aload_1
      //   41: monitorexit
      //   42: aload_2
      //   43: athrow
      //   44: goto +46 -> 90
      //   47: astore_3
      //   48: aload_0
      //   49: getfield 34	com/sun/glass/ui/InvokeLaterDispatcher$Future:this$0	Lcom/sun/glass/ui/InvokeLaterDispatcher;
      //   52: invokestatic 36	com/sun/glass/ui/InvokeLaterDispatcher:access$000	(Lcom/sun/glass/ui/InvokeLaterDispatcher;)Ljava/lang/Object;
      //   55: dup
      //   56: astore 4
      //   58: monitorenter
      //   59: aload_0
      //   60: iconst_1
      //   61: putfield 33	com/sun/glass/ui/InvokeLaterDispatcher$Future:done	Z
      //   64: aload_0
      //   65: getfield 34	com/sun/glass/ui/InvokeLaterDispatcher$Future:this$0	Lcom/sun/glass/ui/InvokeLaterDispatcher;
      //   68: invokestatic 36	com/sun/glass/ui/InvokeLaterDispatcher:access$000	(Lcom/sun/glass/ui/InvokeLaterDispatcher;)Ljava/lang/Object;
      //   71: invokevirtual 38	java/lang/Object:notifyAll	()V
      //   74: aload 4
      //   76: monitorexit
      //   77: goto +11 -> 88
      //   80: astore 5
      //   82: aload 4
      //   84: monitorexit
      //   85: aload 5
      //   87: athrow
      //   88: aload_3
      //   89: athrow
      //   90: return
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	91	0	this	Future
      //   39	4	2	localObject1	Object
      //   47	42	3	localObject2	Object
      //   80	6	5	localObject3	Object
      // Exception table:
      //   from	to	target	type
      //   19	36	39	finally
      //   39	42	39	finally
      //   0	9	47	finally
      //   59	77	80	finally
      //   80	85	80	finally
    }
  }
  
  public static abstract interface InvokeLaterSubmitter
  {
    public abstract void submitForLaterInvocation(Runnable paramRunnable);
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\InvokeLaterDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */