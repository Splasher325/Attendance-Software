package com.sun.glass.ui.delegate;

import com.sun.glass.ui.Pixels;

public abstract interface MenuDelegate
{
  public abstract boolean createMenu(String paramString, boolean paramBoolean);
  
  public abstract boolean setTitle(String paramString);
  
  public abstract boolean setEnabled(boolean paramBoolean);
  
  public abstract boolean setPixels(Pixels paramPixels);
  
  public abstract boolean insert(MenuDelegate paramMenuDelegate, int paramInt);
  
  public abstract boolean insert(MenuItemDelegate paramMenuItemDelegate, int paramInt);
  
  public abstract boolean remove(MenuDelegate paramMenuDelegate, int paramInt);
  
  public abstract boolean remove(MenuItemDelegate paramMenuItemDelegate, int paramInt);
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\delegate\MenuDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */