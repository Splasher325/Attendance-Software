package com.sun.glass.ui.delegate;

import com.sun.glass.ui.Clipboard;

public abstract interface ClipboardDelegate
{
  public abstract Clipboard createClipboard(String paramString);
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\delegate\ClipboardDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */