package com.sun.glass.ui.delegate;

public abstract interface MenuBarDelegate
{
  public abstract boolean createMenuBar();
  
  public abstract boolean insert(MenuDelegate paramMenuDelegate, int paramInt);
  
  public abstract boolean remove(MenuDelegate paramMenuDelegate, int paramInt);
  
  public abstract long getNativeMenu();
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\delegate\MenuBarDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */