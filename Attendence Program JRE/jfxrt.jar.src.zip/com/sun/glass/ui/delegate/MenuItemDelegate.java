package com.sun.glass.ui.delegate;

import com.sun.glass.ui.MenuItem.Callback;
import com.sun.glass.ui.Pixels;

public abstract interface MenuItemDelegate
{
  public abstract boolean createMenuItem(String paramString, MenuItem.Callback paramCallback, int paramInt1, int paramInt2, Pixels paramPixels, boolean paramBoolean1, boolean paramBoolean2);
  
  public abstract boolean setTitle(String paramString);
  
  public abstract boolean setCallback(MenuItem.Callback paramCallback);
  
  public abstract boolean setShortcut(int paramInt1, int paramInt2);
  
  public abstract boolean setPixels(Pixels paramPixels);
  
  public abstract boolean setEnabled(boolean paramBoolean);
  
  public abstract boolean setChecked(boolean paramBoolean);
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\delegate\MenuItemDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */