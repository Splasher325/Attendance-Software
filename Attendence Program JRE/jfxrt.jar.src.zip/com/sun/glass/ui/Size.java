package com.sun.glass.ui;

public final class Size
{
  public int width;
  public int height;
  
  public Size(int paramInt1, int paramInt2)
  {
    this.width = paramInt1;
    this.height = paramInt2;
  }
  
  public Size()
  {
    this(0, 0);
  }
  
  public String toString()
  {
    return "Size(" + this.width + ", " + this.height + ")";
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\Size.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */