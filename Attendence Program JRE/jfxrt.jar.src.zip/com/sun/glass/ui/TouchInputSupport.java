package com.sun.glass.ui;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class TouchInputSupport
{
  private int touchCount = 0;
  private boolean filterTouchCoordinates;
  private Map<Long, TouchCoord> touch;
  private TouchCountListener listener;
  private int curTouchCount;
  private View curView;
  private int curModifiers;
  private boolean curIsDirect;
  
  public TouchInputSupport(TouchCountListener paramTouchCountListener, boolean paramBoolean)
  {
    Application.checkEventThread();
    this.listener = paramTouchCountListener;
    this.filterTouchCoordinates = paramBoolean;
    if (paramBoolean) {
      this.touch = new HashMap();
    }
  }
  
  public int getTouchCount()
  {
    Application.checkEventThread();
    return this.touchCount;
  }
  
  public void notifyBeginTouchEvent(View paramView, int paramInt1, boolean paramBoolean, int paramInt2)
  {
    if ((this.curView != null) && (paramView != this.curView) && (this.touchCount != 0) && (this.touch != null))
    {
      if (!this.curView.isClosed())
      {
        this.curView.notifyBeginTouchEvent(0, true, this.touchCount);
        Iterator localIterator = this.touch.entrySet().iterator();
        while (localIterator.hasNext())
        {
          Map.Entry localEntry = (Map.Entry)localIterator.next();
          TouchCoord localTouchCoord = (TouchCoord)localEntry.getValue();
          this.curView.notifyNextTouchEvent(813, ((Long)localEntry.getKey()).longValue(), localTouchCoord.x, localTouchCoord.y, localTouchCoord.xAbs, localTouchCoord.yAbs);
        }
        this.curView.notifyEndTouchEvent();
      }
      this.touch.clear();
      this.touchCount = 0;
      if (this.listener != null) {
        this.listener.touchCountChanged(this, this.curView, 0, true);
      }
    }
    this.curTouchCount = this.touchCount;
    this.curView = paramView;
    this.curModifiers = paramInt1;
    this.curIsDirect = paramBoolean;
    if (paramView != null) {
      paramView.notifyBeginTouchEvent(paramInt1, paramBoolean, paramInt2);
    }
  }
  
  public void notifyEndTouchEvent(View paramView)
  {
    if (paramView == null) {
      return;
    }
    paramView.notifyEndTouchEvent();
    if ((this.curTouchCount != 0) && (this.touchCount != 0) && (this.curTouchCount != this.touchCount) && (this.listener != null)) {
      this.listener.touchCountChanged(this, this.curView, this.curModifiers, this.curIsDirect);
    }
  }
  
  public void notifyNextTouchEvent(View paramView, int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    switch (paramInt1)
    {
    case 813: 
      this.touchCount -= 1;
      break;
    case 811: 
      this.touchCount += 1;
      break;
    case 812: 
    case 814: 
      break;
    default: 
      System.err.println("Unknown touch state: " + paramInt1);
      return;
    }
    if (this.filterTouchCoordinates) {
      paramInt1 = filterTouchInputState(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    if (paramView != null) {
      paramView.notifyNextTouchEvent(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5);
    }
  }
  
  private int filterTouchInputState(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    switch (paramInt1)
    {
    case 813: 
      this.touch.remove(Long.valueOf(paramLong));
      break;
    case 812: 
      TouchCoord localTouchCoord = (TouchCoord)this.touch.get(Long.valueOf(paramLong));
      if ((paramInt2 == localTouchCoord.x) && (paramInt3 == localTouchCoord.y)) {
        paramInt1 = 814;
      }
      break;
    case 811: 
      this.touch.put(Long.valueOf(paramLong), new TouchCoord(paramInt2, paramInt3, paramInt4, paramInt5, null));
      break;
    case 814: 
      break;
    }
    System.err.println("Unknown touch state: " + paramInt1);
    return paramInt1;
  }
  
  private static class TouchCoord
  {
    private final int x;
    private final int y;
    private final int xAbs;
    private final int yAbs;
    
    private TouchCoord(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      this.x = paramInt1;
      this.y = paramInt2;
      this.xAbs = paramInt3;
      this.yAbs = paramInt4;
    }
  }
  
  public static abstract interface TouchCountListener
  {
    public abstract void touchCountChanged(TouchInputSupport paramTouchInputSupport, View paramView, int paramInt, boolean paramBoolean);
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\TouchInputSupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */