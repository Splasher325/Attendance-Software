package com.sun.glass.ui;

import com.sun.glass.ui.delegate.MenuBarDelegate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class MenuBar
{
  private final MenuBarDelegate delegate;
  private final List<Menu> menus = new ArrayList();
  
  protected MenuBar()
  {
    Application.checkEventThread();
    this.delegate = PlatformFactory.getPlatformFactory().createMenuBarDelegate(this);
    if (!this.delegate.createMenuBar()) {
      throw new RuntimeException("MenuBar creation error.");
    }
  }
  
  long getNativeMenu()
  {
    return this.delegate.getNativeMenu();
  }
  
  public void add(Menu paramMenu)
  {
    Application.checkEventThread();
    insert(paramMenu, this.menus.size());
  }
  
  public void insert(Menu paramMenu, int paramInt)
  {
    
    synchronized (this.menus)
    {
      if (this.delegate.insert(paramMenu.getDelegate(), paramInt)) {
        this.menus.add(paramInt, paramMenu);
      }
    }
  }
  
  public void remove(int paramInt)
  {
    
    synchronized (this.menus)
    {
      Menu localMenu = (Menu)this.menus.get(paramInt);
      if (this.delegate.remove(localMenu.getDelegate(), paramInt)) {
        this.menus.remove(paramInt);
      }
    }
  }
  
  public void remove(Menu paramMenu)
  {
    
    synchronized (this.menus)
    {
      int i = this.menus.indexOf(paramMenu);
      if ((i >= 0) && (this.delegate.remove(paramMenu.getDelegate(), i))) {
        this.menus.remove(i);
      }
    }
  }
  
  public List<Menu> getMenus()
  {
    Application.checkEventThread();
    return Collections.unmodifiableList(this.menus);
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\MenuBar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */