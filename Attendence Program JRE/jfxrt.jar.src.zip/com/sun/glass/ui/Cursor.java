package com.sun.glass.ui;

public abstract class Cursor
{
  public static final int CURSOR_NONE = -1;
  public static final int CURSOR_CUSTOM = 0;
  public static final int CURSOR_DEFAULT = 1;
  public static final int CURSOR_TEXT = 2;
  public static final int CURSOR_CROSSHAIR = 3;
  public static final int CURSOR_CLOSED_HAND = 4;
  public static final int CURSOR_OPEN_HAND = 5;
  public static final int CURSOR_POINTING_HAND = 6;
  public static final int CURSOR_RESIZE_LEFT = 7;
  public static final int CURSOR_RESIZE_RIGHT = 8;
  public static final int CURSOR_RESIZE_UP = 9;
  public static final int CURSOR_RESIZE_DOWN = 10;
  public static final int CURSOR_RESIZE_LEFTRIGHT = 11;
  public static final int CURSOR_RESIZE_UPDOWN = 12;
  public static final int CURSOR_DISAPPEAR = 13;
  public static final int CURSOR_WAIT = 14;
  public static final int CURSOR_RESIZE_SOUTHWEST = 15;
  public static final int CURSOR_RESIZE_SOUTHEAST = 16;
  public static final int CURSOR_RESIZE_NORTHWEST = 17;
  public static final int CURSOR_RESIZE_NORTHEAST = 18;
  public static final int CURSOR_MOVE = 19;
  private final int type;
  private long ptr;
  
  protected Cursor(int paramInt)
  {
    Application.checkEventThread();
    this.type = paramInt;
  }
  
  protected Cursor(int paramInt1, int paramInt2, Pixels paramPixels)
  {
    this(0);
    this.ptr = _createCursor(paramInt1, paramInt2, paramPixels);
  }
  
  public final int getType()
  {
    Application.checkEventThread();
    return this.type;
  }
  
  protected final long getNativeCursor()
  {
    Application.checkEventThread();
    return this.ptr;
  }
  
  public static void setVisible(boolean paramBoolean)
  {
    Application.checkEventThread();
    Application.GetApplication().staticCursor_setVisible(paramBoolean);
  }
  
  public static Size getBestSize(int paramInt1, int paramInt2)
  {
    Application.checkEventThread();
    return Application.GetApplication().staticCursor_getBestSize(paramInt1, paramInt2);
  }
  
  protected abstract long _createCursor(int paramInt1, int paramInt2, Pixels paramPixels);
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\Cursor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */