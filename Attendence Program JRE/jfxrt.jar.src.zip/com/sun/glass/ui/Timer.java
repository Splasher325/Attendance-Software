package com.sun.glass.ui;

public abstract class Timer
{
  private static final double UNSET_PERIOD = -1.0D;
  private static final double SET_PERIOD = -2.0D;
  private final Runnable runnable;
  private long ptr;
  private double period = -1.0D;
  
  protected abstract long _start(Runnable paramRunnable);
  
  protected abstract long _start(Runnable paramRunnable, int paramInt);
  
  protected abstract void _stop(long paramLong);
  
  protected Timer(Runnable paramRunnable)
  {
    if (paramRunnable == null) {
      throw new IllegalArgumentException("runnable shouldn't be null");
    }
    this.runnable = paramRunnable;
  }
  
  public static int getMinPeriod()
  {
    return Application.GetApplication().staticTimer_getMinPeriod();
  }
  
  public static int getMaxPeriod()
  {
    return Application.GetApplication().staticTimer_getMaxPeriod();
  }
  
  public synchronized void start(int paramInt)
  {
    if ((paramInt < getMinPeriod()) || (paramInt > getMaxPeriod())) {
      throw new IllegalArgumentException("period is out of range");
    }
    if (this.ptr != 0L) {
      stop();
    }
    this.ptr = _start(this.runnable, paramInt);
    if (this.ptr == 0L)
    {
      this.period = -1.0D;
      throw new RuntimeException("Failed to start the timer");
    }
    this.period = paramInt;
  }
  
  public synchronized void start()
  {
    if (this.ptr != 0L) {
      stop();
    }
    this.ptr = _start(this.runnable);
    if (this.ptr == 0L)
    {
      this.period = -1.0D;
      throw new RuntimeException("Failed to start the timer");
    }
    this.period = -2.0D;
  }
  
  public synchronized void stop()
  {
    if (this.ptr != 0L)
    {
      _stop(this.ptr);
      this.ptr = 0L;
      this.period = -1.0D;
    }
  }
  
  public synchronized boolean isRunning()
  {
    return this.period != -1.0D;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\Timer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */