package com.sun.glass.ui.win;

import com.sun.glass.ui.CommonDialogs.ExtensionFilter;
import com.sun.glass.ui.CommonDialogs.FileChooserResult;
import com.sun.glass.ui.Window;
import java.io.File;

final class WinCommonDialogs
{
  private static native void _initIDs();
  
  private static native CommonDialogs.FileChooserResult _showFileChooser(long paramLong, String paramString1, String paramString2, String paramString3, int paramInt1, boolean paramBoolean, CommonDialogs.ExtensionFilter[] paramArrayOfExtensionFilter, int paramInt2);
  
  private static native String _showFolderChooser(long paramLong, String paramString1, String paramString2);
  
  static CommonDialogs.FileChooserResult showFileChooser_impl(Window paramWindow, String paramString1, String paramString2, String paramString3, int paramInt1, boolean paramBoolean, CommonDialogs.ExtensionFilter[] paramArrayOfExtensionFilter, int paramInt2)
  {
    if (paramWindow != null) {
      ((WinWindow)paramWindow).setDeferredClosing(true);
    }
    try
    {
      CommonDialogs.FileChooserResult localFileChooserResult = _showFileChooser(paramWindow != null ? paramWindow.getNativeWindow() : 0L, paramString1, paramString2, paramString3, paramInt1, paramBoolean, paramArrayOfExtensionFilter, paramInt2);
      return localFileChooserResult;
    }
    finally
    {
      if (paramWindow != null) {
        ((WinWindow)paramWindow).setDeferredClosing(false);
      }
    }
  }
  
  static File showFolderChooser_impl(Window paramWindow, String paramString1, String paramString2)
  {
    if (paramWindow != null) {
      ((WinWindow)paramWindow).setDeferredClosing(true);
    }
    try
    {
      String str = _showFolderChooser(paramWindow != null ? paramWindow.getNativeWindow() : 0L, paramString1, paramString2);
      File localFile = str != null ? new File(str) : null;
      return localFile;
    }
    finally
    {
      if (paramWindow != null) {
        ((WinWindow)paramWindow).setDeferredClosing(false);
      }
    }
  }
  
  static {}
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinCommonDialogs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */