package com.sun.glass.ui.win;

import com.sun.glass.ui.MenuBar;
import com.sun.glass.ui.delegate.MenuBarDelegate;
import com.sun.glass.ui.delegate.MenuDelegate;

final class WinMenuBarDelegate
  extends WinMenuImpl
  implements MenuBarDelegate
{
  private final MenuBar owner;
  
  WinMenuBarDelegate(MenuBar paramMenuBar)
  {
    this.owner = paramMenuBar;
  }
  
  public MenuBar getOwner()
  {
    return this.owner;
  }
  
  public boolean createMenuBar()
  {
    return create();
  }
  
  public boolean insert(MenuDelegate paramMenuDelegate, int paramInt)
  {
    WinMenuDelegate localWinMenuDelegate = (WinMenuDelegate)paramMenuDelegate;
    if (localWinMenuDelegate.getParent() != null) {}
    return insertSubmenu(localWinMenuDelegate, paramInt);
  }
  
  public boolean remove(MenuDelegate paramMenuDelegate, int paramInt)
  {
    WinMenuDelegate localWinMenuDelegate = (WinMenuDelegate)paramMenuDelegate;
    return removeMenu(localWinMenuDelegate, paramInt);
  }
  
  public long getNativeMenu()
  {
    return getHMENU();
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinMenuBarDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */