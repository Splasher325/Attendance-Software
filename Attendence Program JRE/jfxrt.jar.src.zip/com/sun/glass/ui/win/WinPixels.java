package com.sun.glass.ui.win;

import com.sun.glass.ui.Pixels;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;

final class WinPixels
  extends Pixels
{
  private static final int nativeFormat = ;
  
  private static native int _initIDs();
  
  protected WinPixels(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer)
  {
    super(paramInt1, paramInt2, paramByteBuffer);
  }
  
  protected WinPixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer)
  {
    super(paramInt1, paramInt2, paramIntBuffer);
  }
  
  protected WinPixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer, float paramFloat)
  {
    super(paramInt1, paramInt2, paramIntBuffer, paramFloat);
  }
  
  static int getNativeFormat_impl()
  {
    return nativeFormat;
  }
  
  protected native void _fillDirectByteBuffer(ByteBuffer paramByteBuffer);
  
  protected native void _attachInt(long paramLong, int paramInt1, int paramInt2, IntBuffer paramIntBuffer, int[] paramArrayOfInt, int paramInt3);
  
  protected native void _attachByte(long paramLong, int paramInt1, int paramInt2, ByteBuffer paramByteBuffer, byte[] paramArrayOfByte, int paramInt3);
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinPixels.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */