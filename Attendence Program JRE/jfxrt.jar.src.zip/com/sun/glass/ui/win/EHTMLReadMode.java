package com.sun.glass.ui.win;

 enum EHTMLReadMode
{
  HTML_READ_ALL,  HTML_READ_FRAGMENT,  HTML_READ_SELECTION;
  
  private EHTMLReadMode() {}
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\EHTMLReadMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */