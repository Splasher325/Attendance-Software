package com.sun.glass.ui.win;

import com.sun.glass.ui.Clipboard;
import com.sun.glass.ui.delegate.ClipboardDelegate;

final class WinClipboardDelegate
  implements ClipboardDelegate
{
  public Clipboard createClipboard(String paramString)
  {
    if ("SYSTEM".equals(paramString)) {
      return new WinSystemClipboard(paramString);
    }
    if ("DND".equals(paramString)) {
      return new WinDnDClipboard(paramString);
    }
    return null;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinClipboardDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */