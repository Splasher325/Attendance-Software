package com.sun.glass.ui.win;

import com.sun.glass.ui.Menu;
import com.sun.glass.ui.MenuBar;
import com.sun.glass.ui.MenuItem;
import com.sun.glass.ui.PlatformFactory;
import com.sun.glass.ui.delegate.ClipboardDelegate;
import com.sun.glass.ui.delegate.MenuBarDelegate;
import com.sun.glass.ui.delegate.MenuDelegate;
import com.sun.glass.ui.delegate.MenuItemDelegate;

public final class WinPlatformFactory
  extends PlatformFactory
{
  public WinApplication createApplication()
  {
    return new WinApplication();
  }
  
  public MenuBarDelegate createMenuBarDelegate(MenuBar paramMenuBar)
  {
    return new WinMenuBarDelegate(paramMenuBar);
  }
  
  public MenuDelegate createMenuDelegate(Menu paramMenu)
  {
    return new WinMenuDelegate(paramMenu);
  }
  
  public MenuItemDelegate createMenuItemDelegate(MenuItem paramMenuItem)
  {
    return new WinMenuItemDelegate(paramMenuItem);
  }
  
  public ClipboardDelegate createClipboardDelegate()
  {
    return new WinClipboardDelegate();
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinPlatformFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */