package com.sun.glass.ui.win;

import com.sun.glass.ui.Pixels;
import com.sun.glass.ui.View;
import java.util.Map;

final class WinView
  extends View
{
  private static final long multiClickTime = _getMultiClickTime_impl();
  private static final int multiClickMaxX = _getMultiClickMaxX_impl();
  private static final int multiClickMaxY = _getMultiClickMaxY_impl();
  
  private static native void _initIDs();
  
  private static native long _getMultiClickTime_impl();
  
  private static native int _getMultiClickMaxX_impl();
  
  private static native int _getMultiClickMaxY_impl();
  
  static long getMultiClickTime_impl()
  {
    return multiClickTime;
  }
  
  static int getMultiClickMaxX_impl()
  {
    return multiClickMaxX;
  }
  
  static int getMultiClickMaxY_impl()
  {
    return multiClickMaxY;
  }
  
  protected int _getNativeFrameBuffer(long paramLong)
  {
    return 0;
  }
  
  protected native void _enableInputMethodEvents(long paramLong, boolean paramBoolean);
  
  protected native void _finishInputMethodComposition(long paramLong);
  
  protected native long _create(Map paramMap);
  
  protected native long _getNativeView(long paramLong);
  
  protected native int _getX(long paramLong);
  
  protected native int _getY(long paramLong);
  
  protected native void _setParent(long paramLong1, long paramLong2);
  
  protected native boolean _close(long paramLong);
  
  protected native void _scheduleRepaint(long paramLong);
  
  protected native void _begin(long paramLong);
  
  protected native void _end(long paramLong);
  
  protected native void _uploadPixels(long paramLong, Pixels paramPixels);
  
  protected native boolean _enterFullscreen(long paramLong, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
  
  protected native void _exitFullscreen(long paramLong, boolean paramBoolean);
  
  static {}
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */