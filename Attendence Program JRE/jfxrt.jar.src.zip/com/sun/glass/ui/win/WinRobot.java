package com.sun.glass.ui.win;

import com.sun.glass.ui.Application;
import com.sun.glass.ui.Pixels;
import com.sun.glass.ui.Robot;
import java.nio.IntBuffer;

final class WinRobot
  extends Robot
{
  protected void _create() {}
  
  protected void _destroy() {}
  
  protected native void _keyPress(int paramInt);
  
  protected native void _keyRelease(int paramInt);
  
  protected native void _mouseMove(int paramInt1, int paramInt2);
  
  protected native void _mousePress(int paramInt);
  
  protected native void _mouseRelease(int paramInt);
  
  protected native void _mouseWheel(int paramInt);
  
  protected native int _getMouseX();
  
  protected native int _getMouseY();
  
  protected native int _getPixelColor(int paramInt1, int paramInt2);
  
  private native void _getScreenCapture(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt);
  
  protected Pixels _getScreenCapture(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    int[] arrayOfInt = new int[paramInt3 * paramInt4];
    _getScreenCapture(paramInt1, paramInt2, paramInt3, paramInt4, arrayOfInt);
    return Application.GetApplication().createPixels(paramInt3, paramInt4, IntBuffer.wrap(arrayOfInt));
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinRobot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */