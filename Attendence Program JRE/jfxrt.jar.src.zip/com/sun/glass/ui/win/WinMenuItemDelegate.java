package com.sun.glass.ui.win;

import com.sun.glass.ui.MenuItem;
import com.sun.glass.ui.MenuItem.Callback;
import com.sun.glass.ui.Pixels;
import com.sun.glass.ui.delegate.MenuItemDelegate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

final class WinMenuItemDelegate
  implements MenuItemDelegate
{
  private final MenuItem owner;
  private WinMenuImpl parent = null;
  private int cmdID = -1;
  
  public WinMenuItemDelegate(MenuItem paramMenuItem)
  {
    this.owner = paramMenuItem;
  }
  
  public MenuItem getOwner()
  {
    return this.owner;
  }
  
  public boolean createMenuItem(String paramString, MenuItem.Callback paramCallback, int paramInt1, int paramInt2, Pixels paramPixels, boolean paramBoolean1, boolean paramBoolean2)
  {
    return true;
  }
  
  public boolean setTitle(String paramString)
  {
    if (this.parent != null)
    {
      paramString = getTitle(paramString, getOwner().getShortcutKey(), getOwner().getShortcutModifiers());
      return this.parent.setItemTitle(this, paramString);
    }
    return true;
  }
  
  public boolean setCallback(MenuItem.Callback paramCallback)
  {
    return true;
  }
  
  public boolean setShortcut(int paramInt1, int paramInt2)
  {
    if (this.parent != null)
    {
      String str = getTitle(getOwner().getTitle(), paramInt1, paramInt2);
      return this.parent.setItemTitle(this, str);
    }
    return true;
  }
  
  public boolean setPixels(Pixels paramPixels)
  {
    return false;
  }
  
  public boolean setEnabled(boolean paramBoolean)
  {
    if (this.parent != null) {
      return this.parent.enableItem(this, paramBoolean);
    }
    return true;
  }
  
  public boolean setChecked(boolean paramBoolean)
  {
    if (this.parent != null) {
      return this.parent.checkItem(this, paramBoolean);
    }
    return true;
  }
  
  private String getTitle(String paramString, int paramInt1, int paramInt2)
  {
    if (paramInt1 == 0) {
      return paramString;
    }
    return paramString;
  }
  
  WinMenuImpl getParent()
  {
    return this.parent;
  }
  
  void setParent(WinMenuImpl paramWinMenuImpl)
  {
    if (this.parent != null)
    {
      CommandIDManager.freeID(this.cmdID);
      this.cmdID = -1;
    }
    if (paramWinMenuImpl != null) {
      this.cmdID = CommandIDManager.getID(this);
    }
    this.parent = paramWinMenuImpl;
  }
  
  int getCmdID()
  {
    return this.cmdID;
  }
  
  static class CommandIDManager
  {
    private static final int FIRST_ID = 1;
    private static final int LAST_ID = 65535;
    private static List<Integer> freeList = new ArrayList();
    private static final Map<Integer, WinMenuItemDelegate> map = new HashMap();
    private static int nextID = 1;
    
    public static synchronized int getID(WinMenuItemDelegate paramWinMenuItemDelegate)
    {
      Integer localInteger;
      if (freeList.isEmpty())
      {
        if (nextID > 65535) {
          nextID = 1;
        }
        localInteger = Integer.valueOf(nextID);
        nextID += 1;
      }
      else
      {
        localInteger = (Integer)freeList.remove(freeList.size() - 1);
      }
      map.put(localInteger, paramWinMenuItemDelegate);
      return localInteger.intValue();
    }
    
    public static synchronized void freeID(int paramInt)
    {
      Integer localInteger = Integer.valueOf(paramInt);
      if (map.remove(localInteger) != null) {
        freeList.add(localInteger);
      }
    }
    
    public static WinMenuItemDelegate getHandler(int paramInt)
    {
      return (WinMenuItemDelegate)map.get(Integer.valueOf(paramInt));
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinMenuItemDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */