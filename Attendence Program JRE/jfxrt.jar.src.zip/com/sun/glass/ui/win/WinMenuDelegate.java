package com.sun.glass.ui.win;

import com.sun.glass.ui.Menu;
import com.sun.glass.ui.Pixels;
import com.sun.glass.ui.delegate.MenuDelegate;
import com.sun.glass.ui.delegate.MenuItemDelegate;

final class WinMenuDelegate
  extends WinMenuImpl
  implements MenuDelegate
{
  private final Menu owner;
  private WinMenuImpl parent = null;
  
  public WinMenuDelegate(Menu paramMenu)
  {
    this.owner = paramMenu;
  }
  
  public Menu getOwner()
  {
    return this.owner;
  }
  
  public boolean createMenu(String paramString, boolean paramBoolean)
  {
    return create();
  }
  
  public void dispose()
  {
    destroy();
  }
  
  public boolean setTitle(String paramString)
  {
    if (this.parent != null) {
      return this.parent.setSubmenuTitle(this, paramString);
    }
    return true;
  }
  
  public boolean setEnabled(boolean paramBoolean)
  {
    if (this.parent != null) {
      return this.parent.enableSubmenu(this, paramBoolean);
    }
    return true;
  }
  
  public boolean setPixels(Pixels paramPixels)
  {
    return false;
  }
  
  public boolean insert(MenuDelegate paramMenuDelegate, int paramInt)
  {
    return insertSubmenu((WinMenuDelegate)paramMenuDelegate, paramInt);
  }
  
  public boolean insert(MenuItemDelegate paramMenuItemDelegate, int paramInt)
  {
    return insertItem((WinMenuItemDelegate)paramMenuItemDelegate, paramInt);
  }
  
  public boolean remove(MenuDelegate paramMenuDelegate, int paramInt)
  {
    return removeMenu((WinMenuDelegate)paramMenuDelegate, paramInt);
  }
  
  public boolean remove(MenuItemDelegate paramMenuItemDelegate, int paramInt)
  {
    return removeItem((WinMenuItemDelegate)paramMenuItemDelegate, paramInt);
  }
  
  WinMenuImpl getParent()
  {
    return this.parent;
  }
  
  void setParent(WinMenuImpl paramWinMenuImpl)
  {
    this.parent = paramWinMenuImpl;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinMenuDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */