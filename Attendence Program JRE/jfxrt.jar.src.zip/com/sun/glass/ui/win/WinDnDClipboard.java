package com.sun.glass.ui.win;

final class WinDnDClipboard
  extends WinSystemClipboard
{
  private static int dragButton = 0;
  private int sourceSupportedActions = 0;
  
  public WinDnDClipboard(String paramString)
  {
    super(paramString);
  }
  
  protected void create() {}
  
  protected native void dispose();
  
  protected boolean isOwner()
  {
    return getDragButton() != 0;
  }
  
  protected void pushTargetActionToSystem(int paramInt)
  {
    throw new UnsupportedOperationException("[Target Action] not supported! Override View.handleDragDrop instead.");
  }
  
  protected native void push(Object[] paramArrayOfObject, int paramInt);
  
  protected boolean pop()
  {
    return getPtr() != 0L;
  }
  
  private static WinDnDClipboard getInstance()
  {
    return (WinDnDClipboard)get("DND");
  }
  
  public String toString()
  {
    return "Windows DnD Clipboard";
  }
  
  public int getDragButton()
  {
    return dragButton;
  }
  
  private void setDragButton(int paramInt)
  {
    dragButton = paramInt;
  }
  
  protected final int supportedSourceActionsFromSystem()
  {
    return this.sourceSupportedActions != 0 ? this.sourceSupportedActions : super.supportedSourceActionsFromSystem();
  }
  
  private void setSourceSupportedActions(int paramInt)
  {
    this.sourceSupportedActions = paramInt;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinDnDClipboard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */