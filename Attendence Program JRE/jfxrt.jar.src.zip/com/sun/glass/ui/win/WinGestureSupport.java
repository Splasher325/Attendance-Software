package com.sun.glass.ui.win;

import com.sun.glass.ui.GestureSupport;
import com.sun.glass.ui.TouchInputSupport;
import com.sun.glass.ui.View;

final class WinGestureSupport
{
  private static final double multiplier = 1.0D;
  private static final GestureSupport gestures = new GestureSupport(true);
  private static final TouchInputSupport touches = new TouchInputSupport(gestures.createTouchCountListener(), true);
  private static int modifiers;
  private static boolean isDirect;
  
  private static native void _initIDs();
  
  public static void notifyBeginTouchEvent(View paramView, int paramInt1, boolean paramBoolean, int paramInt2)
  {
    touches.notifyBeginTouchEvent(paramView, paramInt1, paramBoolean, paramInt2);
  }
  
  public static void notifyNextTouchEvent(View paramView, int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    touches.notifyNextTouchEvent(paramView, paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  public static void notifyEndTouchEvent(View paramView)
  {
    touches.notifyEndTouchEvent(paramView);
    gestureFinished(paramView, touches.getTouchCount(), false);
  }
  
  private static void gestureFinished(View paramView, int paramInt, boolean paramBoolean)
  {
    if ((gestures.isScrolling()) && (paramInt == 0)) {
      gestures.handleScrollingEnd(paramView, modifiers, paramInt, isDirect, paramBoolean, Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE);
    }
    if ((gestures.isRotating()) && (paramInt < 2)) {
      gestures.handleRotationEnd(paramView, modifiers, isDirect, paramBoolean, Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE);
    }
    if ((gestures.isZooming()) && (paramInt < 2)) {
      gestures.handleZoomingEnd(paramView, modifiers, isDirect, paramBoolean, Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE);
    }
  }
  
  public static void inertiaGestureFinished(View paramView)
  {
    gestureFinished(paramView, 0, true);
  }
  
  public static void gesturePerformed(View paramView, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7)
  {
    modifiers = paramInt1;
    isDirect = paramBoolean1;
    int i = touches.getTouchCount();
    if (i >= 2)
    {
      gestures.handleTotalZooming(paramView, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramInt3, paramInt4, paramInt5, paramFloat5, paramFloat6);
      gestures.handleTotalRotation(paramView, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramInt3, paramInt4, paramInt5, Math.toDegrees(paramFloat7));
    }
    gestures.handleTotalScrolling(paramView, paramInt1, paramBoolean1, paramBoolean2, i, paramInt2, paramInt3, paramInt4, paramInt5, paramFloat3, paramFloat4, 1.0D, 1.0D);
  }
  
  static {}
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinGestureSupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */