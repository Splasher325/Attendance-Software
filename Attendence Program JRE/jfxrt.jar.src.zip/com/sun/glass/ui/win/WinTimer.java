package com.sun.glass.ui.win;

import com.sun.glass.ui.Timer;

final class WinTimer
  extends Timer
{
  private static final int minPeriod = ;
  private static final int maxPeriod = _getMaxPeriod();
  
  protected WinTimer(Runnable paramRunnable)
  {
    super(paramRunnable);
  }
  
  private static native int _getMinPeriod();
  
  private static native int _getMaxPeriod();
  
  static int getMinPeriod_impl()
  {
    return minPeriod;
  }
  
  static int getMaxPeriod_impl()
  {
    return maxPeriod;
  }
  
  protected long _start(Runnable paramRunnable)
  {
    throw new RuntimeException("vsync timer not supported");
  }
  
  protected native long _start(Runnable paramRunnable, int paramInt);
  
  protected native void _stop(long paramLong);
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinTimer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */