package com.sun.glass.ui.win;

import com.sun.glass.ui.Cursor;
import com.sun.glass.ui.Pixels;
import com.sun.glass.ui.Screen;
import com.sun.glass.ui.View;
import com.sun.glass.ui.Window;

class WinWindow
  extends Window
{
  private boolean deferredClosing = false;
  private boolean closingRequested = false;
  
  private static native void _initIDs();
  
  protected WinWindow(Window paramWindow, Screen paramScreen, int paramInt)
  {
    super(paramWindow, paramScreen, paramInt);
    setPlatformScale(paramScreen.getUIScale());
    setRenderScale(paramScreen.getRenderScale());
  }
  
  protected WinWindow(long paramLong)
  {
    super(paramLong);
    setPlatformScale(getScreen().getUIScale());
    setRenderScale(getScreen().getRenderScale());
  }
  
  protected void notifyScaleChanged(float paramFloat1, float paramFloat2)
  {
    setPlatformScale(paramFloat1);
    setRenderScale(paramFloat2);
  }
  
  protected native long _createWindow(long paramLong1, long paramLong2, int paramInt);
  
  protected native long _createChildWindow(long paramLong);
  
  protected native boolean _close(long paramLong);
  
  protected native boolean _setView(long paramLong, View paramView);
  
  protected native boolean _setMenubar(long paramLong1, long paramLong2);
  
  protected native boolean _minimize(long paramLong, boolean paramBoolean);
  
  protected native boolean _maximize(long paramLong, boolean paramBoolean1, boolean paramBoolean2);
  
  protected native void _setBounds(long paramLong, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, float paramFloat1, float paramFloat2);
  
  protected native boolean _setVisible(long paramLong, boolean paramBoolean);
  
  protected native boolean _setResizable(long paramLong, boolean paramBoolean);
  
  protected native boolean _requestFocus(long paramLong, int paramInt);
  
  protected native void _setFocusable(long paramLong, boolean paramBoolean);
  
  protected native boolean _setTitle(long paramLong, String paramString);
  
  protected native void _setLevel(long paramLong, int paramInt);
  
  protected native void _setAlpha(long paramLong, float paramFloat);
  
  protected native boolean _setBackground(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3);
  
  protected native void _setEnabled(long paramLong, boolean paramBoolean);
  
  protected native boolean _setMinimumSize(long paramLong, int paramInt1, int paramInt2);
  
  protected native boolean _setMaximumSize(long paramLong, int paramInt1, int paramInt2);
  
  protected native void _setIcon(long paramLong, Pixels paramPixels);
  
  protected native void _toFront(long paramLong);
  
  protected native void _toBack(long paramLong);
  
  protected native void _enterModal(long paramLong);
  
  protected native void _enterModalWithWindow(long paramLong1, long paramLong2);
  
  protected native void _exitModal(long paramLong);
  
  protected native boolean _grabFocus(long paramLong);
  
  protected native void _ungrabFocus(long paramLong);
  
  protected native int _getEmbeddedX(long paramLong);
  
  protected native int _getEmbeddedY(long paramLong);
  
  protected native void _setCursor(long paramLong, Cursor paramCursor);
  
  protected void _requestInput(long paramLong, String paramString, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12, double paramDouble13, double paramDouble14)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }
  
  protected void _releaseInput(long paramLong)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }
  
  void setDeferredClosing(boolean paramBoolean)
  {
    this.deferredClosing = paramBoolean;
    if ((!this.deferredClosing) && (this.closingRequested)) {
      close();
    }
  }
  
  public void close()
  {
    if (!this.deferredClosing)
    {
      super.close();
    }
    else
    {
      this.closingRequested = true;
      setVisible(false);
    }
  }
  
  static {}
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinWindow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */