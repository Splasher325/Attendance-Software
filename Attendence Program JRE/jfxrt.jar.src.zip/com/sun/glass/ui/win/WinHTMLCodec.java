package com.sun.glass.ui.win;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

final class WinHTMLCodec
{
  public static final String defaultCharset = "UTF-8";
  
  public static byte[] encode(byte[] paramArrayOfByte)
  {
    return HTMLCodec.convertToHTMLFormat(paramArrayOfByte);
  }
  
  public static byte[] decode(byte[] paramArrayOfByte)
  {
    try
    {
      ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
      HTMLCodec localHTMLCodec = new HTMLCodec(localByteArrayInputStream, EHTMLReadMode.HTML_READ_SELECTION);
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream(paramArrayOfByte.length);
      int i;
      while ((i = localHTMLCodec.read()) != -1) {
        localByteArrayOutputStream.write(i);
      }
      return localByteArrayOutputStream.toByteArray();
    }
    catch (IOException localIOException)
    {
      throw new RuntimeException("Unexpected IOException caught", localIOException);
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinHTMLCodec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */