package com.sun.glass.ui.win;

import com.sun.glass.ui.Application;
import com.sun.glass.ui.Pixels;
import com.sun.glass.ui.SystemClipboard;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

class WinSystemClipboard
  extends SystemClipboard
{
  private long ptr = 0L;
  static final byte[] terminator = { 0, 0 };
  static final String defaultCharset = "UTF-16LE";
  static final String RTFCharset = "US-ASCII";
  
  private static native void initIDs();
  
  protected WinSystemClipboard(String paramString)
  {
    super(paramString);
    create();
  }
  
  protected final long getPtr()
  {
    return this.ptr;
  }
  
  protected native boolean isOwner();
  
  protected native void create();
  
  protected native void dispose();
  
  protected native void push(Object[] paramArrayOfObject, int paramInt);
  
  protected native boolean pop();
  
  private byte[] fosSerialize(String paramString, long paramLong)
  {
    Object localObject1 = getLocalData(paramString);
    Object localObject2;
    if ((localObject1 instanceof ByteBuffer))
    {
      localObject2 = ((ByteBuffer)localObject1).array();
      if ("text/html".equals(paramString)) {
        localObject2 = WinHTMLCodec.encode((byte[])localObject2);
      }
      return (byte[])localObject2;
    }
    if ((localObject1 instanceof String))
    {
      localObject2 = ((String)localObject1).replace("\n", "\r\n");
      ByteBuffer localByteBuffer3;
      if ("text/html".equals(paramString)) {
        try
        {
          byte[] arrayOfByte1 = ((String)localObject2).getBytes("UTF-8");
          localByteBuffer3 = ByteBuffer.allocate(arrayOfByte1.length + 1);
          localByteBuffer3.put(arrayOfByte1);
          localByteBuffer3.put((byte)0);
          return WinHTMLCodec.encode(localByteBuffer3.array());
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException1)
        {
          return null;
        }
      }
      if ("text/rtf".equals(paramString)) {
        try
        {
          byte[] arrayOfByte2 = ((String)localObject2).getBytes("US-ASCII");
          localByteBuffer3 = ByteBuffer.allocate(arrayOfByte2.length + 1);
          localByteBuffer3.put(arrayOfByte2);
          localByteBuffer3.put((byte)0);
          return localByteBuffer3.array();
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException2)
        {
          return null;
        }
      }
      ByteBuffer localByteBuffer1 = ByteBuffer.allocate((((String)localObject2).length() + 1) * 2);
      try
      {
        localByteBuffer1.put(((String)localObject2).getBytes("UTF-16LE"));
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException3) {}
      localByteBuffer1.put(terminator);
      return localByteBuffer1.array();
    }
    if ("application/x-java-file-list".equals(paramString))
    {
      localObject2 = (String[])localObject1;
      if ((localObject2 != null) && (localObject2.length > 0))
      {
        int i = 0;
        for (Object localObject5 : localObject2) {
          i += (((String)localObject5).length() + 1) * 2;
        }
        i += 2;
        try
        {
          ??? = ByteBuffer.allocate(i);
          for (Object localObject6 : localObject2)
          {
            ((ByteBuffer)???).put(((String)localObject6).getBytes("UTF-16LE"));
            ((ByteBuffer)???).put(terminator);
          }
          ((ByteBuffer)???).put(terminator);
          return ((ByteBuffer)???).array();
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException4) {}
      }
    }
    else if ("application/x-java-rawimage".equals(paramString))
    {
      localObject2 = (Pixels)localObject1;
      if (localObject2 != null)
      {
        ByteBuffer localByteBuffer2 = ByteBuffer.allocate(((Pixels)localObject2).getWidth() * ((Pixels)localObject2).getHeight() * 4 + 8);
        localByteBuffer2.putInt(((Pixels)localObject2).getWidth());
        localByteBuffer2.putInt(((Pixels)localObject2).getHeight());
        localByteBuffer2.put(((Pixels)localObject2).asByteBuffer());
        return localByteBuffer2.array();
      }
    }
    return null;
  }
  
  protected final void pushToSystem(HashMap<String, Object> paramHashMap, int paramInt)
  {
    Set localSet = paramHashMap.keySet();
    HashSet localHashSet = new HashSet();
    MimeTypeParser localMimeTypeParser = new MimeTypeParser();
    Iterator localIterator = localSet.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      localMimeTypeParser.parse(str);
      if (!localMimeTypeParser.isInMemoryFile()) {
        localHashSet.add(str);
      }
    }
    push(localHashSet.toArray(), paramInt);
  }
  
  private native byte[] popBytes(String paramString, long paramLong);
  
  protected final Object popFromSystem(String paramString)
  {
    if (!pop()) {
      return null;
    }
    MimeTypeParser localMimeTypeParser = new MimeTypeParser(paramString);
    String str1 = localMimeTypeParser.getMime();
    byte[] arrayOfByte = popBytes(str1, localMimeTypeParser.getIndex());
    if (arrayOfByte != null)
    {
      if (("text/plain".equals(str1)) || ("text/uri-list".equals(str1)))
      {
        try
        {
          return new String(arrayOfByte, 0, arrayOfByte.length - 2, "UTF-16LE");
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException1) {}
      }
      else if ("text/html".equals(str1))
      {
        try
        {
          arrayOfByte = WinHTMLCodec.decode(arrayOfByte);
          return new String(arrayOfByte, 0, arrayOfByte.length, "UTF-8");
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException2) {}
      }
      else if ("text/rtf".equals(str1))
      {
        try
        {
          return new String(arrayOfByte, 0, arrayOfByte.length, "US-ASCII");
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException3) {}
      }
      else if ("application/x-java-file-list".equals(str1))
      {
        try
        {
          String str2 = new String(arrayOfByte, 0, arrayOfByte.length, "UTF-16LE");
          return str2.split("\000");
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException4) {}
      }
      else
      {
        if ("application/x-java-rawimage".equals(str1))
        {
          ByteBuffer localByteBuffer = ByteBuffer.wrap(arrayOfByte, 0, 8);
          return Application.GetApplication().createPixels(localByteBuffer.getInt(), localByteBuffer.getInt(), ByteBuffer.wrap(arrayOfByte, 8, arrayOfByte.length - 8));
        }
        return ByteBuffer.wrap(arrayOfByte);
      }
    }
    else
    {
      if (("text/uri-list".equals(str1)) || ("text/plain".equals(str1)))
      {
        arrayOfByte = popBytes(str1 + ";locale", localMimeTypeParser.getIndex());
        if (arrayOfByte != null) {
          try
          {
            return new String(arrayOfByte, 0, arrayOfByte.length - 1, "UTF-8");
          }
          catch (UnsupportedEncodingException localUnsupportedEncodingException5) {}
        }
      }
      if ("text/uri-list".equals(str1))
      {
        String[] arrayOfString = (String[])popFromSystem("application/x-java-file-list");
        if (arrayOfString != null)
        {
          StringBuilder localStringBuilder = new StringBuilder();
          for (int i = 0; i < arrayOfString.length; i++)
          {
            String str3 = arrayOfString[i];
            str3 = str3.replace("\\", "/");
            if (localStringBuilder.length() > 0) {
              localStringBuilder.append("\r\n");
            }
            localStringBuilder.append("file:/").append(str3);
          }
          return localStringBuilder.toString();
        }
      }
    }
    return null;
  }
  
  private native String[] popMimesFromSystem();
  
  protected final String[] mimesFromSystem()
  {
    if (!pop()) {
      return null;
    }
    return popMimesFromSystem();
  }
  
  public String toString()
  {
    return "Windows System Clipboard";
  }
  
  protected final void close()
  {
    dispose();
    this.ptr = 0L;
  }
  
  protected native void pushTargetActionToSystem(int paramInt);
  
  private native int popSupportedSourceActions();
  
  protected int supportedSourceActionsFromSystem()
  {
    if (!pop()) {
      return 0;
    }
    return popSupportedSourceActions();
  }
  
  static {}
  
  private static final class MimeTypeParser
  {
    protected static final String externalBodyMime = "message/external-body";
    protected String mime;
    protected boolean bInMemoryFile;
    protected int index;
    
    public MimeTypeParser()
    {
      parse("");
    }
    
    public MimeTypeParser(String paramString)
    {
      parse(paramString);
    }
    
    public void parse(String paramString)
    {
      this.mime = paramString;
      this.bInMemoryFile = false;
      this.index = -1;
      if (paramString.startsWith("message/external-body"))
      {
        String[] arrayOfString1 = paramString.split(";");
        String str = "";
        int i = -1;
        for (int j = 1; j < arrayOfString1.length; j++)
        {
          String[] arrayOfString2 = arrayOfString1[j].split("=");
          if (arrayOfString2.length == 2) {
            if (arrayOfString2[0].trim().equalsIgnoreCase("index")) {
              i = Integer.parseInt(arrayOfString2[1].trim());
            } else if (arrayOfString2[0].trim().equalsIgnoreCase("access-type")) {
              str = arrayOfString2[1].trim();
            }
          }
          if ((i != -1) && (!str.isEmpty())) {
            break;
          }
        }
        if (str.equalsIgnoreCase("clipboard"))
        {
          this.bInMemoryFile = true;
          this.mime = arrayOfString1[0];
          this.index = i;
        }
      }
    }
    
    public String getMime()
    {
      return this.mime;
    }
    
    public int getIndex()
    {
      return this.index;
    }
    
    public boolean isInMemoryFile()
    {
      return this.bInMemoryFile;
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinSystemClipboard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */