package com.sun.glass.ui.win;

import com.sun.glass.ui.Pixels;

final class WinChildWindow
  extends WinWindow
{
  protected WinChildWindow(long paramLong)
  {
    super(paramLong);
  }
  
  protected long _createWindow(long paramLong1, long paramLong2, int paramInt)
  {
    return 0L;
  }
  
  protected boolean _setMenubar(long paramLong1, long paramLong2)
  {
    return false;
  }
  
  protected boolean _minimize(long paramLong, boolean paramBoolean)
  {
    return false;
  }
  
  protected boolean _maximize(long paramLong, boolean paramBoolean1, boolean paramBoolean2)
  {
    return false;
  }
  
  protected boolean _setResizable(long paramLong, boolean paramBoolean)
  {
    return false;
  }
  
  protected boolean _setTitle(long paramLong, String paramString)
  {
    return false;
  }
  
  protected void _setLevel(long paramLong, int paramInt) {}
  
  protected void _setAlpha(long paramLong, float paramFloat) {}
  
  protected boolean _setMinimumSize(long paramLong, int paramInt1, int paramInt2)
  {
    return false;
  }
  
  protected boolean _setMaximumSize(long paramLong, int paramInt1, int paramInt2)
  {
    return false;
  }
  
  protected void _setIcon(long paramLong, Pixels paramPixels) {}
  
  protected void _enterModal(long paramLong) {}
  
  protected void _enterModalWithWindow(long paramLong1, long paramLong2) {}
  
  protected void _exitModal(long paramLong) {}
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinChildWindow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */