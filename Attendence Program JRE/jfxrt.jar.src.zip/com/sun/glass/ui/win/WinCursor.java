package com.sun.glass.ui.win;

import com.sun.glass.ui.Cursor;
import com.sun.glass.ui.Pixels;
import com.sun.glass.ui.Size;

final class WinCursor
  extends Cursor
{
  private static native void _initIDs();
  
  protected WinCursor(int paramInt)
  {
    super(paramInt);
  }
  
  protected WinCursor(int paramInt1, int paramInt2, Pixels paramPixels)
  {
    super(paramInt1, paramInt2, paramPixels);
  }
  
  protected native long _createCursor(int paramInt1, int paramInt2, Pixels paramPixels);
  
  private static native void _setVisible(boolean paramBoolean);
  
  private static native Size _getBestSize(int paramInt1, int paramInt2);
  
  static void setVisible_impl(boolean paramBoolean)
  {
    _setVisible(paramBoolean);
  }
  
  static Size getBestSize_impl(int paramInt1, int paramInt2)
  {
    return _getBestSize(paramInt1, paramInt2);
  }
  
  static {}
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinCursor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */