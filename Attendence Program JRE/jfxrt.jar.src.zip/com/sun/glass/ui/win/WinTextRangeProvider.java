package com.sun.glass.ui.win;

import java.io.PrintStream;
import java.text.BreakIterator;
import javafx.geometry.Bounds;
import javafx.scene.AccessibleAction;
import javafx.scene.AccessibleAttribute;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

class WinTextRangeProvider
{
  private static final int TextPatternRangeEndpoint_Start = 0;
  private static final int TextPatternRangeEndpoint_End = 1;
  private static final int TextUnit_Character = 0;
  private static final int TextUnit_Format = 1;
  private static final int TextUnit_Word = 2;
  private static final int TextUnit_Line = 3;
  private static final int TextUnit_Paragraph = 4;
  private static final int TextUnit_Page = 5;
  private static final int TextUnit_Document = 6;
  private static final int UIA_FontNameAttributeId = 40005;
  private static final int UIA_FontSizeAttributeId = 40006;
  private static final int UIA_FontWeightAttributeId = 40007;
  private static final int UIA_IsHiddenAttributeId = 40013;
  private static final int UIA_IsItalicAttributeId = 40014;
  private static final int UIA_IsReadOnlyAttributeId = 40015;
  private static int idCount = 1;
  private int id;
  private int start;
  private int end;
  private WinAccessible accessible;
  private long peer;
  
  private static native void _initIDs();
  
  private native long _createTextRangeProvider(long paramLong);
  
  private native void _destroyTextRangeProvider(long paramLong);
  
  WinTextRangeProvider(WinAccessible paramWinAccessible)
  {
    this.accessible = paramWinAccessible;
    this.peer = _createTextRangeProvider(paramWinAccessible.getNativeAccessible());
    this.id = (idCount++);
  }
  
  long getNativeProvider()
  {
    return this.peer;
  }
  
  void dispose()
  {
    _destroyTextRangeProvider(this.peer);
    this.peer = 0L;
  }
  
  void setRange(int paramInt1, int paramInt2)
  {
    this.start = paramInt1;
    this.end = paramInt2;
  }
  
  int getStart()
  {
    return this.start;
  }
  
  int getEnd()
  {
    return this.end;
  }
  
  public String toString()
  {
    return "Range(start: " + this.start + ", end: " + this.end + ", id: " + this.id + ")";
  }
  
  private Object getAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs)
  {
    return this.accessible.getAttribute(paramAccessibleAttribute, paramVarArgs);
  }
  
  private boolean isWordStart(BreakIterator paramBreakIterator, String paramString, int paramInt)
  {
    if (paramInt == 0) {
      return true;
    }
    if (paramInt == paramString.length()) {
      return true;
    }
    if (paramInt == -1) {
      return true;
    }
    return (paramBreakIterator.isBoundary(paramInt)) && (Character.isLetterOrDigit(paramString.charAt(paramInt)));
  }
  
  private long Clone()
  {
    WinTextRangeProvider localWinTextRangeProvider = new WinTextRangeProvider(this.accessible);
    localWinTextRangeProvider.setRange(this.start, this.end);
    return localWinTextRangeProvider.getNativeProvider();
  }
  
  private boolean Compare(WinTextRangeProvider paramWinTextRangeProvider)
  {
    if (paramWinTextRangeProvider == null) {
      return false;
    }
    return (this.accessible == paramWinTextRangeProvider.accessible) && (this.start == paramWinTextRangeProvider.start) && (this.end == paramWinTextRangeProvider.end);
  }
  
  private int CompareEndpoints(int paramInt1, WinTextRangeProvider paramWinTextRangeProvider, int paramInt2)
  {
    int i = paramInt1 == 0 ? this.start : this.end;
    int j = paramInt2 == 0 ? paramWinTextRangeProvider.start : paramWinTextRangeProvider.end;
    return i - j;
  }
  
  private void ExpandToEnclosingUnit(int paramInt)
  {
    String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
    if (str == null) {
      return;
    }
    int i = str.length();
    if (i == 0) {
      return;
    }
    Object localObject1;
    Object localObject2;
    switch (paramInt)
    {
    case 0: 
      if (this.start == i) {
        this.start -= 1;
      }
      this.end = (this.start + 1);
      break;
    case 1: 
    case 2: 
      localObject1 = BreakIterator.getWordInstance();
      ((BreakIterator)localObject1).setText(str);
      int j;
      if (!isWordStart((BreakIterator)localObject1, str, this.start))
      {
        for (j = ((BreakIterator)localObject1).preceding(this.start); !isWordStart((BreakIterator)localObject1, str, j); j = ((BreakIterator)localObject1).previous()) {}
        this.start = (j != -1 ? j : 0);
      }
      if (!isWordStart((BreakIterator)localObject1, str, this.end))
      {
        for (j = ((BreakIterator)localObject1).following(this.end); !isWordStart((BreakIterator)localObject1, str, j); j = ((BreakIterator)localObject1).next()) {}
        this.end = (j != -1 ? j : i);
      }
      break;
    case 3: 
      localObject1 = (Integer)getAttribute(AccessibleAttribute.LINE_FOR_OFFSET, new Object[] { Integer.valueOf(this.start) });
      localObject2 = (Integer)getAttribute(AccessibleAttribute.LINE_START, new Object[] { localObject1 });
      Integer localInteger = (Integer)getAttribute(AccessibleAttribute.LINE_END, new Object[] { localObject1 });
      if ((localObject1 == null) || (localInteger == null) || (localObject2 == null))
      {
        this.start = 0;
        this.end = i;
      }
      else
      {
        this.start = ((Integer)localObject2).intValue();
        this.end = localInteger.intValue();
      }
      break;
    case 4: 
      localObject1 = (Integer)getAttribute(AccessibleAttribute.LINE_FOR_OFFSET, new Object[] { Integer.valueOf(this.start) });
      if (localObject1 == null)
      {
        this.start = 0;
        this.end = i;
      }
      else
      {
        localObject2 = BreakIterator.getSentenceInstance();
        ((BreakIterator)localObject2).setText(str);
        if (!((BreakIterator)localObject2).isBoundary(this.start))
        {
          k = ((BreakIterator)localObject2).preceding(this.start);
          this.start = (k != -1 ? k : 0);
        }
        int k = ((BreakIterator)localObject2).following(this.start);
        this.end = (k != -1 ? k : i);
      }
      break;
    case 5: 
    case 6: 
      this.start = 0;
      this.end = i;
    }
    this.start = Math.max(0, Math.min(this.start, i));
    this.end = Math.max(this.start, Math.min(this.end, i));
  }
  
  private long FindAttribute(int paramInt, WinVariant paramWinVariant, boolean paramBoolean)
  {
    System.err.println("FindAttribute NOT IMPLEMENTED");
    return 0L;
  }
  
  private long FindText(String paramString, boolean paramBoolean1, boolean paramBoolean2)
  {
    if (paramString == null) {
      return 0L;
    }
    String str1 = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
    if (str1 == null) {
      return 0L;
    }
    String str2 = str1.substring(this.start, this.end);
    if (paramBoolean2)
    {
      str2 = str2.toLowerCase();
      paramString = paramString.toLowerCase();
    }
    int i = -1;
    if (paramBoolean1) {
      i = str2.lastIndexOf(paramString);
    } else {
      i = str2.indexOf(paramString);
    }
    if (i == -1) {
      return 0L;
    }
    WinTextRangeProvider localWinTextRangeProvider = new WinTextRangeProvider(this.accessible);
    localWinTextRangeProvider.setRange(this.start + i, this.start + i + paramString.length());
    return localWinTextRangeProvider.getNativeProvider();
  }
  
  private WinVariant GetAttributeValue(int paramInt)
  {
    WinVariant localWinVariant = null;
    Font localFont;
    boolean bool;
    switch (paramInt)
    {
    case 40005: 
      localFont = (Font)getAttribute(AccessibleAttribute.FONT, new Object[0]);
      if (localFont != null)
      {
        localWinVariant = new WinVariant();
        localWinVariant.vt = 8;
        localWinVariant.bstrVal = localFont.getName();
      }
      break;
    case 40006: 
      localFont = (Font)getAttribute(AccessibleAttribute.FONT, new Object[0]);
      if (localFont != null)
      {
        localWinVariant = new WinVariant();
        localWinVariant.vt = 5;
        localWinVariant.dblVal = localFont.getSize();
      }
      break;
    case 40007: 
      localFont = (Font)getAttribute(AccessibleAttribute.FONT, new Object[0]);
      if (localFont != null)
      {
        bool = localFont.getStyle().toLowerCase().contains("bold");
        localWinVariant = new WinVariant();
        localWinVariant.vt = 3;
        localWinVariant.lVal = (bool ? FontWeight.BOLD.getWeight() : FontWeight.NORMAL.getWeight());
      }
      break;
    case 40013: 
    case 40015: 
      localWinVariant = new WinVariant();
      localWinVariant.vt = 11;
      localWinVariant.boolVal = false;
      break;
    case 40014: 
      localFont = (Font)getAttribute(AccessibleAttribute.FONT, new Object[0]);
      if (localFont != null)
      {
        bool = localFont.getStyle().toLowerCase().contains("italic");
        localWinVariant = new WinVariant();
        localWinVariant.vt = 11;
        localWinVariant.boolVal = bool;
      }
      break;
    }
    return localWinVariant;
  }
  
  private double[] GetBoundingRectangles()
  {
    String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
    if (str == null) {
      return null;
    }
    int i = str.length();
    if (i == 0) {
      return new double[0];
    }
    int j = this.end;
    if ((j > 0) && (j > this.start) && (str.charAt(j - 1) == '\n')) {
      j--;
    }
    if ((j > 0) && (j > this.start) && (str.charAt(j - 1) == '\r')) {
      j--;
    }
    if ((j > 0) && (j > this.start) && (j == i)) {
      j--;
    }
    Bounds[] arrayOfBounds = (Bounds[])getAttribute(AccessibleAttribute.BOUNDS_FOR_RANGE, new Object[] { Integer.valueOf(this.start), Integer.valueOf(j) });
    if (arrayOfBounds != null)
    {
      double[] arrayOfDouble = new double[arrayOfBounds.length * 4];
      int k = 0;
      for (int m = 0; m < arrayOfBounds.length; m++)
      {
        Bounds localBounds = arrayOfBounds[m];
        arrayOfDouble[(k++)] = localBounds.getMinX();
        arrayOfDouble[(k++)] = localBounds.getMinY();
        arrayOfDouble[(k++)] = localBounds.getWidth();
        arrayOfDouble[(k++)] = localBounds.getHeight();
      }
      return arrayOfDouble;
    }
    return null;
  }
  
  private long GetEnclosingElement()
  {
    return this.accessible.getNativeAccessible();
  }
  
  private String GetText(int paramInt)
  {
    String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
    if (str == null) {
      return null;
    }
    int i = paramInt != -1 ? Math.min(this.end, this.start + paramInt) : this.end;
    return str.substring(this.start, i);
  }
  
  private int Move(int paramInt1, int paramInt2)
  {
    if (paramInt2 == 0) {
      return 0;
    }
    String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
    if (str == null) {
      return 0;
    }
    int i = str.length();
    if (i == 0) {
      return 0;
    }
    int j = 0;
    Object localObject;
    int m;
    switch (paramInt1)
    {
    case 0: 
      int k = this.start;
      this.start = Math.max(0, Math.min(this.start + paramInt2, i - 1));
      this.end = (this.start + 1);
      j = this.start - k;
      break;
    case 1: 
    case 2: 
      localObject = BreakIterator.getWordInstance();
      ((BreakIterator)localObject).setText(str);
      for (m = this.start; !isWordStart((BreakIterator)localObject, str, m); m = ((BreakIterator)localObject).preceding(this.start)) {}
      while ((m != -1) && (j != paramInt2)) {
        if (paramInt2 > 0)
        {
          for (m = ((BreakIterator)localObject).following(m); !isWordStart((BreakIterator)localObject, str, m); m = ((BreakIterator)localObject).next()) {}
          j++;
        }
        else
        {
          for (m = ((BreakIterator)localObject).preceding(m); !isWordStart((BreakIterator)localObject, str, m); m = ((BreakIterator)localObject).previous()) {}
          j--;
        }
      }
      if (j != 0)
      {
        if (m != -1) {
          this.start = m;
        } else {
          this.start = (paramInt2 > 0 ? i : 0);
        }
        for (m = ((BreakIterator)localObject).following(this.start); !isWordStart((BreakIterator)localObject, str, m); m = ((BreakIterator)localObject).next()) {}
        this.end = (m != -1 ? m : i);
      }
      break;
    case 3: 
      localObject = (Integer)getAttribute(AccessibleAttribute.LINE_FOR_OFFSET, new Object[] { Integer.valueOf(this.start) });
      if (localObject == null) {
        return 0;
      }
      m = paramInt2 > 0 ? 1 : -1;
      while (paramInt2 != j)
      {
        if (getAttribute(AccessibleAttribute.LINE_START, new Object[] { Integer.valueOf(((Integer)localObject).intValue() + m) }) == null) {
          break;
        }
        localObject = Integer.valueOf(((Integer)localObject).intValue() + m);
        j += m;
      }
      if (j != 0)
      {
        Integer localInteger1 = (Integer)getAttribute(AccessibleAttribute.LINE_START, new Object[] { localObject });
        Integer localInteger2 = (Integer)getAttribute(AccessibleAttribute.LINE_END, new Object[] { localObject });
        if ((localInteger1 == null) || (localInteger2 == null)) {
          return 0;
        }
        this.start = localInteger1.intValue();
        this.end = localInteger2.intValue();
      }
      break;
    case 4: 
      localObject = BreakIterator.getSentenceInstance();
      ((BreakIterator)localObject).setText(str);
      m = ((BreakIterator)localObject).isBoundary(this.start) ? this.start : ((BreakIterator)localObject).preceding(this.start);
      while ((m != -1) && (j != paramInt2)) {
        if (paramInt2 > 0)
        {
          m = ((BreakIterator)localObject).following(m);
          j++;
        }
        else
        {
          m = ((BreakIterator)localObject).preceding(m);
          j--;
        }
      }
      if (j != 0)
      {
        this.start = (m != -1 ? m : 0);
        m = ((BreakIterator)localObject).following(this.start);
        this.end = (m != -1 ? m : i);
      }
      break;
    case 5: 
    case 6: 
      return 0;
    }
    this.start = Math.max(0, Math.min(this.start, i));
    this.end = Math.max(this.start, Math.min(this.end, i));
    return j;
  }
  
  private int MoveEndpointByUnit(int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt3 == 0) {
      return 0;
    }
    String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
    if (str == null) {
      return 0;
    }
    int i = str.length();
    int j = 0;
    int k = paramInt1 == 0 ? this.start : this.end;
    Object localObject;
    switch (paramInt2)
    {
    case 0: 
      int m = k;
      k = Math.max(0, Math.min(k + paramInt3, i));
      j = k - m;
      break;
    case 1: 
    case 2: 
      localObject = BreakIterator.getWordInstance();
      ((BreakIterator)localObject).setText(str);
      while ((k != -1) && (j != paramInt3)) {
        if (paramInt3 > 0)
        {
          for (k = ((BreakIterator)localObject).following(k); !isWordStart((BreakIterator)localObject, str, k); k = ((BreakIterator)localObject).next()) {}
          j++;
        }
        else
        {
          for (k = ((BreakIterator)localObject).preceding(k); !isWordStart((BreakIterator)localObject, str, k); k = ((BreakIterator)localObject).previous()) {}
          j--;
        }
      }
      if (k == -1) {
        k = paramInt3 > 0 ? i : 0;
      }
      break;
    case 3: 
      localObject = (Integer)getAttribute(AccessibleAttribute.LINE_FOR_OFFSET, new Object[] { Integer.valueOf(k) });
      Integer localInteger1 = (Integer)getAttribute(AccessibleAttribute.LINE_START, new Object[] { localObject });
      Integer localInteger2 = (Integer)getAttribute(AccessibleAttribute.LINE_END, new Object[] { localObject });
      if ((localObject == null) || (localInteger1 == null) || (localInteger2 == null))
      {
        k = paramInt3 > 0 ? i : 0;
      }
      else
      {
        int n = paramInt3 > 0 ? 1 : -1;
        int i1 = (paramInt3 > 0 ? localInteger2 : localInteger1).intValue();
        if (k != i1) {
          j += n;
        }
        while (paramInt3 != j)
        {
          if (getAttribute(AccessibleAttribute.LINE_START, new Object[] { Integer.valueOf(((Integer)localObject).intValue() + n) }) == null) {
            break;
          }
          localObject = Integer.valueOf(((Integer)localObject).intValue() + n);
          j += n;
        }
        if (j != 0)
        {
          localInteger1 = (Integer)getAttribute(AccessibleAttribute.LINE_START, new Object[] { localObject });
          localInteger2 = (Integer)getAttribute(AccessibleAttribute.LINE_END, new Object[] { localObject });
          if ((localInteger1 == null) || (localInteger2 == null)) {
            return 0;
          }
          k = (paramInt3 > 0 ? localInteger2 : localInteger1).intValue();
        }
      }
      break;
    case 4: 
      localObject = BreakIterator.getSentenceInstance();
      ((BreakIterator)localObject).setText(str);
      while ((k != -1) && (j != paramInt3)) {
        if (paramInt3 > 0)
        {
          k = ((BreakIterator)localObject).following(k);
          j++;
        }
        else
        {
          k = ((BreakIterator)localObject).preceding(k);
          j--;
        }
      }
      if (k == -1) {
        k = paramInt3 > 0 ? i : 0;
      }
      break;
    case 5: 
    case 6: 
      return 0;
    }
    if (paramInt1 == 0) {
      this.start = k;
    } else {
      this.end = k;
    }
    if (this.start > this.end) {
      this.start = (this.end = k);
    }
    this.start = Math.max(0, Math.min(this.start, i));
    this.end = Math.max(this.start, Math.min(this.end, i));
    return j;
  }
  
  private void MoveEndpointByRange(int paramInt1, WinTextRangeProvider paramWinTextRangeProvider, int paramInt2)
  {
    String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
    if (str == null) {
      return;
    }
    int i = str.length();
    int j = paramInt2 == 0 ? paramWinTextRangeProvider.start : paramWinTextRangeProvider.end;
    if (paramInt1 == 0) {
      this.start = j;
    } else {
      this.end = j;
    }
    if (this.start > this.end) {
      this.start = (this.end = j);
    }
    this.start = Math.max(0, Math.min(this.start, i));
    this.end = Math.max(this.start, Math.min(this.end, i));
  }
  
  private void Select()
  {
    this.accessible.executeAction(AccessibleAction.SET_TEXT_SELECTION, new Object[] { Integer.valueOf(this.start), Integer.valueOf(this.end) });
  }
  
  private void AddToSelection() {}
  
  private void RemoveFromSelection() {}
  
  private void ScrollIntoView(boolean paramBoolean)
  {
    this.accessible.executeAction(AccessibleAction.SHOW_TEXT_RANGE, new Object[] { Integer.valueOf(this.start), Integer.valueOf(this.end) });
  }
  
  private long[] GetChildren()
  {
    return new long[0];
  }
  
  static {}
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinTextRangeProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */