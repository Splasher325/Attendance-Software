package com.sun.glass.ui.win;

import com.sun.glass.ui.Menu;
import com.sun.glass.ui.MenuItem;
import com.sun.glass.ui.MenuItem.Callback;
import com.sun.glass.ui.Window;

class WinMenuImpl
{
  private long ptr = 0L;
  
  private static native void _initIDs();
  
  long getHMENU()
  {
    return this.ptr;
  }
  
  boolean create()
  {
    this.ptr = _create();
    return this.ptr != 0L;
  }
  
  void destroy()
  {
    if (this.ptr != 0L)
    {
      _destroy(this.ptr);
      this.ptr = 0L;
    }
  }
  
  boolean insertSubmenu(WinMenuDelegate paramWinMenuDelegate, int paramInt)
  {
    paramWinMenuDelegate.setParent(this);
    if (!_insertSubmenu(this.ptr, paramInt, paramWinMenuDelegate.getHMENU(), paramWinMenuDelegate.getOwner().getTitle(), paramWinMenuDelegate.getOwner().isEnabled()))
    {
      paramWinMenuDelegate.setParent(null);
      return false;
    }
    return true;
  }
  
  boolean insertItem(WinMenuItemDelegate paramWinMenuItemDelegate, int paramInt)
  {
    if (paramWinMenuItemDelegate == null) {
      return _insertSeparator(this.ptr, paramInt);
    }
    paramWinMenuItemDelegate.setParent(this);
    if (!_insertItem(this.ptr, paramInt, paramWinMenuItemDelegate.getCmdID(), paramWinMenuItemDelegate.getOwner().getTitle(), paramWinMenuItemDelegate.getOwner().isEnabled(), paramWinMenuItemDelegate.getOwner().isChecked(), paramWinMenuItemDelegate.getOwner().getCallback(), paramWinMenuItemDelegate.getOwner().getShortcutKey(), paramWinMenuItemDelegate.getOwner().getShortcutModifiers()))
    {
      paramWinMenuItemDelegate.setParent(null);
      return false;
    }
    return true;
  }
  
  boolean removeMenu(WinMenuDelegate paramWinMenuDelegate, int paramInt)
  {
    if (_removeAtPos(this.ptr, paramInt))
    {
      paramWinMenuDelegate.setParent(null);
      return true;
    }
    return false;
  }
  
  boolean removeItem(WinMenuItemDelegate paramWinMenuItemDelegate, int paramInt)
  {
    if (_removeAtPos(this.ptr, paramInt))
    {
      if (paramWinMenuItemDelegate != null) {
        paramWinMenuItemDelegate.setParent(null);
      }
      return true;
    }
    return false;
  }
  
  boolean setSubmenuTitle(WinMenuDelegate paramWinMenuDelegate, String paramString)
  {
    return _setSubmenuTitle(this.ptr, paramWinMenuDelegate.getHMENU(), paramString);
  }
  
  boolean setItemTitle(WinMenuItemDelegate paramWinMenuItemDelegate, String paramString)
  {
    return _setItemTitle(this.ptr, paramWinMenuItemDelegate.getCmdID(), paramString);
  }
  
  boolean enableSubmenu(WinMenuDelegate paramWinMenuDelegate, boolean paramBoolean)
  {
    return _enableSubmenu(this.ptr, paramWinMenuDelegate.getHMENU(), paramBoolean);
  }
  
  boolean enableItem(WinMenuItemDelegate paramWinMenuItemDelegate, boolean paramBoolean)
  {
    return _enableItem(this.ptr, paramWinMenuItemDelegate.getCmdID(), paramBoolean);
  }
  
  public boolean checkItem(WinMenuItemDelegate paramWinMenuItemDelegate, boolean paramBoolean)
  {
    return _checkItem(this.ptr, paramWinMenuItemDelegate.getCmdID(), paramBoolean);
  }
  
  private static boolean notifyCommand(Window paramWindow, int paramInt)
  {
    WinMenuItemDelegate localWinMenuItemDelegate = WinMenuItemDelegate.CommandIDManager.getHandler(paramInt);
    if (localWinMenuItemDelegate != null)
    {
      MenuItem.Callback localCallback = localWinMenuItemDelegate.getOwner().getCallback();
      if (localCallback != null)
      {
        localCallback.action();
        return true;
      }
    }
    return false;
  }
  
  private native long _create();
  
  private native void _destroy(long paramLong);
  
  private native boolean _insertItem(long paramLong, int paramInt1, int paramInt2, String paramString, boolean paramBoolean1, boolean paramBoolean2, MenuItem.Callback paramCallback, int paramInt3, int paramInt4);
  
  private native boolean _insertSubmenu(long paramLong1, int paramInt, long paramLong2, String paramString, boolean paramBoolean);
  
  private native boolean _insertSeparator(long paramLong, int paramInt);
  
  private native boolean _removeAtPos(long paramLong, int paramInt);
  
  private native boolean _setItemTitle(long paramLong, int paramInt, String paramString);
  
  private native boolean _setSubmenuTitle(long paramLong1, long paramLong2, String paramString);
  
  private native boolean _enableItem(long paramLong, int paramInt, boolean paramBoolean);
  
  private native boolean _enableSubmenu(long paramLong1, long paramLong2, boolean paramBoolean);
  
  private native boolean _checkItem(long paramLong, int paramInt, boolean paramBoolean);
  
  static {}
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\win\WinMenuImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */