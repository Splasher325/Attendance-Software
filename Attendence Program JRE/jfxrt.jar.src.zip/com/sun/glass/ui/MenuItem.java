package com.sun.glass.ui;

import com.sun.glass.ui.delegate.MenuItemDelegate;

public final class MenuItem
{
  public static final MenuItem Separator = null;
  private final MenuItemDelegate delegate;
  private String title;
  private Callback callback;
  private boolean enabled;
  private boolean checked;
  private int shortcutKey;
  private int shortcutModifiers;
  
  protected MenuItem(String paramString)
  {
    this(paramString, null);
  }
  
  protected MenuItem(String paramString, Callback paramCallback)
  {
    this(paramString, paramCallback, 0, 0);
  }
  
  protected MenuItem(String paramString, Callback paramCallback, int paramInt1, int paramInt2)
  {
    this(paramString, paramCallback, paramInt1, paramInt2, null);
  }
  
  protected MenuItem(String paramString, Callback paramCallback, int paramInt1, int paramInt2, Pixels paramPixels)
  {
    Application.checkEventThread();
    this.title = paramString;
    this.callback = paramCallback;
    this.shortcutKey = paramInt1;
    this.shortcutModifiers = paramInt2;
    this.enabled = true;
    this.checked = false;
    this.delegate = PlatformFactory.getPlatformFactory().createMenuItemDelegate(this);
    if (!this.delegate.createMenuItem(paramString, paramCallback, paramInt1, paramInt2, paramPixels, this.enabled, this.checked)) {
      throw new RuntimeException("MenuItem creation error.");
    }
  }
  
  public String getTitle()
  {
    Application.checkEventThread();
    return this.title;
  }
  
  public void setTitle(String paramString)
  {
    
    if (this.delegate.setTitle(paramString)) {
      this.title = paramString;
    }
  }
  
  public Callback getCallback()
  {
    Application.checkEventThread();
    return this.callback;
  }
  
  public void setCallback(Callback paramCallback)
  {
    
    if (this.delegate.setCallback(paramCallback)) {
      this.callback = paramCallback;
    }
  }
  
  public boolean isEnabled()
  {
    Application.checkEventThread();
    return this.enabled;
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    
    if (this.delegate.setEnabled(paramBoolean)) {
      this.enabled = paramBoolean;
    }
  }
  
  public boolean isChecked()
  {
    Application.checkEventThread();
    return this.checked;
  }
  
  public void setChecked(boolean paramBoolean)
  {
    
    if (this.delegate.setChecked(paramBoolean)) {
      this.checked = paramBoolean;
    }
  }
  
  public int getShortcutKey()
  {
    Application.checkEventThread();
    return this.shortcutKey;
  }
  
  public int getShortcutModifiers()
  {
    Application.checkEventThread();
    return this.shortcutModifiers;
  }
  
  public void setShortcut(int paramInt1, int paramInt2)
  {
    
    if (this.delegate.setShortcut(paramInt1, paramInt2))
    {
      this.shortcutKey = paramInt1;
      this.shortcutModifiers = paramInt2;
    }
  }
  
  public boolean setPixels(Pixels paramPixels)
  {
    Application.checkEventThread();
    return this.delegate.setPixels(paramPixels);
  }
  
  MenuItemDelegate getDelegate()
  {
    return this.delegate;
  }
  
  public static abstract interface Callback
  {
    public abstract void action();
    
    public abstract void validate();
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\MenuItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */