package com.sun.glass.ui;

import java.util.HashMap;

public class ClipboardAssistance
{
  private final HashMap<String, Object> cacheData = new HashMap();
  private final Clipboard clipboard;
  private int supportedActions = 1342177279;
  
  public ClipboardAssistance(String paramString)
  {
    Application.checkEventThread();
    this.clipboard = Clipboard.get(paramString);
    this.clipboard.add(this);
  }
  
  public void close()
  {
    Application.checkEventThread();
    this.clipboard.remove(this);
  }
  
  public void flush()
  {
    Application.checkEventThread();
    this.clipboard.flush(this, this.cacheData, this.supportedActions);
  }
  
  public void emptyCache()
  {
    Application.checkEventThread();
    this.cacheData.clear();
  }
  
  public boolean isCacheEmpty()
  {
    Application.checkEventThread();
    return this.cacheData.isEmpty();
  }
  
  public void setData(String paramString, Object paramObject)
  {
    Application.checkEventThread();
    this.cacheData.put(paramString, paramObject);
  }
  
  public Object getData(String paramString)
  {
    Application.checkEventThread();
    return this.clipboard.getData(paramString);
  }
  
  public void setSupportedActions(int paramInt)
  {
    Application.checkEventThread();
    this.supportedActions = paramInt;
  }
  
  public int getSupportedSourceActions()
  {
    Application.checkEventThread();
    return this.clipboard.getSupportedSourceActions();
  }
  
  public void setTargetAction(int paramInt)
  {
    Application.checkEventThread();
    this.clipboard.setTargetAction(paramInt);
  }
  
  public void contentChanged() {}
  
  public void actionPerformed(int paramInt) {}
  
  public String[] getMimeTypes()
  {
    Application.checkEventThread();
    return this.clipboard.getMimeTypes();
  }
  
  public String toString()
  {
    return "ClipboardAssistance[" + this.clipboard + "]";
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\ui\ClipboardAssistance.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */