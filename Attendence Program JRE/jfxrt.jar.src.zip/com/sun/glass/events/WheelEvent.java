package com.sun.glass.events;

public class WheelEvent {}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\events\WheelEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */