package com.sun.glass.events;

import java.io.PrintStream;

public class ViewEvent
{
  public static final int ADD = 411;
  public static final int REMOVE = 412;
  public static final int REPAINT = 421;
  public static final int RESIZE = 422;
  public static final int MOVE = 423;
  public static final int FULLSCREEN_ENTER = 431;
  public static final int FULLSCREEN_EXIT = 432;
  
  public static String getTypeString(int paramInt)
  {
    String str = "UNKNOWN";
    switch (paramInt)
    {
    case 411: 
      str = "ADD";
      break;
    case 412: 
      str = "REMOVE";
      break;
    case 421: 
      str = "REPAINT";
      break;
    case 422: 
      str = "RESIZE";
      break;
    case 423: 
      str = "MOVE";
      break;
    case 431: 
      str = "FULLSCREEN_ENTER";
      break;
    case 432: 
      str = "FULLSCREEN_EXIT";
      break;
    case 413: 
    case 414: 
    case 415: 
    case 416: 
    case 417: 
    case 418: 
    case 419: 
    case 420: 
    case 424: 
    case 425: 
    case 426: 
    case 427: 
    case 428: 
    case 429: 
    case 430: 
    default: 
      System.err.println("Unknown view event type: " + paramInt);
    }
    return str;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\events\ViewEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */