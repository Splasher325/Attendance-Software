package com.sun.glass.events;

public class GestureEvent
{
  public static final int GESTURE_STARTED = 1;
  public static final int GESTURE_PERFORMED = 2;
  public static final int GESTURE_FINISHED = 3;
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\glass\events\GestureEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */