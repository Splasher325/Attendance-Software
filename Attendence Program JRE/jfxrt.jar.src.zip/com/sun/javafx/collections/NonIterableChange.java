package com.sun.javafx.collections;

import java.util.Collections;
import java.util.List;
import javafx.collections.ListChangeListener.Change;
import javafx.collections.ObservableList;

public abstract class NonIterableChange<E>
  extends ListChangeListener.Change<E>
{
  private final int from;
  private final int to;
  private boolean invalid = true;
  private static final int[] EMPTY_PERM = new int[0];
  
  protected NonIterableChange(int paramInt1, int paramInt2, ObservableList<E> paramObservableList)
  {
    super(paramObservableList);
    this.from = paramInt1;
    this.to = paramInt2;
  }
  
  public int getFrom()
  {
    checkState();
    return this.from;
  }
  
  public int getTo()
  {
    checkState();
    return this.to;
  }
  
  protected int[] getPermutation()
  {
    checkState();
    return EMPTY_PERM;
  }
  
  public boolean next()
  {
    if (this.invalid)
    {
      this.invalid = false;
      return true;
    }
    return false;
  }
  
  public void reset()
  {
    this.invalid = true;
  }
  
  public void checkState()
  {
    if (this.invalid) {
      throw new IllegalStateException("Invalid Change state: next() must be called before inspecting the Change.");
    }
  }
  
  public String toString()
  {
    boolean bool = this.invalid;
    this.invalid = false;
    String str;
    if (wasPermutated()) {
      str = ChangeHelper.permChangeToString(getPermutation());
    } else if (wasUpdated()) {
      str = ChangeHelper.updateChangeToString(this.from, this.to);
    } else {
      str = ChangeHelper.addRemoveChangeToString(this.from, this.to, getList(), getRemoved());
    }
    this.invalid = bool;
    return "{ " + str + " }";
  }
  
  public static class GenericAddRemoveChange<E>
    extends NonIterableChange<E>
  {
    private final List<E> removed;
    
    public GenericAddRemoveChange(int paramInt1, int paramInt2, List<E> paramList, ObservableList<E> paramObservableList)
    {
      super(paramInt2, paramObservableList);
      this.removed = paramList;
    }
    
    public List<E> getRemoved()
    {
      checkState();
      return this.removed;
    }
  }
  
  public static class SimpleAddChange<E>
    extends NonIterableChange<E>
  {
    public SimpleAddChange(int paramInt1, int paramInt2, ObservableList<E> paramObservableList)
    {
      super(paramInt2, paramObservableList);
    }
    
    public boolean wasRemoved()
    {
      checkState();
      return false;
    }
    
    public List<E> getRemoved()
    {
      checkState();
      return Collections.emptyList();
    }
  }
  
  public static class SimplePermutationChange<E>
    extends NonIterableChange<E>
  {
    private final int[] permutation;
    
    public SimplePermutationChange(int paramInt1, int paramInt2, int[] paramArrayOfInt, ObservableList<E> paramObservableList)
    {
      super(paramInt2, paramObservableList);
      this.permutation = paramArrayOfInt;
    }
    
    public List<E> getRemoved()
    {
      checkState();
      return Collections.emptyList();
    }
    
    protected int[] getPermutation()
    {
      checkState();
      return this.permutation;
    }
  }
  
  public static class SimpleRemovedChange<E>
    extends NonIterableChange<E>
  {
    private final List<E> removed;
    
    public SimpleRemovedChange(int paramInt1, int paramInt2, E paramE, ObservableList<E> paramObservableList)
    {
      super(paramInt2, paramObservableList);
      this.removed = Collections.singletonList(paramE);
    }
    
    public boolean wasRemoved()
    {
      checkState();
      return true;
    }
    
    public List<E> getRemoved()
    {
      checkState();
      return this.removed;
    }
  }
  
  public static class SimpleUpdateChange<E>
    extends NonIterableChange<E>
  {
    public SimpleUpdateChange(int paramInt, ObservableList<E> paramObservableList)
    {
      this(paramInt, paramInt + 1, paramObservableList);
    }
    
    public SimpleUpdateChange(int paramInt1, int paramInt2, ObservableList<E> paramObservableList)
    {
      super(paramInt2, paramObservableList);
    }
    
    public List<E> getRemoved()
    {
      return Collections.emptyList();
    }
    
    public boolean wasUpdated()
    {
      return true;
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\collections\NonIterableChange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */