package com.sun.javafx.collections;

import java.util.AbstractList;
import java.util.List;
import javafx.collections.ListChangeListener.Change;
import javafx.collections.ObservableList;

public final class MappingChange<E, F>
  extends ListChangeListener.Change<F>
{
  private final Map<E, F> map;
  private final ListChangeListener.Change<? extends E> original;
  private List<F> removed;
  public static final Map NOOP_MAP = new Map()
  {
    public Object map(Object paramAnonymousObject)
    {
      return paramAnonymousObject;
    }
  };
  
  public MappingChange(ListChangeListener.Change<? extends E> paramChange, Map<E, F> paramMap, ObservableList<F> paramObservableList)
  {
    super(paramObservableList);
    this.original = paramChange;
    this.map = paramMap;
  }
  
  public boolean next()
  {
    return this.original.next();
  }
  
  public void reset()
  {
    this.original.reset();
  }
  
  public int getFrom()
  {
    return this.original.getFrom();
  }
  
  public int getTo()
  {
    return this.original.getTo();
  }
  
  public List<F> getRemoved()
  {
    if (this.removed == null) {
      this.removed = new AbstractList()
      {
        public F get(int paramAnonymousInt)
        {
          return (F)MappingChange.this.map.map(MappingChange.this.original.getRemoved().get(paramAnonymousInt));
        }
        
        public int size()
        {
          return MappingChange.this.original.getRemovedSize();
        }
      };
    }
    return this.removed;
  }
  
  protected int[] getPermutation()
  {
    return new int[0];
  }
  
  public boolean wasPermutated()
  {
    return this.original.wasPermutated();
  }
  
  public boolean wasUpdated()
  {
    return this.original.wasUpdated();
  }
  
  public int getPermutation(int paramInt)
  {
    return this.original.getPermutation(paramInt);
  }
  
  public String toString()
  {
    for (int i = 0; next(); i++) {}
    int j = 0;
    reset();
    while (next()) {
      j++;
    }
    reset();
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("{ ");
    int k = 0;
    while (next())
    {
      if (wasPermutated()) {
        localStringBuilder.append(ChangeHelper.permChangeToString(getPermutation()));
      } else if (wasUpdated()) {
        localStringBuilder.append(ChangeHelper.updateChangeToString(getFrom(), getTo()));
      } else {
        localStringBuilder.append(ChangeHelper.addRemoveChangeToString(getFrom(), getTo(), getList(), getRemoved()));
      }
      if (k != j) {
        localStringBuilder.append(", ");
      }
    }
    localStringBuilder.append(" }");
    reset();
    k = j - i;
    while (k-- > 0) {
      next();
    }
    return localStringBuilder.toString();
  }
  
  public static abstract interface Map<E, F>
  {
    public abstract F map(E paramE);
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\collections\MappingChange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */