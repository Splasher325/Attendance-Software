package com.sun.javafx.collections;

import com.sun.javafx.binding.ExpressionHelperBase;
import java.util.Arrays;
import javafx.beans.InvalidationListener;
import javafx.collections.ArrayChangeListener;
import javafx.collections.ObservableArray;

public abstract class ArrayListenerHelper<T extends ObservableArray<T>>
  extends ExpressionHelperBase
{
  protected final T observable;
  
  public static <T extends ObservableArray<T>> ArrayListenerHelper addListener(ArrayListenerHelper paramArrayListenerHelper, T paramT, InvalidationListener paramInvalidationListener)
  {
    if (paramInvalidationListener == null) {
      throw new NullPointerException();
    }
    return paramArrayListenerHelper == null ? new SingleInvalidation(paramT, paramInvalidationListener, null) : paramArrayListenerHelper.addListener(paramInvalidationListener);
  }
  
  public static ArrayListenerHelper removeListener(ArrayListenerHelper paramArrayListenerHelper, InvalidationListener paramInvalidationListener)
  {
    if (paramInvalidationListener == null) {
      throw new NullPointerException();
    }
    return paramArrayListenerHelper == null ? null : paramArrayListenerHelper.removeListener(paramInvalidationListener);
  }
  
  public static <T extends ObservableArray<T>> ArrayListenerHelper addListener(ArrayListenerHelper paramArrayListenerHelper, T paramT, ArrayChangeListener paramArrayChangeListener)
  {
    if (paramArrayChangeListener == null) {
      throw new NullPointerException();
    }
    return paramArrayListenerHelper == null ? new SingleChange(paramT, paramArrayChangeListener, null) : paramArrayListenerHelper.addListener(paramArrayChangeListener);
  }
  
  public static ArrayListenerHelper removeListener(ArrayListenerHelper paramArrayListenerHelper, ArrayChangeListener paramArrayChangeListener)
  {
    if (paramArrayChangeListener == null) {
      throw new NullPointerException();
    }
    return paramArrayListenerHelper == null ? null : paramArrayListenerHelper.removeListener(paramArrayChangeListener);
  }
  
  public static void fireValueChangedEvent(ArrayListenerHelper paramArrayListenerHelper, boolean paramBoolean, int paramInt1, int paramInt2)
  {
    if ((paramArrayListenerHelper != null) && ((paramInt1 < paramInt2) || (paramBoolean))) {
      paramArrayListenerHelper.fireValueChangedEvent(paramBoolean, paramInt1, paramInt2);
    }
  }
  
  public static boolean hasListeners(ArrayListenerHelper paramArrayListenerHelper)
  {
    return paramArrayListenerHelper != null;
  }
  
  public ArrayListenerHelper(T paramT)
  {
    this.observable = paramT;
  }
  
  protected abstract ArrayListenerHelper addListener(InvalidationListener paramInvalidationListener);
  
  protected abstract ArrayListenerHelper removeListener(InvalidationListener paramInvalidationListener);
  
  protected abstract ArrayListenerHelper addListener(ArrayChangeListener<T> paramArrayChangeListener);
  
  protected abstract ArrayListenerHelper removeListener(ArrayChangeListener<T> paramArrayChangeListener);
  
  protected abstract void fireValueChangedEvent(boolean paramBoolean, int paramInt1, int paramInt2);
  
  private static class Generic<T extends ObservableArray<T>>
    extends ArrayListenerHelper<T>
  {
    private InvalidationListener[] invalidationListeners;
    private ArrayChangeListener[] changeListeners;
    private int invalidationSize;
    private int changeSize;
    private boolean locked;
    
    private Generic(T paramT, InvalidationListener paramInvalidationListener1, InvalidationListener paramInvalidationListener2)
    {
      super();
      this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener1, paramInvalidationListener2 };
      this.invalidationSize = 2;
    }
    
    private Generic(T paramT, ArrayChangeListener paramArrayChangeListener1, ArrayChangeListener paramArrayChangeListener2)
    {
      super();
      this.changeListeners = new ArrayChangeListener[] { paramArrayChangeListener1, paramArrayChangeListener2 };
      this.changeSize = 2;
    }
    
    private Generic(T paramT, InvalidationListener paramInvalidationListener, ArrayChangeListener paramArrayChangeListener)
    {
      super();
      this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener };
      this.invalidationSize = 1;
      this.changeListeners = new ArrayChangeListener[] { paramArrayChangeListener };
      this.changeSize = 1;
    }
    
    protected Generic addListener(InvalidationListener paramInvalidationListener)
    {
      if (this.invalidationListeners == null)
      {
        this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener };
        this.invalidationSize = 1;
      }
      else
      {
        int i = this.invalidationListeners.length;
        int j;
        if (this.locked)
        {
          j = this.invalidationSize < i ? i : i * 3 / 2 + 1;
          this.invalidationListeners = ((InvalidationListener[])Arrays.copyOf(this.invalidationListeners, j));
        }
        else if (this.invalidationSize == i)
        {
          this.invalidationSize = trim(this.invalidationSize, this.invalidationListeners);
          if (this.invalidationSize == i)
          {
            j = i * 3 / 2 + 1;
            this.invalidationListeners = ((InvalidationListener[])Arrays.copyOf(this.invalidationListeners, j));
          }
        }
        this.invalidationListeners[(this.invalidationSize++)] = paramInvalidationListener;
      }
      return this;
    }
    
    protected ArrayListenerHelper removeListener(InvalidationListener paramInvalidationListener)
    {
      if (this.invalidationListeners != null) {
        for (int i = 0; i < this.invalidationSize; i++) {
          if (paramInvalidationListener.equals(this.invalidationListeners[i]))
          {
            if (this.invalidationSize == 1)
            {
              if (this.changeSize == 1) {
                return new ArrayListenerHelper.SingleChange(this.observable, this.changeListeners[0], null);
              }
              this.invalidationListeners = null;
              this.invalidationSize = 0;
              break;
            }
            if ((this.invalidationSize == 2) && (this.changeSize == 0)) {
              return new ArrayListenerHelper.SingleInvalidation(this.observable, this.invalidationListeners[(1 - i)], null);
            }
            int j = this.invalidationSize - i - 1;
            InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
            if (this.locked)
            {
              this.invalidationListeners = new InvalidationListener[this.invalidationListeners.length];
              System.arraycopy(arrayOfInvalidationListener, 0, this.invalidationListeners, 0, i + 1);
            }
            if (j > 0) {
              System.arraycopy(arrayOfInvalidationListener, i + 1, this.invalidationListeners, i, j);
            }
            this.invalidationSize -= 1;
            if (!this.locked) {
              this.invalidationListeners[this.invalidationSize] = null;
            }
            break;
          }
        }
      }
      return this;
    }
    
    protected ArrayListenerHelper addListener(ArrayChangeListener<T> paramArrayChangeListener)
    {
      if (this.changeListeners == null)
      {
        this.changeListeners = new ArrayChangeListener[] { paramArrayChangeListener };
        this.changeSize = 1;
      }
      else
      {
        int i = this.changeListeners.length;
        int j;
        if (this.locked)
        {
          j = this.changeSize < i ? i : i * 3 / 2 + 1;
          this.changeListeners = ((ArrayChangeListener[])Arrays.copyOf(this.changeListeners, j));
        }
        else if (this.changeSize == i)
        {
          this.changeSize = trim(this.changeSize, this.changeListeners);
          if (this.changeSize == i)
          {
            j = i * 3 / 2 + 1;
            this.changeListeners = ((ArrayChangeListener[])Arrays.copyOf(this.changeListeners, j));
          }
        }
        this.changeListeners[(this.changeSize++)] = paramArrayChangeListener;
      }
      return this;
    }
    
    protected ArrayListenerHelper removeListener(ArrayChangeListener<T> paramArrayChangeListener)
    {
      if (this.changeListeners != null) {
        for (int i = 0; i < this.changeSize; i++) {
          if (paramArrayChangeListener.equals(this.changeListeners[i]))
          {
            if (this.changeSize == 1)
            {
              if (this.invalidationSize == 1) {
                return new ArrayListenerHelper.SingleInvalidation(this.observable, this.invalidationListeners[0], null);
              }
              this.changeListeners = null;
              this.changeSize = 0;
              break;
            }
            if ((this.changeSize == 2) && (this.invalidationSize == 0)) {
              return new ArrayListenerHelper.SingleChange(this.observable, this.changeListeners[(1 - i)], null);
            }
            int j = this.changeSize - i - 1;
            ArrayChangeListener[] arrayOfArrayChangeListener = this.changeListeners;
            if (this.locked)
            {
              this.changeListeners = new ArrayChangeListener[this.changeListeners.length];
              System.arraycopy(arrayOfArrayChangeListener, 0, this.changeListeners, 0, i + 1);
            }
            if (j > 0) {
              System.arraycopy(arrayOfArrayChangeListener, i + 1, this.changeListeners, i, j);
            }
            this.changeSize -= 1;
            if (!this.locked) {
              this.changeListeners[this.changeSize] = null;
            }
            break;
          }
        }
      }
      return this;
    }
    
    protected void fireValueChangedEvent(boolean paramBoolean, int paramInt1, int paramInt2)
    {
      InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
      int i = this.invalidationSize;
      ArrayChangeListener[] arrayOfArrayChangeListener = this.changeListeners;
      int j = this.changeSize;
      try
      {
        this.locked = true;
        for (int k = 0; k < i; k++) {
          try
          {
            arrayOfInvalidationListener[k].invalidated(this.observable);
          }
          catch (Exception localException1)
          {
            Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), localException1);
          }
        }
        for (k = 0; k < j; k++) {
          try
          {
            arrayOfArrayChangeListener[k].onChanged(this.observable, paramBoolean, paramInt1, paramInt2);
          }
          catch (Exception localException2)
          {
            Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), localException2);
          }
        }
      }
      finally
      {
        this.locked = false;
      }
    }
  }
  
  private static class SingleChange<T extends ObservableArray<T>>
    extends ArrayListenerHelper<T>
  {
    private final ArrayChangeListener listener;
    
    private SingleChange(T paramT, ArrayChangeListener paramArrayChangeListener)
    {
      super();
      this.listener = paramArrayChangeListener;
    }
    
    protected ArrayListenerHelper addListener(InvalidationListener paramInvalidationListener)
    {
      return new ArrayListenerHelper.Generic(this.observable, paramInvalidationListener, this.listener, null);
    }
    
    protected ArrayListenerHelper removeListener(InvalidationListener paramInvalidationListener)
    {
      return this;
    }
    
    protected ArrayListenerHelper addListener(ArrayChangeListener paramArrayChangeListener)
    {
      return new ArrayListenerHelper.Generic(this.observable, this.listener, paramArrayChangeListener, null);
    }
    
    protected ArrayListenerHelper removeListener(ArrayChangeListener paramArrayChangeListener)
    {
      return paramArrayChangeListener.equals(this.listener) ? null : this;
    }
    
    protected void fireValueChangedEvent(boolean paramBoolean, int paramInt1, int paramInt2)
    {
      try
      {
        this.listener.onChanged(this.observable, paramBoolean, paramInt1, paramInt2);
      }
      catch (Exception localException)
      {
        Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), localException);
      }
    }
  }
  
  private static class SingleInvalidation<T extends ObservableArray<T>>
    extends ArrayListenerHelper<T>
  {
    private final InvalidationListener listener;
    
    private SingleInvalidation(T paramT, InvalidationListener paramInvalidationListener)
    {
      super();
      this.listener = paramInvalidationListener;
    }
    
    protected ArrayListenerHelper addListener(InvalidationListener paramInvalidationListener)
    {
      return new ArrayListenerHelper.Generic(this.observable, this.listener, paramInvalidationListener, null);
    }
    
    protected ArrayListenerHelper removeListener(InvalidationListener paramInvalidationListener)
    {
      return paramInvalidationListener.equals(this.listener) ? null : this;
    }
    
    protected ArrayListenerHelper addListener(ArrayChangeListener paramArrayChangeListener)
    {
      return new ArrayListenerHelper.Generic(this.observable, this.listener, paramArrayChangeListener, null);
    }
    
    protected ArrayListenerHelper removeListener(ArrayChangeListener paramArrayChangeListener)
    {
      return this;
    }
    
    protected void fireValueChangedEvent(boolean paramBoolean, int paramInt1, int paramInt2)
    {
      try
      {
        this.listener.invalidated(this.observable);
      }
      catch (Exception localException)
      {
        Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), localException);
      }
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\collections\ArrayListenerHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */