package com.sun.javafx.collections;

import java.util.IdentityHashMap;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.collections.ObservableListBase;
import javafx.util.Callback;

final class ElementObserver<E>
{
  private Callback<E, Observable[]> extractor;
  private final Callback<E, InvalidationListener> listenerGenerator;
  private final ObservableListBase<E> list;
  private IdentityHashMap<E, ElementsMapElement> elementsMap = new IdentityHashMap();
  
  ElementObserver(Callback<E, Observable[]> paramCallback, Callback<E, InvalidationListener> paramCallback1, ObservableListBase<E> paramObservableListBase)
  {
    this.extractor = paramCallback;
    this.listenerGenerator = paramCallback1;
    this.list = paramObservableListBase;
  }
  
  void attachListener(E paramE)
  {
    if ((this.elementsMap != null) && (paramE != null)) {
      if (this.elementsMap.containsKey(paramE))
      {
        ((ElementsMapElement)this.elementsMap.get(paramE)).increment();
      }
      else
      {
        InvalidationListener localInvalidationListener = (InvalidationListener)this.listenerGenerator.call(paramE);
        for (Observable localObservable : (Observable[])this.extractor.call(paramE)) {
          localObservable.addListener(localInvalidationListener);
        }
        this.elementsMap.put(paramE, new ElementsMapElement(localInvalidationListener));
      }
    }
  }
  
  void detachListener(E paramE)
  {
    if ((this.elementsMap != null) && (paramE != null))
    {
      ElementsMapElement localElementsMapElement = (ElementsMapElement)this.elementsMap.get(paramE);
      for (Observable localObservable : (Observable[])this.extractor.call(paramE)) {
        localObservable.removeListener(localElementsMapElement.getListener());
      }
      if (localElementsMapElement.decrement() == 0) {
        this.elementsMap.remove(paramE);
      }
    }
  }
  
  private static class ElementsMapElement
  {
    InvalidationListener listener;
    int counter;
    
    public ElementsMapElement(InvalidationListener paramInvalidationListener)
    {
      this.listener = paramInvalidationListener;
      this.counter = 1;
    }
    
    public void increment()
    {
      this.counter += 1;
    }
    
    public int decrement()
    {
      return --this.counter;
    }
    
    private InvalidationListener getListener()
    {
      return this.listener;
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\collections\ElementObserver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */