package com.sun.javafx.collections;

import java.util.Arrays;
import java.util.List;

public class ChangeHelper
{
  public static String addRemoveChangeToString(int paramInt1, int paramInt2, List<?> paramList1, List<?> paramList2)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if (paramList2.isEmpty())
    {
      localStringBuilder.append(paramList1.subList(paramInt1, paramInt2));
      localStringBuilder.append(" added at ").append(paramInt1);
    }
    else
    {
      localStringBuilder.append(paramList2);
      if (paramInt1 == paramInt2)
      {
        localStringBuilder.append(" removed at ").append(paramInt1);
      }
      else
      {
        localStringBuilder.append(" replaced by ");
        localStringBuilder.append(paramList1.subList(paramInt1, paramInt2));
        localStringBuilder.append(" at ").append(paramInt1);
      }
    }
    return localStringBuilder.toString();
  }
  
  public static String permChangeToString(int[] paramArrayOfInt)
  {
    return "permutated by " + Arrays.toString(paramArrayOfInt);
  }
  
  public static String updateChangeToString(int paramInt1, int paramInt2)
  {
    return "updated at range [" + paramInt1 + ", " + paramInt2 + ")";
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\collections\ChangeHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */