package com.sun.javafx.collections;

import javafx.collections.MapChangeListener.Change;
import javafx.collections.ObservableMap;

public class MapAdapterChange<K, V>
  extends MapChangeListener.Change<K, V>
{
  private final MapChangeListener.Change<? extends K, ? extends V> change;
  
  public MapAdapterChange(ObservableMap<K, V> paramObservableMap, MapChangeListener.Change<? extends K, ? extends V> paramChange)
  {
    super(paramObservableMap);
    this.change = paramChange;
  }
  
  public boolean wasAdded()
  {
    return this.change.wasAdded();
  }
  
  public boolean wasRemoved()
  {
    return this.change.wasRemoved();
  }
  
  public K getKey()
  {
    return (K)this.change.getKey();
  }
  
  public V getValueAdded()
  {
    return (V)this.change.getValueAdded();
  }
  
  public V getValueRemoved()
  {
    return (V)this.change.getValueRemoved();
  }
  
  public String toString()
  {
    return this.change.toString();
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\collections\MapAdapterChange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */