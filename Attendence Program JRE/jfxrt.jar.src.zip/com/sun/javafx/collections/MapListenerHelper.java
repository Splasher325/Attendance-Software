package com.sun.javafx.collections;

import com.sun.javafx.binding.ExpressionHelperBase;
import java.util.Arrays;
import javafx.beans.InvalidationListener;
import javafx.collections.MapChangeListener;
import javafx.collections.MapChangeListener.Change;

public abstract class MapListenerHelper<K, V>
  extends ExpressionHelperBase
{
  public static <K, V> MapListenerHelper<K, V> addListener(MapListenerHelper<K, V> paramMapListenerHelper, InvalidationListener paramInvalidationListener)
  {
    if (paramInvalidationListener == null) {
      throw new NullPointerException();
    }
    return paramMapListenerHelper == null ? new SingleInvalidation(paramInvalidationListener, null) : paramMapListenerHelper.addListener(paramInvalidationListener);
  }
  
  public static <K, V> MapListenerHelper<K, V> removeListener(MapListenerHelper<K, V> paramMapListenerHelper, InvalidationListener paramInvalidationListener)
  {
    if (paramInvalidationListener == null) {
      throw new NullPointerException();
    }
    return paramMapListenerHelper == null ? null : paramMapListenerHelper.removeListener(paramInvalidationListener);
  }
  
  public static <K, V> MapListenerHelper<K, V> addListener(MapListenerHelper<K, V> paramMapListenerHelper, MapChangeListener<? super K, ? super V> paramMapChangeListener)
  {
    if (paramMapChangeListener == null) {
      throw new NullPointerException();
    }
    return paramMapListenerHelper == null ? new SingleChange(paramMapChangeListener, null) : paramMapListenerHelper.addListener(paramMapChangeListener);
  }
  
  public static <K, V> MapListenerHelper<K, V> removeListener(MapListenerHelper<K, V> paramMapListenerHelper, MapChangeListener<? super K, ? super V> paramMapChangeListener)
  {
    if (paramMapChangeListener == null) {
      throw new NullPointerException();
    }
    return paramMapListenerHelper == null ? null : paramMapListenerHelper.removeListener(paramMapChangeListener);
  }
  
  public static <K, V> void fireValueChangedEvent(MapListenerHelper<K, V> paramMapListenerHelper, MapChangeListener.Change<? extends K, ? extends V> paramChange)
  {
    if (paramMapListenerHelper != null) {
      paramMapListenerHelper.fireValueChangedEvent(paramChange);
    }
  }
  
  public static <K, V> boolean hasListeners(MapListenerHelper<K, V> paramMapListenerHelper)
  {
    return paramMapListenerHelper != null;
  }
  
  protected abstract MapListenerHelper<K, V> addListener(InvalidationListener paramInvalidationListener);
  
  protected abstract MapListenerHelper<K, V> removeListener(InvalidationListener paramInvalidationListener);
  
  protected abstract MapListenerHelper<K, V> addListener(MapChangeListener<? super K, ? super V> paramMapChangeListener);
  
  protected abstract MapListenerHelper<K, V> removeListener(MapChangeListener<? super K, ? super V> paramMapChangeListener);
  
  protected abstract void fireValueChangedEvent(MapChangeListener.Change<? extends K, ? extends V> paramChange);
  
  private static class Generic<K, V>
    extends MapListenerHelper<K, V>
  {
    private InvalidationListener[] invalidationListeners;
    private MapChangeListener<? super K, ? super V>[] changeListeners;
    private int invalidationSize;
    private int changeSize;
    private boolean locked;
    
    private Generic(InvalidationListener paramInvalidationListener1, InvalidationListener paramInvalidationListener2)
    {
      this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener1, paramInvalidationListener2 };
      this.invalidationSize = 2;
    }
    
    private Generic(MapChangeListener<? super K, ? super V> paramMapChangeListener1, MapChangeListener<? super K, ? super V> paramMapChangeListener2)
    {
      this.changeListeners = new MapChangeListener[] { paramMapChangeListener1, paramMapChangeListener2 };
      this.changeSize = 2;
    }
    
    private Generic(InvalidationListener paramInvalidationListener, MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener };
      this.invalidationSize = 1;
      this.changeListeners = new MapChangeListener[] { paramMapChangeListener };
      this.changeSize = 1;
    }
    
    protected Generic<K, V> addListener(InvalidationListener paramInvalidationListener)
    {
      if (this.invalidationListeners == null)
      {
        this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener };
        this.invalidationSize = 1;
      }
      else
      {
        int i = this.invalidationListeners.length;
        int j;
        if (this.locked)
        {
          j = this.invalidationSize < i ? i : i * 3 / 2 + 1;
          this.invalidationListeners = ((InvalidationListener[])Arrays.copyOf(this.invalidationListeners, j));
        }
        else if (this.invalidationSize == i)
        {
          this.invalidationSize = trim(this.invalidationSize, this.invalidationListeners);
          if (this.invalidationSize == i)
          {
            j = i * 3 / 2 + 1;
            this.invalidationListeners = ((InvalidationListener[])Arrays.copyOf(this.invalidationListeners, j));
          }
        }
        this.invalidationListeners[(this.invalidationSize++)] = paramInvalidationListener;
      }
      return this;
    }
    
    protected MapListenerHelper<K, V> removeListener(InvalidationListener paramInvalidationListener)
    {
      if (this.invalidationListeners != null) {
        for (int i = 0; i < this.invalidationSize; i++) {
          if (paramInvalidationListener.equals(this.invalidationListeners[i]))
          {
            if (this.invalidationSize == 1)
            {
              if (this.changeSize == 1) {
                return new MapListenerHelper.SingleChange(this.changeListeners[0], null);
              }
              this.invalidationListeners = null;
              this.invalidationSize = 0;
              break;
            }
            if ((this.invalidationSize == 2) && (this.changeSize == 0)) {
              return new MapListenerHelper.SingleInvalidation(this.invalidationListeners[(1 - i)], null);
            }
            int j = this.invalidationSize - i - 1;
            InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
            if (this.locked)
            {
              this.invalidationListeners = new InvalidationListener[this.invalidationListeners.length];
              System.arraycopy(arrayOfInvalidationListener, 0, this.invalidationListeners, 0, i);
            }
            if (j > 0) {
              System.arraycopy(arrayOfInvalidationListener, i + 1, this.invalidationListeners, i, j);
            }
            this.invalidationSize -= 1;
            if (!this.locked) {
              this.invalidationListeners[this.invalidationSize] = null;
            }
            break;
          }
        }
      }
      return this;
    }
    
    protected MapListenerHelper<K, V> addListener(MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      if (this.changeListeners == null)
      {
        this.changeListeners = new MapChangeListener[] { paramMapChangeListener };
        this.changeSize = 1;
      }
      else
      {
        int i = this.changeListeners.length;
        int j;
        if (this.locked)
        {
          j = this.changeSize < i ? i : i * 3 / 2 + 1;
          this.changeListeners = ((MapChangeListener[])Arrays.copyOf(this.changeListeners, j));
        }
        else if (this.changeSize == i)
        {
          this.changeSize = trim(this.changeSize, this.changeListeners);
          if (this.changeSize == i)
          {
            j = i * 3 / 2 + 1;
            this.changeListeners = ((MapChangeListener[])Arrays.copyOf(this.changeListeners, j));
          }
        }
        this.changeListeners[(this.changeSize++)] = paramMapChangeListener;
      }
      return this;
    }
    
    protected MapListenerHelper<K, V> removeListener(MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      if (this.changeListeners != null) {
        for (int i = 0; i < this.changeSize; i++) {
          if (paramMapChangeListener.equals(this.changeListeners[i]))
          {
            if (this.changeSize == 1)
            {
              if (this.invalidationSize == 1) {
                return new MapListenerHelper.SingleInvalidation(this.invalidationListeners[0], null);
              }
              this.changeListeners = null;
              this.changeSize = 0;
              break;
            }
            if ((this.changeSize == 2) && (this.invalidationSize == 0)) {
              return new MapListenerHelper.SingleChange(this.changeListeners[(1 - i)], null);
            }
            int j = this.changeSize - i - 1;
            MapChangeListener[] arrayOfMapChangeListener = this.changeListeners;
            if (this.locked)
            {
              this.changeListeners = new MapChangeListener[this.changeListeners.length];
              System.arraycopy(arrayOfMapChangeListener, 0, this.changeListeners, 0, i);
            }
            if (j > 0) {
              System.arraycopy(arrayOfMapChangeListener, i + 1, this.changeListeners, i, j);
            }
            this.changeSize -= 1;
            if (!this.locked) {
              this.changeListeners[this.changeSize] = null;
            }
            break;
          }
        }
      }
      return this;
    }
    
    protected void fireValueChangedEvent(MapChangeListener.Change<? extends K, ? extends V> paramChange)
    {
      InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
      int i = this.invalidationSize;
      MapChangeListener[] arrayOfMapChangeListener = this.changeListeners;
      int j = this.changeSize;
      try
      {
        this.locked = true;
        for (int k = 0; k < i; k++) {
          try
          {
            arrayOfInvalidationListener[k].invalidated(paramChange.getMap());
          }
          catch (Exception localException1)
          {
            Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), localException1);
          }
        }
        for (k = 0; k < j; k++) {
          try
          {
            arrayOfMapChangeListener[k].onChanged(paramChange);
          }
          catch (Exception localException2)
          {
            Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), localException2);
          }
        }
      }
      finally
      {
        this.locked = false;
      }
    }
  }
  
  private static class SingleChange<K, V>
    extends MapListenerHelper<K, V>
  {
    private final MapChangeListener<? super K, ? super V> listener;
    
    private SingleChange(MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      this.listener = paramMapChangeListener;
    }
    
    protected MapListenerHelper<K, V> addListener(InvalidationListener paramInvalidationListener)
    {
      return new MapListenerHelper.Generic(paramInvalidationListener, this.listener, null);
    }
    
    protected MapListenerHelper<K, V> removeListener(InvalidationListener paramInvalidationListener)
    {
      return this;
    }
    
    protected MapListenerHelper<K, V> addListener(MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      return new MapListenerHelper.Generic(this.listener, paramMapChangeListener, null);
    }
    
    protected MapListenerHelper<K, V> removeListener(MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      return paramMapChangeListener.equals(this.listener) ? null : this;
    }
    
    protected void fireValueChangedEvent(MapChangeListener.Change<? extends K, ? extends V> paramChange)
    {
      try
      {
        this.listener.onChanged(paramChange);
      }
      catch (Exception localException)
      {
        Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), localException);
      }
    }
  }
  
  private static class SingleInvalidation<K, V>
    extends MapListenerHelper<K, V>
  {
    private final InvalidationListener listener;
    
    private SingleInvalidation(InvalidationListener paramInvalidationListener)
    {
      this.listener = paramInvalidationListener;
    }
    
    protected MapListenerHelper<K, V> addListener(InvalidationListener paramInvalidationListener)
    {
      return new MapListenerHelper.Generic(this.listener, paramInvalidationListener, null);
    }
    
    protected MapListenerHelper<K, V> removeListener(InvalidationListener paramInvalidationListener)
    {
      return paramInvalidationListener.equals(this.listener) ? null : this;
    }
    
    protected MapListenerHelper<K, V> addListener(MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      return new MapListenerHelper.Generic(this.listener, paramMapChangeListener, null);
    }
    
    protected MapListenerHelper<K, V> removeListener(MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      return this;
    }
    
    protected void fireValueChangedEvent(MapChangeListener.Change<? extends K, ? extends V> paramChange)
    {
      try
      {
        this.listener.invalidated(paramChange.getMap());
      }
      catch (Exception localException)
      {
        Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), localException);
      }
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\collections\MapListenerHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */