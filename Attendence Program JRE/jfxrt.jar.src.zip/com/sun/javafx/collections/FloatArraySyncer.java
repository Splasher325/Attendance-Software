package com.sun.javafx.collections;

public abstract interface FloatArraySyncer
{
  public abstract float[] syncTo(float[] paramArrayOfFloat, int[] paramArrayOfInt);
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\collections\FloatArraySyncer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */