package com.sun.javafx.collections;

public abstract interface IntegerArraySyncer
{
  public abstract int[] syncTo(int[] paramArrayOfInt1, int[] paramArrayOfInt2);
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\collections\IntegerArraySyncer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */