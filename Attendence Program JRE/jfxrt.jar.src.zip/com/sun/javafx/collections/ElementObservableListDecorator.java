package com.sun.javafx.collections;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.collections.ListChangeListener;
import javafx.collections.ListChangeListener.Change;
import javafx.collections.ObservableList;
import javafx.collections.ObservableListBase;
import javafx.collections.WeakListChangeListener;
import javafx.util.Callback;

public final class ElementObservableListDecorator<E>
  extends ObservableListBase<E>
  implements ObservableList<E>
{
  private final ObservableList<E> decoratedList;
  private final ListChangeListener<E> listener;
  private ElementObserver<E> observer = new ElementObserver(paramCallback, new Callback()
  {
    public InvalidationListener call(final E paramAnonymousE)
    {
      new InvalidationListener()
      {
        public void invalidated(Observable paramAnonymous2Observable)
        {
          ElementObservableListDecorator.this.beginChange();
          int i = 0;
          if ((ElementObservableListDecorator.this.decoratedList instanceof RandomAccess))
          {
            int j = ElementObservableListDecorator.this.size();
            while (i < j)
            {
              if (ElementObservableListDecorator.this.get(i) == paramAnonymousE) {
                ElementObservableListDecorator.this.nextUpdate(i);
              }
              i++;
            }
          }
          else
          {
            Iterator localIterator = ElementObservableListDecorator.this.iterator();
            while (localIterator.hasNext())
            {
              if (localIterator.next() == paramAnonymousE) {
                ElementObservableListDecorator.this.nextUpdate(i);
              }
              i++;
            }
          }
          ElementObservableListDecorator.this.endChange();
        }
      };
    }
  }, this);
  
  public ElementObservableListDecorator(ObservableList<E> paramObservableList, Callback<E, Observable[]> paramCallback)
  {
    this.decoratedList = paramObservableList;
    int i = this.decoratedList.size();
    for (int j = 0; j < i; j++) {
      this.observer.attachListener(this.decoratedList.get(j));
    }
    this.listener = new ListChangeListener()
    {
      public void onChanged(ListChangeListener.Change<? extends E> paramAnonymousChange)
      {
        while (paramAnonymousChange.next()) {
          if ((paramAnonymousChange.wasAdded()) || (paramAnonymousChange.wasRemoved()))
          {
            int i = paramAnonymousChange.getRemovedSize();
            List localList = paramAnonymousChange.getRemoved();
            for (int j = 0; j < i; j++) {
              ElementObservableListDecorator.this.observer.detachListener(localList.get(j));
            }
            if ((ElementObservableListDecorator.this.decoratedList instanceof RandomAccess))
            {
              j = paramAnonymousChange.getTo();
              for (int k = paramAnonymousChange.getFrom(); k < j; k++) {
                ElementObservableListDecorator.this.observer.attachListener(ElementObservableListDecorator.this.decoratedList.get(k));
              }
            }
            else
            {
              Iterator localIterator = paramAnonymousChange.getAddedSubList().iterator();
              while (localIterator.hasNext())
              {
                Object localObject = localIterator.next();
                ElementObservableListDecorator.this.observer.attachListener(localObject);
              }
            }
          }
        }
        paramAnonymousChange.reset();
        ElementObservableListDecorator.this.fireChange(paramAnonymousChange);
      }
    };
    this.decoratedList.addListener(new WeakListChangeListener(this.listener));
  }
  
  public <T> T[] toArray(T[] paramArrayOfT)
  {
    return this.decoratedList.toArray(paramArrayOfT);
  }
  
  public Object[] toArray()
  {
    return this.decoratedList.toArray();
  }
  
  public List<E> subList(int paramInt1, int paramInt2)
  {
    return this.decoratedList.subList(paramInt1, paramInt2);
  }
  
  public int size()
  {
    return this.decoratedList.size();
  }
  
  public E set(int paramInt, E paramE)
  {
    return (E)this.decoratedList.set(paramInt, paramE);
  }
  
  public boolean retainAll(Collection<?> paramCollection)
  {
    return this.decoratedList.retainAll(paramCollection);
  }
  
  public boolean removeAll(Collection<?> paramCollection)
  {
    return this.decoratedList.removeAll(paramCollection);
  }
  
  public E remove(int paramInt)
  {
    return (E)this.decoratedList.remove(paramInt);
  }
  
  public boolean remove(Object paramObject)
  {
    return this.decoratedList.remove(paramObject);
  }
  
  public ListIterator<E> listIterator(int paramInt)
  {
    return this.decoratedList.listIterator(paramInt);
  }
  
  public ListIterator<E> listIterator()
  {
    return this.decoratedList.listIterator();
  }
  
  public int lastIndexOf(Object paramObject)
  {
    return this.decoratedList.lastIndexOf(paramObject);
  }
  
  public Iterator<E> iterator()
  {
    return this.decoratedList.iterator();
  }
  
  public boolean isEmpty()
  {
    return this.decoratedList.isEmpty();
  }
  
  public int indexOf(Object paramObject)
  {
    return this.decoratedList.indexOf(paramObject);
  }
  
  public E get(int paramInt)
  {
    return (E)this.decoratedList.get(paramInt);
  }
  
  public boolean containsAll(Collection<?> paramCollection)
  {
    return this.decoratedList.containsAll(paramCollection);
  }
  
  public boolean contains(Object paramObject)
  {
    return this.decoratedList.contains(paramObject);
  }
  
  public void clear()
  {
    this.decoratedList.clear();
  }
  
  public boolean addAll(int paramInt, Collection<? extends E> paramCollection)
  {
    return this.decoratedList.addAll(paramInt, paramCollection);
  }
  
  public boolean addAll(Collection<? extends E> paramCollection)
  {
    return this.decoratedList.addAll(paramCollection);
  }
  
  public void add(int paramInt, E paramE)
  {
    this.decoratedList.add(paramInt, paramE);
  }
  
  public boolean add(E paramE)
  {
    return this.decoratedList.add(paramE);
  }
  
  public boolean setAll(Collection<? extends E> paramCollection)
  {
    return this.decoratedList.setAll(paramCollection);
  }
  
  public boolean setAll(E... paramVarArgs)
  {
    return this.decoratedList.setAll(paramVarArgs);
  }
  
  public boolean retainAll(E... paramVarArgs)
  {
    return this.decoratedList.retainAll(paramVarArgs);
  }
  
  public boolean removeAll(E... paramVarArgs)
  {
    return this.decoratedList.removeAll(paramVarArgs);
  }
  
  public void remove(int paramInt1, int paramInt2)
  {
    this.decoratedList.remove(paramInt1, paramInt2);
  }
  
  public boolean addAll(E... paramVarArgs)
  {
    return this.decoratedList.addAll(paramVarArgs);
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\collections\ElementObservableListDecorator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */