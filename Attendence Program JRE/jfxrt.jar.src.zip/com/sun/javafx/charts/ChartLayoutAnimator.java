package com.sun.javafx.charts;

import java.util.HashMap;
import java.util.Map;
import javafx.animation.Animation;
import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.SequentialTransition;
import javafx.animation.Timeline;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.chart.Axis;

public final class ChartLayoutAnimator
  extends AnimationTimer
  implements EventHandler<ActionEvent>
{
  private Parent nodeToLayout;
  private final Map<Object, Animation> activeTimeLines = new HashMap();
  private final boolean isAxis;
  
  public ChartLayoutAnimator(Parent paramParent)
  {
    this.nodeToLayout = paramParent;
    this.isAxis = (paramParent instanceof Axis);
  }
  
  public void handle(long paramLong)
  {
    if (this.isAxis) {
      ((Axis)this.nodeToLayout).requestAxisLayout();
    } else {
      this.nodeToLayout.requestLayout();
    }
  }
  
  public void handle(ActionEvent paramActionEvent)
  {
    this.activeTimeLines.remove(paramActionEvent.getSource());
    if (this.activeTimeLines.isEmpty()) {
      stop();
    }
    handle(0L);
  }
  
  public void stop(Object paramObject)
  {
    Animation localAnimation = (Animation)this.activeTimeLines.remove(paramObject);
    if (localAnimation != null) {
      localAnimation.stop();
    }
    if (this.activeTimeLines.isEmpty()) {
      stop();
    }
  }
  
  public Object animate(KeyFrame... paramVarArgs)
  {
    Timeline localTimeline = new Timeline();
    localTimeline.setAutoReverse(false);
    localTimeline.setCycleCount(1);
    localTimeline.getKeyFrames().addAll(paramVarArgs);
    localTimeline.setOnFinished(this);
    if (this.activeTimeLines.isEmpty()) {
      start();
    }
    this.activeTimeLines.put(localTimeline, localTimeline);
    localTimeline.play();
    return localTimeline;
  }
  
  public Object animate(Animation paramAnimation)
  {
    SequentialTransition localSequentialTransition = new SequentialTransition();
    localSequentialTransition.getChildren().add(paramAnimation);
    localSequentialTransition.setOnFinished(this);
    if (this.activeTimeLines.isEmpty()) {
      start();
    }
    this.activeTimeLines.put(localSequentialTransition, localSequentialTransition);
    localSequentialTransition.play();
    return localSequentialTransition;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\charts\ChartLayoutAnimator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */