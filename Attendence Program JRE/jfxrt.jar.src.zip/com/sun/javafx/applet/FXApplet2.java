package com.sun.javafx.applet;

import com.sun.applet2.Applet2;
import com.sun.applet2.Applet2Context;
import com.sun.applet2.preloader.event.ErrorEvent;
import com.sun.deploy.uitoolkit.impl.fx.FXPluginToolkit;
import com.sun.deploy.uitoolkit.impl.fx.FXPreloader;
import com.sun.deploy.uitoolkit.impl.fx.FXWindow;
import com.sun.deploy.uitoolkit.impl.fx.Utils;
import com.sun.javafx.application.ParametersImpl;
import com.sun.javafx.application.PlatformImpl;
import com.sun.javafx.perf.PerformanceTracker;
import java.io.PrintStream;
import java.security.AllPermission;
import java.security.PermissionCollection;
import java.security.ProtectionDomain;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Callable;
import javafx.application.Application;
import javafx.application.Application.Parameters;
import javafx.application.Platform;
import javafx.stage.Stage;
import sun.misc.PerformanceLogger;

public class FXApplet2
  implements Applet2
{
  static final int SANDBOXAPP_DESTROY_TIMEOUT = 200;
  static final String JAVFX_APPLICATION_PARAM = "javafx.application";
  private Application application;
  private Applet2Context a2c;
  private FXWindow window;
  private Class<? extends Application> applicationClass = null;
  private boolean isAborted = false;
  
  public FXApplet2(Class<? extends Application> paramClass, FXWindow paramFXWindow)
  {
    this.applicationClass = paramClass;
    this.window = paramFXWindow;
  }
  
  public void init(Applet2Context paramApplet2Context)
  {
    synchronized (this)
    {
      if (this.isAborted) {
        return;
      }
    }
    try
    {
      FXPluginToolkit.callAndWait(new Callable()
      {
        public Object call()
          throws Exception
        {
          FXApplet2.this.application = ((Application)FXApplet2.this.applicationClass.newInstance());
          return null;
        }
      });
    }
    catch (Throwable localThrowable1)
    {
      localThrowable1.printStackTrace();
      FXPreloader.notifyCurrentPreloaderOnError(new ErrorEvent(null, "Failed to instantiate application.", localThrowable1));
      if ((localThrowable1 instanceof ClassCastException)) {
        throw new UnsupportedOperationException("In the JavaFX mode we only support applications extending JavaFX Application class.", localThrowable1);
      }
      throw new RuntimeException(localThrowable1);
    }
    this.a2c = paramApplet2Context;
    String[] arrayOfString = Utils.getUnnamed(this.a2c);
    Map localMap = Utils.getNamedParameters(this.a2c);
    ParametersImpl.registerParameters(this.application, new ParametersImpl(localMap, arrayOfString));
    PlatformImpl.setApplicationName(this.applicationClass);
    try
    {
      this.application.init();
    }
    catch (Throwable localThrowable2)
    {
      localThrowable2.printStackTrace();
      FXPreloader.notifyCurrentPreloaderOnError(new ErrorEvent(null, "Failed to init application.", localThrowable2));
      throw new RuntimeException(localThrowable2);
    }
  }
  
  public Application getApplication()
  {
    return this.application;
  }
  
  public synchronized void abortLaunch()
  {
    this.isAborted = true;
  }
  
  public void start()
  {
    synchronized (this)
    {
      if (this.isAborted) {
        return;
      }
    }
    Platform.runLater(new Runnable()
    {
      public void run()
      {
        if (FXApplet2.this.application != null)
        {
          Stage localStage;
          if (FXApplet2.this.window == null) {
            localStage = new Stage();
          } else {
            localStage = FXApplet2.this.window.getAppletStage();
          }
          try
          {
            FXApplet2.this.application.start(localStage);
            if (PerformanceTracker.isLoggingEnabled())
            {
              String str = (String)FXApplet2.this.application.getParameters().getNamed().get("sun_perflog_fx_launchtime");
              if ((str != null) && (!str.equals("")))
              {
                long l = Long.parseLong(str);
                PerformanceLogger.setStartTime("LaunchTime", l);
              }
            }
          }
          catch (Throwable localThrowable)
          {
            localThrowable.printStackTrace();
            FXPreloader.notifyCurrentPreloaderOnError(new ErrorEvent(null, "Failed to start application.", localThrowable));
            throw new RuntimeException(localThrowable);
          }
        }
        else
        {
          System.err.println("application is null?");
        }
      }
    });
  }
  
  public void stop() {}
  
  private boolean isSandboxApplication()
  {
    try
    {
      ProtectionDomain localProtectionDomain = this.applicationClass.getProtectionDomain();
      if (localProtectionDomain.getPermissions().implies(new AllPermission())) {
        return false;
      }
    }
    catch (SecurityException localSecurityException)
    {
      localSecurityException.printStackTrace();
    }
    return true;
  }
  
  public void destroy()
  {
    synchronized (this)
    {
      if (this.isAborted) {
        return;
      }
    }
    PlatformImpl.runAndWait(new Runnable()
    {
      public void run()
      {
        if (FXApplet2.this.isSandboxApplication())
        {
          Timer localTimer = new Timer("Exit timer", true);
          TimerTask local1 = new TimerTask()
          {
            public void run()
            {
              System.exit(0);
            }
          };
          localTimer.schedule(local1, 200L);
        }
        try
        {
          FXApplet2.this.application.stop();
          FXPreloader.notfiyCurrentPreloaderOnExit();
        }
        catch (Throwable localThrowable)
        {
          localThrowable.printStackTrace();
          FXPreloader.notifyCurrentPreloaderOnError(new ErrorEvent(null, "Failed to stop application.", localThrowable));
        }
      }
    });
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\applet\FXApplet2.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */