package com.sun.javafx.applet;

import com.sun.applet2.Applet2Context;
import com.sun.applet2.Applet2Host;
import netscape.javascript.JSObject;
import sun.plugin2.applet2.Plugin2Host;

public class ExperimentalExtensions
{
  Applet2Context a2c;
  private static ExperimentalExtensions instance = null;
  
  public static synchronized ExperimentalExtensions get()
  {
    return instance;
  }
  
  public static synchronized void init(Applet2Context paramApplet2Context)
  {
    instance = new ExperimentalExtensions(paramApplet2Context);
  }
  
  private ExperimentalExtensions(Applet2Context paramApplet2Context)
  {
    this.a2c = paramApplet2Context;
  }
  
  public JSObject getOneWayJSObject()
  {
    Applet2Host localApplet2Host = this.a2c.getHost();
    if ((localApplet2Host instanceof Plugin2Host)) {
      try
      {
        return ((Plugin2Host)localApplet2Host).getOneWayJSObject();
      }
      catch (Exception localException) {}
    }
    return null;
  }
  
  public Splash getSplash()
  {
    return new Splash(this.a2c);
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\applet\ExperimentalExtensions.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */