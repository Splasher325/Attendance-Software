package com.sun.javafx.applet;

import com.sun.applet2.Applet2Context;
import com.sun.applet2.AppletParameters;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import java.util.Map;
import netscape.javascript.JSObject;

public class Splash
{
  Applet2Context a2c = null;
  
  public Splash(Applet2Context paramApplet2Context)
  {
    this.a2c = paramApplet2Context;
  }
  
  public void hide()
  {
    Runnable local1 = new Runnable()
    {
      public void run()
      {
        try
        {
          JSObject localJSObject = ExperimentalExtensions.get().getOneWayJSObject();
          if (localJSObject == null)
          {
            Trace.println("Can not hide splash as Javascript handle is not avaialble", TraceLevel.UI);
            return;
          }
          AppletParameters localAppletParameters = null;
          if (Splash.this.a2c != null) {
            localAppletParameters = Splash.this.a2c.getParameters();
          }
          if ((localAppletParameters != null) && (!"false".equals(localAppletParameters.get("javafx_splash"))))
          {
            String str = (String)localAppletParameters.get("javafx_applet_id");
            if (str != null) {
              localJSObject.eval("dtjava.hideSplash('" + str + "');");
            } else {
              Trace.println("Missing applet id parameter!");
            }
          }
        }
        catch (Exception localException)
        {
          Trace.ignored(localException);
        }
      }
    };
    Thread localThread = new Thread(local1);
    localThread.setDaemon(true);
    localThread.start();
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\applet\Splash.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */