package com.sun.javafx.applet;

import com.sun.applet2.Applet2Context;
import com.sun.applet2.Applet2Host;
import com.sun.javafx.application.HostServicesDelegate;
import java.net.URI;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import javafx.application.Application;
import netscape.javascript.JSObject;
import sun.plugin2.applet2.Plugin2Host;

public class HostServicesImpl
  extends HostServicesDelegate
{
  private static HostServicesDelegate instance = null;
  private Applet2Context a2c = null;
  
  private HostServicesImpl(Applet2Context paramApplet2Context)
  {
    this.a2c = paramApplet2Context;
  }
  
  public static void init(Applet2Context paramApplet2Context)
  {
    instance = new HostServicesImpl(paramApplet2Context);
  }
  
  public static HostServicesDelegate getInstance(Application paramApplication)
  {
    return instance;
  }
  
  public String getCodeBase()
  {
    return this.a2c.getCodeBase().toExternalForm();
  }
  
  public String getDocumentBase()
  {
    return this.a2c.getHost().getDocumentBase().toExternalForm();
  }
  
  private URL toURL(String paramString)
  {
    try
    {
      return new URI(paramString).toURL();
    }
    catch (RuntimeException localRuntimeException)
    {
      throw localRuntimeException;
    }
    catch (Exception localException)
    {
      throw new IllegalArgumentException(localException);
    }
  }
  
  public void showDocument(String paramString)
  {
    this.a2c.getHost().showDocument(toURL(paramString), "_blank");
  }
  
  public JSObject getWebContext()
  {
    try
    {
      return (JSObject)AccessController.doPrivileged(new WCGetter());
    }
    catch (PrivilegedActionException localPrivilegedActionException)
    {
      localPrivilegedActionException.printStackTrace();
    }
    return null;
  }
  
  class WCGetter
    implements PrivilegedExceptionAction<JSObject>
  {
    WCGetter() {}
    
    public JSObject run()
    {
      Applet2Host localApplet2Host = HostServicesImpl.this.a2c.getHost();
      if ((localApplet2Host instanceof Plugin2Host)) {
        try
        {
          return ((Plugin2Host)localApplet2Host).getJSObject();
        }
        catch (Exception localException) {}
      }
      return null;
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\applet\HostServicesImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */