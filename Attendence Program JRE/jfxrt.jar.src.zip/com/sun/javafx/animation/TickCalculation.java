package com.sun.javafx.animation;

import javafx.util.Duration;

public class TickCalculation
{
  public static final int TICKS_PER_SECOND = 6000;
  private static final double TICKS_PER_MILI = 6.0D;
  private static final double TICKS_PER_NANO = 6.0E-6D;
  
  public static long add(long paramLong1, long paramLong2)
  {
    assert (paramLong1 >= 0L);
    if ((paramLong1 == Long.MAX_VALUE) || (paramLong2 == Long.MAX_VALUE)) {
      return Long.MAX_VALUE;
    }
    if (paramLong2 == Long.MIN_VALUE) {
      return 0L;
    }
    if (paramLong2 >= 0L)
    {
      long l = paramLong1 + paramLong2;
      return l < 0L ? Long.MAX_VALUE : l;
    }
    return Math.max(0L, paramLong1 + paramLong2);
  }
  
  public static long sub(long paramLong1, long paramLong2)
  {
    assert (paramLong1 >= 0L);
    if ((paramLong1 == Long.MAX_VALUE) || (paramLong2 == Long.MIN_VALUE)) {
      return Long.MAX_VALUE;
    }
    if (paramLong2 == Long.MAX_VALUE) {
      return 0L;
    }
    if (paramLong2 >= 0L) {
      return Math.max(0L, paramLong1 - paramLong2);
    }
    long l = paramLong1 - paramLong2;
    return l < 0L ? Long.MAX_VALUE : l;
  }
  
  public static long fromMillis(double paramDouble)
  {
    return Math.round(6.0D * paramDouble);
  }
  
  public static long fromNano(long paramLong)
  {
    return Math.round(6.0E-6D * paramLong);
  }
  
  public static long fromDuration(Duration paramDuration)
  {
    return fromMillis(paramDuration.toMillis());
  }
  
  public static long fromDuration(Duration paramDuration, double paramDouble)
  {
    return Math.round(6.0D * paramDuration.toMillis() / Math.abs(paramDouble));
  }
  
  public static Duration toDuration(long paramLong)
  {
    return Duration.millis(toMillis(paramLong));
  }
  
  public static double toMillis(long paramLong)
  {
    return paramLong / 6.0D;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\animation\TickCalculation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */