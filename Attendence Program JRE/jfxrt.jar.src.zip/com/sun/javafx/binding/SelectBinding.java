package com.sun.javafx.binding;

import com.sun.javafx.property.JavaBeanAccessHelper;
import com.sun.javafx.property.PropertyReference;
import java.util.Arrays;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.binding.Binding;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.binding.DoubleBinding;
import javafx.beans.binding.FloatBinding;
import javafx.beans.binding.IntegerBinding;
import javafx.beans.binding.LongBinding;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.binding.StringBinding;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.value.ObservableNumberValue;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import sun.util.logging.PlatformLogger;
import sun.util.logging.PlatformLogger.Level;

public class SelectBinding
{
  public static class AsBoolean
    extends BooleanBinding
  {
    private static final boolean DEFAULT_VALUE = false;
    private final SelectBinding.SelectBindingHelper helper;
    
    public AsBoolean(ObservableValue<?> paramObservableValue, String... paramVarArgs)
    {
      this.helper = new SelectBinding.SelectBindingHelper(this, paramObservableValue, paramVarArgs, null);
    }
    
    public AsBoolean(Object paramObject, String... paramVarArgs)
    {
      this.helper = new SelectBinding.SelectBindingHelper(this, paramObject, paramVarArgs, null);
    }
    
    public void dispose()
    {
      SelectBinding.SelectBindingHelper.access$200(this.helper);
    }
    
    protected void onInvalidating()
    {
      SelectBinding.SelectBindingHelper.access$200(this.helper);
    }
    
    protected boolean computeValue()
    {
      ObservableValue localObservableValue = this.helper.getObservableValue();
      if (localObservableValue == null) {
        return false;
      }
      if ((localObservableValue instanceof ObservableBooleanValue)) {
        return ((ObservableBooleanValue)localObservableValue).get();
      }
      try
      {
        return ((Boolean)localObservableValue.getValue()).booleanValue();
      }
      catch (NullPointerException localNullPointerException)
      {
        Logging.getLogger().fine("Value of select binding is null, returning default value", localNullPointerException);
      }
      catch (ClassCastException localClassCastException)
      {
        Logging.getLogger().warning("Value of select-binding has wrong type, returning default value.", localClassCastException);
      }
      return false;
    }
    
    public ObservableList<ObservableValue<?>> getDependencies()
    {
      return this.helper.getDependencies();
    }
  }
  
  public static class AsDouble
    extends DoubleBinding
  {
    private static final double DEFAULT_VALUE = 0.0D;
    private final SelectBinding.SelectBindingHelper helper;
    
    public AsDouble(ObservableValue<?> paramObservableValue, String... paramVarArgs)
    {
      this.helper = new SelectBinding.SelectBindingHelper(this, paramObservableValue, paramVarArgs, null);
    }
    
    public AsDouble(Object paramObject, String... paramVarArgs)
    {
      this.helper = new SelectBinding.SelectBindingHelper(this, paramObject, paramVarArgs, null);
    }
    
    public void dispose()
    {
      SelectBinding.SelectBindingHelper.access$200(this.helper);
    }
    
    protected void onInvalidating()
    {
      SelectBinding.SelectBindingHelper.access$200(this.helper);
    }
    
    protected double computeValue()
    {
      ObservableValue localObservableValue = this.helper.getObservableValue();
      if (localObservableValue == null) {
        return 0.0D;
      }
      if ((localObservableValue instanceof ObservableNumberValue)) {
        return ((ObservableNumberValue)localObservableValue).doubleValue();
      }
      try
      {
        return ((Number)localObservableValue.getValue()).doubleValue();
      }
      catch (NullPointerException localNullPointerException)
      {
        Logging.getLogger().fine("Value of select binding is null, returning default value", localNullPointerException);
      }
      catch (ClassCastException localClassCastException)
      {
        Logging.getLogger().warning("Exception while evaluating select-binding", localClassCastException);
      }
      return 0.0D;
    }
    
    public ObservableList<ObservableValue<?>> getDependencies()
    {
      return this.helper.getDependencies();
    }
  }
  
  public static class AsFloat
    extends FloatBinding
  {
    private static final float DEFAULT_VALUE = 0.0F;
    private final SelectBinding.SelectBindingHelper helper;
    
    public AsFloat(ObservableValue<?> paramObservableValue, String... paramVarArgs)
    {
      this.helper = new SelectBinding.SelectBindingHelper(this, paramObservableValue, paramVarArgs, null);
    }
    
    public AsFloat(Object paramObject, String... paramVarArgs)
    {
      this.helper = new SelectBinding.SelectBindingHelper(this, paramObject, paramVarArgs, null);
    }
    
    public void dispose()
    {
      SelectBinding.SelectBindingHelper.access$200(this.helper);
    }
    
    protected void onInvalidating()
    {
      SelectBinding.SelectBindingHelper.access$200(this.helper);
    }
    
    protected float computeValue()
    {
      ObservableValue localObservableValue = this.helper.getObservableValue();
      if (localObservableValue == null) {
        return 0.0F;
      }
      if ((localObservableValue instanceof ObservableNumberValue)) {
        return ((ObservableNumberValue)localObservableValue).floatValue();
      }
      try
      {
        return ((Number)localObservableValue.getValue()).floatValue();
      }
      catch (NullPointerException localNullPointerException)
      {
        Logging.getLogger().fine("Value of select binding is null, returning default value", localNullPointerException);
      }
      catch (ClassCastException localClassCastException)
      {
        Logging.getLogger().warning("Exception while evaluating select-binding", localClassCastException);
      }
      return 0.0F;
    }
    
    public ObservableList<ObservableValue<?>> getDependencies()
    {
      return this.helper.getDependencies();
    }
  }
  
  public static class AsInteger
    extends IntegerBinding
  {
    private static final int DEFAULT_VALUE = 0;
    private final SelectBinding.SelectBindingHelper helper;
    
    public AsInteger(ObservableValue<?> paramObservableValue, String... paramVarArgs)
    {
      this.helper = new SelectBinding.SelectBindingHelper(this, paramObservableValue, paramVarArgs, null);
    }
    
    public AsInteger(Object paramObject, String... paramVarArgs)
    {
      this.helper = new SelectBinding.SelectBindingHelper(this, paramObject, paramVarArgs, null);
    }
    
    public void dispose()
    {
      SelectBinding.SelectBindingHelper.access$200(this.helper);
    }
    
    protected void onInvalidating()
    {
      SelectBinding.SelectBindingHelper.access$200(this.helper);
    }
    
    protected int computeValue()
    {
      ObservableValue localObservableValue = this.helper.getObservableValue();
      if (localObservableValue == null) {
        return 0;
      }
      if ((localObservableValue instanceof ObservableNumberValue)) {
        return ((ObservableNumberValue)localObservableValue).intValue();
      }
      try
      {
        return ((Number)localObservableValue.getValue()).intValue();
      }
      catch (NullPointerException localNullPointerException)
      {
        Logging.getLogger().fine("Value of select binding is null, returning default value", localNullPointerException);
      }
      catch (ClassCastException localClassCastException)
      {
        Logging.getLogger().warning("Exception while evaluating select-binding", localClassCastException);
      }
      return 0;
    }
    
    public ObservableList<ObservableValue<?>> getDependencies()
    {
      return this.helper.getDependencies();
    }
  }
  
  public static class AsLong
    extends LongBinding
  {
    private static final long DEFAULT_VALUE = 0L;
    private final SelectBinding.SelectBindingHelper helper;
    
    public AsLong(ObservableValue<?> paramObservableValue, String... paramVarArgs)
    {
      this.helper = new SelectBinding.SelectBindingHelper(this, paramObservableValue, paramVarArgs, null);
    }
    
    public AsLong(Object paramObject, String... paramVarArgs)
    {
      this.helper = new SelectBinding.SelectBindingHelper(this, paramObject, paramVarArgs, null);
    }
    
    public void dispose()
    {
      SelectBinding.SelectBindingHelper.access$200(this.helper);
    }
    
    protected void onInvalidating()
    {
      SelectBinding.SelectBindingHelper.access$200(this.helper);
    }
    
    protected long computeValue()
    {
      ObservableValue localObservableValue = this.helper.getObservableValue();
      if (localObservableValue == null) {
        return 0L;
      }
      if ((localObservableValue instanceof ObservableNumberValue)) {
        return ((ObservableNumberValue)localObservableValue).longValue();
      }
      try
      {
        return ((Number)localObservableValue.getValue()).longValue();
      }
      catch (NullPointerException localNullPointerException)
      {
        Logging.getLogger().fine("Value of select binding is null, returning default value", localNullPointerException);
      }
      catch (ClassCastException localClassCastException)
      {
        Logging.getLogger().warning("Exception while evaluating select-binding", localClassCastException);
      }
      return 0L;
    }
    
    public ObservableList<ObservableValue<?>> getDependencies()
    {
      return this.helper.getDependencies();
    }
  }
  
  public static class AsObject<T>
    extends ObjectBinding<T>
  {
    private final SelectBinding.SelectBindingHelper helper;
    
    public AsObject(ObservableValue<?> paramObservableValue, String... paramVarArgs)
    {
      this.helper = new SelectBinding.SelectBindingHelper(this, paramObservableValue, paramVarArgs, null);
    }
    
    public AsObject(Object paramObject, String... paramVarArgs)
    {
      this.helper = new SelectBinding.SelectBindingHelper(this, paramObject, paramVarArgs, null);
    }
    
    public void dispose()
    {
      SelectBinding.SelectBindingHelper.access$200(this.helper);
    }
    
    protected void onInvalidating()
    {
      SelectBinding.SelectBindingHelper.access$200(this.helper);
    }
    
    protected T computeValue()
    {
      ObservableValue localObservableValue = this.helper.getObservableValue();
      if (localObservableValue == null) {
        return null;
      }
      try
      {
        return (T)localObservableValue.getValue();
      }
      catch (ClassCastException localClassCastException)
      {
        Logging.getLogger().warning("Value of select-binding has wrong type, returning null.", localClassCastException);
      }
      return null;
    }
    
    public ObservableList<ObservableValue<?>> getDependencies()
    {
      return this.helper.getDependencies();
    }
  }
  
  public static class AsString
    extends StringBinding
  {
    private static final String DEFAULT_VALUE = null;
    private final SelectBinding.SelectBindingHelper helper;
    
    public AsString(ObservableValue<?> paramObservableValue, String... paramVarArgs)
    {
      this.helper = new SelectBinding.SelectBindingHelper(this, paramObservableValue, paramVarArgs, null);
    }
    
    public AsString(Object paramObject, String... paramVarArgs)
    {
      this.helper = new SelectBinding.SelectBindingHelper(this, paramObject, paramVarArgs, null);
    }
    
    public void dispose()
    {
      SelectBinding.SelectBindingHelper.access$200(this.helper);
    }
    
    protected void onInvalidating()
    {
      SelectBinding.SelectBindingHelper.access$200(this.helper);
    }
    
    protected String computeValue()
    {
      ObservableValue localObservableValue = this.helper.getObservableValue();
      if (localObservableValue == null) {
        return DEFAULT_VALUE;
      }
      try
      {
        return localObservableValue.getValue().toString();
      }
      catch (RuntimeException localRuntimeException)
      {
        Logging.getLogger().warning("Exception while evaluating select-binding", localRuntimeException);
      }
      return DEFAULT_VALUE;
    }
    
    public ObservableList<ObservableValue<?>> getDependencies()
    {
      return this.helper.getDependencies();
    }
  }
  
  private static class SelectBindingHelper
    implements InvalidationListener
  {
    private final Binding<?> binding;
    private final String[] propertyNames;
    private final ObservableValue<?>[] properties;
    private final PropertyReference<?>[] propRefs;
    private final WeakInvalidationListener observer;
    private ObservableList<ObservableValue<?>> dependencies;
    
    private SelectBindingHelper(Binding<?> paramBinding, ObservableValue<?> paramObservableValue, String... paramVarArgs)
    {
      if (paramObservableValue == null) {
        throw new NullPointerException("Must specify the root");
      }
      if (paramVarArgs == null) {
        paramVarArgs = new String[0];
      }
      this.binding = paramBinding;
      int i = paramVarArgs.length;
      for (int j = 0; j < i; j++) {
        if (paramVarArgs[j] == null) {
          throw new NullPointerException("all steps must be specified");
        }
      }
      this.observer = new WeakInvalidationListener(this);
      this.propertyNames = new String[i];
      System.arraycopy(paramVarArgs, 0, this.propertyNames, 0, i);
      this.propRefs = new PropertyReference[i];
      this.properties = new ObservableValue[i + 1];
      this.properties[0] = paramObservableValue;
      this.properties[0].addListener(this.observer);
    }
    
    private static ObservableValue<?> checkAndCreateFirstStep(Object paramObject, String[] paramArrayOfString)
    {
      if ((paramObject == null) || (paramArrayOfString == null) || (paramArrayOfString[0] == null)) {
        throw new NullPointerException("Must specify the root and the first property");
      }
      try
      {
        return JavaBeanAccessHelper.createReadOnlyJavaBeanProperty(paramObject, paramArrayOfString[0]);
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        throw new IllegalArgumentException("The first property '" + paramArrayOfString[0] + "' doesn't exist");
      }
    }
    
    private SelectBindingHelper(Binding<?> paramBinding, Object paramObject, String... paramVarArgs)
    {
      this(paramBinding, checkAndCreateFirstStep(paramObject, paramVarArgs), (String[])Arrays.copyOfRange(paramVarArgs, 1, paramVarArgs.length));
    }
    
    public void invalidated(Observable paramObservable)
    {
      this.binding.invalidate();
    }
    
    public ObservableValue<?> getObservableValue()
    {
      int i = this.properties.length;
      for (int j = 0; j < i - 1; j++)
      {
        Object localObject = this.properties[j].getValue();
        try
        {
          if ((this.propRefs[j] == null) || (!localObject.getClass().equals(this.propRefs[j].getContainingClass()))) {
            this.propRefs[j] = new PropertyReference(localObject.getClass(), this.propertyNames[j]);
          }
          if (this.propRefs[j].hasProperty()) {
            this.properties[(j + 1)] = this.propRefs[j].getProperty(localObject);
          } else {
            this.properties[(j + 1)] = JavaBeanAccessHelper.createReadOnlyJavaBeanProperty(localObject, this.propRefs[j].getName());
          }
        }
        catch (NoSuchMethodException localNoSuchMethodException)
        {
          Logging.getLogger().warning("Exception while evaluating select-binding " + stepsToString(), localNoSuchMethodException);
          updateDependencies();
          return null;
        }
        catch (RuntimeException localRuntimeException)
        {
          PlatformLogger localPlatformLogger = Logging.getLogger();
          if (localPlatformLogger.isLoggable(PlatformLogger.Level.WARNING))
          {
            Logging.getLogger().warning("Exception while evaluating select-binding " + stepsToString());
            if ((localRuntimeException instanceof IllegalStateException)) {
              localPlatformLogger.warning("Property '" + this.propertyNames[j] + "' does not exist in " + localObject.getClass(), localRuntimeException);
            } else if ((localRuntimeException instanceof NullPointerException)) {
              localPlatformLogger.fine("Property '" + this.propertyNames[j] + "' in " + this.properties[j] + " is null", localRuntimeException);
            } else {
              Logging.getLogger().warning("", localRuntimeException);
            }
          }
          updateDependencies();
          return null;
        }
        this.properties[(j + 1)].addListener(this.observer);
      }
      updateDependencies();
      ObservableValue localObservableValue = this.properties[(i - 1)];
      if (localObservableValue == null) {
        Logging.getLogger().fine("Property '" + this.propertyNames[(i - 1)] + "' in " + this.properties[(i - 1)] + " is null", new NullPointerException());
      }
      return localObservableValue;
    }
    
    private String stepsToString()
    {
      return Arrays.toString(this.propertyNames);
    }
    
    private void unregisterListener()
    {
      int i = this.properties.length;
      for (int j = 1; (j < i) && (this.properties[j] != null); j++)
      {
        this.properties[j].removeListener(this.observer);
        this.properties[j] = null;
      }
      updateDependencies();
    }
    
    private void updateDependencies()
    {
      if (this.dependencies != null)
      {
        this.dependencies.clear();
        int i = this.properties.length;
        for (int j = 0; (j < i) && (this.properties[j] != null); j++) {
          this.dependencies.add(this.properties[j]);
        }
      }
    }
    
    public ObservableList<ObservableValue<?>> getDependencies()
    {
      if (this.dependencies == null)
      {
        this.dependencies = FXCollections.observableArrayList();
        updateDependencies();
      }
      return FXCollections.unmodifiableObservableList(this.dependencies);
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\binding\SelectBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */