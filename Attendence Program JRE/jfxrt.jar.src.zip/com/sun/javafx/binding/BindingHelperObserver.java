package com.sun.javafx.binding;

import java.lang.ref.WeakReference;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.Binding;

public class BindingHelperObserver
  implements InvalidationListener
{
  private final WeakReference<Binding<?>> ref;
  
  public BindingHelperObserver(Binding<?> paramBinding)
  {
    if (paramBinding == null) {
      throw new NullPointerException("Binding has to be specified.");
    }
    this.ref = new WeakReference(paramBinding);
  }
  
  public void invalidated(Observable paramObservable)
  {
    Binding localBinding = (Binding)this.ref.get();
    if (localBinding == null) {
      paramObservable.removeListener(this);
    } else {
      localBinding.invalidate();
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\binding\BindingHelperObserver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */