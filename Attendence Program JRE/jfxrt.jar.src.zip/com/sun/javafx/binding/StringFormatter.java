package com.sun.javafx.binding;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javafx.beans.Observable;
import javafx.beans.binding.StringBinding;
import javafx.beans.binding.StringExpression;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public abstract class StringFormatter
  extends StringBinding
{
  private static Object extractValue(Object paramObject)
  {
    return (paramObject instanceof ObservableValue) ? ((ObservableValue)paramObject).getValue() : paramObject;
  }
  
  private static Object[] extractValues(Object[] paramArrayOfObject)
  {
    int i = paramArrayOfObject.length;
    Object[] arrayOfObject = new Object[i];
    for (int j = 0; j < i; j++) {
      arrayOfObject[j] = extractValue(paramArrayOfObject[j]);
    }
    return arrayOfObject;
  }
  
  private static ObservableValue<?>[] extractDependencies(Object... paramVarArgs)
  {
    ArrayList localArrayList = new ArrayList();
    for (Object localObject : paramVarArgs) {
      if ((localObject instanceof ObservableValue)) {
        localArrayList.add((ObservableValue)localObject);
      }
    }
    return (ObservableValue[])localArrayList.toArray(new ObservableValue[localArrayList.size()]);
  }
  
  public static StringExpression convert(ObservableValue<?> paramObservableValue)
  {
    if (paramObservableValue == null) {
      throw new NullPointerException("ObservableValue must be specified");
    }
    if ((paramObservableValue instanceof StringExpression)) {
      return (StringExpression)paramObservableValue;
    }
    new StringBinding()
    {
      public void dispose()
      {
        super.unbind(new Observable[] { this.val$observableValue });
      }
      
      protected String computeValue()
      {
        Object localObject = this.val$observableValue.getValue();
        return localObject == null ? "null" : localObject.toString();
      }
      
      public ObservableList<ObservableValue<?>> getDependencies()
      {
        return FXCollections.singletonObservableList(this.val$observableValue);
      }
    };
  }
  
  public static StringExpression concat(Object... paramVarArgs)
  {
    if ((paramVarArgs == null) || (paramVarArgs.length == 0)) {
      return StringConstant.valueOf("");
    }
    Object localObject1;
    if (paramVarArgs.length == 1)
    {
      localObject1 = paramVarArgs[0];
      return (localObject1 instanceof ObservableValue) ? convert((ObservableValue)localObject1) : StringConstant.valueOf(localObject1.toString());
    }
    if (extractDependencies(paramVarArgs).length == 0)
    {
      localObject1 = new StringBuilder();
      for (Object localObject2 : paramVarArgs) {
        ((StringBuilder)localObject1).append(localObject2);
      }
      return StringConstant.valueOf(((StringBuilder)localObject1).toString());
    }
    new StringFormatter()
    {
      public void dispose()
      {
        super.unbind(StringFormatter.extractDependencies(this.val$args));
      }
      
      protected String computeValue()
      {
        StringBuilder localStringBuilder = new StringBuilder();
        for (Object localObject : this.val$args) {
          localStringBuilder.append(StringFormatter.extractValue(localObject));
        }
        return localStringBuilder.toString();
      }
      
      public ObservableList<ObservableValue<?>> getDependencies()
      {
        return FXCollections.unmodifiableObservableList(FXCollections.observableArrayList(StringFormatter.extractDependencies(this.val$args)));
      }
    };
  }
  
  public static StringExpression format(final Locale paramLocale, final String paramString, Object... paramVarArgs)
  {
    if (paramString == null) {
      throw new NullPointerException("Format cannot be null.");
    }
    if (extractDependencies(paramVarArgs).length == 0) {
      return StringConstant.valueOf(String.format(paramLocale, paramString, paramVarArgs));
    }
    StringFormatter local3 = new StringFormatter()
    {
      public void dispose()
      {
        super.unbind(StringFormatter.extractDependencies(this.val$args));
      }
      
      protected String computeValue()
      {
        Object[] arrayOfObject = StringFormatter.extractValues(this.val$args);
        return String.format(paramLocale, paramString, arrayOfObject);
      }
      
      public ObservableList<ObservableValue<?>> getDependencies()
      {
        return FXCollections.unmodifiableObservableList(FXCollections.observableArrayList(StringFormatter.extractDependencies(this.val$args)));
      }
    };
    local3.get();
    return local3;
  }
  
  public static StringExpression format(final String paramString, Object... paramVarArgs)
  {
    if (paramString == null) {
      throw new NullPointerException("Format cannot be null.");
    }
    if (extractDependencies(paramVarArgs).length == 0) {
      return StringConstant.valueOf(String.format(paramString, paramVarArgs));
    }
    StringFormatter local4 = new StringFormatter()
    {
      public void dispose()
      {
        super.unbind(StringFormatter.extractDependencies(this.val$args));
      }
      
      protected String computeValue()
      {
        Object[] arrayOfObject = StringFormatter.extractValues(this.val$args);
        return String.format(paramString, arrayOfObject);
      }
      
      public ObservableList<ObservableValue<?>> getDependencies()
      {
        return FXCollections.unmodifiableObservableList(FXCollections.observableArrayList(StringFormatter.extractDependencies(this.val$args)));
      }
    };
    local4.get();
    return local4;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\binding\StringFormatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */