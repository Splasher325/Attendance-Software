package com.sun.javafx.binding;

import sun.util.logging.PlatformLogger;

public class Logging
{
  public static PlatformLogger getLogger()
  {
    return LoggerHolder.INSTANCE;
  }
  
  private static class LoggerHolder
  {
    private static final PlatformLogger INSTANCE = PlatformLogger.getLogger("javafx.beans");
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\binding\Logging.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */