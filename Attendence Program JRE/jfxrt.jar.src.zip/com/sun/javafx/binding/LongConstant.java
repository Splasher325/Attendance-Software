package com.sun.javafx.binding;

import javafx.beans.InvalidationListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableLongValue;

public final class LongConstant
  implements ObservableLongValue
{
  private final long value;
  
  private LongConstant(long paramLong)
  {
    this.value = paramLong;
  }
  
  public static LongConstant valueOf(long paramLong)
  {
    return new LongConstant(paramLong);
  }
  
  public long get()
  {
    return this.value;
  }
  
  public Long getValue()
  {
    return Long.valueOf(this.value);
  }
  
  public void addListener(InvalidationListener paramInvalidationListener) {}
  
  public void addListener(ChangeListener<? super Number> paramChangeListener) {}
  
  public void removeListener(InvalidationListener paramInvalidationListener) {}
  
  public void removeListener(ChangeListener<? super Number> paramChangeListener) {}
  
  public int intValue()
  {
    return (int)this.value;
  }
  
  public long longValue()
  {
    return this.value;
  }
  
  public float floatValue()
  {
    return (float)this.value;
  }
  
  public double doubleValue()
  {
    return this.value;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\binding\LongConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */