package com.sun.javafx.binding;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import javafx.beans.InvalidationListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableMapValue;
import javafx.collections.MapChangeListener;
import javafx.collections.MapChangeListener.Change;
import javafx.collections.ObservableMap;

public abstract class MapExpressionHelper<K, V>
  extends ExpressionHelperBase
{
  protected final ObservableMapValue<K, V> observable;
  
  public static <K, V> MapExpressionHelper<K, V> addListener(MapExpressionHelper<K, V> paramMapExpressionHelper, ObservableMapValue<K, V> paramObservableMapValue, InvalidationListener paramInvalidationListener)
  {
    if ((paramObservableMapValue == null) || (paramInvalidationListener == null)) {
      throw new NullPointerException();
    }
    paramObservableMapValue.getValue();
    return paramMapExpressionHelper == null ? new SingleInvalidation(paramObservableMapValue, paramInvalidationListener, null) : paramMapExpressionHelper.addListener(paramInvalidationListener);
  }
  
  public static <K, V> MapExpressionHelper<K, V> removeListener(MapExpressionHelper<K, V> paramMapExpressionHelper, InvalidationListener paramInvalidationListener)
  {
    if (paramInvalidationListener == null) {
      throw new NullPointerException();
    }
    return paramMapExpressionHelper == null ? null : paramMapExpressionHelper.removeListener(paramInvalidationListener);
  }
  
  public static <K, V> MapExpressionHelper<K, V> addListener(MapExpressionHelper<K, V> paramMapExpressionHelper, ObservableMapValue<K, V> paramObservableMapValue, ChangeListener<? super ObservableMap<K, V>> paramChangeListener)
  {
    if ((paramObservableMapValue == null) || (paramChangeListener == null)) {
      throw new NullPointerException();
    }
    return paramMapExpressionHelper == null ? new SingleChange(paramObservableMapValue, paramChangeListener, null) : paramMapExpressionHelper.addListener(paramChangeListener);
  }
  
  public static <K, V> MapExpressionHelper<K, V> removeListener(MapExpressionHelper<K, V> paramMapExpressionHelper, ChangeListener<? super ObservableMap<K, V>> paramChangeListener)
  {
    if (paramChangeListener == null) {
      throw new NullPointerException();
    }
    return paramMapExpressionHelper == null ? null : paramMapExpressionHelper.removeListener(paramChangeListener);
  }
  
  public static <K, V> MapExpressionHelper<K, V> addListener(MapExpressionHelper<K, V> paramMapExpressionHelper, ObservableMapValue<K, V> paramObservableMapValue, MapChangeListener<? super K, ? super V> paramMapChangeListener)
  {
    if ((paramObservableMapValue == null) || (paramMapChangeListener == null)) {
      throw new NullPointerException();
    }
    return paramMapExpressionHelper == null ? new SingleMapChange(paramObservableMapValue, paramMapChangeListener, null) : paramMapExpressionHelper.addListener(paramMapChangeListener);
  }
  
  public static <K, V> MapExpressionHelper<K, V> removeListener(MapExpressionHelper<K, V> paramMapExpressionHelper, MapChangeListener<? super K, ? super V> paramMapChangeListener)
  {
    if (paramMapChangeListener == null) {
      throw new NullPointerException();
    }
    return paramMapExpressionHelper == null ? null : paramMapExpressionHelper.removeListener(paramMapChangeListener);
  }
  
  public static <K, V> void fireValueChangedEvent(MapExpressionHelper<K, V> paramMapExpressionHelper)
  {
    if (paramMapExpressionHelper != null) {
      paramMapExpressionHelper.fireValueChangedEvent();
    }
  }
  
  public static <K, V> void fireValueChangedEvent(MapExpressionHelper<K, V> paramMapExpressionHelper, MapChangeListener.Change<? extends K, ? extends V> paramChange)
  {
    if (paramMapExpressionHelper != null) {
      paramMapExpressionHelper.fireValueChangedEvent(paramChange);
    }
  }
  
  protected MapExpressionHelper(ObservableMapValue<K, V> paramObservableMapValue)
  {
    this.observable = paramObservableMapValue;
  }
  
  protected abstract MapExpressionHelper<K, V> addListener(InvalidationListener paramInvalidationListener);
  
  protected abstract MapExpressionHelper<K, V> removeListener(InvalidationListener paramInvalidationListener);
  
  protected abstract MapExpressionHelper<K, V> addListener(ChangeListener<? super ObservableMap<K, V>> paramChangeListener);
  
  protected abstract MapExpressionHelper<K, V> removeListener(ChangeListener<? super ObservableMap<K, V>> paramChangeListener);
  
  protected abstract MapExpressionHelper<K, V> addListener(MapChangeListener<? super K, ? super V> paramMapChangeListener);
  
  protected abstract MapExpressionHelper<K, V> removeListener(MapChangeListener<? super K, ? super V> paramMapChangeListener);
  
  protected abstract void fireValueChangedEvent();
  
  protected abstract void fireValueChangedEvent(MapChangeListener.Change<? extends K, ? extends V> paramChange);
  
  private static class Generic<K, V>
    extends MapExpressionHelper<K, V>
  {
    private InvalidationListener[] invalidationListeners;
    private ChangeListener<? super ObservableMap<K, V>>[] changeListeners;
    private MapChangeListener<? super K, ? super V>[] mapChangeListeners;
    private int invalidationSize;
    private int changeSize;
    private int mapChangeSize;
    private boolean locked;
    private ObservableMap<K, V> currentValue;
    
    private Generic(ObservableMapValue<K, V> paramObservableMapValue, InvalidationListener paramInvalidationListener1, InvalidationListener paramInvalidationListener2)
    {
      super();
      this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener1, paramInvalidationListener2 };
      this.invalidationSize = 2;
    }
    
    private Generic(ObservableMapValue<K, V> paramObservableMapValue, ChangeListener<? super ObservableMap<K, V>> paramChangeListener1, ChangeListener<? super ObservableMap<K, V>> paramChangeListener2)
    {
      super();
      this.changeListeners = new ChangeListener[] { paramChangeListener1, paramChangeListener2 };
      this.changeSize = 2;
      this.currentValue = ((ObservableMap)paramObservableMapValue.getValue());
    }
    
    private Generic(ObservableMapValue<K, V> paramObservableMapValue, MapChangeListener<? super K, ? super V> paramMapChangeListener1, MapChangeListener<? super K, ? super V> paramMapChangeListener2)
    {
      super();
      this.mapChangeListeners = new MapChangeListener[] { paramMapChangeListener1, paramMapChangeListener2 };
      this.mapChangeSize = 2;
      this.currentValue = ((ObservableMap)paramObservableMapValue.getValue());
    }
    
    private Generic(ObservableMapValue<K, V> paramObservableMapValue, InvalidationListener paramInvalidationListener, ChangeListener<? super ObservableMap<K, V>> paramChangeListener)
    {
      super();
      this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener };
      this.invalidationSize = 1;
      this.changeListeners = new ChangeListener[] { paramChangeListener };
      this.changeSize = 1;
      this.currentValue = ((ObservableMap)paramObservableMapValue.getValue());
    }
    
    private Generic(ObservableMapValue<K, V> paramObservableMapValue, InvalidationListener paramInvalidationListener, MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      super();
      this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener };
      this.invalidationSize = 1;
      this.mapChangeListeners = new MapChangeListener[] { paramMapChangeListener };
      this.mapChangeSize = 1;
      this.currentValue = ((ObservableMap)paramObservableMapValue.getValue());
    }
    
    private Generic(ObservableMapValue<K, V> paramObservableMapValue, ChangeListener<? super ObservableMap<K, V>> paramChangeListener, MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      super();
      this.changeListeners = new ChangeListener[] { paramChangeListener };
      this.changeSize = 1;
      this.mapChangeListeners = new MapChangeListener[] { paramMapChangeListener };
      this.mapChangeSize = 1;
      this.currentValue = ((ObservableMap)paramObservableMapValue.getValue());
    }
    
    protected MapExpressionHelper<K, V> addListener(InvalidationListener paramInvalidationListener)
    {
      if (this.invalidationListeners == null)
      {
        this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener };
        this.invalidationSize = 1;
      }
      else
      {
        int i = this.invalidationListeners.length;
        int j;
        if (this.locked)
        {
          j = this.invalidationSize < i ? i : i * 3 / 2 + 1;
          this.invalidationListeners = ((InvalidationListener[])Arrays.copyOf(this.invalidationListeners, j));
        }
        else if (this.invalidationSize == i)
        {
          this.invalidationSize = trim(this.invalidationSize, this.invalidationListeners);
          if (this.invalidationSize == i)
          {
            j = i * 3 / 2 + 1;
            this.invalidationListeners = ((InvalidationListener[])Arrays.copyOf(this.invalidationListeners, j));
          }
        }
        this.invalidationListeners[(this.invalidationSize++)] = paramInvalidationListener;
      }
      return this;
    }
    
    protected MapExpressionHelper<K, V> removeListener(InvalidationListener paramInvalidationListener)
    {
      if (this.invalidationListeners != null) {
        for (int i = 0; i < this.invalidationSize; i++) {
          if (paramInvalidationListener.equals(this.invalidationListeners[i]))
          {
            if (this.invalidationSize == 1)
            {
              if ((this.changeSize == 1) && (this.mapChangeSize == 0)) {
                return new MapExpressionHelper.SingleChange(this.observable, this.changeListeners[0], null);
              }
              if ((this.changeSize == 0) && (this.mapChangeSize == 1)) {
                return new MapExpressionHelper.SingleMapChange(this.observable, this.mapChangeListeners[0], null);
              }
              this.invalidationListeners = null;
              this.invalidationSize = 0;
              break;
            }
            int j = this.invalidationSize - i - 1;
            InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
            if (this.locked)
            {
              this.invalidationListeners = new InvalidationListener[this.invalidationListeners.length];
              System.arraycopy(arrayOfInvalidationListener, 0, this.invalidationListeners, 0, i + 1);
            }
            if (j > 0) {
              System.arraycopy(arrayOfInvalidationListener, i + 1, this.invalidationListeners, i, j);
            }
            this.invalidationSize -= 1;
            if (!this.locked) {
              this.invalidationListeners[(--this.invalidationSize)] = null;
            }
            break;
          }
        }
      }
      return this;
    }
    
    protected MapExpressionHelper<K, V> addListener(ChangeListener<? super ObservableMap<K, V>> paramChangeListener)
    {
      if (this.changeListeners == null)
      {
        this.changeListeners = new ChangeListener[] { paramChangeListener };
        this.changeSize = 1;
      }
      else
      {
        int i = this.changeListeners.length;
        int j;
        if (this.locked)
        {
          j = this.changeSize < i ? i : i * 3 / 2 + 1;
          this.changeListeners = ((ChangeListener[])Arrays.copyOf(this.changeListeners, j));
        }
        else if (this.changeSize == i)
        {
          this.changeSize = trim(this.changeSize, this.changeListeners);
          if (this.changeSize == i)
          {
            j = i * 3 / 2 + 1;
            this.changeListeners = ((ChangeListener[])Arrays.copyOf(this.changeListeners, j));
          }
        }
        this.changeListeners[(this.changeSize++)] = paramChangeListener;
      }
      if (this.changeSize == 1) {
        this.currentValue = ((ObservableMap)this.observable.getValue());
      }
      return this;
    }
    
    protected MapExpressionHelper<K, V> removeListener(ChangeListener<? super ObservableMap<K, V>> paramChangeListener)
    {
      if (this.changeListeners != null) {
        for (int i = 0; i < this.changeSize; i++) {
          if (paramChangeListener.equals(this.changeListeners[i]))
          {
            if (this.changeSize == 1)
            {
              if ((this.invalidationSize == 1) && (this.mapChangeSize == 0)) {
                return new MapExpressionHelper.SingleInvalidation(this.observable, this.invalidationListeners[0], null);
              }
              if ((this.invalidationSize == 0) && (this.mapChangeSize == 1)) {
                return new MapExpressionHelper.SingleMapChange(this.observable, this.mapChangeListeners[0], null);
              }
              this.changeListeners = null;
              this.changeSize = 0;
              break;
            }
            int j = this.changeSize - i - 1;
            ChangeListener[] arrayOfChangeListener = this.changeListeners;
            if (this.locked)
            {
              this.changeListeners = new ChangeListener[this.changeListeners.length];
              System.arraycopy(arrayOfChangeListener, 0, this.changeListeners, 0, i + 1);
            }
            if (j > 0) {
              System.arraycopy(arrayOfChangeListener, i + 1, this.changeListeners, i, j);
            }
            this.changeSize -= 1;
            if (!this.locked) {
              this.changeListeners[(--this.changeSize)] = null;
            }
            break;
          }
        }
      }
      return this;
    }
    
    protected MapExpressionHelper<K, V> addListener(MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      if (this.mapChangeListeners == null)
      {
        this.mapChangeListeners = new MapChangeListener[] { paramMapChangeListener };
        this.mapChangeSize = 1;
      }
      else
      {
        int i = this.mapChangeListeners.length;
        int j;
        if (this.locked)
        {
          j = this.mapChangeSize < i ? i : i * 3 / 2 + 1;
          this.mapChangeListeners = ((MapChangeListener[])Arrays.copyOf(this.mapChangeListeners, j));
        }
        else if (this.mapChangeSize == i)
        {
          this.mapChangeSize = trim(this.mapChangeSize, this.mapChangeListeners);
          if (this.mapChangeSize == i)
          {
            j = i * 3 / 2 + 1;
            this.mapChangeListeners = ((MapChangeListener[])Arrays.copyOf(this.mapChangeListeners, j));
          }
        }
        this.mapChangeListeners[(this.mapChangeSize++)] = paramMapChangeListener;
      }
      if (this.mapChangeSize == 1) {
        this.currentValue = ((ObservableMap)this.observable.getValue());
      }
      return this;
    }
    
    protected MapExpressionHelper<K, V> removeListener(MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      if (this.mapChangeListeners != null) {
        for (int i = 0; i < this.mapChangeSize; i++) {
          if (paramMapChangeListener.equals(this.mapChangeListeners[i]))
          {
            if (this.mapChangeSize == 1)
            {
              if ((this.invalidationSize == 1) && (this.changeSize == 0)) {
                return new MapExpressionHelper.SingleInvalidation(this.observable, this.invalidationListeners[0], null);
              }
              if ((this.invalidationSize == 0) && (this.changeSize == 1)) {
                return new MapExpressionHelper.SingleChange(this.observable, this.changeListeners[0], null);
              }
              this.mapChangeListeners = null;
              this.mapChangeSize = 0;
              break;
            }
            int j = this.mapChangeSize - i - 1;
            MapChangeListener[] arrayOfMapChangeListener = this.mapChangeListeners;
            if (this.locked)
            {
              this.mapChangeListeners = new MapChangeListener[this.mapChangeListeners.length];
              System.arraycopy(arrayOfMapChangeListener, 0, this.mapChangeListeners, 0, i + 1);
            }
            if (j > 0) {
              System.arraycopy(arrayOfMapChangeListener, i + 1, this.mapChangeListeners, i, j);
            }
            this.mapChangeSize -= 1;
            if (!this.locked) {
              this.mapChangeListeners[(--this.mapChangeSize)] = null;
            }
            break;
          }
        }
      }
      return this;
    }
    
    protected void fireValueChangedEvent()
    {
      if ((this.changeSize == 0) && (this.mapChangeSize == 0))
      {
        notifyListeners(this.currentValue, null);
      }
      else
      {
        ObservableMap localObservableMap = this.currentValue;
        this.currentValue = ((ObservableMap)this.observable.getValue());
        notifyListeners(localObservableMap, null);
      }
    }
    
    protected void fireValueChangedEvent(MapChangeListener.Change<? extends K, ? extends V> paramChange)
    {
      MapExpressionHelper.SimpleChange localSimpleChange = this.mapChangeSize == 0 ? null : new MapExpressionHelper.SimpleChange(this.observable, paramChange);
      notifyListeners(this.currentValue, localSimpleChange);
    }
    
    private void notifyListeners(ObservableMap<K, V> paramObservableMap, MapExpressionHelper.SimpleChange<K, V> paramSimpleChange)
    {
      InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
      int i = this.invalidationSize;
      ChangeListener[] arrayOfChangeListener = this.changeListeners;
      int j = this.changeSize;
      MapChangeListener[] arrayOfMapChangeListener = this.mapChangeListeners;
      int k = this.mapChangeSize;
      try
      {
        this.locked = true;
        for (int m = 0; m < i; m++) {
          arrayOfInvalidationListener[m].invalidated(this.observable);
        }
        if ((this.currentValue != paramObservableMap) || (paramSimpleChange != null))
        {
          for (m = 0; m < j; m++) {
            arrayOfChangeListener[m].changed(this.observable, paramObservableMap, this.currentValue);
          }
          if (k > 0) {
            if (paramSimpleChange != null)
            {
              for (m = 0; m < k; m++) {
                arrayOfMapChangeListener[m].onChanged(paramSimpleChange);
              }
            }
            else
            {
              paramSimpleChange = new MapExpressionHelper.SimpleChange(this.observable);
              Iterator localIterator;
              Map.Entry localEntry;
              int n;
              if (this.currentValue == null)
              {
                localIterator = paramObservableMap.entrySet().iterator();
                while (localIterator.hasNext())
                {
                  localEntry = (Map.Entry)localIterator.next();
                  paramSimpleChange.setRemoved(localEntry.getKey(), localEntry.getValue());
                  for (n = 0; n < k; n++) {
                    arrayOfMapChangeListener[n].onChanged(paramSimpleChange);
                  }
                }
              }
              else if (paramObservableMap == null)
              {
                localIterator = this.currentValue.entrySet().iterator();
                while (localIterator.hasNext())
                {
                  localEntry = (Map.Entry)localIterator.next();
                  paramSimpleChange.setAdded(localEntry.getKey(), localEntry.getValue());
                  for (n = 0; n < k; n++) {
                    arrayOfMapChangeListener[n].onChanged(paramSimpleChange);
                  }
                }
              }
              else
              {
                localIterator = paramObservableMap.entrySet().iterator();
                Object localObject1;
                while (localIterator.hasNext())
                {
                  localEntry = (Map.Entry)localIterator.next();
                  localObject1 = localEntry.getKey();
                  Object localObject2 = localEntry.getValue();
                  if (this.currentValue.containsKey(localObject1))
                  {
                    Object localObject3 = this.currentValue.get(localObject1);
                    if (localObject2 == null ? localObject3 != null : !localObject3.equals(localObject2))
                    {
                      paramSimpleChange.setPut(localObject1, localObject2, localObject3);
                      for (int i3 = 0; i3 < k; i3++) {
                        arrayOfMapChangeListener[i3].onChanged(paramSimpleChange);
                      }
                    }
                  }
                  else
                  {
                    paramSimpleChange.setRemoved(localObject1, localObject2);
                    for (int i2 = 0; i2 < k; i2++) {
                      arrayOfMapChangeListener[i2].onChanged(paramSimpleChange);
                    }
                  }
                }
                localIterator = this.currentValue.entrySet().iterator();
                while (localIterator.hasNext())
                {
                  localEntry = (Map.Entry)localIterator.next();
                  localObject1 = localEntry.getKey();
                  if (!paramObservableMap.containsKey(localObject1))
                  {
                    paramSimpleChange.setAdded(localObject1, localEntry.getValue());
                    for (int i1 = 0; i1 < k; i1++) {
                      arrayOfMapChangeListener[i1].onChanged(paramSimpleChange);
                    }
                  }
                }
              }
            }
          }
        }
      }
      finally
      {
        this.locked = false;
      }
    }
  }
  
  public static class SimpleChange<K, V>
    extends MapChangeListener.Change<K, V>
  {
    private K key;
    private V old;
    private V added;
    private boolean removeOp;
    private boolean addOp;
    
    public SimpleChange(ObservableMap<K, V> paramObservableMap)
    {
      super();
    }
    
    public SimpleChange(ObservableMap<K, V> paramObservableMap, MapChangeListener.Change<? extends K, ? extends V> paramChange)
    {
      super();
      this.key = paramChange.getKey();
      this.old = paramChange.getValueRemoved();
      this.added = paramChange.getValueAdded();
      this.addOp = paramChange.wasAdded();
      this.removeOp = paramChange.wasRemoved();
    }
    
    public SimpleChange<K, V> setRemoved(K paramK, V paramV)
    {
      this.key = paramK;
      this.old = paramV;
      this.added = null;
      this.addOp = false;
      this.removeOp = true;
      return this;
    }
    
    public SimpleChange<K, V> setAdded(K paramK, V paramV)
    {
      this.key = paramK;
      this.old = null;
      this.added = paramV;
      this.addOp = true;
      this.removeOp = false;
      return this;
    }
    
    public SimpleChange<K, V> setPut(K paramK, V paramV1, V paramV2)
    {
      this.key = paramK;
      this.old = paramV1;
      this.added = paramV2;
      this.addOp = true;
      this.removeOp = true;
      return this;
    }
    
    public boolean wasAdded()
    {
      return this.addOp;
    }
    
    public boolean wasRemoved()
    {
      return this.removeOp;
    }
    
    public K getKey()
    {
      return (K)this.key;
    }
    
    public V getValueAdded()
    {
      return (V)this.added;
    }
    
    public V getValueRemoved()
    {
      return (V)this.old;
    }
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      if (this.addOp)
      {
        if (this.removeOp) {
          localStringBuilder.append("replaced ").append(this.old).append("by ").append(this.added);
        } else {
          localStringBuilder.append("added ").append(this.added);
        }
      }
      else {
        localStringBuilder.append("removed ").append(this.old);
      }
      localStringBuilder.append(" at key ").append(this.key);
      return localStringBuilder.toString();
    }
  }
  
  private static class SingleChange<K, V>
    extends MapExpressionHelper<K, V>
  {
    private final ChangeListener<? super ObservableMap<K, V>> listener;
    private ObservableMap<K, V> currentValue;
    
    private SingleChange(ObservableMapValue<K, V> paramObservableMapValue, ChangeListener<? super ObservableMap<K, V>> paramChangeListener)
    {
      super();
      this.listener = paramChangeListener;
      this.currentValue = ((ObservableMap)paramObservableMapValue.getValue());
    }
    
    protected MapExpressionHelper<K, V> addListener(InvalidationListener paramInvalidationListener)
    {
      return new MapExpressionHelper.Generic(this.observable, paramInvalidationListener, this.listener, null);
    }
    
    protected MapExpressionHelper<K, V> removeListener(InvalidationListener paramInvalidationListener)
    {
      return this;
    }
    
    protected MapExpressionHelper<K, V> addListener(ChangeListener<? super ObservableMap<K, V>> paramChangeListener)
    {
      return new MapExpressionHelper.Generic(this.observable, this.listener, paramChangeListener, null);
    }
    
    protected MapExpressionHelper<K, V> removeListener(ChangeListener<? super ObservableMap<K, V>> paramChangeListener)
    {
      return paramChangeListener.equals(this.listener) ? null : this;
    }
    
    protected MapExpressionHelper<K, V> addListener(MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      return new MapExpressionHelper.Generic(this.observable, this.listener, paramMapChangeListener, null);
    }
    
    protected MapExpressionHelper<K, V> removeListener(MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      return this;
    }
    
    protected void fireValueChangedEvent()
    {
      ObservableMap localObservableMap = this.currentValue;
      this.currentValue = ((ObservableMap)this.observable.getValue());
      if (this.currentValue != localObservableMap) {
        this.listener.changed(this.observable, localObservableMap, this.currentValue);
      }
    }
    
    protected void fireValueChangedEvent(MapChangeListener.Change<? extends K, ? extends V> paramChange)
    {
      this.listener.changed(this.observable, this.currentValue, this.currentValue);
    }
  }
  
  private static class SingleInvalidation<K, V>
    extends MapExpressionHelper<K, V>
  {
    private final InvalidationListener listener;
    
    private SingleInvalidation(ObservableMapValue<K, V> paramObservableMapValue, InvalidationListener paramInvalidationListener)
    {
      super();
      this.listener = paramInvalidationListener;
    }
    
    protected MapExpressionHelper<K, V> addListener(InvalidationListener paramInvalidationListener)
    {
      return new MapExpressionHelper.Generic(this.observable, this.listener, paramInvalidationListener, null);
    }
    
    protected MapExpressionHelper<K, V> removeListener(InvalidationListener paramInvalidationListener)
    {
      return paramInvalidationListener.equals(this.listener) ? null : this;
    }
    
    protected MapExpressionHelper<K, V> addListener(ChangeListener<? super ObservableMap<K, V>> paramChangeListener)
    {
      return new MapExpressionHelper.Generic(this.observable, this.listener, paramChangeListener, null);
    }
    
    protected MapExpressionHelper<K, V> removeListener(ChangeListener<? super ObservableMap<K, V>> paramChangeListener)
    {
      return this;
    }
    
    protected MapExpressionHelper<K, V> addListener(MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      return new MapExpressionHelper.Generic(this.observable, this.listener, paramMapChangeListener, null);
    }
    
    protected MapExpressionHelper<K, V> removeListener(MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      return this;
    }
    
    protected void fireValueChangedEvent()
    {
      this.listener.invalidated(this.observable);
    }
    
    protected void fireValueChangedEvent(MapChangeListener.Change<? extends K, ? extends V> paramChange)
    {
      this.listener.invalidated(this.observable);
    }
  }
  
  private static class SingleMapChange<K, V>
    extends MapExpressionHelper<K, V>
  {
    private final MapChangeListener<? super K, ? super V> listener;
    private ObservableMap<K, V> currentValue;
    
    private SingleMapChange(ObservableMapValue<K, V> paramObservableMapValue, MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      super();
      this.listener = paramMapChangeListener;
      this.currentValue = ((ObservableMap)paramObservableMapValue.getValue());
    }
    
    protected MapExpressionHelper<K, V> addListener(InvalidationListener paramInvalidationListener)
    {
      return new MapExpressionHelper.Generic(this.observable, paramInvalidationListener, this.listener, null);
    }
    
    protected MapExpressionHelper<K, V> removeListener(InvalidationListener paramInvalidationListener)
    {
      return this;
    }
    
    protected MapExpressionHelper<K, V> addListener(ChangeListener<? super ObservableMap<K, V>> paramChangeListener)
    {
      return new MapExpressionHelper.Generic(this.observable, paramChangeListener, this.listener, null);
    }
    
    protected MapExpressionHelper<K, V> removeListener(ChangeListener<? super ObservableMap<K, V>> paramChangeListener)
    {
      return this;
    }
    
    protected MapExpressionHelper<K, V> addListener(MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      return new MapExpressionHelper.Generic(this.observable, this.listener, paramMapChangeListener, null);
    }
    
    protected MapExpressionHelper<K, V> removeListener(MapChangeListener<? super K, ? super V> paramMapChangeListener)
    {
      return paramMapChangeListener.equals(this.listener) ? null : this;
    }
    
    protected void fireValueChangedEvent()
    {
      ObservableMap localObservableMap = this.currentValue;
      this.currentValue = ((ObservableMap)this.observable.getValue());
      if (this.currentValue != localObservableMap)
      {
        MapExpressionHelper.SimpleChange localSimpleChange = new MapExpressionHelper.SimpleChange(this.observable);
        Iterator localIterator;
        Map.Entry localEntry;
        if (this.currentValue == null)
        {
          localIterator = localObservableMap.entrySet().iterator();
          while (localIterator.hasNext())
          {
            localEntry = (Map.Entry)localIterator.next();
            this.listener.onChanged(localSimpleChange.setRemoved(localEntry.getKey(), localEntry.getValue()));
          }
        }
        else if (localObservableMap == null)
        {
          localIterator = this.currentValue.entrySet().iterator();
          while (localIterator.hasNext())
          {
            localEntry = (Map.Entry)localIterator.next();
            this.listener.onChanged(localSimpleChange.setAdded(localEntry.getKey(), localEntry.getValue()));
          }
        }
        else
        {
          localIterator = localObservableMap.entrySet().iterator();
          Object localObject1;
          while (localIterator.hasNext())
          {
            localEntry = (Map.Entry)localIterator.next();
            localObject1 = localEntry.getKey();
            Object localObject2 = localEntry.getValue();
            if (this.currentValue.containsKey(localObject1))
            {
              Object localObject3 = this.currentValue.get(localObject1);
              if (localObject2 == null ? localObject3 != null : !localObject3.equals(localObject2)) {
                this.listener.onChanged(localSimpleChange.setPut(localObject1, localObject2, localObject3));
              }
            }
            else
            {
              this.listener.onChanged(localSimpleChange.setRemoved(localObject1, localObject2));
            }
          }
          localIterator = this.currentValue.entrySet().iterator();
          while (localIterator.hasNext())
          {
            localEntry = (Map.Entry)localIterator.next();
            localObject1 = localEntry.getKey();
            if (!localObservableMap.containsKey(localObject1)) {
              this.listener.onChanged(localSimpleChange.setAdded(localObject1, localEntry.getValue()));
            }
          }
        }
      }
    }
    
    protected void fireValueChangedEvent(MapChangeListener.Change<? extends K, ? extends V> paramChange)
    {
      this.listener.onChanged(new MapExpressionHelper.SimpleChange(this.observable, paramChange));
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\binding\MapExpressionHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */