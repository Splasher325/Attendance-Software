package com.sun.javafx.binding;

import java.util.Arrays;
import javafx.beans.InvalidationListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

public abstract class ExpressionHelper<T>
  extends ExpressionHelperBase
{
  protected final ObservableValue<T> observable;
  
  public static <T> ExpressionHelper<T> addListener(ExpressionHelper<T> paramExpressionHelper, ObservableValue<T> paramObservableValue, InvalidationListener paramInvalidationListener)
  {
    if ((paramObservableValue == null) || (paramInvalidationListener == null)) {
      throw new NullPointerException();
    }
    paramObservableValue.getValue();
    return paramExpressionHelper == null ? new SingleInvalidation(paramObservableValue, paramInvalidationListener, null) : paramExpressionHelper.addListener(paramInvalidationListener);
  }
  
  public static <T> ExpressionHelper<T> removeListener(ExpressionHelper<T> paramExpressionHelper, InvalidationListener paramInvalidationListener)
  {
    if (paramInvalidationListener == null) {
      throw new NullPointerException();
    }
    return paramExpressionHelper == null ? null : paramExpressionHelper.removeListener(paramInvalidationListener);
  }
  
  public static <T> ExpressionHelper<T> addListener(ExpressionHelper<T> paramExpressionHelper, ObservableValue<T> paramObservableValue, ChangeListener<? super T> paramChangeListener)
  {
    if ((paramObservableValue == null) || (paramChangeListener == null)) {
      throw new NullPointerException();
    }
    return paramExpressionHelper == null ? new SingleChange(paramObservableValue, paramChangeListener, null) : paramExpressionHelper.addListener(paramChangeListener);
  }
  
  public static <T> ExpressionHelper<T> removeListener(ExpressionHelper<T> paramExpressionHelper, ChangeListener<? super T> paramChangeListener)
  {
    if (paramChangeListener == null) {
      throw new NullPointerException();
    }
    return paramExpressionHelper == null ? null : paramExpressionHelper.removeListener(paramChangeListener);
  }
  
  public static <T> void fireValueChangedEvent(ExpressionHelper<T> paramExpressionHelper)
  {
    if (paramExpressionHelper != null) {
      paramExpressionHelper.fireValueChangedEvent();
    }
  }
  
  private ExpressionHelper(ObservableValue<T> paramObservableValue)
  {
    this.observable = paramObservableValue;
  }
  
  protected abstract ExpressionHelper<T> addListener(InvalidationListener paramInvalidationListener);
  
  protected abstract ExpressionHelper<T> removeListener(InvalidationListener paramInvalidationListener);
  
  protected abstract ExpressionHelper<T> addListener(ChangeListener<? super T> paramChangeListener);
  
  protected abstract ExpressionHelper<T> removeListener(ChangeListener<? super T> paramChangeListener);
  
  protected abstract void fireValueChangedEvent();
  
  private static class Generic<T>
    extends ExpressionHelper<T>
  {
    private InvalidationListener[] invalidationListeners;
    private ChangeListener<? super T>[] changeListeners;
    private int invalidationSize;
    private int changeSize;
    private boolean locked;
    private T currentValue;
    
    private Generic(ObservableValue<T> paramObservableValue, InvalidationListener paramInvalidationListener1, InvalidationListener paramInvalidationListener2)
    {
      super(null);
      this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener1, paramInvalidationListener2 };
      this.invalidationSize = 2;
    }
    
    private Generic(ObservableValue<T> paramObservableValue, ChangeListener<? super T> paramChangeListener1, ChangeListener<? super T> paramChangeListener2)
    {
      super(null);
      this.changeListeners = new ChangeListener[] { paramChangeListener1, paramChangeListener2 };
      this.changeSize = 2;
      this.currentValue = paramObservableValue.getValue();
    }
    
    private Generic(ObservableValue<T> paramObservableValue, InvalidationListener paramInvalidationListener, ChangeListener<? super T> paramChangeListener)
    {
      super(null);
      this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener };
      this.invalidationSize = 1;
      this.changeListeners = new ChangeListener[] { paramChangeListener };
      this.changeSize = 1;
      this.currentValue = paramObservableValue.getValue();
    }
    
    protected Generic<T> addListener(InvalidationListener paramInvalidationListener)
    {
      if (this.invalidationListeners == null)
      {
        this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener };
        this.invalidationSize = 1;
      }
      else
      {
        int i = this.invalidationListeners.length;
        int j;
        if (this.locked)
        {
          j = this.invalidationSize < i ? i : i * 3 / 2 + 1;
          this.invalidationListeners = ((InvalidationListener[])Arrays.copyOf(this.invalidationListeners, j));
        }
        else if (this.invalidationSize == i)
        {
          this.invalidationSize = trim(this.invalidationSize, this.invalidationListeners);
          if (this.invalidationSize == i)
          {
            j = i * 3 / 2 + 1;
            this.invalidationListeners = ((InvalidationListener[])Arrays.copyOf(this.invalidationListeners, j));
          }
        }
        this.invalidationListeners[(this.invalidationSize++)] = paramInvalidationListener;
      }
      return this;
    }
    
    protected ExpressionHelper<T> removeListener(InvalidationListener paramInvalidationListener)
    {
      if (this.invalidationListeners != null) {
        for (int i = 0; i < this.invalidationSize; i++) {
          if (paramInvalidationListener.equals(this.invalidationListeners[i]))
          {
            if (this.invalidationSize == 1)
            {
              if (this.changeSize == 1) {
                return new ExpressionHelper.SingleChange(this.observable, this.changeListeners[0], null);
              }
              this.invalidationListeners = null;
              this.invalidationSize = 0;
              break;
            }
            if ((this.invalidationSize == 2) && (this.changeSize == 0)) {
              return new ExpressionHelper.SingleInvalidation(this.observable, this.invalidationListeners[(1 - i)], null);
            }
            int j = this.invalidationSize - i - 1;
            InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
            if (this.locked)
            {
              this.invalidationListeners = new InvalidationListener[this.invalidationListeners.length];
              System.arraycopy(arrayOfInvalidationListener, 0, this.invalidationListeners, 0, i);
            }
            if (j > 0) {
              System.arraycopy(arrayOfInvalidationListener, i + 1, this.invalidationListeners, i, j);
            }
            this.invalidationSize -= 1;
            if (!this.locked) {
              this.invalidationListeners[this.invalidationSize] = null;
            }
            break;
          }
        }
      }
      return this;
    }
    
    protected ExpressionHelper<T> addListener(ChangeListener<? super T> paramChangeListener)
    {
      if (this.changeListeners == null)
      {
        this.changeListeners = new ChangeListener[] { paramChangeListener };
        this.changeSize = 1;
      }
      else
      {
        int i = this.changeListeners.length;
        int j;
        if (this.locked)
        {
          j = this.changeSize < i ? i : i * 3 / 2 + 1;
          this.changeListeners = ((ChangeListener[])Arrays.copyOf(this.changeListeners, j));
        }
        else if (this.changeSize == i)
        {
          this.changeSize = trim(this.changeSize, this.changeListeners);
          if (this.changeSize == i)
          {
            j = i * 3 / 2 + 1;
            this.changeListeners = ((ChangeListener[])Arrays.copyOf(this.changeListeners, j));
          }
        }
        this.changeListeners[(this.changeSize++)] = paramChangeListener;
      }
      if (this.changeSize == 1) {
        this.currentValue = this.observable.getValue();
      }
      return this;
    }
    
    protected ExpressionHelper<T> removeListener(ChangeListener<? super T> paramChangeListener)
    {
      if (this.changeListeners != null) {
        for (int i = 0; i < this.changeSize; i++) {
          if (paramChangeListener.equals(this.changeListeners[i]))
          {
            if (this.changeSize == 1)
            {
              if (this.invalidationSize == 1) {
                return new ExpressionHelper.SingleInvalidation(this.observable, this.invalidationListeners[0], null);
              }
              this.changeListeners = null;
              this.changeSize = 0;
              break;
            }
            if ((this.changeSize == 2) && (this.invalidationSize == 0)) {
              return new ExpressionHelper.SingleChange(this.observable, this.changeListeners[(1 - i)], null);
            }
            int j = this.changeSize - i - 1;
            ChangeListener[] arrayOfChangeListener = this.changeListeners;
            if (this.locked)
            {
              this.changeListeners = new ChangeListener[this.changeListeners.length];
              System.arraycopy(arrayOfChangeListener, 0, this.changeListeners, 0, i);
            }
            if (j > 0) {
              System.arraycopy(arrayOfChangeListener, i + 1, this.changeListeners, i, j);
            }
            this.changeSize -= 1;
            if (!this.locked) {
              this.changeListeners[this.changeSize] = null;
            }
            break;
          }
        }
      }
      return this;
    }
    
    protected void fireValueChangedEvent()
    {
      InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
      int i = this.invalidationSize;
      ChangeListener[] arrayOfChangeListener = this.changeListeners;
      int j = this.changeSize;
      try
      {
        this.locked = true;
        for (int k = 0; k < i; k++) {
          try
          {
            arrayOfInvalidationListener[k].invalidated(this.observable);
          }
          catch (Exception localException1)
          {
            Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), localException1);
          }
        }
        if (j > 0)
        {
          Object localObject1 = this.currentValue;
          this.currentValue = this.observable.getValue();
          int m = !this.currentValue.equals(localObject1) ? 1 : this.currentValue == null ? 0 : localObject1 != null ? 1 : 0;
          if (m != 0) {
            for (int n = 0; n < j; n++) {
              try
              {
                arrayOfChangeListener[n].changed(this.observable, localObject1, this.currentValue);
              }
              catch (Exception localException2)
              {
                Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), localException2);
              }
            }
          }
        }
      }
      finally
      {
        this.locked = false;
      }
    }
  }
  
  private static class SingleChange<T>
    extends ExpressionHelper<T>
  {
    private final ChangeListener<? super T> listener;
    private T currentValue;
    
    private SingleChange(ObservableValue<T> paramObservableValue, ChangeListener<? super T> paramChangeListener)
    {
      super(null);
      this.listener = paramChangeListener;
      this.currentValue = paramObservableValue.getValue();
    }
    
    protected ExpressionHelper<T> addListener(InvalidationListener paramInvalidationListener)
    {
      return new ExpressionHelper.Generic(this.observable, paramInvalidationListener, this.listener, null);
    }
    
    protected ExpressionHelper<T> removeListener(InvalidationListener paramInvalidationListener)
    {
      return this;
    }
    
    protected ExpressionHelper<T> addListener(ChangeListener<? super T> paramChangeListener)
    {
      return new ExpressionHelper.Generic(this.observable, this.listener, paramChangeListener, null);
    }
    
    protected ExpressionHelper<T> removeListener(ChangeListener<? super T> paramChangeListener)
    {
      return paramChangeListener.equals(this.listener) ? null : this;
    }
    
    protected void fireValueChangedEvent()
    {
      Object localObject = this.currentValue;
      this.currentValue = this.observable.getValue();
      int i = !this.currentValue.equals(localObject) ? 1 : this.currentValue == null ? 0 : localObject != null ? 1 : 0;
      if (i != 0) {
        try
        {
          this.listener.changed(this.observable, localObject, this.currentValue);
        }
        catch (Exception localException)
        {
          Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), localException);
        }
      }
    }
  }
  
  private static class SingleInvalidation<T>
    extends ExpressionHelper<T>
  {
    private final InvalidationListener listener;
    
    private SingleInvalidation(ObservableValue<T> paramObservableValue, InvalidationListener paramInvalidationListener)
    {
      super(null);
      this.listener = paramInvalidationListener;
    }
    
    protected ExpressionHelper<T> addListener(InvalidationListener paramInvalidationListener)
    {
      return new ExpressionHelper.Generic(this.observable, this.listener, paramInvalidationListener, null);
    }
    
    protected ExpressionHelper<T> removeListener(InvalidationListener paramInvalidationListener)
    {
      return paramInvalidationListener.equals(this.listener) ? null : this;
    }
    
    protected ExpressionHelper<T> addListener(ChangeListener<? super T> paramChangeListener)
    {
      return new ExpressionHelper.Generic(this.observable, this.listener, paramChangeListener, null);
    }
    
    protected ExpressionHelper<T> removeListener(ChangeListener<? super T> paramChangeListener)
    {
      return this;
    }
    
    protected void fireValueChangedEvent()
    {
      try
      {
        this.listener.invalidated(this.observable);
      }
      catch (Exception localException)
      {
        Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), localException);
      }
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\binding\ExpressionHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */