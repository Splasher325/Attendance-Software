package com.sun.javafx.binding;

import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javafx.beans.WeakListener;
import javafx.collections.ListChangeListener;
import javafx.collections.ListChangeListener.Change;
import javafx.collections.MapChangeListener;
import javafx.collections.MapChangeListener.Change;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.collections.ObservableSet;
import javafx.collections.SetChangeListener;
import javafx.collections.SetChangeListener.Change;

public class ContentBinding
{
  private static void checkParameters(Object paramObject1, Object paramObject2)
  {
    if ((paramObject1 == null) || (paramObject2 == null)) {
      throw new NullPointerException("Both parameters must be specified.");
    }
    if (paramObject1 == paramObject2) {
      throw new IllegalArgumentException("Cannot bind object to itself");
    }
  }
  
  public static <E> Object bind(List<E> paramList, ObservableList<? extends E> paramObservableList)
  {
    checkParameters(paramList, paramObservableList);
    ListContentBinding localListContentBinding = new ListContentBinding(paramList);
    if ((paramList instanceof ObservableList))
    {
      ((ObservableList)paramList).setAll(paramObservableList);
    }
    else
    {
      paramList.clear();
      paramList.addAll(paramObservableList);
    }
    paramObservableList.removeListener(localListContentBinding);
    paramObservableList.addListener(localListContentBinding);
    return localListContentBinding;
  }
  
  public static <E> Object bind(Set<E> paramSet, ObservableSet<? extends E> paramObservableSet)
  {
    checkParameters(paramSet, paramObservableSet);
    SetContentBinding localSetContentBinding = new SetContentBinding(paramSet);
    paramSet.clear();
    paramSet.addAll(paramObservableSet);
    paramObservableSet.removeListener(localSetContentBinding);
    paramObservableSet.addListener(localSetContentBinding);
    return localSetContentBinding;
  }
  
  public static <K, V> Object bind(Map<K, V> paramMap, ObservableMap<? extends K, ? extends V> paramObservableMap)
  {
    checkParameters(paramMap, paramObservableMap);
    MapContentBinding localMapContentBinding = new MapContentBinding(paramMap);
    paramMap.clear();
    paramMap.putAll(paramObservableMap);
    paramObservableMap.removeListener(localMapContentBinding);
    paramObservableMap.addListener(localMapContentBinding);
    return localMapContentBinding;
  }
  
  public static void unbind(Object paramObject1, Object paramObject2)
  {
    checkParameters(paramObject1, paramObject2);
    if (((paramObject1 instanceof List)) && ((paramObject2 instanceof ObservableList))) {
      ((ObservableList)paramObject2).removeListener(new ListContentBinding((List)paramObject1));
    } else if (((paramObject1 instanceof Set)) && ((paramObject2 instanceof ObservableSet))) {
      ((ObservableSet)paramObject2).removeListener(new SetContentBinding((Set)paramObject1));
    } else if (((paramObject1 instanceof Map)) && ((paramObject2 instanceof ObservableMap))) {
      ((ObservableMap)paramObject2).removeListener(new MapContentBinding((Map)paramObject1));
    }
  }
  
  private static class ListContentBinding<E>
    implements ListChangeListener<E>, WeakListener
  {
    private final WeakReference<List<E>> listRef;
    
    public ListContentBinding(List<E> paramList)
    {
      this.listRef = new WeakReference(paramList);
    }
    
    public void onChanged(ListChangeListener.Change<? extends E> paramChange)
    {
      List localList = (List)this.listRef.get();
      if (localList == null) {
        paramChange.getList().removeListener(this);
      } else {
        while (paramChange.next()) {
          if (paramChange.wasPermutated())
          {
            localList.subList(paramChange.getFrom(), paramChange.getTo()).clear();
            localList.addAll(paramChange.getFrom(), paramChange.getList().subList(paramChange.getFrom(), paramChange.getTo()));
          }
          else
          {
            if (paramChange.wasRemoved()) {
              localList.subList(paramChange.getFrom(), paramChange.getFrom() + paramChange.getRemovedSize()).clear();
            }
            if (paramChange.wasAdded()) {
              localList.addAll(paramChange.getFrom(), paramChange.getAddedSubList());
            }
          }
        }
      }
    }
    
    public boolean wasGarbageCollected()
    {
      return this.listRef.get() == null;
    }
    
    public int hashCode()
    {
      List localList = (List)this.listRef.get();
      return localList == null ? 0 : localList.hashCode();
    }
    
    public boolean equals(Object paramObject)
    {
      if (this == paramObject) {
        return true;
      }
      List localList1 = (List)this.listRef.get();
      if (localList1 == null) {
        return false;
      }
      if ((paramObject instanceof ListContentBinding))
      {
        ListContentBinding localListContentBinding = (ListContentBinding)paramObject;
        List localList2 = (List)localListContentBinding.listRef.get();
        return localList1 == localList2;
      }
      return false;
    }
  }
  
  private static class MapContentBinding<K, V>
    implements MapChangeListener<K, V>, WeakListener
  {
    private final WeakReference<Map<K, V>> mapRef;
    
    public MapContentBinding(Map<K, V> paramMap)
    {
      this.mapRef = new WeakReference(paramMap);
    }
    
    public void onChanged(MapChangeListener.Change<? extends K, ? extends V> paramChange)
    {
      Map localMap = (Map)this.mapRef.get();
      if (localMap == null) {
        paramChange.getMap().removeListener(this);
      } else if (paramChange.wasRemoved()) {
        localMap.remove(paramChange.getKey());
      } else {
        localMap.put(paramChange.getKey(), paramChange.getValueAdded());
      }
    }
    
    public boolean wasGarbageCollected()
    {
      return this.mapRef.get() == null;
    }
    
    public int hashCode()
    {
      Map localMap = (Map)this.mapRef.get();
      return localMap == null ? 0 : localMap.hashCode();
    }
    
    public boolean equals(Object paramObject)
    {
      if (this == paramObject) {
        return true;
      }
      Map localMap1 = (Map)this.mapRef.get();
      if (localMap1 == null) {
        return false;
      }
      if ((paramObject instanceof MapContentBinding))
      {
        MapContentBinding localMapContentBinding = (MapContentBinding)paramObject;
        Map localMap2 = (Map)localMapContentBinding.mapRef.get();
        return localMap1 == localMap2;
      }
      return false;
    }
  }
  
  private static class SetContentBinding<E>
    implements SetChangeListener<E>, WeakListener
  {
    private final WeakReference<Set<E>> setRef;
    
    public SetContentBinding(Set<E> paramSet)
    {
      this.setRef = new WeakReference(paramSet);
    }
    
    public void onChanged(SetChangeListener.Change<? extends E> paramChange)
    {
      Set localSet = (Set)this.setRef.get();
      if (localSet == null) {
        paramChange.getSet().removeListener(this);
      } else if (paramChange.wasRemoved()) {
        localSet.remove(paramChange.getElementRemoved());
      } else {
        localSet.add(paramChange.getElementAdded());
      }
    }
    
    public boolean wasGarbageCollected()
    {
      return this.setRef.get() == null;
    }
    
    public int hashCode()
    {
      Set localSet = (Set)this.setRef.get();
      return localSet == null ? 0 : localSet.hashCode();
    }
    
    public boolean equals(Object paramObject)
    {
      if (this == paramObject) {
        return true;
      }
      Set localSet1 = (Set)this.setRef.get();
      if (localSet1 == null) {
        return false;
      }
      if ((paramObject instanceof SetContentBinding))
      {
        SetContentBinding localSetContentBinding = (SetContentBinding)paramObject;
        Set localSet2 = (Set)localSetContentBinding.setRef.get();
        return localSet1 == localSet2;
      }
      return false;
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\binding\ContentBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */