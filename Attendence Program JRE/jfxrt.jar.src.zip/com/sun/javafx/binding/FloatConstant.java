package com.sun.javafx.binding;

import javafx.beans.InvalidationListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableFloatValue;

public final class FloatConstant
  implements ObservableFloatValue
{
  private final float value;
  
  private FloatConstant(float paramFloat)
  {
    this.value = paramFloat;
  }
  
  public static FloatConstant valueOf(float paramFloat)
  {
    return new FloatConstant(paramFloat);
  }
  
  public float get()
  {
    return this.value;
  }
  
  public Float getValue()
  {
    return Float.valueOf(this.value);
  }
  
  public void addListener(InvalidationListener paramInvalidationListener) {}
  
  public void addListener(ChangeListener<? super Number> paramChangeListener) {}
  
  public void removeListener(InvalidationListener paramInvalidationListener) {}
  
  public void removeListener(ChangeListener<? super Number> paramChangeListener) {}
  
  public int intValue()
  {
    return (int)this.value;
  }
  
  public long longValue()
  {
    return this.value;
  }
  
  public float floatValue()
  {
    return this.value;
  }
  
  public double doubleValue()
  {
    return this.value;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\binding\FloatConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */