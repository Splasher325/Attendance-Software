package com.sun.javafx.binding;

import java.lang.ref.WeakReference;
import java.text.Format;
import java.text.ParseException;
import javafx.beans.Observable;
import javafx.beans.WeakListener;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.FloatProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.LongProperty;
import javafx.beans.property.Property;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.util.StringConverter;
import sun.util.logging.PlatformLogger;

public abstract class BidirectionalBinding<T>
  implements ChangeListener<T>, WeakListener
{
  private final int cachedHashCode;
  
  private static void checkParameters(Object paramObject1, Object paramObject2)
  {
    if ((paramObject1 == null) || (paramObject2 == null)) {
      throw new NullPointerException("Both properties must be specified.");
    }
    if (paramObject1 == paramObject2) {
      throw new IllegalArgumentException("Cannot bind property to itself");
    }
  }
  
  public static <T> BidirectionalBinding bind(Property<T> paramProperty1, Property<T> paramProperty2)
  {
    checkParameters(paramProperty1, paramProperty2);
    TypedGenericBidirectionalBinding localTypedGenericBidirectionalBinding = ((paramProperty1 instanceof BooleanProperty)) && ((paramProperty2 instanceof BooleanProperty)) ? new BidirectionalBooleanBinding((BooleanProperty)paramProperty1, (BooleanProperty)paramProperty2, null) : ((paramProperty1 instanceof LongProperty)) && ((paramProperty2 instanceof LongProperty)) ? new BidirectionalLongBinding((LongProperty)paramProperty1, (LongProperty)paramProperty2, null) : ((paramProperty1 instanceof IntegerProperty)) && ((paramProperty2 instanceof IntegerProperty)) ? new BidirectionalIntegerBinding((IntegerProperty)paramProperty1, (IntegerProperty)paramProperty2, null) : ((paramProperty1 instanceof FloatProperty)) && ((paramProperty2 instanceof FloatProperty)) ? new BidirectionalFloatBinding((FloatProperty)paramProperty1, (FloatProperty)paramProperty2, null) : ((paramProperty1 instanceof DoubleProperty)) && ((paramProperty2 instanceof DoubleProperty)) ? new BidirectionalDoubleBinding((DoubleProperty)paramProperty1, (DoubleProperty)paramProperty2, null) : new TypedGenericBidirectionalBinding(paramProperty1, paramProperty2, null);
    paramProperty1.setValue(paramProperty2.getValue());
    paramProperty1.addListener(localTypedGenericBidirectionalBinding);
    paramProperty2.addListener(localTypedGenericBidirectionalBinding);
    return localTypedGenericBidirectionalBinding;
  }
  
  public static Object bind(Property<String> paramProperty, Property<?> paramProperty1, Format paramFormat)
  {
    checkParameters(paramProperty, paramProperty1);
    if (paramFormat == null) {
      throw new NullPointerException("Format cannot be null");
    }
    StringFormatBidirectionalBinding localStringFormatBidirectionalBinding = new StringFormatBidirectionalBinding(paramProperty, paramProperty1, paramFormat);
    paramProperty.setValue(paramFormat.format(paramProperty1.getValue()));
    paramProperty.addListener(localStringFormatBidirectionalBinding);
    paramProperty1.addListener(localStringFormatBidirectionalBinding);
    return localStringFormatBidirectionalBinding;
  }
  
  public static <T> Object bind(Property<String> paramProperty, Property<T> paramProperty1, StringConverter<T> paramStringConverter)
  {
    checkParameters(paramProperty, paramProperty1);
    if (paramStringConverter == null) {
      throw new NullPointerException("Converter cannot be null");
    }
    StringConverterBidirectionalBinding localStringConverterBidirectionalBinding = new StringConverterBidirectionalBinding(paramProperty, paramProperty1, paramStringConverter);
    paramProperty.setValue(paramStringConverter.toString(paramProperty1.getValue()));
    paramProperty.addListener(localStringConverterBidirectionalBinding);
    paramProperty1.addListener(localStringConverterBidirectionalBinding);
    return localStringConverterBidirectionalBinding;
  }
  
  public static <T> void unbind(Property<T> paramProperty1, Property<T> paramProperty2)
  {
    checkParameters(paramProperty1, paramProperty2);
    UntypedGenericBidirectionalBinding localUntypedGenericBidirectionalBinding = new UntypedGenericBidirectionalBinding(paramProperty1, paramProperty2);
    paramProperty1.removeListener(localUntypedGenericBidirectionalBinding);
    paramProperty2.removeListener(localUntypedGenericBidirectionalBinding);
  }
  
  public static void unbind(Object paramObject1, Object paramObject2)
  {
    checkParameters(paramObject1, paramObject2);
    UntypedGenericBidirectionalBinding localUntypedGenericBidirectionalBinding = new UntypedGenericBidirectionalBinding(paramObject1, paramObject2);
    if ((paramObject1 instanceof ObservableValue)) {
      ((ObservableValue)paramObject1).removeListener(localUntypedGenericBidirectionalBinding);
    }
    if ((paramObject2 instanceof Observable)) {
      ((ObservableValue)paramObject2).removeListener(localUntypedGenericBidirectionalBinding);
    }
  }
  
  public static BidirectionalBinding bindNumber(Property<Integer> paramProperty, IntegerProperty paramIntegerProperty)
  {
    return bindNumber(paramProperty, paramIntegerProperty);
  }
  
  public static BidirectionalBinding bindNumber(Property<Long> paramProperty, LongProperty paramLongProperty)
  {
    return bindNumber(paramProperty, paramLongProperty);
  }
  
  public static BidirectionalBinding bindNumber(Property<Float> paramProperty, FloatProperty paramFloatProperty)
  {
    return bindNumber(paramProperty, paramFloatProperty);
  }
  
  public static BidirectionalBinding bindNumber(Property<Double> paramProperty, DoubleProperty paramDoubleProperty)
  {
    return bindNumber(paramProperty, paramDoubleProperty);
  }
  
  public static BidirectionalBinding bindNumber(IntegerProperty paramIntegerProperty, Property<Integer> paramProperty)
  {
    return bindNumberObject(paramIntegerProperty, paramProperty);
  }
  
  public static BidirectionalBinding bindNumber(LongProperty paramLongProperty, Property<Long> paramProperty)
  {
    return bindNumberObject(paramLongProperty, paramProperty);
  }
  
  public static BidirectionalBinding bindNumber(FloatProperty paramFloatProperty, Property<Float> paramProperty)
  {
    return bindNumberObject(paramFloatProperty, paramProperty);
  }
  
  public static BidirectionalBinding bindNumber(DoubleProperty paramDoubleProperty, Property<Double> paramProperty)
  {
    return bindNumberObject(paramDoubleProperty, paramProperty);
  }
  
  private static <T extends Number> BidirectionalBinding bindNumberObject(Property<Number> paramProperty, Property<T> paramProperty1)
  {
    checkParameters(paramProperty, paramProperty1);
    TypedNumberBidirectionalBinding localTypedNumberBidirectionalBinding = new TypedNumberBidirectionalBinding(paramProperty1, paramProperty, null);
    paramProperty.setValue(paramProperty1.getValue());
    paramProperty.addListener(localTypedNumberBidirectionalBinding);
    paramProperty1.addListener(localTypedNumberBidirectionalBinding);
    return localTypedNumberBidirectionalBinding;
  }
  
  private static <T extends Number> BidirectionalBinding bindNumber(Property<T> paramProperty, Property<Number> paramProperty1)
  {
    checkParameters(paramProperty, paramProperty1);
    TypedNumberBidirectionalBinding localTypedNumberBidirectionalBinding = new TypedNumberBidirectionalBinding(paramProperty, paramProperty1, null);
    paramProperty.setValue((Number)paramProperty1.getValue());
    paramProperty.addListener(localTypedNumberBidirectionalBinding);
    paramProperty1.addListener(localTypedNumberBidirectionalBinding);
    return localTypedNumberBidirectionalBinding;
  }
  
  public static <T extends Number> void unbindNumber(Property<T> paramProperty, Property<Number> paramProperty1)
  {
    checkParameters(paramProperty, paramProperty1);
    UntypedGenericBidirectionalBinding localUntypedGenericBidirectionalBinding = new UntypedGenericBidirectionalBinding(paramProperty, paramProperty1);
    if ((paramProperty instanceof ObservableValue)) {
      paramProperty.removeListener(localUntypedGenericBidirectionalBinding);
    }
    if ((paramProperty1 instanceof Observable)) {
      paramProperty1.removeListener(localUntypedGenericBidirectionalBinding);
    }
  }
  
  private BidirectionalBinding(Object paramObject1, Object paramObject2)
  {
    this.cachedHashCode = (paramObject1.hashCode() * paramObject2.hashCode());
  }
  
  protected abstract Object getProperty1();
  
  protected abstract Object getProperty2();
  
  public int hashCode()
  {
    return this.cachedHashCode;
  }
  
  public boolean wasGarbageCollected()
  {
    return (getProperty1() == null) || (getProperty2() == null);
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    Object localObject1 = getProperty1();
    Object localObject2 = getProperty2();
    if ((localObject1 == null) || (localObject2 == null)) {
      return false;
    }
    if ((paramObject instanceof BidirectionalBinding))
    {
      BidirectionalBinding localBidirectionalBinding = (BidirectionalBinding)paramObject;
      Object localObject3 = localBidirectionalBinding.getProperty1();
      Object localObject4 = localBidirectionalBinding.getProperty2();
      if ((localObject3 == null) || (localObject4 == null)) {
        return false;
      }
      if ((localObject1 == localObject3) && (localObject2 == localObject4)) {
        return true;
      }
      if ((localObject1 == localObject4) && (localObject2 == localObject3)) {
        return true;
      }
    }
    return false;
  }
  
  private static class BidirectionalBooleanBinding
    extends BidirectionalBinding<Boolean>
  {
    private final WeakReference<BooleanProperty> propertyRef1;
    private final WeakReference<BooleanProperty> propertyRef2;
    private boolean updating = false;
    
    private BidirectionalBooleanBinding(BooleanProperty paramBooleanProperty1, BooleanProperty paramBooleanProperty2)
    {
      super(paramBooleanProperty2, null);
      this.propertyRef1 = new WeakReference(paramBooleanProperty1);
      this.propertyRef2 = new WeakReference(paramBooleanProperty2);
    }
    
    protected Property<Boolean> getProperty1()
    {
      return (Property)this.propertyRef1.get();
    }
    
    protected Property<Boolean> getProperty2()
    {
      return (Property)this.propertyRef2.get();
    }
    
    public void changed(ObservableValue<? extends Boolean> paramObservableValue, Boolean paramBoolean1, Boolean paramBoolean2)
    {
      if (!this.updating)
      {
        BooleanProperty localBooleanProperty1 = (BooleanProperty)this.propertyRef1.get();
        BooleanProperty localBooleanProperty2 = (BooleanProperty)this.propertyRef2.get();
        if ((localBooleanProperty1 == null) || (localBooleanProperty2 == null))
        {
          if (localBooleanProperty1 != null) {
            localBooleanProperty1.removeListener(this);
          }
          if (localBooleanProperty2 != null) {
            localBooleanProperty2.removeListener(this);
          }
        }
        else
        {
          try
          {
            this.updating = true;
            if (localBooleanProperty1 == paramObservableValue) {
              localBooleanProperty2.set(paramBoolean2.booleanValue());
            } else {
              localBooleanProperty1.set(paramBoolean2.booleanValue());
            }
          }
          catch (RuntimeException localRuntimeException)
          {
            try
            {
              if (localBooleanProperty1 == paramObservableValue) {
                localBooleanProperty1.set(paramBoolean1.booleanValue());
              } else {
                localBooleanProperty2.set(paramBoolean1.booleanValue());
              }
            }
            catch (Exception localException)
            {
              localException.addSuppressed(localRuntimeException);
              unbind(localBooleanProperty1, localBooleanProperty2);
              throw new RuntimeException("Bidirectional binding failed together with an attempt to restore the source property to the previous value. Removing the bidirectional binding from properties " + localBooleanProperty1 + " and " + localBooleanProperty2, localException);
            }
            throw new RuntimeException("Bidirectional binding failed, setting to the previous value", localRuntimeException);
          }
          finally
          {
            this.updating = false;
          }
        }
      }
    }
  }
  
  private static class BidirectionalDoubleBinding
    extends BidirectionalBinding<Number>
  {
    private final WeakReference<DoubleProperty> propertyRef1;
    private final WeakReference<DoubleProperty> propertyRef2;
    private boolean updating = false;
    
    private BidirectionalDoubleBinding(DoubleProperty paramDoubleProperty1, DoubleProperty paramDoubleProperty2)
    {
      super(paramDoubleProperty2, null);
      this.propertyRef1 = new WeakReference(paramDoubleProperty1);
      this.propertyRef2 = new WeakReference(paramDoubleProperty2);
    }
    
    protected Property<Number> getProperty1()
    {
      return (Property)this.propertyRef1.get();
    }
    
    protected Property<Number> getProperty2()
    {
      return (Property)this.propertyRef2.get();
    }
    
    public void changed(ObservableValue<? extends Number> paramObservableValue, Number paramNumber1, Number paramNumber2)
    {
      if (!this.updating)
      {
        DoubleProperty localDoubleProperty1 = (DoubleProperty)this.propertyRef1.get();
        DoubleProperty localDoubleProperty2 = (DoubleProperty)this.propertyRef2.get();
        if ((localDoubleProperty1 == null) || (localDoubleProperty2 == null))
        {
          if (localDoubleProperty1 != null) {
            localDoubleProperty1.removeListener(this);
          }
          if (localDoubleProperty2 != null) {
            localDoubleProperty2.removeListener(this);
          }
        }
        else
        {
          try
          {
            this.updating = true;
            if (localDoubleProperty1 == paramObservableValue) {
              localDoubleProperty2.set(paramNumber2.doubleValue());
            } else {
              localDoubleProperty1.set(paramNumber2.doubleValue());
            }
          }
          catch (RuntimeException localRuntimeException)
          {
            try
            {
              if (localDoubleProperty1 == paramObservableValue) {
                localDoubleProperty1.set(paramNumber1.doubleValue());
              } else {
                localDoubleProperty2.set(paramNumber1.doubleValue());
              }
            }
            catch (Exception localException)
            {
              localException.addSuppressed(localRuntimeException);
              unbind(localDoubleProperty1, localDoubleProperty2);
              throw new RuntimeException("Bidirectional binding failed together with an attempt to restore the source property to the previous value. Removing the bidirectional binding from properties " + localDoubleProperty1 + " and " + localDoubleProperty2, localException);
            }
            throw new RuntimeException("Bidirectional binding failed, setting to the previous value", localRuntimeException);
          }
          finally
          {
            this.updating = false;
          }
        }
      }
    }
  }
  
  private static class BidirectionalFloatBinding
    extends BidirectionalBinding<Number>
  {
    private final WeakReference<FloatProperty> propertyRef1;
    private final WeakReference<FloatProperty> propertyRef2;
    private boolean updating = false;
    
    private BidirectionalFloatBinding(FloatProperty paramFloatProperty1, FloatProperty paramFloatProperty2)
    {
      super(paramFloatProperty2, null);
      this.propertyRef1 = new WeakReference(paramFloatProperty1);
      this.propertyRef2 = new WeakReference(paramFloatProperty2);
    }
    
    protected Property<Number> getProperty1()
    {
      return (Property)this.propertyRef1.get();
    }
    
    protected Property<Number> getProperty2()
    {
      return (Property)this.propertyRef2.get();
    }
    
    public void changed(ObservableValue<? extends Number> paramObservableValue, Number paramNumber1, Number paramNumber2)
    {
      if (!this.updating)
      {
        FloatProperty localFloatProperty1 = (FloatProperty)this.propertyRef1.get();
        FloatProperty localFloatProperty2 = (FloatProperty)this.propertyRef2.get();
        if ((localFloatProperty1 == null) || (localFloatProperty2 == null))
        {
          if (localFloatProperty1 != null) {
            localFloatProperty1.removeListener(this);
          }
          if (localFloatProperty2 != null) {
            localFloatProperty2.removeListener(this);
          }
        }
        else
        {
          try
          {
            this.updating = true;
            if (localFloatProperty1 == paramObservableValue) {
              localFloatProperty2.set(paramNumber2.floatValue());
            } else {
              localFloatProperty1.set(paramNumber2.floatValue());
            }
          }
          catch (RuntimeException localRuntimeException)
          {
            try
            {
              if (localFloatProperty1 == paramObservableValue) {
                localFloatProperty1.set(paramNumber1.floatValue());
              } else {
                localFloatProperty2.set(paramNumber1.floatValue());
              }
            }
            catch (Exception localException)
            {
              localException.addSuppressed(localRuntimeException);
              unbind(localFloatProperty1, localFloatProperty2);
              throw new RuntimeException("Bidirectional binding failed together with an attempt to restore the source property to the previous value. Removing the bidirectional binding from properties " + localFloatProperty1 + " and " + localFloatProperty2, localException);
            }
            throw new RuntimeException("Bidirectional binding failed, setting to the previous value", localRuntimeException);
          }
          finally
          {
            this.updating = false;
          }
        }
      }
    }
  }
  
  private static class BidirectionalIntegerBinding
    extends BidirectionalBinding<Number>
  {
    private final WeakReference<IntegerProperty> propertyRef1;
    private final WeakReference<IntegerProperty> propertyRef2;
    private boolean updating = false;
    
    private BidirectionalIntegerBinding(IntegerProperty paramIntegerProperty1, IntegerProperty paramIntegerProperty2)
    {
      super(paramIntegerProperty2, null);
      this.propertyRef1 = new WeakReference(paramIntegerProperty1);
      this.propertyRef2 = new WeakReference(paramIntegerProperty2);
    }
    
    protected Property<Number> getProperty1()
    {
      return (Property)this.propertyRef1.get();
    }
    
    protected Property<Number> getProperty2()
    {
      return (Property)this.propertyRef2.get();
    }
    
    public void changed(ObservableValue<? extends Number> paramObservableValue, Number paramNumber1, Number paramNumber2)
    {
      if (!this.updating)
      {
        IntegerProperty localIntegerProperty1 = (IntegerProperty)this.propertyRef1.get();
        IntegerProperty localIntegerProperty2 = (IntegerProperty)this.propertyRef2.get();
        if ((localIntegerProperty1 == null) || (localIntegerProperty2 == null))
        {
          if (localIntegerProperty1 != null) {
            localIntegerProperty1.removeListener(this);
          }
          if (localIntegerProperty2 != null) {
            localIntegerProperty2.removeListener(this);
          }
        }
        else
        {
          try
          {
            this.updating = true;
            if (localIntegerProperty1 == paramObservableValue) {
              localIntegerProperty2.set(paramNumber2.intValue());
            } else {
              localIntegerProperty1.set(paramNumber2.intValue());
            }
          }
          catch (RuntimeException localRuntimeException)
          {
            try
            {
              if (localIntegerProperty1 == paramObservableValue) {
                localIntegerProperty1.set(paramNumber1.intValue());
              } else {
                localIntegerProperty2.set(paramNumber1.intValue());
              }
            }
            catch (Exception localException)
            {
              localException.addSuppressed(localRuntimeException);
              unbind(localIntegerProperty1, localIntegerProperty2);
              throw new RuntimeException("Bidirectional binding failed together with an attempt to restore the source property to the previous value. Removing the bidirectional binding from properties " + localIntegerProperty1 + " and " + localIntegerProperty2, localException);
            }
            throw new RuntimeException("Bidirectional binding failed, setting to the previous value", localRuntimeException);
          }
          finally
          {
            this.updating = false;
          }
        }
      }
    }
  }
  
  private static class BidirectionalLongBinding
    extends BidirectionalBinding<Number>
  {
    private final WeakReference<LongProperty> propertyRef1;
    private final WeakReference<LongProperty> propertyRef2;
    private boolean updating = false;
    
    private BidirectionalLongBinding(LongProperty paramLongProperty1, LongProperty paramLongProperty2)
    {
      super(paramLongProperty2, null);
      this.propertyRef1 = new WeakReference(paramLongProperty1);
      this.propertyRef2 = new WeakReference(paramLongProperty2);
    }
    
    protected Property<Number> getProperty1()
    {
      return (Property)this.propertyRef1.get();
    }
    
    protected Property<Number> getProperty2()
    {
      return (Property)this.propertyRef2.get();
    }
    
    public void changed(ObservableValue<? extends Number> paramObservableValue, Number paramNumber1, Number paramNumber2)
    {
      if (!this.updating)
      {
        LongProperty localLongProperty1 = (LongProperty)this.propertyRef1.get();
        LongProperty localLongProperty2 = (LongProperty)this.propertyRef2.get();
        if ((localLongProperty1 == null) || (localLongProperty2 == null))
        {
          if (localLongProperty1 != null) {
            localLongProperty1.removeListener(this);
          }
          if (localLongProperty2 != null) {
            localLongProperty2.removeListener(this);
          }
        }
        else
        {
          try
          {
            this.updating = true;
            if (localLongProperty1 == paramObservableValue) {
              localLongProperty2.set(paramNumber2.longValue());
            } else {
              localLongProperty1.set(paramNumber2.longValue());
            }
          }
          catch (RuntimeException localRuntimeException)
          {
            try
            {
              if (localLongProperty1 == paramObservableValue) {
                localLongProperty1.set(paramNumber1.longValue());
              } else {
                localLongProperty2.set(paramNumber1.longValue());
              }
            }
            catch (Exception localException)
            {
              localException.addSuppressed(localRuntimeException);
              unbind(localLongProperty1, localLongProperty2);
              throw new RuntimeException("Bidirectional binding failed together with an attempt to restore the source property to the previous value. Removing the bidirectional binding from properties " + localLongProperty1 + " and " + localLongProperty2, localException);
            }
            throw new RuntimeException("Bidirectional binding failed, setting to the previous value", localRuntimeException);
          }
          finally
          {
            this.updating = false;
          }
        }
      }
    }
  }
  
  public static abstract class StringConversionBidirectionalBinding<T>
    extends BidirectionalBinding<Object>
  {
    private final WeakReference<Property<String>> stringPropertyRef;
    private final WeakReference<Property<T>> otherPropertyRef;
    private boolean updating;
    
    public StringConversionBidirectionalBinding(Property<String> paramProperty, Property<T> paramProperty1)
    {
      super(paramProperty1, null);
      this.stringPropertyRef = new WeakReference(paramProperty);
      this.otherPropertyRef = new WeakReference(paramProperty1);
    }
    
    protected abstract String toString(T paramT);
    
    protected abstract T fromString(String paramString)
      throws ParseException;
    
    protected Object getProperty1()
    {
      return this.stringPropertyRef.get();
    }
    
    protected Object getProperty2()
    {
      return this.otherPropertyRef.get();
    }
    
    public void changed(ObservableValue<? extends Object> paramObservableValue, Object paramObject1, Object paramObject2)
    {
      if (!this.updating)
      {
        Property localProperty1 = (Property)this.stringPropertyRef.get();
        Property localProperty2 = (Property)this.otherPropertyRef.get();
        if ((localProperty1 == null) || (localProperty2 == null))
        {
          if (localProperty1 != null) {
            localProperty1.removeListener(this);
          }
          if (localProperty2 != null) {
            localProperty2.removeListener(this);
          }
        }
        else
        {
          try
          {
            this.updating = true;
            if (localProperty1 == paramObservableValue) {
              try
              {
                localProperty2.setValue(fromString((String)localProperty1.getValue()));
              }
              catch (Exception localException1)
              {
                Logging.getLogger().warning("Exception while parsing String in bidirectional binding", localException1);
                localProperty2.setValue(null);
              }
            } else {
              try
              {
                localProperty1.setValue(toString(localProperty2.getValue()));
              }
              catch (Exception localException2)
              {
                Logging.getLogger().warning("Exception while converting Object to String in bidirectional binding", localException2);
                localProperty1.setValue("");
              }
            }
          }
          finally
          {
            this.updating = false;
          }
        }
      }
    }
  }
  
  private static class StringConverterBidirectionalBinding<T>
    extends BidirectionalBinding.StringConversionBidirectionalBinding<T>
  {
    private final StringConverter<T> converter;
    
    public StringConverterBidirectionalBinding(Property<String> paramProperty, Property<T> paramProperty1, StringConverter<T> paramStringConverter)
    {
      super(paramProperty1);
      this.converter = paramStringConverter;
    }
    
    protected String toString(T paramT)
    {
      return this.converter.toString(paramT);
    }
    
    protected T fromString(String paramString)
      throws ParseException
    {
      return (T)this.converter.fromString(paramString);
    }
  }
  
  private static class StringFormatBidirectionalBinding
    extends BidirectionalBinding.StringConversionBidirectionalBinding
  {
    private final Format format;
    
    public StringFormatBidirectionalBinding(Property<String> paramProperty, Property<?> paramProperty1, Format paramFormat)
    {
      super(paramProperty1);
      this.format = paramFormat;
    }
    
    protected String toString(Object paramObject)
    {
      return this.format.format(paramObject);
    }
    
    protected Object fromString(String paramString)
      throws ParseException
    {
      return this.format.parseObject(paramString);
    }
  }
  
  private static class TypedGenericBidirectionalBinding<T>
    extends BidirectionalBinding<T>
  {
    private final WeakReference<Property<T>> propertyRef1;
    private final WeakReference<Property<T>> propertyRef2;
    private boolean updating = false;
    
    private TypedGenericBidirectionalBinding(Property<T> paramProperty1, Property<T> paramProperty2)
    {
      super(paramProperty2, null);
      this.propertyRef1 = new WeakReference(paramProperty1);
      this.propertyRef2 = new WeakReference(paramProperty2);
    }
    
    protected Property<T> getProperty1()
    {
      return (Property)this.propertyRef1.get();
    }
    
    protected Property<T> getProperty2()
    {
      return (Property)this.propertyRef2.get();
    }
    
    public void changed(ObservableValue<? extends T> paramObservableValue, T paramT1, T paramT2)
    {
      if (!this.updating)
      {
        Property localProperty1 = (Property)this.propertyRef1.get();
        Property localProperty2 = (Property)this.propertyRef2.get();
        if ((localProperty1 == null) || (localProperty2 == null))
        {
          if (localProperty1 != null) {
            localProperty1.removeListener(this);
          }
          if (localProperty2 != null) {
            localProperty2.removeListener(this);
          }
        }
        else
        {
          try
          {
            this.updating = true;
            if (localProperty1 == paramObservableValue) {
              localProperty2.setValue(paramT2);
            } else {
              localProperty1.setValue(paramT2);
            }
          }
          catch (RuntimeException localRuntimeException)
          {
            try
            {
              if (localProperty1 == paramObservableValue) {
                localProperty1.setValue(paramT1);
              } else {
                localProperty2.setValue(paramT1);
              }
            }
            catch (Exception localException)
            {
              localException.addSuppressed(localRuntimeException);
              unbind(localProperty1, localProperty2);
              throw new RuntimeException("Bidirectional binding failed together with an attempt to restore the source property to the previous value. Removing the bidirectional binding from properties " + localProperty1 + " and " + localProperty2, localException);
            }
            throw new RuntimeException("Bidirectional binding failed, setting to the previous value", localRuntimeException);
          }
          finally
          {
            this.updating = false;
          }
        }
      }
    }
  }
  
  private static class TypedNumberBidirectionalBinding<T extends Number>
    extends BidirectionalBinding<Number>
  {
    private final WeakReference<Property<T>> propertyRef1;
    private final WeakReference<Property<Number>> propertyRef2;
    private boolean updating = false;
    
    private TypedNumberBidirectionalBinding(Property<T> paramProperty, Property<Number> paramProperty1)
    {
      super(paramProperty1, null);
      this.propertyRef1 = new WeakReference(paramProperty);
      this.propertyRef2 = new WeakReference(paramProperty1);
    }
    
    protected Property<T> getProperty1()
    {
      return (Property)this.propertyRef1.get();
    }
    
    protected Property<Number> getProperty2()
    {
      return (Property)this.propertyRef2.get();
    }
    
    public void changed(ObservableValue<? extends Number> paramObservableValue, Number paramNumber1, Number paramNumber2)
    {
      if (!this.updating)
      {
        Property localProperty1 = (Property)this.propertyRef1.get();
        Property localProperty2 = (Property)this.propertyRef2.get();
        if ((localProperty1 == null) || (localProperty2 == null))
        {
          if (localProperty1 != null) {
            localProperty1.removeListener(this);
          }
          if (localProperty2 != null) {
            localProperty2.removeListener(this);
          }
        }
        else
        {
          try
          {
            this.updating = true;
            if (localProperty1 == paramObservableValue) {
              localProperty2.setValue(paramNumber2);
            } else {
              localProperty1.setValue(paramNumber2);
            }
          }
          catch (RuntimeException localRuntimeException)
          {
            try
            {
              if (localProperty1 == paramObservableValue) {
                localProperty1.setValue(paramNumber1);
              } else {
                localProperty2.setValue(paramNumber1);
              }
            }
            catch (Exception localException)
            {
              localException.addSuppressed(localRuntimeException);
              unbind(localProperty1, localProperty2);
              throw new RuntimeException("Bidirectional binding failed together with an attempt to restore the source property to the previous value. Removing the bidirectional binding from properties " + localProperty1 + " and " + localProperty2, localException);
            }
            throw new RuntimeException("Bidirectional binding failed, setting to the previous value", localRuntimeException);
          }
          finally
          {
            this.updating = false;
          }
        }
      }
    }
  }
  
  private static class UntypedGenericBidirectionalBinding
    extends BidirectionalBinding<Object>
  {
    private final Object property1;
    private final Object property2;
    
    public UntypedGenericBidirectionalBinding(Object paramObject1, Object paramObject2)
    {
      super(paramObject2, null);
      this.property1 = paramObject1;
      this.property2 = paramObject2;
    }
    
    protected Object getProperty1()
    {
      return this.property1;
    }
    
    protected Object getProperty2()
    {
      return this.property2;
    }
    
    public void changed(ObservableValue<? extends Object> paramObservableValue, Object paramObject1, Object paramObject2)
    {
      throw new RuntimeException("Should not reach here");
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\binding\BidirectionalBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */