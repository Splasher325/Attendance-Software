package com.sun.javafx.binding;

import javafx.beans.InvalidationListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableObjectValue;

public class ObjectConstant<T>
  implements ObservableObjectValue<T>
{
  private final T value;
  
  private ObjectConstant(T paramT)
  {
    this.value = paramT;
  }
  
  public static <T> ObjectConstant<T> valueOf(T paramT)
  {
    return new ObjectConstant(paramT);
  }
  
  public T get()
  {
    return (T)this.value;
  }
  
  public T getValue()
  {
    return (T)this.value;
  }
  
  public void addListener(InvalidationListener paramInvalidationListener) {}
  
  public void addListener(ChangeListener<? super T> paramChangeListener) {}
  
  public void removeListener(InvalidationListener paramInvalidationListener) {}
  
  public void removeListener(ChangeListener<? super T> paramChangeListener) {}
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\binding\ObjectConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */