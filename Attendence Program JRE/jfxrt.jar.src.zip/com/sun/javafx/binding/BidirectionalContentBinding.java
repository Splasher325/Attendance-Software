package com.sun.javafx.binding;

import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.Set;
import javafx.beans.WeakListener;
import javafx.collections.ListChangeListener;
import javafx.collections.ListChangeListener.Change;
import javafx.collections.MapChangeListener;
import javafx.collections.MapChangeListener.Change;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.collections.ObservableSet;
import javafx.collections.SetChangeListener;
import javafx.collections.SetChangeListener.Change;

public class BidirectionalContentBinding
{
  private static void checkParameters(Object paramObject1, Object paramObject2)
  {
    if ((paramObject1 == null) || (paramObject2 == null)) {
      throw new NullPointerException("Both parameters must be specified.");
    }
    if (paramObject1 == paramObject2) {
      throw new IllegalArgumentException("Cannot bind object to itself");
    }
  }
  
  public static <E> Object bind(ObservableList<E> paramObservableList1, ObservableList<E> paramObservableList2)
  {
    checkParameters(paramObservableList1, paramObservableList2);
    ListContentBinding localListContentBinding = new ListContentBinding(paramObservableList1, paramObservableList2);
    paramObservableList1.setAll(paramObservableList2);
    paramObservableList1.addListener(localListContentBinding);
    paramObservableList2.addListener(localListContentBinding);
    return localListContentBinding;
  }
  
  public static <E> Object bind(ObservableSet<E> paramObservableSet1, ObservableSet<E> paramObservableSet2)
  {
    checkParameters(paramObservableSet1, paramObservableSet2);
    SetContentBinding localSetContentBinding = new SetContentBinding(paramObservableSet1, paramObservableSet2);
    paramObservableSet1.clear();
    paramObservableSet1.addAll(paramObservableSet2);
    paramObservableSet1.addListener(localSetContentBinding);
    paramObservableSet2.addListener(localSetContentBinding);
    return localSetContentBinding;
  }
  
  public static <K, V> Object bind(ObservableMap<K, V> paramObservableMap1, ObservableMap<K, V> paramObservableMap2)
  {
    checkParameters(paramObservableMap1, paramObservableMap2);
    MapContentBinding localMapContentBinding = new MapContentBinding(paramObservableMap1, paramObservableMap2);
    paramObservableMap1.clear();
    paramObservableMap1.putAll(paramObservableMap2);
    paramObservableMap1.addListener(localMapContentBinding);
    paramObservableMap2.addListener(localMapContentBinding);
    return localMapContentBinding;
  }
  
  public static void unbind(Object paramObject1, Object paramObject2)
  {
    checkParameters(paramObject1, paramObject2);
    Object localObject1;
    Object localObject2;
    Object localObject3;
    if (((paramObject1 instanceof ObservableList)) && ((paramObject2 instanceof ObservableList)))
    {
      localObject1 = (ObservableList)paramObject1;
      localObject2 = (ObservableList)paramObject2;
      localObject3 = new ListContentBinding((ObservableList)localObject1, (ObservableList)localObject2);
      ((ObservableList)localObject1).removeListener((ListChangeListener)localObject3);
      ((ObservableList)localObject2).removeListener((ListChangeListener)localObject3);
    }
    else if (((paramObject1 instanceof ObservableSet)) && ((paramObject2 instanceof ObservableSet)))
    {
      localObject1 = (ObservableSet)paramObject1;
      localObject2 = (ObservableSet)paramObject2;
      localObject3 = new SetContentBinding((ObservableSet)localObject1, (ObservableSet)localObject2);
      ((ObservableSet)localObject1).removeListener((SetChangeListener)localObject3);
      ((ObservableSet)localObject2).removeListener((SetChangeListener)localObject3);
    }
    else if (((paramObject1 instanceof ObservableMap)) && ((paramObject2 instanceof ObservableMap)))
    {
      localObject1 = (ObservableMap)paramObject1;
      localObject2 = (ObservableMap)paramObject2;
      localObject3 = new MapContentBinding((ObservableMap)localObject1, (ObservableMap)localObject2);
      ((ObservableMap)localObject1).removeListener((MapChangeListener)localObject3);
      ((ObservableMap)localObject2).removeListener((MapChangeListener)localObject3);
    }
  }
  
  private static class ListContentBinding<E>
    implements ListChangeListener<E>, WeakListener
  {
    private final WeakReference<ObservableList<E>> propertyRef1;
    private final WeakReference<ObservableList<E>> propertyRef2;
    private boolean updating = false;
    
    public ListContentBinding(ObservableList<E> paramObservableList1, ObservableList<E> paramObservableList2)
    {
      this.propertyRef1 = new WeakReference(paramObservableList1);
      this.propertyRef2 = new WeakReference(paramObservableList2);
    }
    
    public void onChanged(ListChangeListener.Change<? extends E> paramChange)
    {
      if (!this.updating)
      {
        ObservableList localObservableList1 = (ObservableList)this.propertyRef1.get();
        ObservableList localObservableList2 = (ObservableList)this.propertyRef2.get();
        if ((localObservableList1 == null) || (localObservableList2 == null))
        {
          if (localObservableList1 != null) {
            localObservableList1.removeListener(this);
          }
          if (localObservableList2 != null) {
            localObservableList2.removeListener(this);
          }
        }
        else
        {
          try
          {
            this.updating = true;
            ObservableList localObservableList3 = localObservableList1 == paramChange.getList() ? localObservableList2 : localObservableList1;
            while (paramChange.next()) {
              if (paramChange.wasPermutated())
              {
                localObservableList3.remove(paramChange.getFrom(), paramChange.getTo());
                localObservableList3.addAll(paramChange.getFrom(), paramChange.getList().subList(paramChange.getFrom(), paramChange.getTo()));
              }
              else
              {
                if (paramChange.wasRemoved()) {
                  localObservableList3.remove(paramChange.getFrom(), paramChange.getFrom() + paramChange.getRemovedSize());
                }
                if (paramChange.wasAdded()) {
                  localObservableList3.addAll(paramChange.getFrom(), paramChange.getAddedSubList());
                }
              }
            }
          }
          finally
          {
            this.updating = false;
          }
        }
      }
    }
    
    public boolean wasGarbageCollected()
    {
      return (this.propertyRef1.get() == null) || (this.propertyRef2.get() == null);
    }
    
    public int hashCode()
    {
      ObservableList localObservableList1 = (ObservableList)this.propertyRef1.get();
      ObservableList localObservableList2 = (ObservableList)this.propertyRef2.get();
      int i = localObservableList1 == null ? 0 : localObservableList1.hashCode();
      int j = localObservableList2 == null ? 0 : localObservableList2.hashCode();
      return i * j;
    }
    
    public boolean equals(Object paramObject)
    {
      if (this == paramObject) {
        return true;
      }
      Object localObject1 = this.propertyRef1.get();
      Object localObject2 = this.propertyRef2.get();
      if ((localObject1 == null) || (localObject2 == null)) {
        return false;
      }
      if ((paramObject instanceof ListContentBinding))
      {
        ListContentBinding localListContentBinding = (ListContentBinding)paramObject;
        Object localObject3 = localListContentBinding.propertyRef1.get();
        Object localObject4 = localListContentBinding.propertyRef2.get();
        if ((localObject3 == null) || (localObject4 == null)) {
          return false;
        }
        if ((localObject1 == localObject3) && (localObject2 == localObject4)) {
          return true;
        }
        if ((localObject1 == localObject4) && (localObject2 == localObject3)) {
          return true;
        }
      }
      return false;
    }
  }
  
  private static class MapContentBinding<K, V>
    implements MapChangeListener<K, V>, WeakListener
  {
    private final WeakReference<ObservableMap<K, V>> propertyRef1;
    private final WeakReference<ObservableMap<K, V>> propertyRef2;
    private boolean updating = false;
    
    public MapContentBinding(ObservableMap<K, V> paramObservableMap1, ObservableMap<K, V> paramObservableMap2)
    {
      this.propertyRef1 = new WeakReference(paramObservableMap1);
      this.propertyRef2 = new WeakReference(paramObservableMap2);
    }
    
    public void onChanged(MapChangeListener.Change<? extends K, ? extends V> paramChange)
    {
      if (!this.updating)
      {
        ObservableMap localObservableMap1 = (ObservableMap)this.propertyRef1.get();
        ObservableMap localObservableMap2 = (ObservableMap)this.propertyRef2.get();
        if ((localObservableMap1 == null) || (localObservableMap2 == null))
        {
          if (localObservableMap1 != null) {
            localObservableMap1.removeListener(this);
          }
          if (localObservableMap2 != null) {
            localObservableMap2.removeListener(this);
          }
        }
        else
        {
          try
          {
            this.updating = true;
            ObservableMap localObservableMap3 = localObservableMap1 == paramChange.getMap() ? localObservableMap2 : localObservableMap1;
            if (paramChange.wasRemoved()) {
              localObservableMap3.remove(paramChange.getKey());
            } else {
              localObservableMap3.put(paramChange.getKey(), paramChange.getValueAdded());
            }
          }
          finally
          {
            this.updating = false;
          }
        }
      }
    }
    
    public boolean wasGarbageCollected()
    {
      return (this.propertyRef1.get() == null) || (this.propertyRef2.get() == null);
    }
    
    public int hashCode()
    {
      ObservableMap localObservableMap1 = (ObservableMap)this.propertyRef1.get();
      ObservableMap localObservableMap2 = (ObservableMap)this.propertyRef2.get();
      int i = localObservableMap1 == null ? 0 : localObservableMap1.hashCode();
      int j = localObservableMap2 == null ? 0 : localObservableMap2.hashCode();
      return i * j;
    }
    
    public boolean equals(Object paramObject)
    {
      if (this == paramObject) {
        return true;
      }
      Object localObject1 = this.propertyRef1.get();
      Object localObject2 = this.propertyRef2.get();
      if ((localObject1 == null) || (localObject2 == null)) {
        return false;
      }
      if ((paramObject instanceof MapContentBinding))
      {
        MapContentBinding localMapContentBinding = (MapContentBinding)paramObject;
        Object localObject3 = localMapContentBinding.propertyRef1.get();
        Object localObject4 = localMapContentBinding.propertyRef2.get();
        if ((localObject3 == null) || (localObject4 == null)) {
          return false;
        }
        if ((localObject1 == localObject3) && (localObject2 == localObject4)) {
          return true;
        }
        if ((localObject1 == localObject4) && (localObject2 == localObject3)) {
          return true;
        }
      }
      return false;
    }
  }
  
  private static class SetContentBinding<E>
    implements SetChangeListener<E>, WeakListener
  {
    private final WeakReference<ObservableSet<E>> propertyRef1;
    private final WeakReference<ObservableSet<E>> propertyRef2;
    private boolean updating = false;
    
    public SetContentBinding(ObservableSet<E> paramObservableSet1, ObservableSet<E> paramObservableSet2)
    {
      this.propertyRef1 = new WeakReference(paramObservableSet1);
      this.propertyRef2 = new WeakReference(paramObservableSet2);
    }
    
    public void onChanged(SetChangeListener.Change<? extends E> paramChange)
    {
      if (!this.updating)
      {
        ObservableSet localObservableSet1 = (ObservableSet)this.propertyRef1.get();
        ObservableSet localObservableSet2 = (ObservableSet)this.propertyRef2.get();
        if ((localObservableSet1 == null) || (localObservableSet2 == null))
        {
          if (localObservableSet1 != null) {
            localObservableSet1.removeListener(this);
          }
          if (localObservableSet2 != null) {
            localObservableSet2.removeListener(this);
          }
        }
        else
        {
          try
          {
            this.updating = true;
            ObservableSet localObservableSet3 = localObservableSet1 == paramChange.getSet() ? localObservableSet2 : localObservableSet1;
            if (paramChange.wasRemoved()) {
              localObservableSet3.remove(paramChange.getElementRemoved());
            } else {
              localObservableSet3.add(paramChange.getElementAdded());
            }
          }
          finally
          {
            this.updating = false;
          }
        }
      }
    }
    
    public boolean wasGarbageCollected()
    {
      return (this.propertyRef1.get() == null) || (this.propertyRef2.get() == null);
    }
    
    public int hashCode()
    {
      ObservableSet localObservableSet1 = (ObservableSet)this.propertyRef1.get();
      ObservableSet localObservableSet2 = (ObservableSet)this.propertyRef2.get();
      int i = localObservableSet1 == null ? 0 : localObservableSet1.hashCode();
      int j = localObservableSet2 == null ? 0 : localObservableSet2.hashCode();
      return i * j;
    }
    
    public boolean equals(Object paramObject)
    {
      if (this == paramObject) {
        return true;
      }
      Object localObject1 = this.propertyRef1.get();
      Object localObject2 = this.propertyRef2.get();
      if ((localObject1 == null) || (localObject2 == null)) {
        return false;
      }
      if ((paramObject instanceof SetContentBinding))
      {
        SetContentBinding localSetContentBinding = (SetContentBinding)paramObject;
        Object localObject3 = localSetContentBinding.propertyRef1.get();
        Object localObject4 = localSetContentBinding.propertyRef2.get();
        if ((localObject3 == null) || (localObject4 == null)) {
          return false;
        }
        if ((localObject1 == localObject3) && (localObject2 == localObject4)) {
          return true;
        }
        if ((localObject1 == localObject4) && (localObject2 == localObject3)) {
          return true;
        }
      }
      return false;
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\binding\BidirectionalContentBinding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */