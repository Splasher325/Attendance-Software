package com.sun.javafx.binding;

import java.util.Arrays;
import java.util.Iterator;
import javafx.beans.InvalidationListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableSetValue;
import javafx.collections.ObservableSet;
import javafx.collections.SetChangeListener;
import javafx.collections.SetChangeListener.Change;

public abstract class SetExpressionHelper<E>
  extends ExpressionHelperBase
{
  protected final ObservableSetValue<E> observable;
  
  public static <E> SetExpressionHelper<E> addListener(SetExpressionHelper<E> paramSetExpressionHelper, ObservableSetValue<E> paramObservableSetValue, InvalidationListener paramInvalidationListener)
  {
    if ((paramObservableSetValue == null) || (paramInvalidationListener == null)) {
      throw new NullPointerException();
    }
    paramObservableSetValue.getValue();
    return paramSetExpressionHelper == null ? new SingleInvalidation(paramObservableSetValue, paramInvalidationListener, null) : paramSetExpressionHelper.addListener(paramInvalidationListener);
  }
  
  public static <E> SetExpressionHelper<E> removeListener(SetExpressionHelper<E> paramSetExpressionHelper, InvalidationListener paramInvalidationListener)
  {
    if (paramInvalidationListener == null) {
      throw new NullPointerException();
    }
    return paramSetExpressionHelper == null ? null : paramSetExpressionHelper.removeListener(paramInvalidationListener);
  }
  
  public static <E> SetExpressionHelper<E> addListener(SetExpressionHelper<E> paramSetExpressionHelper, ObservableSetValue<E> paramObservableSetValue, ChangeListener<? super ObservableSet<E>> paramChangeListener)
  {
    if ((paramObservableSetValue == null) || (paramChangeListener == null)) {
      throw new NullPointerException();
    }
    return paramSetExpressionHelper == null ? new SingleChange(paramObservableSetValue, paramChangeListener, null) : paramSetExpressionHelper.addListener(paramChangeListener);
  }
  
  public static <E> SetExpressionHelper<E> removeListener(SetExpressionHelper<E> paramSetExpressionHelper, ChangeListener<? super ObservableSet<E>> paramChangeListener)
  {
    if (paramChangeListener == null) {
      throw new NullPointerException();
    }
    return paramSetExpressionHelper == null ? null : paramSetExpressionHelper.removeListener(paramChangeListener);
  }
  
  public static <E> SetExpressionHelper<E> addListener(SetExpressionHelper<E> paramSetExpressionHelper, ObservableSetValue<E> paramObservableSetValue, SetChangeListener<? super E> paramSetChangeListener)
  {
    if ((paramObservableSetValue == null) || (paramSetChangeListener == null)) {
      throw new NullPointerException();
    }
    return paramSetExpressionHelper == null ? new SingleSetChange(paramObservableSetValue, paramSetChangeListener, null) : paramSetExpressionHelper.addListener(paramSetChangeListener);
  }
  
  public static <E> SetExpressionHelper<E> removeListener(SetExpressionHelper<E> paramSetExpressionHelper, SetChangeListener<? super E> paramSetChangeListener)
  {
    if (paramSetChangeListener == null) {
      throw new NullPointerException();
    }
    return paramSetExpressionHelper == null ? null : paramSetExpressionHelper.removeListener(paramSetChangeListener);
  }
  
  public static <E> void fireValueChangedEvent(SetExpressionHelper<E> paramSetExpressionHelper)
  {
    if (paramSetExpressionHelper != null) {
      paramSetExpressionHelper.fireValueChangedEvent();
    }
  }
  
  public static <E> void fireValueChangedEvent(SetExpressionHelper<E> paramSetExpressionHelper, SetChangeListener.Change<? extends E> paramChange)
  {
    if (paramSetExpressionHelper != null) {
      paramSetExpressionHelper.fireValueChangedEvent(paramChange);
    }
  }
  
  protected SetExpressionHelper(ObservableSetValue<E> paramObservableSetValue)
  {
    this.observable = paramObservableSetValue;
  }
  
  protected abstract SetExpressionHelper<E> addListener(InvalidationListener paramInvalidationListener);
  
  protected abstract SetExpressionHelper<E> removeListener(InvalidationListener paramInvalidationListener);
  
  protected abstract SetExpressionHelper<E> addListener(ChangeListener<? super ObservableSet<E>> paramChangeListener);
  
  protected abstract SetExpressionHelper<E> removeListener(ChangeListener<? super ObservableSet<E>> paramChangeListener);
  
  protected abstract SetExpressionHelper<E> addListener(SetChangeListener<? super E> paramSetChangeListener);
  
  protected abstract SetExpressionHelper<E> removeListener(SetChangeListener<? super E> paramSetChangeListener);
  
  protected abstract void fireValueChangedEvent();
  
  protected abstract void fireValueChangedEvent(SetChangeListener.Change<? extends E> paramChange);
  
  private static class Generic<E>
    extends SetExpressionHelper<E>
  {
    private InvalidationListener[] invalidationListeners;
    private ChangeListener<? super ObservableSet<E>>[] changeListeners;
    private SetChangeListener<? super E>[] setChangeListeners;
    private int invalidationSize;
    private int changeSize;
    private int setChangeSize;
    private boolean locked;
    private ObservableSet<E> currentValue;
    
    private Generic(ObservableSetValue<E> paramObservableSetValue, InvalidationListener paramInvalidationListener1, InvalidationListener paramInvalidationListener2)
    {
      super();
      this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener1, paramInvalidationListener2 };
      this.invalidationSize = 2;
    }
    
    private Generic(ObservableSetValue<E> paramObservableSetValue, ChangeListener<? super ObservableSet<E>> paramChangeListener1, ChangeListener<? super ObservableSet<E>> paramChangeListener2)
    {
      super();
      this.changeListeners = new ChangeListener[] { paramChangeListener1, paramChangeListener2 };
      this.changeSize = 2;
      this.currentValue = ((ObservableSet)paramObservableSetValue.getValue());
    }
    
    private Generic(ObservableSetValue<E> paramObservableSetValue, SetChangeListener<? super E> paramSetChangeListener1, SetChangeListener<? super E> paramSetChangeListener2)
    {
      super();
      this.setChangeListeners = new SetChangeListener[] { paramSetChangeListener1, paramSetChangeListener2 };
      this.setChangeSize = 2;
      this.currentValue = ((ObservableSet)paramObservableSetValue.getValue());
    }
    
    private Generic(ObservableSetValue<E> paramObservableSetValue, InvalidationListener paramInvalidationListener, ChangeListener<? super ObservableSet<E>> paramChangeListener)
    {
      super();
      this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener };
      this.invalidationSize = 1;
      this.changeListeners = new ChangeListener[] { paramChangeListener };
      this.changeSize = 1;
      this.currentValue = ((ObservableSet)paramObservableSetValue.getValue());
    }
    
    private Generic(ObservableSetValue<E> paramObservableSetValue, InvalidationListener paramInvalidationListener, SetChangeListener<? super E> paramSetChangeListener)
    {
      super();
      this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener };
      this.invalidationSize = 1;
      this.setChangeListeners = new SetChangeListener[] { paramSetChangeListener };
      this.setChangeSize = 1;
      this.currentValue = ((ObservableSet)paramObservableSetValue.getValue());
    }
    
    private Generic(ObservableSetValue<E> paramObservableSetValue, ChangeListener<? super ObservableSet<E>> paramChangeListener, SetChangeListener<? super E> paramSetChangeListener)
    {
      super();
      this.changeListeners = new ChangeListener[] { paramChangeListener };
      this.changeSize = 1;
      this.setChangeListeners = new SetChangeListener[] { paramSetChangeListener };
      this.setChangeSize = 1;
      this.currentValue = ((ObservableSet)paramObservableSetValue.getValue());
    }
    
    protected SetExpressionHelper<E> addListener(InvalidationListener paramInvalidationListener)
    {
      if (this.invalidationListeners == null)
      {
        this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener };
        this.invalidationSize = 1;
      }
      else
      {
        int i = this.invalidationListeners.length;
        int j;
        if (this.locked)
        {
          j = this.invalidationSize < i ? i : i * 3 / 2 + 1;
          this.invalidationListeners = ((InvalidationListener[])Arrays.copyOf(this.invalidationListeners, j));
        }
        else if (this.invalidationSize == i)
        {
          this.invalidationSize = trim(this.invalidationSize, this.invalidationListeners);
          if (this.invalidationSize == i)
          {
            j = i * 3 / 2 + 1;
            this.invalidationListeners = ((InvalidationListener[])Arrays.copyOf(this.invalidationListeners, j));
          }
        }
        this.invalidationListeners[(this.invalidationSize++)] = paramInvalidationListener;
      }
      return this;
    }
    
    protected SetExpressionHelper<E> removeListener(InvalidationListener paramInvalidationListener)
    {
      if (this.invalidationListeners != null) {
        for (int i = 0; i < this.invalidationSize; i++) {
          if (paramInvalidationListener.equals(this.invalidationListeners[i]))
          {
            if (this.invalidationSize == 1)
            {
              if ((this.changeSize == 1) && (this.setChangeSize == 0)) {
                return new SetExpressionHelper.SingleChange(this.observable, this.changeListeners[0], null);
              }
              if ((this.changeSize == 0) && (this.setChangeSize == 1)) {
                return new SetExpressionHelper.SingleSetChange(this.observable, this.setChangeListeners[0], null);
              }
              this.invalidationListeners = null;
              this.invalidationSize = 0;
              break;
            }
            int j = this.invalidationSize - i - 1;
            InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
            if (this.locked)
            {
              this.invalidationListeners = new InvalidationListener[this.invalidationListeners.length];
              System.arraycopy(arrayOfInvalidationListener, 0, this.invalidationListeners, 0, i + 1);
            }
            if (j > 0) {
              System.arraycopy(arrayOfInvalidationListener, i + 1, this.invalidationListeners, i, j);
            }
            this.invalidationSize -= 1;
            if (!this.locked) {
              this.invalidationListeners[(--this.invalidationSize)] = null;
            }
            break;
          }
        }
      }
      return this;
    }
    
    protected SetExpressionHelper<E> addListener(ChangeListener<? super ObservableSet<E>> paramChangeListener)
    {
      if (this.changeListeners == null)
      {
        this.changeListeners = new ChangeListener[] { paramChangeListener };
        this.changeSize = 1;
      }
      else
      {
        int i = this.changeListeners.length;
        int j;
        if (this.locked)
        {
          j = this.changeSize < i ? i : i * 3 / 2 + 1;
          this.changeListeners = ((ChangeListener[])Arrays.copyOf(this.changeListeners, j));
        }
        else if (this.changeSize == i)
        {
          this.changeSize = trim(this.changeSize, this.changeListeners);
          if (this.changeSize == i)
          {
            j = i * 3 / 2 + 1;
            this.changeListeners = ((ChangeListener[])Arrays.copyOf(this.changeListeners, j));
          }
        }
        this.changeListeners[(this.changeSize++)] = paramChangeListener;
      }
      if (this.changeSize == 1) {
        this.currentValue = ((ObservableSet)this.observable.getValue());
      }
      return this;
    }
    
    protected SetExpressionHelper<E> removeListener(ChangeListener<? super ObservableSet<E>> paramChangeListener)
    {
      if (this.changeListeners != null) {
        for (int i = 0; i < this.changeSize; i++) {
          if (paramChangeListener.equals(this.changeListeners[i]))
          {
            if (this.changeSize == 1)
            {
              if ((this.invalidationSize == 1) && (this.setChangeSize == 0)) {
                return new SetExpressionHelper.SingleInvalidation(this.observable, this.invalidationListeners[0], null);
              }
              if ((this.invalidationSize == 0) && (this.setChangeSize == 1)) {
                return new SetExpressionHelper.SingleSetChange(this.observable, this.setChangeListeners[0], null);
              }
              this.changeListeners = null;
              this.changeSize = 0;
              break;
            }
            int j = this.changeSize - i - 1;
            ChangeListener[] arrayOfChangeListener = this.changeListeners;
            if (this.locked)
            {
              this.changeListeners = new ChangeListener[this.changeListeners.length];
              System.arraycopy(arrayOfChangeListener, 0, this.changeListeners, 0, i + 1);
            }
            if (j > 0) {
              System.arraycopy(arrayOfChangeListener, i + 1, this.changeListeners, i, j);
            }
            this.changeSize -= 1;
            if (!this.locked) {
              this.changeListeners[this.changeSize] = null;
            }
            break;
          }
        }
      }
      return this;
    }
    
    protected SetExpressionHelper<E> addListener(SetChangeListener<? super E> paramSetChangeListener)
    {
      if (this.setChangeListeners == null)
      {
        this.setChangeListeners = new SetChangeListener[] { paramSetChangeListener };
        this.setChangeSize = 1;
      }
      else
      {
        int i = this.setChangeListeners.length;
        int j;
        if (this.locked)
        {
          j = this.setChangeSize < i ? i : i * 3 / 2 + 1;
          this.setChangeListeners = ((SetChangeListener[])Arrays.copyOf(this.setChangeListeners, j));
        }
        else if (this.setChangeSize == i)
        {
          this.setChangeSize = trim(this.setChangeSize, this.setChangeListeners);
          if (this.setChangeSize == i)
          {
            j = i * 3 / 2 + 1;
            this.setChangeListeners = ((SetChangeListener[])Arrays.copyOf(this.setChangeListeners, j));
          }
        }
        this.setChangeListeners[(this.setChangeSize++)] = paramSetChangeListener;
      }
      if (this.setChangeSize == 1) {
        this.currentValue = ((ObservableSet)this.observable.getValue());
      }
      return this;
    }
    
    protected SetExpressionHelper<E> removeListener(SetChangeListener<? super E> paramSetChangeListener)
    {
      if (this.setChangeListeners != null) {
        for (int i = 0; i < this.setChangeSize; i++) {
          if (paramSetChangeListener.equals(this.setChangeListeners[i]))
          {
            if (this.setChangeSize == 1)
            {
              if ((this.invalidationSize == 1) && (this.changeSize == 0)) {
                return new SetExpressionHelper.SingleInvalidation(this.observable, this.invalidationListeners[0], null);
              }
              if ((this.invalidationSize == 0) && (this.changeSize == 1)) {
                return new SetExpressionHelper.SingleChange(this.observable, this.changeListeners[0], null);
              }
              this.setChangeListeners = null;
              this.setChangeSize = 0;
              break;
            }
            int j = this.setChangeSize - i - 1;
            SetChangeListener[] arrayOfSetChangeListener = this.setChangeListeners;
            if (this.locked)
            {
              this.setChangeListeners = new SetChangeListener[this.setChangeListeners.length];
              System.arraycopy(arrayOfSetChangeListener, 0, this.setChangeListeners, 0, i + 1);
            }
            if (j > 0) {
              System.arraycopy(arrayOfSetChangeListener, i + 1, this.setChangeListeners, i, j);
            }
            this.setChangeSize -= 1;
            if (!this.locked) {
              this.setChangeListeners[this.setChangeSize] = null;
            }
            break;
          }
        }
      }
      return this;
    }
    
    protected void fireValueChangedEvent()
    {
      if ((this.changeSize == 0) && (this.setChangeSize == 0))
      {
        notifyListeners(this.currentValue, null);
      }
      else
      {
        ObservableSet localObservableSet = this.currentValue;
        this.currentValue = ((ObservableSet)this.observable.getValue());
        notifyListeners(localObservableSet, null);
      }
    }
    
    protected void fireValueChangedEvent(SetChangeListener.Change<? extends E> paramChange)
    {
      SetExpressionHelper.SimpleChange localSimpleChange = this.setChangeSize == 0 ? null : new SetExpressionHelper.SimpleChange(this.observable, paramChange);
      notifyListeners(this.currentValue, localSimpleChange);
    }
    
    private void notifyListeners(ObservableSet<E> paramObservableSet, SetExpressionHelper.SimpleChange<E> paramSimpleChange)
    {
      InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
      int i = this.invalidationSize;
      ChangeListener[] arrayOfChangeListener = this.changeListeners;
      int j = this.changeSize;
      SetChangeListener[] arrayOfSetChangeListener = this.setChangeListeners;
      int k = this.setChangeSize;
      try
      {
        this.locked = true;
        for (int m = 0; m < i; m++) {
          arrayOfInvalidationListener[m].invalidated(this.observable);
        }
        if ((this.currentValue != paramObservableSet) || (paramSimpleChange != null))
        {
          for (m = 0; m < j; m++) {
            arrayOfChangeListener[m].changed(this.observable, paramObservableSet, this.currentValue);
          }
          if (k > 0) {
            if (paramSimpleChange != null)
            {
              for (m = 0; m < k; m++) {
                arrayOfSetChangeListener[m].onChanged(paramSimpleChange);
              }
            }
            else
            {
              paramSimpleChange = new SetExpressionHelper.SimpleChange(this.observable);
              Iterator localIterator;
              Object localObject1;
              int n;
              if (this.currentValue == null)
              {
                localIterator = paramObservableSet.iterator();
                while (localIterator.hasNext())
                {
                  localObject1 = localIterator.next();
                  paramSimpleChange.setRemoved(localObject1);
                  for (n = 0; n < k; n++) {
                    arrayOfSetChangeListener[n].onChanged(paramSimpleChange);
                  }
                }
              }
              else if (paramObservableSet == null)
              {
                localIterator = this.currentValue.iterator();
                while (localIterator.hasNext())
                {
                  localObject1 = localIterator.next();
                  paramSimpleChange.setAdded(localObject1);
                  for (n = 0; n < k; n++) {
                    arrayOfSetChangeListener[n].onChanged(paramSimpleChange);
                  }
                }
              }
              else
              {
                localIterator = paramObservableSet.iterator();
                while (localIterator.hasNext())
                {
                  localObject1 = localIterator.next();
                  if (!this.currentValue.contains(localObject1))
                  {
                    paramSimpleChange.setRemoved(localObject1);
                    for (n = 0; n < k; n++) {
                      arrayOfSetChangeListener[n].onChanged(paramSimpleChange);
                    }
                  }
                }
                localIterator = this.currentValue.iterator();
                while (localIterator.hasNext())
                {
                  localObject1 = localIterator.next();
                  if (!paramObservableSet.contains(localObject1))
                  {
                    paramSimpleChange.setAdded(localObject1);
                    for (n = 0; n < k; n++) {
                      arrayOfSetChangeListener[n].onChanged(paramSimpleChange);
                    }
                  }
                }
              }
            }
          }
        }
      }
      finally
      {
        this.locked = false;
      }
    }
  }
  
  public static class SimpleChange<E>
    extends SetChangeListener.Change<E>
  {
    private E old;
    private E added;
    private boolean addOp;
    
    public SimpleChange(ObservableSet<E> paramObservableSet)
    {
      super();
    }
    
    public SimpleChange(ObservableSet<E> paramObservableSet, SetChangeListener.Change<? extends E> paramChange)
    {
      super();
      this.old = paramChange.getElementRemoved();
      this.added = paramChange.getElementAdded();
      this.addOp = paramChange.wasAdded();
    }
    
    public SimpleChange<E> setRemoved(E paramE)
    {
      this.old = paramE;
      this.added = null;
      this.addOp = false;
      return this;
    }
    
    public SimpleChange<E> setAdded(E paramE)
    {
      this.old = null;
      this.added = paramE;
      this.addOp = true;
      return this;
    }
    
    public boolean wasAdded()
    {
      return this.addOp;
    }
    
    public boolean wasRemoved()
    {
      return !this.addOp;
    }
    
    public E getElementAdded()
    {
      return (E)this.added;
    }
    
    public E getElementRemoved()
    {
      return (E)this.old;
    }
    
    public String toString()
    {
      return "removed " + this.old;
    }
  }
  
  private static class SingleChange<E>
    extends SetExpressionHelper<E>
  {
    private final ChangeListener<? super ObservableSet<E>> listener;
    private ObservableSet<E> currentValue;
    
    private SingleChange(ObservableSetValue<E> paramObservableSetValue, ChangeListener<? super ObservableSet<E>> paramChangeListener)
    {
      super();
      this.listener = paramChangeListener;
      this.currentValue = ((ObservableSet)paramObservableSetValue.getValue());
    }
    
    protected SetExpressionHelper<E> addListener(InvalidationListener paramInvalidationListener)
    {
      return new SetExpressionHelper.Generic(this.observable, paramInvalidationListener, this.listener, null);
    }
    
    protected SetExpressionHelper<E> removeListener(InvalidationListener paramInvalidationListener)
    {
      return this;
    }
    
    protected SetExpressionHelper<E> addListener(ChangeListener<? super ObservableSet<E>> paramChangeListener)
    {
      return new SetExpressionHelper.Generic(this.observable, this.listener, paramChangeListener, null);
    }
    
    protected SetExpressionHelper<E> removeListener(ChangeListener<? super ObservableSet<E>> paramChangeListener)
    {
      return paramChangeListener.equals(this.listener) ? null : this;
    }
    
    protected SetExpressionHelper<E> addListener(SetChangeListener<? super E> paramSetChangeListener)
    {
      return new SetExpressionHelper.Generic(this.observable, this.listener, paramSetChangeListener, null);
    }
    
    protected SetExpressionHelper<E> removeListener(SetChangeListener<? super E> paramSetChangeListener)
    {
      return this;
    }
    
    protected void fireValueChangedEvent()
    {
      ObservableSet localObservableSet = this.currentValue;
      this.currentValue = ((ObservableSet)this.observable.getValue());
      if (this.currentValue != localObservableSet) {
        this.listener.changed(this.observable, localObservableSet, this.currentValue);
      }
    }
    
    protected void fireValueChangedEvent(SetChangeListener.Change<? extends E> paramChange)
    {
      this.listener.changed(this.observable, this.currentValue, this.currentValue);
    }
  }
  
  private static class SingleInvalidation<E>
    extends SetExpressionHelper<E>
  {
    private final InvalidationListener listener;
    
    private SingleInvalidation(ObservableSetValue<E> paramObservableSetValue, InvalidationListener paramInvalidationListener)
    {
      super();
      this.listener = paramInvalidationListener;
    }
    
    protected SetExpressionHelper<E> addListener(InvalidationListener paramInvalidationListener)
    {
      return new SetExpressionHelper.Generic(this.observable, this.listener, paramInvalidationListener, null);
    }
    
    protected SetExpressionHelper<E> removeListener(InvalidationListener paramInvalidationListener)
    {
      return paramInvalidationListener.equals(this.listener) ? null : this;
    }
    
    protected SetExpressionHelper<E> addListener(ChangeListener<? super ObservableSet<E>> paramChangeListener)
    {
      return new SetExpressionHelper.Generic(this.observable, this.listener, paramChangeListener, null);
    }
    
    protected SetExpressionHelper<E> removeListener(ChangeListener<? super ObservableSet<E>> paramChangeListener)
    {
      return this;
    }
    
    protected SetExpressionHelper<E> addListener(SetChangeListener<? super E> paramSetChangeListener)
    {
      return new SetExpressionHelper.Generic(this.observable, this.listener, paramSetChangeListener, null);
    }
    
    protected SetExpressionHelper<E> removeListener(SetChangeListener<? super E> paramSetChangeListener)
    {
      return this;
    }
    
    protected void fireValueChangedEvent()
    {
      this.listener.invalidated(this.observable);
    }
    
    protected void fireValueChangedEvent(SetChangeListener.Change<? extends E> paramChange)
    {
      this.listener.invalidated(this.observable);
    }
  }
  
  private static class SingleSetChange<E>
    extends SetExpressionHelper<E>
  {
    private final SetChangeListener<? super E> listener;
    private ObservableSet<E> currentValue;
    
    private SingleSetChange(ObservableSetValue<E> paramObservableSetValue, SetChangeListener<? super E> paramSetChangeListener)
    {
      super();
      this.listener = paramSetChangeListener;
      this.currentValue = ((ObservableSet)paramObservableSetValue.getValue());
    }
    
    protected SetExpressionHelper<E> addListener(InvalidationListener paramInvalidationListener)
    {
      return new SetExpressionHelper.Generic(this.observable, paramInvalidationListener, this.listener, null);
    }
    
    protected SetExpressionHelper<E> removeListener(InvalidationListener paramInvalidationListener)
    {
      return this;
    }
    
    protected SetExpressionHelper<E> addListener(ChangeListener<? super ObservableSet<E>> paramChangeListener)
    {
      return new SetExpressionHelper.Generic(this.observable, paramChangeListener, this.listener, null);
    }
    
    protected SetExpressionHelper<E> removeListener(ChangeListener<? super ObservableSet<E>> paramChangeListener)
    {
      return this;
    }
    
    protected SetExpressionHelper<E> addListener(SetChangeListener<? super E> paramSetChangeListener)
    {
      return new SetExpressionHelper.Generic(this.observable, this.listener, paramSetChangeListener, null);
    }
    
    protected SetExpressionHelper<E> removeListener(SetChangeListener<? super E> paramSetChangeListener)
    {
      return paramSetChangeListener.equals(this.listener) ? null : this;
    }
    
    protected void fireValueChangedEvent()
    {
      ObservableSet localObservableSet = this.currentValue;
      this.currentValue = ((ObservableSet)this.observable.getValue());
      if (this.currentValue != localObservableSet)
      {
        SetExpressionHelper.SimpleChange localSimpleChange = new SetExpressionHelper.SimpleChange(this.observable);
        Iterator localIterator;
        Object localObject;
        if (this.currentValue == null)
        {
          localIterator = localObservableSet.iterator();
          while (localIterator.hasNext())
          {
            localObject = localIterator.next();
            this.listener.onChanged(localSimpleChange.setRemoved(localObject));
          }
        }
        else if (localObservableSet == null)
        {
          localIterator = this.currentValue.iterator();
          while (localIterator.hasNext())
          {
            localObject = localIterator.next();
            this.listener.onChanged(localSimpleChange.setAdded(localObject));
          }
        }
        else
        {
          localIterator = localObservableSet.iterator();
          while (localIterator.hasNext())
          {
            localObject = localIterator.next();
            if (!this.currentValue.contains(localObject)) {
              this.listener.onChanged(localSimpleChange.setRemoved(localObject));
            }
          }
          localIterator = this.currentValue.iterator();
          while (localIterator.hasNext())
          {
            localObject = localIterator.next();
            if (!localObservableSet.contains(localObject)) {
              this.listener.onChanged(localSimpleChange.setAdded(localObject));
            }
          }
        }
      }
    }
    
    protected void fireValueChangedEvent(SetChangeListener.Change<? extends E> paramChange)
    {
      this.listener.onChanged(new SetExpressionHelper.SimpleChange(this.observable, paramChange));
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\binding\SetExpressionHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */