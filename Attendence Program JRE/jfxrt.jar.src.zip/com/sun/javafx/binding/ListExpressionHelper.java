package com.sun.javafx.binding;

import com.sun.javafx.collections.NonIterableChange.GenericAddRemoveChange;
import com.sun.javafx.collections.SourceAdapterChange;
import java.util.Arrays;
import javafx.beans.InvalidationListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableListValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ListChangeListener.Change;
import javafx.collections.ObservableList;

public abstract class ListExpressionHelper<E>
  extends ExpressionHelperBase
{
  protected final ObservableListValue<E> observable;
  
  public static <E> ListExpressionHelper<E> addListener(ListExpressionHelper<E> paramListExpressionHelper, ObservableListValue<E> paramObservableListValue, InvalidationListener paramInvalidationListener)
  {
    if ((paramObservableListValue == null) || (paramInvalidationListener == null)) {
      throw new NullPointerException();
    }
    paramObservableListValue.getValue();
    return paramListExpressionHelper == null ? new SingleInvalidation(paramObservableListValue, paramInvalidationListener, null) : paramListExpressionHelper.addListener(paramInvalidationListener);
  }
  
  public static <E> ListExpressionHelper<E> removeListener(ListExpressionHelper<E> paramListExpressionHelper, InvalidationListener paramInvalidationListener)
  {
    if (paramInvalidationListener == null) {
      throw new NullPointerException();
    }
    return paramListExpressionHelper == null ? null : paramListExpressionHelper.removeListener(paramInvalidationListener);
  }
  
  public static <E> ListExpressionHelper<E> addListener(ListExpressionHelper<E> paramListExpressionHelper, ObservableListValue<E> paramObservableListValue, ChangeListener<? super ObservableList<E>> paramChangeListener)
  {
    if ((paramObservableListValue == null) || (paramChangeListener == null)) {
      throw new NullPointerException();
    }
    return paramListExpressionHelper == null ? new SingleChange(paramObservableListValue, paramChangeListener, null) : paramListExpressionHelper.addListener(paramChangeListener);
  }
  
  public static <E> ListExpressionHelper<E> removeListener(ListExpressionHelper<E> paramListExpressionHelper, ChangeListener<? super ObservableList<E>> paramChangeListener)
  {
    if (paramChangeListener == null) {
      throw new NullPointerException();
    }
    return paramListExpressionHelper == null ? null : paramListExpressionHelper.removeListener(paramChangeListener);
  }
  
  public static <E> ListExpressionHelper<E> addListener(ListExpressionHelper<E> paramListExpressionHelper, ObservableListValue<E> paramObservableListValue, ListChangeListener<? super E> paramListChangeListener)
  {
    if ((paramObservableListValue == null) || (paramListChangeListener == null)) {
      throw new NullPointerException();
    }
    return paramListExpressionHelper == null ? new SingleListChange(paramObservableListValue, paramListChangeListener, null) : paramListExpressionHelper.addListener(paramListChangeListener);
  }
  
  public static <E> ListExpressionHelper<E> removeListener(ListExpressionHelper<E> paramListExpressionHelper, ListChangeListener<? super E> paramListChangeListener)
  {
    if (paramListChangeListener == null) {
      throw new NullPointerException();
    }
    return paramListExpressionHelper == null ? null : paramListExpressionHelper.removeListener(paramListChangeListener);
  }
  
  public static <E> void fireValueChangedEvent(ListExpressionHelper<E> paramListExpressionHelper)
  {
    if (paramListExpressionHelper != null) {
      paramListExpressionHelper.fireValueChangedEvent();
    }
  }
  
  public static <E> void fireValueChangedEvent(ListExpressionHelper<E> paramListExpressionHelper, ListChangeListener.Change<? extends E> paramChange)
  {
    if (paramListExpressionHelper != null) {
      paramListExpressionHelper.fireValueChangedEvent(paramChange);
    }
  }
  
  protected ListExpressionHelper(ObservableListValue<E> paramObservableListValue)
  {
    this.observable = paramObservableListValue;
  }
  
  protected abstract ListExpressionHelper<E> addListener(InvalidationListener paramInvalidationListener);
  
  protected abstract ListExpressionHelper<E> removeListener(InvalidationListener paramInvalidationListener);
  
  protected abstract ListExpressionHelper<E> addListener(ChangeListener<? super ObservableList<E>> paramChangeListener);
  
  protected abstract ListExpressionHelper<E> removeListener(ChangeListener<? super ObservableList<E>> paramChangeListener);
  
  protected abstract ListExpressionHelper<E> addListener(ListChangeListener<? super E> paramListChangeListener);
  
  protected abstract ListExpressionHelper<E> removeListener(ListChangeListener<? super E> paramListChangeListener);
  
  protected abstract void fireValueChangedEvent();
  
  protected abstract void fireValueChangedEvent(ListChangeListener.Change<? extends E> paramChange);
  
  private static class Generic<E>
    extends ListExpressionHelper<E>
  {
    private InvalidationListener[] invalidationListeners;
    private ChangeListener<? super ObservableList<E>>[] changeListeners;
    private ListChangeListener<? super E>[] listChangeListeners;
    private int invalidationSize;
    private int changeSize;
    private int listChangeSize;
    private boolean locked;
    private ObservableList<E> currentValue;
    
    private Generic(ObservableListValue<E> paramObservableListValue, InvalidationListener paramInvalidationListener1, InvalidationListener paramInvalidationListener2)
    {
      super();
      this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener1, paramInvalidationListener2 };
      this.invalidationSize = 2;
    }
    
    private Generic(ObservableListValue<E> paramObservableListValue, ChangeListener<? super ObservableList<E>> paramChangeListener1, ChangeListener<? super ObservableList<E>> paramChangeListener2)
    {
      super();
      this.changeListeners = new ChangeListener[] { paramChangeListener1, paramChangeListener2 };
      this.changeSize = 2;
      this.currentValue = ((ObservableList)paramObservableListValue.getValue());
    }
    
    private Generic(ObservableListValue<E> paramObservableListValue, ListChangeListener<? super E> paramListChangeListener1, ListChangeListener<? super E> paramListChangeListener2)
    {
      super();
      this.listChangeListeners = new ListChangeListener[] { paramListChangeListener1, paramListChangeListener2 };
      this.listChangeSize = 2;
      this.currentValue = ((ObservableList)paramObservableListValue.getValue());
    }
    
    private Generic(ObservableListValue<E> paramObservableListValue, InvalidationListener paramInvalidationListener, ChangeListener<? super ObservableList<E>> paramChangeListener)
    {
      super();
      this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener };
      this.invalidationSize = 1;
      this.changeListeners = new ChangeListener[] { paramChangeListener };
      this.changeSize = 1;
      this.currentValue = ((ObservableList)paramObservableListValue.getValue());
    }
    
    private Generic(ObservableListValue<E> paramObservableListValue, InvalidationListener paramInvalidationListener, ListChangeListener<? super E> paramListChangeListener)
    {
      super();
      this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener };
      this.invalidationSize = 1;
      this.listChangeListeners = new ListChangeListener[] { paramListChangeListener };
      this.listChangeSize = 1;
      this.currentValue = ((ObservableList)paramObservableListValue.getValue());
    }
    
    private Generic(ObservableListValue<E> paramObservableListValue, ChangeListener<? super ObservableList<E>> paramChangeListener, ListChangeListener<? super E> paramListChangeListener)
    {
      super();
      this.changeListeners = new ChangeListener[] { paramChangeListener };
      this.changeSize = 1;
      this.listChangeListeners = new ListChangeListener[] { paramListChangeListener };
      this.listChangeSize = 1;
      this.currentValue = ((ObservableList)paramObservableListValue.getValue());
    }
    
    protected ListExpressionHelper<E> addListener(InvalidationListener paramInvalidationListener)
    {
      if (this.invalidationListeners == null)
      {
        this.invalidationListeners = new InvalidationListener[] { paramInvalidationListener };
        this.invalidationSize = 1;
      }
      else
      {
        int i = this.invalidationListeners.length;
        int j;
        if (this.locked)
        {
          j = this.invalidationSize < i ? i : i * 3 / 2 + 1;
          this.invalidationListeners = ((InvalidationListener[])Arrays.copyOf(this.invalidationListeners, j));
        }
        else if (this.invalidationSize == i)
        {
          this.invalidationSize = trim(this.invalidationSize, this.invalidationListeners);
          if (this.invalidationSize == i)
          {
            j = i * 3 / 2 + 1;
            this.invalidationListeners = ((InvalidationListener[])Arrays.copyOf(this.invalidationListeners, j));
          }
        }
        this.invalidationListeners[(this.invalidationSize++)] = paramInvalidationListener;
      }
      return this;
    }
    
    protected ListExpressionHelper<E> removeListener(InvalidationListener paramInvalidationListener)
    {
      if (this.invalidationListeners != null) {
        for (int i = 0; i < this.invalidationSize; i++) {
          if (paramInvalidationListener.equals(this.invalidationListeners[i]))
          {
            if (this.invalidationSize == 1)
            {
              if ((this.changeSize == 1) && (this.listChangeSize == 0)) {
                return new ListExpressionHelper.SingleChange(this.observable, this.changeListeners[0], null);
              }
              if ((this.changeSize == 0) && (this.listChangeSize == 1)) {
                return new ListExpressionHelper.SingleListChange(this.observable, this.listChangeListeners[0], null);
              }
              this.invalidationListeners = null;
              this.invalidationSize = 0;
              break;
            }
            if ((this.invalidationSize == 2) && (this.changeSize == 0) && (this.listChangeSize == 0)) {
              return new ListExpressionHelper.SingleInvalidation(this.observable, this.invalidationListeners[(1 - i)], null);
            }
            int j = this.invalidationSize - i - 1;
            InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
            if (this.locked)
            {
              this.invalidationListeners = new InvalidationListener[this.invalidationListeners.length];
              System.arraycopy(arrayOfInvalidationListener, 0, this.invalidationListeners, 0, i + 1);
            }
            if (j > 0) {
              System.arraycopy(arrayOfInvalidationListener, i + 1, this.invalidationListeners, i, j);
            }
            this.invalidationSize -= 1;
            if (!this.locked) {
              this.invalidationListeners[this.invalidationSize] = null;
            }
            break;
          }
        }
      }
      return this;
    }
    
    protected ListExpressionHelper<E> addListener(ChangeListener<? super ObservableList<E>> paramChangeListener)
    {
      if (this.changeListeners == null)
      {
        this.changeListeners = new ChangeListener[] { paramChangeListener };
        this.changeSize = 1;
      }
      else
      {
        int i = this.changeListeners.length;
        int j;
        if (this.locked)
        {
          j = this.changeSize < i ? i : i * 3 / 2 + 1;
          this.changeListeners = ((ChangeListener[])Arrays.copyOf(this.changeListeners, j));
        }
        else if (this.changeSize == i)
        {
          this.changeSize = trim(this.changeSize, this.changeListeners);
          if (this.changeSize == i)
          {
            j = i * 3 / 2 + 1;
            this.changeListeners = ((ChangeListener[])Arrays.copyOf(this.changeListeners, j));
          }
        }
        this.changeListeners[(this.changeSize++)] = paramChangeListener;
      }
      if (this.changeSize == 1) {
        this.currentValue = ((ObservableList)this.observable.getValue());
      }
      return this;
    }
    
    protected ListExpressionHelper<E> removeListener(ChangeListener<? super ObservableList<E>> paramChangeListener)
    {
      if (this.changeListeners != null) {
        for (int i = 0; i < this.changeSize; i++) {
          if (paramChangeListener.equals(this.changeListeners[i]))
          {
            if (this.changeSize == 1)
            {
              if ((this.invalidationSize == 1) && (this.listChangeSize == 0)) {
                return new ListExpressionHelper.SingleInvalidation(this.observable, this.invalidationListeners[0], null);
              }
              if ((this.invalidationSize == 0) && (this.listChangeSize == 1)) {
                return new ListExpressionHelper.SingleListChange(this.observable, this.listChangeListeners[0], null);
              }
              this.changeListeners = null;
              this.changeSize = 0;
              break;
            }
            if ((this.changeSize == 2) && (this.invalidationSize == 0) && (this.listChangeSize == 0)) {
              return new ListExpressionHelper.SingleChange(this.observable, this.changeListeners[(1 - i)], null);
            }
            int j = this.changeSize - i - 1;
            ChangeListener[] arrayOfChangeListener = this.changeListeners;
            if (this.locked)
            {
              this.changeListeners = new ChangeListener[this.changeListeners.length];
              System.arraycopy(arrayOfChangeListener, 0, this.changeListeners, 0, i + 1);
            }
            if (j > 0) {
              System.arraycopy(arrayOfChangeListener, i + 1, this.changeListeners, i, j);
            }
            this.changeSize -= 1;
            if (!this.locked) {
              this.changeListeners[this.changeSize] = null;
            }
            break;
          }
        }
      }
      return this;
    }
    
    protected ListExpressionHelper<E> addListener(ListChangeListener<? super E> paramListChangeListener)
    {
      if (this.listChangeListeners == null)
      {
        this.listChangeListeners = new ListChangeListener[] { paramListChangeListener };
        this.listChangeSize = 1;
      }
      else
      {
        int i = this.listChangeListeners.length;
        int j;
        if (this.locked)
        {
          j = this.listChangeSize < i ? i : i * 3 / 2 + 1;
          this.listChangeListeners = ((ListChangeListener[])Arrays.copyOf(this.listChangeListeners, j));
        }
        else if (this.listChangeSize == i)
        {
          this.listChangeSize = trim(this.listChangeSize, this.listChangeListeners);
          if (this.listChangeSize == i)
          {
            j = i * 3 / 2 + 1;
            this.listChangeListeners = ((ListChangeListener[])Arrays.copyOf(this.listChangeListeners, j));
          }
        }
        this.listChangeListeners[(this.listChangeSize++)] = paramListChangeListener;
      }
      if (this.listChangeSize == 1) {
        this.currentValue = ((ObservableList)this.observable.getValue());
      }
      return this;
    }
    
    protected ListExpressionHelper<E> removeListener(ListChangeListener<? super E> paramListChangeListener)
    {
      if (this.listChangeListeners != null) {
        for (int i = 0; i < this.listChangeSize; i++) {
          if (paramListChangeListener.equals(this.listChangeListeners[i]))
          {
            if (this.listChangeSize == 1)
            {
              if ((this.invalidationSize == 1) && (this.changeSize == 0)) {
                return new ListExpressionHelper.SingleInvalidation(this.observable, this.invalidationListeners[0], null);
              }
              if ((this.invalidationSize == 0) && (this.changeSize == 1)) {
                return new ListExpressionHelper.SingleChange(this.observable, this.changeListeners[0], null);
              }
              this.listChangeListeners = null;
              this.listChangeSize = 0;
              break;
            }
            if ((this.listChangeSize == 2) && (this.invalidationSize == 0) && (this.changeSize == 0)) {
              return new ListExpressionHelper.SingleListChange(this.observable, this.listChangeListeners[(1 - i)], null);
            }
            int j = this.listChangeSize - i - 1;
            ListChangeListener[] arrayOfListChangeListener = this.listChangeListeners;
            if (this.locked)
            {
              this.listChangeListeners = new ListChangeListener[this.listChangeListeners.length];
              System.arraycopy(arrayOfListChangeListener, 0, this.listChangeListeners, 0, i + 1);
            }
            if (j > 0) {
              System.arraycopy(arrayOfListChangeListener, i + 1, this.listChangeListeners, i, j);
            }
            this.listChangeSize -= 1;
            if (!this.locked) {
              this.listChangeListeners[this.listChangeSize] = null;
            }
            break;
          }
        }
      }
      return this;
    }
    
    protected void fireValueChangedEvent()
    {
      if ((this.changeSize == 0) && (this.listChangeSize == 0))
      {
        notifyListeners(this.currentValue, null, false);
      }
      else
      {
        ObservableList localObservableList1 = this.currentValue;
        this.currentValue = ((ObservableList)this.observable.getValue());
        if (this.currentValue != localObservableList1)
        {
          NonIterableChange.GenericAddRemoveChange localGenericAddRemoveChange = null;
          if (this.listChangeSize > 0)
          {
            int i = this.currentValue == null ? 0 : this.currentValue.size();
            ObservableList localObservableList2 = localObservableList1 == null ? FXCollections.emptyObservableList() : FXCollections.unmodifiableObservableList(localObservableList1);
            localGenericAddRemoveChange = new NonIterableChange.GenericAddRemoveChange(0, i, localObservableList2, this.observable);
          }
          notifyListeners(localObservableList1, localGenericAddRemoveChange, false);
        }
        else
        {
          notifyListeners(this.currentValue, null, true);
        }
      }
    }
    
    protected void fireValueChangedEvent(ListChangeListener.Change<? extends E> paramChange)
    {
      SourceAdapterChange localSourceAdapterChange = this.listChangeSize == 0 ? null : new SourceAdapterChange(this.observable, paramChange);
      notifyListeners(this.currentValue, localSourceAdapterChange, false);
    }
    
    private void notifyListeners(ObservableList<E> paramObservableList, ListChangeListener.Change<E> paramChange, boolean paramBoolean)
    {
      InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
      int i = this.invalidationSize;
      ChangeListener[] arrayOfChangeListener = this.changeListeners;
      int j = this.changeSize;
      ListChangeListener[] arrayOfListChangeListener = this.listChangeListeners;
      int k = this.listChangeSize;
      try
      {
        this.locked = true;
        for (int m = 0; m < i; m++) {
          arrayOfInvalidationListener[m].invalidated(this.observable);
        }
        if (!paramBoolean)
        {
          for (m = 0; m < j; m++) {
            arrayOfChangeListener[m].changed(this.observable, paramObservableList, this.currentValue);
          }
          if (paramChange != null) {
            for (m = 0; m < k; m++)
            {
              paramChange.reset();
              arrayOfListChangeListener[m].onChanged(paramChange);
            }
          }
        }
      }
      finally
      {
        this.locked = false;
      }
    }
  }
  
  private static class SingleChange<E>
    extends ListExpressionHelper<E>
  {
    private final ChangeListener<? super ObservableList<E>> listener;
    private ObservableList<E> currentValue;
    
    private SingleChange(ObservableListValue<E> paramObservableListValue, ChangeListener<? super ObservableList<E>> paramChangeListener)
    {
      super();
      this.listener = paramChangeListener;
      this.currentValue = ((ObservableList)paramObservableListValue.getValue());
    }
    
    protected ListExpressionHelper<E> addListener(InvalidationListener paramInvalidationListener)
    {
      return new ListExpressionHelper.Generic(this.observable, paramInvalidationListener, this.listener, null);
    }
    
    protected ListExpressionHelper<E> removeListener(InvalidationListener paramInvalidationListener)
    {
      return this;
    }
    
    protected ListExpressionHelper<E> addListener(ChangeListener<? super ObservableList<E>> paramChangeListener)
    {
      return new ListExpressionHelper.Generic(this.observable, this.listener, paramChangeListener, null);
    }
    
    protected ListExpressionHelper<E> removeListener(ChangeListener<? super ObservableList<E>> paramChangeListener)
    {
      return paramChangeListener.equals(this.listener) ? null : this;
    }
    
    protected ListExpressionHelper<E> addListener(ListChangeListener<? super E> paramListChangeListener)
    {
      return new ListExpressionHelper.Generic(this.observable, this.listener, paramListChangeListener, null);
    }
    
    protected ListExpressionHelper<E> removeListener(ListChangeListener<? super E> paramListChangeListener)
    {
      return this;
    }
    
    protected void fireValueChangedEvent()
    {
      ObservableList localObservableList = this.currentValue;
      this.currentValue = ((ObservableList)this.observable.getValue());
      if (this.currentValue != localObservableList) {
        this.listener.changed(this.observable, localObservableList, this.currentValue);
      }
    }
    
    protected void fireValueChangedEvent(ListChangeListener.Change<? extends E> paramChange)
    {
      this.listener.changed(this.observable, this.currentValue, this.currentValue);
    }
  }
  
  private static class SingleInvalidation<E>
    extends ListExpressionHelper<E>
  {
    private final InvalidationListener listener;
    
    private SingleInvalidation(ObservableListValue<E> paramObservableListValue, InvalidationListener paramInvalidationListener)
    {
      super();
      this.listener = paramInvalidationListener;
    }
    
    protected ListExpressionHelper<E> addListener(InvalidationListener paramInvalidationListener)
    {
      return new ListExpressionHelper.Generic(this.observable, this.listener, paramInvalidationListener, null);
    }
    
    protected ListExpressionHelper<E> removeListener(InvalidationListener paramInvalidationListener)
    {
      return paramInvalidationListener.equals(this.listener) ? null : this;
    }
    
    protected ListExpressionHelper<E> addListener(ChangeListener<? super ObservableList<E>> paramChangeListener)
    {
      return new ListExpressionHelper.Generic(this.observable, this.listener, paramChangeListener, null);
    }
    
    protected ListExpressionHelper<E> removeListener(ChangeListener<? super ObservableList<E>> paramChangeListener)
    {
      return this;
    }
    
    protected ListExpressionHelper<E> addListener(ListChangeListener<? super E> paramListChangeListener)
    {
      return new ListExpressionHelper.Generic(this.observable, this.listener, paramListChangeListener, null);
    }
    
    protected ListExpressionHelper<E> removeListener(ListChangeListener<? super E> paramListChangeListener)
    {
      return this;
    }
    
    protected void fireValueChangedEvent()
    {
      this.listener.invalidated(this.observable);
    }
    
    protected void fireValueChangedEvent(ListChangeListener.Change<? extends E> paramChange)
    {
      this.listener.invalidated(this.observable);
    }
  }
  
  private static class SingleListChange<E>
    extends ListExpressionHelper<E>
  {
    private final ListChangeListener<? super E> listener;
    private ObservableList<E> currentValue;
    
    private SingleListChange(ObservableListValue<E> paramObservableListValue, ListChangeListener<? super E> paramListChangeListener)
    {
      super();
      this.listener = paramListChangeListener;
      this.currentValue = ((ObservableList)paramObservableListValue.getValue());
    }
    
    protected ListExpressionHelper<E> addListener(InvalidationListener paramInvalidationListener)
    {
      return new ListExpressionHelper.Generic(this.observable, paramInvalidationListener, this.listener, null);
    }
    
    protected ListExpressionHelper<E> removeListener(InvalidationListener paramInvalidationListener)
    {
      return this;
    }
    
    protected ListExpressionHelper<E> addListener(ChangeListener<? super ObservableList<E>> paramChangeListener)
    {
      return new ListExpressionHelper.Generic(this.observable, paramChangeListener, this.listener, null);
    }
    
    protected ListExpressionHelper<E> removeListener(ChangeListener<? super ObservableList<E>> paramChangeListener)
    {
      return this;
    }
    
    protected ListExpressionHelper<E> addListener(ListChangeListener<? super E> paramListChangeListener)
    {
      return new ListExpressionHelper.Generic(this.observable, this.listener, paramListChangeListener, null);
    }
    
    protected ListExpressionHelper<E> removeListener(ListChangeListener<? super E> paramListChangeListener)
    {
      return paramListChangeListener.equals(this.listener) ? null : this;
    }
    
    protected void fireValueChangedEvent()
    {
      ObservableList localObservableList1 = this.currentValue;
      this.currentValue = ((ObservableList)this.observable.getValue());
      if (this.currentValue != localObservableList1)
      {
        int i = this.currentValue == null ? 0 : this.currentValue.size();
        ObservableList localObservableList2 = localObservableList1 == null ? FXCollections.emptyObservableList() : FXCollections.unmodifiableObservableList(localObservableList1);
        NonIterableChange.GenericAddRemoveChange localGenericAddRemoveChange = new NonIterableChange.GenericAddRemoveChange(0, i, localObservableList2, this.observable);
        this.listener.onChanged(localGenericAddRemoveChange);
      }
    }
    
    protected void fireValueChangedEvent(ListChangeListener.Change<? extends E> paramChange)
    {
      this.listener.onChanged(new SourceAdapterChange(this.observable, paramChange));
    }
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\binding\ListExpressionHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */