package com.sun.javafx.binding;

import javafx.beans.InvalidationListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableDoubleValue;

public final class DoubleConstant
  implements ObservableDoubleValue
{
  private final double value;
  
  private DoubleConstant(double paramDouble)
  {
    this.value = paramDouble;
  }
  
  public static DoubleConstant valueOf(double paramDouble)
  {
    return new DoubleConstant(paramDouble);
  }
  
  public double get()
  {
    return this.value;
  }
  
  public Double getValue()
  {
    return Double.valueOf(this.value);
  }
  
  public void addListener(InvalidationListener paramInvalidationListener) {}
  
  public void addListener(ChangeListener<? super Number> paramChangeListener) {}
  
  public void removeListener(InvalidationListener paramInvalidationListener) {}
  
  public void removeListener(ChangeListener<? super Number> paramChangeListener) {}
  
  public int intValue()
  {
    return (int)this.value;
  }
  
  public long longValue()
  {
    return this.value;
  }
  
  public float floatValue()
  {
    return (float)this.value;
  }
  
  public double doubleValue()
  {
    return this.value;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\binding\DoubleConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */