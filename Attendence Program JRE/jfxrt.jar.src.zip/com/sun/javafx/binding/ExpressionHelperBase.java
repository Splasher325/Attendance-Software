package com.sun.javafx.binding;

import javafx.beans.WeakListener;

public class ExpressionHelperBase
{
  protected static int trim(int paramInt, Object[] paramArrayOfObject)
  {
    for (int i = 0; i < paramInt; i++)
    {
      Object localObject = paramArrayOfObject[i];
      if (((localObject instanceof WeakListener)) && (((WeakListener)localObject).wasGarbageCollected()))
      {
        int j = paramInt - i - 1;
        if (j > 0) {
          System.arraycopy(paramArrayOfObject, i + 1, paramArrayOfObject, i, j);
        }
        paramArrayOfObject[(--paramInt)] = null;
        i--;
      }
    }
    return paramInt;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\binding\ExpressionHelperBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */