package com.sun.javafx.application;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javafx.application.Application;
import javafx.application.Application.Parameters;

public class ParametersImpl
  extends Application.Parameters
{
  private List<String> rawArgs = new ArrayList();
  private Map<String, String> namedParams = new HashMap();
  private List<String> unnamedParams = new ArrayList();
  private List<String> readonlyRawArgs = null;
  private Map<String, String> readonlyNamedParams = null;
  private List<String> readonlyUnnamedParams = null;
  private static Map<Application, Application.Parameters> params = new HashMap();
  
  public ParametersImpl() {}
  
  public ParametersImpl(List<String> paramList)
  {
    if (paramList != null) {
      init(paramList);
    }
  }
  
  public ParametersImpl(String[] paramArrayOfString)
  {
    if (paramArrayOfString != null) {
      init(Arrays.asList(paramArrayOfString));
    }
  }
  
  public ParametersImpl(Map paramMap, String[] paramArrayOfString)
  {
    init(paramMap, paramArrayOfString);
  }
  
  private void init(List<String> paramList)
  {
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      if (str != null) {
        this.rawArgs.add(str);
      }
    }
    computeNamedParams();
    computeUnnamedParams();
  }
  
  private void init(Map paramMap, String[] paramArrayOfString)
  {
    Object localObject1 = paramMap.entrySet().iterator();
    Object localObject4;
    while (((Iterator)localObject1).hasNext())
    {
      Object localObject2 = ((Iterator)localObject1).next();
      Object localObject3 = ((Map.Entry)localObject2).getKey();
      if (validKey(localObject3))
      {
        localObject4 = paramMap.get(localObject3);
        if ((localObject4 instanceof String)) {
          this.namedParams.put((String)localObject3, (String)localObject4);
        }
      }
    }
    computeRawArgs();
    if (paramArrayOfString != null) {
      for (localObject4 : paramArrayOfString)
      {
        this.unnamedParams.add(localObject4);
        this.rawArgs.add(localObject4);
      }
    }
  }
  
  private boolean validFirstChar(char paramChar)
  {
    return (Character.isLetter(paramChar)) || (paramChar == '_');
  }
  
  private boolean validKey(Object paramObject)
  {
    if ((paramObject instanceof String))
    {
      String str = (String)paramObject;
      if ((str.length() > 0) && (str.indexOf('=') < 0)) {
        return validFirstChar(str.charAt(0));
      }
    }
    return false;
  }
  
  private boolean isNamedParam(String paramString)
  {
    if (paramString.startsWith("--")) {
      return (paramString.indexOf('=') > 2) && (validFirstChar(paramString.charAt(2)));
    }
    return false;
  }
  
  private void computeUnnamedParams()
  {
    Iterator localIterator = this.rawArgs.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      if (!isNamedParam(str)) {
        this.unnamedParams.add(str);
      }
    }
  }
  
  private void computeNamedParams()
  {
    Iterator localIterator = this.rawArgs.iterator();
    while (localIterator.hasNext())
    {
      String str1 = (String)localIterator.next();
      if (isNamedParam(str1))
      {
        int i = str1.indexOf('=');
        String str2 = str1.substring(2, i);
        String str3 = str1.substring(i + 1);
        this.namedParams.put(str2, str3);
      }
    }
  }
  
  private void computeRawArgs()
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.addAll(this.namedParams.keySet());
    Collections.sort(localArrayList);
    Iterator localIterator = localArrayList.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      this.rawArgs.add("--" + str + "=" + (String)this.namedParams.get(str));
    }
  }
  
  public List<String> getRaw()
  {
    if (this.readonlyRawArgs == null) {
      this.readonlyRawArgs = Collections.unmodifiableList(this.rawArgs);
    }
    return this.readonlyRawArgs;
  }
  
  public Map<String, String> getNamed()
  {
    if (this.readonlyNamedParams == null) {
      this.readonlyNamedParams = Collections.unmodifiableMap(this.namedParams);
    }
    return this.readonlyNamedParams;
  }
  
  public List<String> getUnnamed()
  {
    if (this.readonlyUnnamedParams == null) {
      this.readonlyUnnamedParams = Collections.unmodifiableList(this.unnamedParams);
    }
    return this.readonlyUnnamedParams;
  }
  
  public static Application.Parameters getParameters(Application paramApplication)
  {
    Application.Parameters localParameters = (Application.Parameters)params.get(paramApplication);
    return localParameters;
  }
  
  public static void registerParameters(Application paramApplication, Application.Parameters paramParameters)
  {
    params.put(paramApplication, paramParameters);
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\application\ParametersImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */