package com.sun.javafx.beans.event;

import javafx.beans.InvalidationListener;
import javafx.beans.WeakInvalidationListener;

public abstract class AbstractNotifyListener
  implements InvalidationListener
{
  private final WeakInvalidationListener weakListener = new WeakInvalidationListener(this);
  
  public InvalidationListener getWeakListener()
  {
    return this.weakListener;
  }
}


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\jfxrt.jar!\com\sun\javafx\beans\event\AbstractNotifyListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */