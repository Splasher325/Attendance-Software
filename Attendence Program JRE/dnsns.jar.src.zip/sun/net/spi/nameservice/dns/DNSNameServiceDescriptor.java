/*    */ package sun.net.spi.nameservice.dns;
/*    */ 
/*    */ import sun.net.spi.nameservice.NameService;
/*    */ import sun.net.spi.nameservice.NameServiceDescriptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DNSNameServiceDescriptor
/*    */   implements NameServiceDescriptor
/*    */ {
/*    */   public NameService createNameService()
/*    */     throws Exception
/*    */   {
/* 35 */     return new DNSNameService();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getProviderName()
/*    */   {
/* 43 */     return "sun";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getType()
/*    */   {
/* 51 */     return "dns";
/*    */   }
/*    */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\dnsns.jar!\sun\net\spi\nameservice\dns\DNSNameServiceDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */