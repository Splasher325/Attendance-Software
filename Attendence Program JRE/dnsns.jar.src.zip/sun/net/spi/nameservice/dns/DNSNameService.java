/*     */ package sun.net.spi.nameservice.dns;
/*     */ 
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.NamingEnumeration;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.directory.Attribute;
/*     */ import javax.naming.directory.Attributes;
/*     */ import javax.naming.directory.DirContext;
/*     */ import javax.naming.spi.NamingManager;
/*     */ import sun.net.dns.ResolverConfiguration;
/*     */ import sun.net.spi.nameservice.NameService;
/*     */ import sun.net.util.IPAddressUtil;
/*     */ import sun.security.action.GetPropertyAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DNSNameService
/*     */   implements NameService
/*     */ {
/*  48 */   private LinkedList<String> domainList = null;
/*     */   
/*     */ 
/*  51 */   private String nameProviderUrl = null;
/*     */   
/*     */ 
/*  54 */   private static ThreadLocal<SoftReference<ThreadContext>> contextRef = new ThreadLocal();
/*     */   
/*     */   private static class ThreadContext
/*     */   {
/*     */     private DirContext dirCtxt;
/*     */     private List<String> nsList;
/*     */     
/*     */     public ThreadContext(DirContext paramDirContext, List<String> paramList)
/*     */     {
/*  63 */       this.dirCtxt = paramDirContext;
/*  64 */       this.nsList = paramList;
/*     */     }
/*     */     
/*     */     public DirContext dirContext() {
/*  68 */       return this.dirCtxt;
/*     */     }
/*     */     
/*     */     public List<String> nameservers() {
/*  72 */       return this.nsList;
/*     */     }
/*     */   }
/*     */   
/*     */   private DirContext getTemporaryContext() throws NamingException
/*     */   {
/*  78 */     SoftReference localSoftReference = (SoftReference)contextRef.get();
/*  79 */     ThreadContext localThreadContext = null;
/*  80 */     List localList = null;
/*     */     
/*     */ 
/*     */ 
/*  84 */     if (this.nameProviderUrl == null) {
/*  85 */       localList = ResolverConfiguration.open().nameservers();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  91 */     if ((localSoftReference != null) && ((localThreadContext = (ThreadContext)localSoftReference.get()) != null) && 
/*  92 */       (this.nameProviderUrl == null) && 
/*  93 */       (!localThreadContext.nameservers().equals(localList)))
/*     */     {
/*  95 */       localThreadContext = null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 101 */     if (localThreadContext == null) {
/* 102 */       final Hashtable localHashtable = new Hashtable();
/* 103 */       localHashtable.put("java.naming.factory.initial", "com.sun.jndi.dns.DnsContextFactory");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */       String str = this.nameProviderUrl;
/* 110 */       if (str == null) {
/* 111 */         str = createProviderURL(localList);
/* 112 */         if (str.length() == 0) {
/* 113 */           throw new RuntimeException("bad nameserver configuration");
/*     */         }
/*     */       }
/* 116 */       localHashtable.put("java.naming.provider.url", str);
/*     */       
/*     */ 
/*     */       DirContext localDirContext;
/*     */       
/*     */       try
/*     */       {
/* 123 */         localDirContext = (DirContext)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */ 
/*     */           public DirContext run()
/*     */             throws NamingException
/*     */           {
/* 129 */             Context localContext = NamingManager.getInitialContext(localHashtable);
/* 130 */             if (!(localContext instanceof DirContext)) {
/* 131 */               return null;
/*     */             }
/* 133 */             return (DirContext)localContext;
/*     */           }
/*     */         });
/*     */       } catch (PrivilegedActionException localPrivilegedActionException) {
/* 137 */         throw ((NamingException)localPrivilegedActionException.getException());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 142 */       localThreadContext = new ThreadContext(localDirContext, localList);
/* 143 */       contextRef.set(new SoftReference(localThreadContext));
/*     */     }
/*     */     
/* 146 */     return localThreadContext.dirContext();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList<String> resolve(final DirContext paramDirContext, final String paramString, final String[] paramArrayOfString, int paramInt)
/*     */     throws UnknownHostException
/*     */   {
/* 168 */     ArrayList localArrayList = new ArrayList();
/*     */     
/*     */     Attributes localAttributes;
/*     */     try
/*     */     {
/* 173 */       localAttributes = (Attributes)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */       {
/*     */         public Attributes run() throws NamingException {
/* 176 */           return paramDirContext.getAttributes(paramString, paramArrayOfString);
/*     */         }
/*     */       });
/*     */     } catch (PrivilegedActionException localPrivilegedActionException) {
/* 180 */       throw new UnknownHostException(localPrivilegedActionException.getException().getMessage());
/*     */     }
/*     */     
/*     */ 
/* 184 */     NamingEnumeration localNamingEnumeration1 = localAttributes.getAll();
/* 185 */     if (!localNamingEnumeration1.hasMoreElements()) {
/* 186 */       throw new UnknownHostException("DNS record not found");
/*     */     }
/*     */     
/*     */ 
/* 190 */     Object localObject = null;
/*     */     try { String str1;
/* 192 */       NamingEnumeration localNamingEnumeration2; while (localNamingEnumeration1.hasMoreElements()) {
/* 193 */         Attribute localAttribute = (Attribute)localNamingEnumeration1.next();
/* 194 */         str1 = localAttribute.getID();
/*     */         
/* 196 */         for (localNamingEnumeration2 = localAttribute.getAll(); localNamingEnumeration2.hasMoreElements();) {
/* 197 */           String str2 = (String)localNamingEnumeration2.next();
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 202 */           if (str1.equals("CNAME")) {
/* 203 */             if (paramInt > 4) {
/* 204 */               throw new UnknownHostException(paramString + ": possible CNAME loop");
/*     */             }
/*     */             try {
/* 207 */               localArrayList.addAll(resolve(paramDirContext, str2, paramArrayOfString, paramInt + 1));
/*     */             }
/*     */             catch (UnknownHostException localUnknownHostException) {
/* 210 */               if (localObject == null)
/* 211 */                 localObject = localUnknownHostException;
/*     */             }
/*     */           } else {
/* 214 */             localArrayList.add(str2);
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (NamingException localNamingException) {
/* 219 */       throw new UnknownHostException(localNamingException.getMessage());
/*     */     }
/*     */     
/*     */ 
/* 223 */     if ((localArrayList.isEmpty()) && (localObject != null)) {
/* 224 */       throw ((Throwable)localObject);
/*     */     }
/*     */     
/* 227 */     return localArrayList;
/*     */   }
/*     */   
/*     */   public DNSNameService()
/*     */     throws Exception
/*     */   {
/* 233 */     String str1 = (String)AccessController.doPrivileged(new GetPropertyAction("sun.net.spi.nameservice.domain"));
/*     */     
/* 235 */     if ((str1 != null) && (str1.length() > 0)) {
/* 236 */       this.domainList = new LinkedList();
/* 237 */       this.domainList.add(str1);
/*     */     }
/*     */     
/*     */ 
/* 241 */     String str2 = (String)AccessController.doPrivileged(new GetPropertyAction("sun.net.spi.nameservice.nameservers"));
/*     */     
/* 243 */     if ((str2 != null) && (str2.length() > 0)) {
/* 244 */       this.nameProviderUrl = createProviderURL(str2);
/* 245 */       if (this.nameProviderUrl.length() == 0) {
/* 246 */         throw new RuntimeException("malformed nameservers property");
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 254 */       List localList = ResolverConfiguration.open().nameservers();
/* 255 */       if (localList.isEmpty()) {
/* 256 */         throw new RuntimeException("no nameservers provided");
/*     */       }
/* 258 */       int i = 0;
/* 259 */       for (String str3 : localList) {
/* 260 */         if ((IPAddressUtil.isIPv4LiteralAddress(str3)) || 
/* 261 */           (IPAddressUtil.isIPv6LiteralAddress(str3))) {
/* 262 */           i = 1;
/* 263 */           break;
/*     */         }
/*     */       }
/* 266 */       if (i == 0) {
/* 267 */         throw new RuntimeException("bad nameserver configuration");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public InetAddress[] lookupAllHostAddr(String paramString)
/*     */     throws UnknownHostException
/*     */   {
/* 275 */     String[] arrayOfString = { "A", "AAAA", "CNAME" };
/*     */     
/*     */     DirContext localDirContext;
/*     */     try
/*     */     {
/* 280 */       localDirContext = getTemporaryContext();
/*     */     } catch (NamingException localNamingException) {
/* 282 */       throw new Error(localNamingException);
/*     */     }
/*     */     
/* 285 */     ArrayList localArrayList = null;
/* 286 */     Object localObject1 = null;
/*     */     
/*     */ 
/* 289 */     if (paramString.indexOf('.') >= 0) {
/*     */       try {
/* 291 */         localArrayList = resolve(localDirContext, paramString, arrayOfString, 0);
/*     */       } catch (UnknownHostException localUnknownHostException1) {
/* 293 */         localObject1 = localUnknownHostException1;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     String str;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 309 */     if (localArrayList == null) {
/* 310 */       localObject2 = null;
/*     */       
/* 312 */       j = 0;
/*     */       Iterator localIterator;
/* 314 */       if (this.domainList != null) {
/* 315 */         localIterator = this.domainList.iterator();
/*     */       } else {
/* 317 */         localObject2 = ResolverConfiguration.open().searchlist();
/* 318 */         if (((List)localObject2).size() > 1) {
/* 319 */           j = 1;
/*     */         }
/* 321 */         localIterator = ((List)localObject2).iterator();
/*     */       }
/*     */       
/*     */ 
/* 325 */       while (localIterator.hasNext()) {
/* 326 */         str = (String)localIterator.next();
/* 327 */         int m = 0;
/* 328 */         for (;;) { if (((m = str.indexOf(".")) != -1) && 
/* 329 */             (m < str.length() - 1))
/*     */             try {
/* 331 */               localArrayList = resolve(localDirContext, paramString + "." + str, arrayOfString, 0);
/*     */             }
/*     */             catch (UnknownHostException localUnknownHostException2) {
/* 334 */               localObject1 = localUnknownHostException2;
/* 335 */               if (j == 0)
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/* 340 */                 str = str.substring(m + 1); }
/*     */             }
/*     */         }
/* 343 */         if (localArrayList != null) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 350 */     if ((localArrayList == null) && (paramString.indexOf('.') < 0)) {
/* 351 */       localArrayList = resolve(localDirContext, paramString, arrayOfString, 0);
/*     */     }
/*     */     
/*     */ 
/* 355 */     if (localArrayList == null) {
/* 356 */       assert (localObject1 != null);
/* 357 */       throw ((Throwable)localObject1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 364 */     assert (localArrayList.size() > 0);
/* 365 */     Object localObject2 = new InetAddress[localArrayList.size()];
/* 366 */     int i = 0;
/* 367 */     for (int j = 0; j < localArrayList.size(); j++) {
/* 368 */       str = (String)localArrayList.get(j);
/* 369 */       byte[] arrayOfByte = IPAddressUtil.textToNumericFormatV4(str);
/* 370 */       if (arrayOfByte == null) {
/* 371 */         arrayOfByte = IPAddressUtil.textToNumericFormatV6(str);
/*     */       }
/* 373 */       if (arrayOfByte != null) {
/* 374 */         localObject2[(i++)] = InetAddress.getByAddress(paramString, arrayOfByte);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 383 */     if (i == 0) {
/* 384 */       throw new UnknownHostException(paramString + ": no valid DNS records");
/*     */     }
/* 386 */     if (i < localArrayList.size()) {
/* 387 */       InetAddress[] arrayOfInetAddress = new InetAddress[i];
/* 388 */       for (int k = 0; k < i; k++) {
/* 389 */         arrayOfInetAddress[k] = localObject2[k];
/*     */       }
/* 391 */       localObject2 = arrayOfInetAddress;
/*     */     }
/*     */     
/* 394 */     return (InetAddress[])localObject2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHostByAddr(byte[] paramArrayOfByte)
/*     */     throws UnknownHostException
/*     */   {
/* 404 */     String str1 = null;
/*     */     try {
/* 406 */       String str2 = "";
/* 407 */       String[] arrayOfString = { "PTR" };
/*     */       
/* 409 */       ArrayList localArrayList = null;
/*     */       DirContext localDirContext;
/* 411 */       try { localDirContext = getTemporaryContext();
/*     */       } catch (NamingException localNamingException) {
/* 413 */         throw new Error(localNamingException); }
/*     */       int i;
/* 415 */       if (paramArrayOfByte.length == 4) {
/* 416 */         for (i = paramArrayOfByte.length - 1; i >= 0; i--) {
/* 417 */           str2 = str2 + (paramArrayOfByte[i] & 0xFF) + ".";
/*     */         }
/* 419 */         str2 = str2 + "IN-ADDR.ARPA.";
/*     */         
/* 421 */         localArrayList = resolve(localDirContext, str2, arrayOfString, 0);
/* 422 */         str1 = (String)localArrayList.get(0);
/* 423 */       } else if (paramArrayOfByte.length == 16)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 431 */         for (i = paramArrayOfByte.length - 1; i >= 0; i--)
/*     */         {
/* 433 */           str2 = str2 + Integer.toHexString(paramArrayOfByte[i] & 0xF) + "." + Integer.toHexString((paramArrayOfByte[i] & 0xF0) >> 4) + ".";
/*     */         }
/* 435 */         String str3 = str2 + "IP6.ARPA.";
/*     */         try
/*     */         {
/* 438 */           localArrayList = resolve(localDirContext, str3, arrayOfString, 0);
/* 439 */           str1 = (String)localArrayList.get(0);
/*     */         } catch (UnknownHostException localUnknownHostException) {
/* 441 */           str1 = null;
/*     */         }
/* 443 */         if (str1 == null)
/*     */         {
/* 445 */           str3 = str2 + "IP6.INT.";
/* 446 */           localArrayList = resolve(localDirContext, str3, arrayOfString, 0);
/* 447 */           str1 = (String)localArrayList.get(0);
/*     */         }
/*     */       }
/*     */     } catch (Exception localException) {
/* 451 */       throw new UnknownHostException(localException.getMessage());
/*     */     }
/*     */     
/* 454 */     if (str1 == null) {
/* 455 */       throw new UnknownHostException();
/*     */     }
/* 457 */     if (str1.endsWith(".")) {
/* 458 */       str1 = str1.substring(0, str1.length() - 1);
/*     */     }
/* 460 */     return str1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static void appendIfLiteralAddress(String paramString, StringBuffer paramStringBuffer)
/*     */   {
/* 467 */     if (IPAddressUtil.isIPv4LiteralAddress(paramString)) {
/* 468 */       paramStringBuffer.append("dns://" + paramString + " ");
/*     */     }
/* 470 */     else if (IPAddressUtil.isIPv6LiteralAddress(paramString)) {
/* 471 */       paramStringBuffer.append("dns://[" + paramString + "] ");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String createProviderURL(List<String> paramList)
/*     */   {
/* 481 */     StringBuffer localStringBuffer = new StringBuffer();
/* 482 */     for (String str : paramList) {
/* 483 */       appendIfLiteralAddress(str, localStringBuffer);
/*     */     }
/* 485 */     return localStringBuffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String createProviderURL(String paramString)
/*     */   {
/* 494 */     StringBuffer localStringBuffer = new StringBuffer();
/* 495 */     StringTokenizer localStringTokenizer = new StringTokenizer(paramString, ",");
/* 496 */     while (localStringTokenizer.hasMoreTokens()) {
/* 497 */       appendIfLiteralAddress(localStringTokenizer.nextToken(), localStringBuffer);
/*     */     }
/* 499 */     return localStringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\jbrow\Desktop\Attendence Program Rebirth!\!\Attendence Program JRE\dnsns.jar!\sun\net\spi\nameservice\dns\DNSNameService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */